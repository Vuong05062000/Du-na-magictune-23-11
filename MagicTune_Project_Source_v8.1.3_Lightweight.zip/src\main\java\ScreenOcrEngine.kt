package com.example.core.ocr

import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Log
import com.example.core.service.NoAccessibilityScreenEngine.ScreenTextNode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.math.abs

/**
 * Động Cơ Nhận Diện Văn Bản Trên Màn Hình Bằng Google ML Kit OCR (Text Recognition).
 *
 * TỐI ƯU NHIỆT & PIN:
 * - Giới hạn tối đa 2 luồng xử lý OCR (`Executors.newFixedThreadPool(2)`) cho cả Coroutine và ML Kit Executor
 *   để không đẩy xung nhịp các nhân CPU hiệu năng cao lên tối đa.
 * - Cắt bỏ vùng thanh trạng thái trên & thanh điều hướng dưới khi Dịch Cuộn để giảm ~12-15% pixel OCR.
 * - So sánh nhanh chữ ký độ sáng khung hình (12x16 mẫu): nếu màn hình chưa đổi thì bỏ qua ML Kit (0% NPU/CPU).
 * - Giải phóng ngay `cropped.recycle()` sau khi OCR xong để tránh Garbage Collection (GC) liên tục.
 */
object ScreenOcrEngine {
    private const val TAG = "ScreenOcrEngine"

    private val ocrExecutor: ExecutorService = Executors.newFixedThreadPool(2) { runnable ->
        Thread(runnable, "MagicTune-OCR").apply {
            isDaemon = true
            priority = Thread.NORM_PRIORITY - 1
        }
    }
    private val ocrDispatcher = ocrExecutor.asCoroutineDispatcher()

    private val recognizerLock = Any()
    @Volatile
    private var cachedRecognizer: TextRecognizer? = null

    private val screenRecognition = Mutex()
    private data class ScrollFrame(
        val width: Int = 0,
        val top: Int = 0,
        val height: Int = 0,
        val sample: IntArray? = null,
        val nodes: List<ScreenTextNode> = emptyList()
    )
    private val scrollFrame = java.util.concurrent.atomic.AtomicReference(ScrollFrame())

    private fun getOrCreateRecognizer(): TextRecognizer {
        cachedRecognizer?.let { return it }
        synchronized(recognizerLock) {
            cachedRecognizer?.let { return it }
            val created = try {
                TextRecognition.getClient(
                    ChineseTextRecognizerOptions.Builder()
                        .setExecutor(ocrExecutor)
                        .build()
                )
            } catch (e: Throwable) {
                Log.w(TAG, "Fallback to Latin TextRecognizer: ${e.message}")
                TextRecognition.getClient(
                    TextRecognizerOptions.Builder()
                        .setExecutor(ocrExecutor)
                        .build()
                )
            }
            cachedRecognizer = created
            return created
        }
    }

    fun releaseIdleResources() {
        clearScrollOcrFrameCache()
        synchronized(recognizerLock) {
            try {
                cachedRecognizer?.close()
            } catch (_: Throwable) {}
            cachedRecognizer = null
        }
    }

    fun clearScrollOcrFrameCache() {
        scrollFrame.set(ScrollFrame())
    }

    private fun sampleBitmapLumaGrid(bmp: Bitmap, top: Int, height: Int): IntArray? {
        return try {
            if (bmp.isRecycled || bmp.width < 32 || bmp.height < 32) return null
            val cols = 12
            val rows = 16
            val out = IntArray(cols * rows)
            val w = bmp.width
            var idx = 0
            for (r in 1..rows) {
                val y = top + (height * r) / (rows + 1)
                for (c in 1..cols) {
                    val x = (w * c) / (cols + 1)
                    val px = bmp.getPixel(x.coerceIn(0, w - 1), y)
                    val red = (px ushr 16) and 0xFF
                    val green = (px ushr 8) and 0xFF
                    val blue = px and 0xFF
                    out[idx++] = (red * 30 + green * 59 + blue * 11) / 100
                }
            }
            out
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Nhận diện toàn bộ các dòng chữ và tọa độ khung hình trên Bitmap màn hình (giới hạn 2 threads OCR).
     */
    suspend fun recognizeScreenTextNodes(bitmap: Bitmap): List<ScreenTextNode> = withContext(ocrDispatcher) {
        if (bitmap.isRecycled) return@withContext emptyList()
        val inputImage = try {
            InputImage.fromBitmap(bitmap, 0)
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to create InputImage: ${e.message}")
            return@withContext emptyList()
        }

        screenRecognition.withLock {
            currentCoroutineContext().ensureActive()
            val result = try {
                val task = getOrCreateRecognizer().process(inputImage)
                // ML Kit still owns the bitmap until its task completes, even if the overlay closes.
                withContext(NonCancellable) { task.await() }
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                throw cancelled
            } catch (failure: Exception) {
                Log.w(TAG, "Text recognition failed", failure)
                return@withLock emptyList()
            }
            currentCoroutineContext().ensureActive()
            buildList {
                for (block in result.textBlocks) for (line in block.lines) {
                    val text = line.text.trim()
                    val box = line.boundingBox ?: continue
                    if (text.isNotEmpty() && box.width() > 4 && box.height() > 4) add(ScreenTextNode(text, box))
                }
            }
        }
    }

    /**
     * Phiên bản siêu mát dành riêng cho Dịch Cuộn:
     * - Giới hạn tối đa 2 luồng OCR (`ocrDispatcher`).
     * - Cắt bỏ thanh trạng thái (4.5% trên) & thanh điều hướng đáy (6.5% dưới) để giảm tải NPU/CPU.
     * - Kiểm tra nhanh mẫu 12x16 điểm ảnh: nếu màn hình chưa thay đổi đáng kể so với khung trước -> bỏ qua OCR 0ms!
     * - Giải phóng `cropped.recycle()` ngay sau khi nhận diện xong.
     */
    suspend fun recognizeScrollRegionTextNodes(
        bitmap: Bitmap,
        cropTopFraction: Float = 0.045f,
        cropBottomFraction: Float = 0.065f
    ): List<ScreenTextNode> = withContext(ocrDispatcher) {
        if (bitmap.isRecycled || bitmap.width < 48 || bitmap.height < 120) {
            return@withContext emptyList()
        }
        val topOffset = (bitmap.height * cropTopFraction).toInt().coerceIn(0, bitmap.height / 4)
        val bottomCut = (bitmap.height * cropBottomFraction).toInt().coerceIn(0, bitmap.height / 4)
        val cropHeight = (bitmap.height - topOffset - bottomCut).coerceAtLeast(32)

        // Compare the region in the source bitmap before allocating a cropped bitmap.
        val previous = scrollFrame.get()
        val sample = sampleBitmapLumaGrid(bitmap, topOffset, cropHeight)
        val old = previous.sample
        if (sample != null && old != null && bitmap.width == previous.width &&
            topOffset == previous.top && cropHeight == previous.height) {
            val delta = sample.indices.sumOf { abs(sample[it] - old[it]) }
            if (delta < 3.5f * sample.size) return@withContext previous.nodes
        }

        val cropped = try {
            Bitmap.createBitmap(bitmap, 0, topOffset, bitmap.width, cropHeight)
        } catch (_: RuntimeException) {
            return@withContext recognizeScreenTextNodes(bitmap)
        }

        try {
            val rawNodes = recognizeScreenTextNodes(cropped)
            val shiftedNodes = if (topOffset == 0) {
                rawNodes
            } else {
                rawNodes.map { node ->
                    val b = node.boundsInScreen
                    ScreenTextNode(
                        text = node.text,
                        boundsInScreen = Rect(b.left, b.top + topOffset, b.right, b.bottom + topOffset)
                    )
                }
            }
            val frame = if (shiftedNodes.isNotEmpty() && sample != null) {
                ScrollFrame(bitmap.width, topOffset, cropHeight, sample, shiftedNodes)
            } else ScrollFrame()
            scrollFrame.compareAndSet(previous, frame)
            return@withContext shiftedNodes
        } finally {
            if (cropped !== bitmap) {
                try { cropped.recycle() } catch (_: Throwable) {}
            }
        }
    }

    /**
     * Nhận diện văn bản trong một vùng cắt chữ nhật cụ thể trên màn hình
     */
    suspend fun recognizeTextInRegion(bitmap: Bitmap, region: Rect): List<ScreenTextNode> = withContext(ocrDispatcher) {
        if (bitmap.isRecycled) return@withContext emptyList()
        val safeLeft = region.left.coerceIn(0, bitmap.width - 1)
        val safeTop = region.top.coerceIn(0, bitmap.height - 1)
        val safeRight = region.right.coerceIn(safeLeft + 1, bitmap.width)
        val safeBottom = region.bottom.coerceIn(safeTop + 1, bitmap.height)
        val w = safeRight - safeLeft
        val h = safeBottom - safeTop

        if (w <= 8 || h <= 8) return@withContext emptyList()

        val cropped = try {
            Bitmap.createBitmap(bitmap, safeLeft, safeTop, w, h)
        } catch (_: Throwable) {
            return@withContext emptyList()
        }

        val relativeNodes = try {
            recognizeScreenTextNodes(cropped)
        } finally {
            if (cropped !== bitmap) {
                try { cropped.recycle() } catch (_: Throwable) {}
            }
        }

        // Tịnh tiến tọa độ tương đối về tọa độ màn hình thực tế
        return@withContext relativeNodes.map { node ->
            ScreenTextNode(
                text = node.text,
                boundsInScreen = Rect(
                    node.boundsInScreen.left + safeLeft,
                    node.boundsInScreen.top + safeTop,
                    node.boundsInScreen.right + safeLeft,
                    node.boundsInScreen.bottom + safeTop
                )
            )
        }
    }

    /**
     * Nhận diện nhanh 1 chữ cái viết tay (A-Z) từ Bitmap vẽ cử chỉ bằng Google ML Kit
     */
    suspend fun recognizeSingleCharFromBitmap(bitmap: Bitmap): Char? = withContext(ocrDispatcher) {
        if (bitmap.isRecycled) return@withContext null
        val inputImage = try {
            InputImage.fromBitmap(bitmap, 0)
        } catch (_: Throwable) { return@withContext null }

        val recognizer = getOrCreateRecognizer()
        return@withContext suspendCancellableCoroutine { continuation ->
            recognizer.process(inputImage)
                .addOnSuccessListener(ocrExecutor) { visionText ->
                    val clean = visionText.text.trim().uppercase()
                    val candidate = clean.firstOrNull { it in 'A'..'Z' }
                    if (continuation.isActive) {
                        continuation.resume(candidate)
                    }
                }
                .addOnFailureListener(ocrExecutor) {
                    if (continuation.isActive) {
                        continuation.resume(null)
                    }
                }
        }
    }
}
