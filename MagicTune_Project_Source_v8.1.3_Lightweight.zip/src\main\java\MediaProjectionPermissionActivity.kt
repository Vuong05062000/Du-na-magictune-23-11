package com.example.core.projection

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.example.core.service.MagicTuneMediaProjectionService

/**
 * Activity Nhỏ Gọn Trong Suốt Xin Quyền Chiếu Màn Hình MediaProjection.
 *
 * 1. Hoàn toàn không che khuất màn hình (theme trong suốt).
 * 2. Gọi API công khai chính thức `MediaProjectionManager.createScreenCaptureIntent()`.
 * 3. Chuyển token kết quả sang `MagicTuneMediaProjectionService` để kích hoạt engine chiếu màn hình.
 * 4. Tự động đóng ngay sau khi người dùng bấm xác nhận.
 * 5. Tích hợp cơ chế Debounce & Mutex chống loop, chống nháy giao diện khi gọi nhiều lần.
 */
class MediaProjectionPermissionActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (savedInstanceState != null) {
            // Đã được khôi phục từ trạng thái trước, tránh gửi intent đúp
            return
        }

        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
        if (mpManager == null) {
            isRequesting = false
            notifyResult(false)
            finish()
            return
        }

        try {
            val captureIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                try {
                    mpManager.createScreenCaptureIntent(
                        android.media.projection.MediaProjectionConfig.createConfigForDefaultDisplay()
                    )
                } catch (_: Throwable) {
                    mpManager.createScreenCaptureIntent()
                }
            } else {
                mpManager.createScreenCaptureIntent()
            }
            startActivityForResult(captureIntent, REQUEST_CODE_MEDIA_PROJECTION)
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to start MediaProjection intent: ${e.message}", e)
            isRequesting = false
            notifyResult(false)
            finish()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        isRequesting = false
        if (requestCode == REQUEST_CODE_MEDIA_PROJECTION) {
            if (resultCode == RESULT_OK && data != null) {
                Log.d(TAG, "MediaProjection permission granted by user")
                MagicTuneMediaProjectionService.start(applicationContext, resultCode, data)
                notifyResult(true)
            } else {
                Log.w(TAG, "MediaProjection permission denied or cancelled by user")
                notifyResult(false)
            }
        }
        finish()
    }

    override fun onDestroy() {
        isRequesting = false
        super.onDestroy()
    }

    companion object {
        private const val TAG = "MediaProjectionPermissionActivity"
        private const val REQUEST_CODE_MEDIA_PROJECTION = 9981

        @Volatile
        private var isRequesting: Boolean = false

        @Volatile
        private var lastRequestTimeMs: Long = 0L

        private var onPermissionResultCallback: ((Boolean) -> Unit)? = null

        fun requestPermission(context: Context, onResult: ((Boolean) -> Unit)? = null) {
            val now = System.currentTimeMillis()
            // Cơ chế Debounce: Không mở trùng lặp nếu đang có yêu cầu mở hoặc vừa gọi cách đây dưới 3.5s
            if (isRequesting || (now - lastRequestTimeMs < 3500L)) {
                Log.d(TAG, "MediaProjection request suppressed: already requesting or in cooldown")
                onResult?.invoke(MediaProjectionHolder.hasProjectionPermission())
                return
            }

            if (MediaProjectionHolder.hasProjectionPermission()) {
                Log.d(TAG, "MediaProjection already active, skipping request")
                onResult?.invoke(true)
                return
            }

            isRequesting = true
            lastRequestTimeMs = now
            onPermissionResultCallback = onResult

            val intent = Intent(context, MediaProjectionPermissionActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            try {
                context.startActivity(intent)
            } catch (e: Throwable) {
                Log.e(TAG, "Cannot launch MediaProjectionPermissionActivity: ${e.message}")
                isRequesting = false
                onResult?.invoke(false)
            }
        }

        private fun notifyResult(granted: Boolean) {
            val cb = onPermissionResultCallback
            onPermissionResultCallback = null
            cb?.invoke(granted)
        }
    }
}
