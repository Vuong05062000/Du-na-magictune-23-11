package com.example.ui.components

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.widget.MagicTuneCalendarWeatherWidgetProvider
import com.example.core.widget.VietnamAdministrativeDataset
import com.example.core.widget.VietnamClimateEngine
import com.example.core.widget.VietnameseLunarCalendar
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeatherDetailScreen(
    openPerpetualCalendarTrigger: Int = 0
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences(VietnamClimateEngine.PREFS_NAME, Context.MODE_PRIVATE) }

    var currentCity by remember {
        mutableStateOf(prefs.getString(VietnamClimateEngine.KEY_LOCATION, "Phường Kim Mã, Ba Đình, Hà Nội") ?: "Phường Kim Mã, Ba Đình, Hà Nội")
    }

    var showLocationSearchDialog by remember { mutableStateOf(false) }
    var showPerpetualCalendarDialog by remember { mutableStateOf(false) }
    var selectedDayIndexForDetail by remember { mutableStateOf<Int?>(null) }
    var isRefreshingWeather by remember { mutableStateOf(false) }

    // Đọc ngay dữ liệu thực tế đã lưu của đúng khu vực (nếu có), tránh hiển thị nhiệt độ ảo
    var weatherData by remember(currentCity) {
        mutableStateOf(VietnamClimateEngine.getCachedOrInitialWeather(context, currentCity))
    }

    val locationPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val hasLocationPermission =
                androidx.core.content.ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.ACCESS_FINE_LOCATION
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED ||
                    androidx.core.content.ContextCompat.checkSelfPermission(
                        context,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (!hasLocationPermission) {
                Toast.makeText(context, "⚠️ Quyền vị trí đã bị thu hồi.", Toast.LENGTH_SHORT).show()
            } else try {
                val lm = context.getSystemService(Context.LOCATION_SERVICE) as? android.location.LocationManager
                val loc = lm?.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER)
                    ?: lm?.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER)
                if (loc != null) {
                    coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                        val preciseLocation = VietnamAdministrativeDataset.resolvePreciseLocationFromCoordinates(
                            context = context,
                            latitude = loc.latitude,
                            longitude = loc.longitude
                        )
                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                            currentCity = preciseLocation
                            isRefreshingWeather = true
                            MagicTuneCalendarWeatherWidgetProvider.syncNewLocationWeatherNow(context, preciseLocation) { live ->
                                weatherData = live
                                isRefreshingWeather = false
                            }
                            Toast.makeText(context, "🛰️ Đã định vị chính xác vị trí của bạn: $preciseLocation", Toast.LENGTH_SHORT).show()
                            showLocationSearchDialog = false
                        }
                    }
                } else {
                    Toast.makeText(context, "⚠️ Không lấy được tọa độ GPS hiện tại. Hãy kiểm tra GPS thiết bị.", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "⚠️ Lỗi định vị GPS: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "⚠️ Quyền vị trí bị từ chối.", Toast.LENGTH_SHORT).show()
        }
    }

    // Tự động tải thời tiết thực tế mới nhất ngay khi đổi khu vực hoặc khi dữ liệu đã cũ (> 5 phút)
    // đồng thời đẩy trực tiếp nhiệt độ thực tế vừa tải lên Widget ngoài màn hình chính
    LaunchedEffect(currentCity) {
        val cached = VietnamClimateEngine.getCachedOrInitialWeather(context, currentCity)
        weatherData = cached
        if (!cached.isLiveData || VietnamClimateEngine.isWeatherCacheStale(context, currentCity, maxAgeMs = 5 * 60_000L)) {
            isRefreshingWeather = true
            try {
                val live = VietnamClimateEngine.fetchLiveWeatherAsync(context, currentCity)
                weatherData = live
                MagicTuneCalendarWeatherWidgetProvider.notifyWidgetUpdate(context, triggerNetworkSync = false)
            } catch (_: Throwable) {}
            isRefreshingWeather = false
        } else {
            MagicTuneCalendarWeatherWidgetProvider.notifyWidgetUpdate(context, triggerNetworkSync = false)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MagicDarkBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Ô #09: Tiêu đề & Nút đổi địa điểm
        item(key = "weather_header", contentType = "weather_header") {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        color = MagicCyan.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(5.dp),
                        border = BorderStroke(0.8.dp, MagicCyan.copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = "Ô #09",
                            color = MagicCyanLight,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Text(
                        text = "THỜI TIẾT 63 TỈNH THÀNH & GPS",
                        color = MagicCyan,
                        fontSize = 12.2.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            showLocationSearchDialog = true
                        },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                    border = BorderStroke(1.dp, MagicCyan)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "Khu vực đang theo dõi:", color = TextMuted, fontSize = 10.5.sp)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(text = "📍 $currentCity", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = {
                                showLocationSearchDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                        ) {
                            Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Đổi vị trí", color = Color.Black, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Thẻ Quyển Lịch Vạn Niên Tháng & Đưa Widget Lịch Vạn Niên ra Màn hình chính
        item(key = "perpetual_calendar_card", contentType = "perpetual_calendar_card") {
            val todayLunarText = remember {
                VietnameseLunarCalendar.formatCompactLunar(java.util.Date())
            }
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.65f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                color = MagicAmber.copy(alpha = 0.22f),
                                shape = RoundedCornerShape(5.dp),
                                border = BorderStroke(0.8.dp, MagicAmber.copy(alpha = 0.6f))
                            ) {
                                Text(
                                    text = "Ô #10",
                                    color = MagicAmberLight,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = "LỊCH VẠN NIÊN (DƯƠNG & ÂM)",
                                color = MagicAmberLight,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Text(
                            text = "🌙 Hôm nay: $todayLunarText",
                            color = Color.White,
                            fontSize = 12.2.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showPerpetualCalendarDialog = true },
                            modifier = Modifier
                                .weight(1.1f)
                                .heightIn(min = 48.dp)
                                .testTag("open_perpetual_calendar_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MagicAmber,
                                contentColor = Color(0xFF020617)
                            )
                        ) {
                            Text("📖 Mở Lịch Vạn Niên", fontSize = 11.5.sp, fontWeight = FontWeight.Black)
                        }
                        OutlinedButton(
                            onClick = { requestPinPerpetualCalendarWidget(context) },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("pin_perpetual_calendar_button"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.7f))
                        ) {
                            Text("📌 Ghim Widget (Free)", color = MagicCyanLight, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Thẻ Tuỳ chỉnh Ẩn/Hiện & Phóng To/Thu Nhỏ Widget Đồng Hồ & Thời Tiết (Miễn phí vĩnh viễn cho mọi máy)
        item(key = "weather_widget_customizer", contentType = "weather_widget_customizer") {
            WeatherWidgetCustomizerCard(initiallyExpanded = false)
        }

        // Hero Card: Thời tiết hiện tại của khu vực được chọn
        item(key = "weather_hero", contentType = "weather_hero") {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                border = BorderStroke(1.dp, MagicBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                color = MagicEmerald.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(5.dp),
                                border = BorderStroke(0.8.dp, MagicEmerald.copy(alpha = 0.6f))
                            ) {
                                Text(
                                    text = "Ô #12",
                                    color = MagicEmeraldLight,
                                    fontSize = 9.2.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                )
                            }
                            Text(
                                text = "📍 $currentCity",
                                color = MagicEmerald,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        IconButton(
                            onClick = {
                                coroutineScope.launch {
                                    isRefreshingWeather = true
                                    try {
                                        val live = VietnamClimateEngine.fetchLiveWeatherAsync(context, currentCity)
                                        weatherData = live
                                        MagicTuneCalendarWeatherWidgetProvider.notifyWidgetUpdate(context, triggerNetworkSync = false)
                                        val msg = if (live.isLiveData) {
                                            "🌤️ Đã cập nhật thời tiết thực tế mới nhất!"
                                        } else {
                                            "⚠️ Không có mạng, đang dùng dữ liệu dự phòng"
                                        }
                                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                    } catch (e: Throwable) {
                                        Toast.makeText(context, "⚠️ Lỗi cập nhật thời tiết: ${e.localizedMessage ?: "Kiểm tra lại mạng"}", Toast.LENGTH_SHORT).show()
                                    } finally {
                                        isRefreshingWeather = false
                                    }
                                }
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Làm mới thời tiết",
                                tint = MagicCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(text = weatherData.icon, fontSize = 42.sp)
                        Spacer(modifier = Modifier.width(14.dp))
                        Text(
                            text = "${weatherData.currentTemp}°C",
                            color = Color.White,
                            fontSize = 44.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = weatherData.condition,
                        color = TextSecondary,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    val syncBadgeText = remember(weatherData.isLiveData, weatherData.sourceLabel, weatherData.updatedAtMillis) {
                        if (weatherData.isLiveData && weatherData.updatedAtMillis > 0L) {
                            val hhmm = java.text.SimpleDateFormat("HH:mm", java.util.Locale("vi", "VN"))
                                .format(java.util.Date(weatherData.updatedAtMillis))
                            "🟢 ${weatherData.sourceLabel} • Cập nhật lúc $hhmm"
                        } else {
                            "🟡 ${weatherData.sourceLabel}"
                        }
                    }
                    Text(
                        text = syncBadgeText,
                        color = if (weatherData.isLiveData) MagicEmerald else TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )

                    if (isRefreshingWeather) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(12.dp),
                                color = MagicCyan,
                                strokeWidth = 1.5.dp
                            )
                            Text(
                                text = "Đang lấy nhiệt độ thực tế miễn phí (Open-Meteo / MET Norway)...",
                                color = MagicCyan,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        WeatherStatItem("Độ ẩm", "${weatherData.humidity}%")
                        WeatherStatItem("Gió", "${weatherData.windSpeed} km/h")
                        WeatherStatItem("Chỉ số UV", weatherData.uvIndex)
                        WeatherStatItem("Không khí", weatherData.airQuality)
                    }
                }
            }
        }

        // Dự báo thời tiết theo giờ (24 giờ tới - LazyRow tái sử dụng ô để cuộn mượt 120Hz)
        item(key = "weather_hourly", contentType = "weather_hourly") {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "⏰ Dự báo thời tiết theo giờ (24 giờ tới tại ${weatherData.fullLocation.substringAfterLast(",")})",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(
                        items = weatherData.hourlyForecast,
                        key = { _, item -> item.hourLabel },
                        contentType = { _, _ -> "hourly_slot" }
                    ) { _, item ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                            modifier = Modifier.width(72.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(text = item.hourLabel, color = TextMuted, fontSize = 10.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = item.icon, fontSize = 18.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = item.temp, color = MagicCyan, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Tiêu đề 7 ngày tới
        item(key = "weather_daily_header", contentType = "section_header") {
            Text(
                text = "📅 Dự báo 7 ngày tới (Chạm để xem chi tiết)",
                color = TextPrimary,
                fontSize = 12.8.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Danh sách 7 ngày tới
        itemsIndexed(
            items = weatherData.dailyForecast,
            key = { _, itemData -> itemData.dateStr },
            contentType = { _, _ -> "daily_slot" }
        ) { index, itemData ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedDayIndexForDetail = index },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                border = BorderStroke(1.dp, if (selectedDayIndexForDetail == index) MagicCyan else MagicBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(text = itemData.icon, fontSize = 24.sp)
                        Column {
                            Text(
                                text = "${index + 1}. ${itemData.dayName} (${itemData.dateStr})",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = itemData.condition,
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "${itemData.minTemp}° ~ ${itemData.maxTemp}°C",
                            color = MagicCyan,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(imageVector = Icons.Default.KeyboardArrowRight, contentDescription = null, tint = TextMuted)
                    }
                }
            }
        }
    }

    // Hộp thoại tìm kiếm và đổi khu vực (Toàn diện 63 tỉnh thành, 700+ huyện/thị, xã vùng sâu vùng xa, biên giới & biển đảo)
    if (showLocationSearchDialog) {
        LocationSearchDialog(
            context = context,
            onDismiss = { showLocationSearchDialog = false },
            onLocationSelected = { loc ->
                currentCity = loc
                isRefreshingWeather = true
                MagicTuneCalendarWeatherWidgetProvider.syncNewLocationWeatherNow(context, loc) { live ->
                    weatherData = live
                    isRefreshingWeather = false
                }
                Toast.makeText(context, "🌤️ Đã đổi sang: $loc", Toast.LENGTH_SHORT).show()
                showLocationSearchDialog = false
            },
            onUseGps = {
                locationPermissionLauncher.launch(android.Manifest.permission.ACCESS_FINE_LOCATION)
            }
        )
    }

    // Hộp thoại chi tiết từng ngày trong 7 ngày
    selectedDayIndexForDetail?.let { idx ->
        val data = weatherData.dailyForecast.getOrNull(idx)
        if (data != null) {
            AlertDialog(
                onDismissRequest = { selectedDayIndexForDetail = null },
                containerColor = MagicSurfaceDark,
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(text = data.icon, fontSize = 24.sp)
                        Text(text = "Chi tiết: ${data.dayName} (${data.dateStr})", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(text = "📍 Địa phương: $currentCity", color = MagicEmerald, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(text = "🌤️ Tình trạng: ${data.condition}", color = TextPrimary, fontSize = 13.sp)
                        Text(text = "🌡️ Nhiệt độ thấp nhất - cao nhất: ${data.minTemp}°C ~ ${data.maxTemp}°C", color = MagicCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(text = "💧 Độ ẩm không khí: ${data.humidity}%", color = TextSecondary, fontSize = 12.sp)
                        Text(text = "💨 Tốc độ gió: ${data.windSpeed} km/h", color = TextSecondary, fontSize = 12.sp)
                        Text(text = "☀️ Chỉ số bức xạ UV: ${data.uvIndex}", color = TextSecondary, fontSize = 12.sp)
                        Text(text = "🍃 Chất lượng không khí (AQI): ${data.airQuality}", color = MagicEmerald, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Divider(color = MagicBorder)
                        Text(text = "💡 Nguồn khí tượng miễn phí: ${weatherData.sourceLabel}", color = TextMuted, fontSize = 11.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { selectedDayIndexForDetail = null }) {
                        Text("Đóng", color = MagicCyan, fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    }

    if (showPerpetualCalendarDialog) {
        PerpetualCalendarDialog(
            onDismiss = { showPerpetualCalendarDialog = false }
        )
    }
}

@Composable
private fun WeatherStatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, color = TextMuted, fontSize = 10.sp)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LocationSearchDialog(
    context: Context,
    onDismiss: () -> Unit,
    onLocationSelected: (String) -> Unit,
    onUseGps: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf("ALL") }
    var searchResults by remember {
        mutableStateOf(VietnamAdministrativeDataset.searchOffline("", "ALL"))
    }
    var isSearchingOnline by remember { mutableStateOf(false) }

    val filterCategories = remember {
        listOf(
            "ALL" to "🌐 Toàn Quốc",
            "REMOTE_HIGHLAND" to "🏔️ Vùng Cao & Biên Giới",
            "ISLANDS" to "🏝️ Biển Đảo VN"
        ) + VietnamAdministrativeDataset.allProvinces.map { it to "📍 $it" }
    }

    LaunchedEffect(searchQuery, selectedCategoryFilter) {
        val q = searchQuery.trim()
        val offline = VietnamAdministrativeDataset.searchOffline(q, selectedCategoryFilter)
        searchResults = offline

        if (q.length >= 2 && offline.size < 5) {
            isSearchingOnline = true
            delay(400)
            try {
                val online = VietnamAdministrativeDataset.searchOnlineGeocoder(context, q)
                if (online.isNotEmpty()) {
                    searchResults = (offline + online).distinct().take(40)
                }
            } catch (_: Throwable) {
            } finally {
                isSearchingOnline = false
            }
        } else {
            isSearchingOnline = false
        }
    }

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .padding(horizontal = 6.dp, vertical = 16.dp),
            shape = RoundedCornerShape(16.dp),
            color = MagicSurfaceDark,
            border = BorderStroke(1.dp, MagicCyan)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🔍 Chọn Xã, Phường, Huyện, Đảo, 63 Tỉnh/Thành",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Đóng", tint = MagicCyan)
                        }
                    }

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = {
                            Text(
                                "Gõ Thôn, Bản, Xã, Huyện, Đảo (VD: Lũng Cú, Trường Sa...)",
                                color = TextMuted,
                                fontSize = 11.5.sp
                            )
                        },
                        singleLine = true,
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(imageVector = Icons.Default.Clear, contentDescription = "Xóa", tint = TextMuted)
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("weather_location_search_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MagicCyan,
                            unfocusedBorderColor = MagicBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    // Thanh chọn nhanh Phân vùng: Toàn Quốc / Vùng Cao Biên Giới / Biển Đảo / 63 Tỉnh Thành
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(filterCategories, key = { it.first }) { (catKey, catLabel) ->
                            val isSelected = selectedCategoryFilter == catKey
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) MagicCyan.copy(alpha = 0.22f) else MagicSurfaceCard,
                                border = BorderStroke(1.dp, if (isSelected) MagicCyan else MagicBorder),
                                modifier = Modifier.clickable {
                                    selectedCategoryFilter = catKey
                                }
                            ) {
                                Text(
                                    text = catLabel,
                                    color = if (isSelected) MagicCyan else TextSecondary,
                                    fontSize = 10.5.sp,
                                    fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    if (isSearchingOnline) {
                        LinearProgressIndicator(
                            modifier = Modifier.fillMaxWidth().height(2.dp),
                            color = MagicCyan,
                            trackColor = Color.Transparent
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        item(key = "auto_gps_location_card") {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onUseGps()
                                        onDismiss()
                                    },
                                colors = CardDefaults.cardColors(containerColor = MagicEmerald.copy(alpha = 0.16f)),
                                border = BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.6f))
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "🛰️ Tự động chọn khu vực của tôi (GPS)",
                                            color = MagicEmeraldLight,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Sử dụng quyền vị trí để định vị chính xác vị trí của bạn",
                                            color = TextSecondary,
                                            fontSize = 10.sp
                                        )
                                    }
                                    Icon(imageVector = Icons.Default.Place, contentDescription = null, tint = MagicEmeraldLight, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        val trimmedQuery = searchQuery.trim()
                        if (trimmedQuery.length >= 2 && searchResults.none { it.equals(trimmedQuery, ignoreCase = true) }) {
                            item(key = "custom_direct_location") {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            onLocationSelected(trimmedQuery)
                                        },
                                    colors = CardDefaults.cardColors(containerColor = MagicCyan.copy(alpha = 0.14f)),
                                    border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "🛰️ Định vị trực tiếp: \"$trimmedQuery\"",
                                                color = MagicCyan,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "Tự động tra tọa độ GPS thực tế xã/thôn/bản này",
                                                color = TextSecondary,
                                                fontSize = 10.sp
                                            )
                                        }
                                        Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }

                        if (searchResults.isEmpty()) {
                            item(key = "empty_location_search_result") {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = "🛰️ Bấm vào khung 'Định vị trực tiếp' phía trên để lấy thời tiết tọa độ GPS cho địa danh này.",
                                        color = TextSecondary,
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Hỗ trợ đầy đủ vùng cao, biên giới và biển đảo (Lũng Cú, Mèo Vạc, A Pa Chải, Trường Sa, Hoàng Sa, Côn Đảo, Phú Quốc...)",
                                        color = TextMuted,
                                        fontSize = 11.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        } else {
                            itemsIndexed(
                                items = searchResults,
                                key = { index, loc -> "${index}_${loc}" },
                                contentType = { _, _ -> "city_item" }
                            ) { _, loc ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            onLocationSelected(loc)
                                        },
                                    colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = "📍 $loc", color = TextPrimary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                                        Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Đóng", color = MagicCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
