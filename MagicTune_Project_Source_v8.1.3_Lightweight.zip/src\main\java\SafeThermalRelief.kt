package com.example.core.perf

import android.content.Context
import android.os.PowerManager
import com.example.core.shell.ShellEngine

/**
 * User-triggered, reversible power reduction through the standard Android shell API.
 * This does not override device thermal policy or claim to control physical cooling hardware.
 */
object SafeThermalRelief {
    private const val PREFS_NAME = "magictune_safe_thermal_relief"
    private const val KEY_MANAGED = "managed_by_magictune"
    private const val KEY_PREVIOUS_POWER_SAVE = "previous_power_save_mode"

    data class Result(
        val success: Boolean,
        val enabled: Boolean,
        val message: String
    )

    fun isEnabled(context: Context): Boolean {
        val appContext = context.applicationContext ?: context
        val managed = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_MANAGED, false)
        val powerManager = appContext.getSystemService(Context.POWER_SERVICE) as? PowerManager
        return managed && powerManager?.isPowerSaveMode == true
    }

    suspend fun enable(context: Context): Result {
        val appContext = context.applicationContext ?: context
        val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (isEnabled(appContext)) {
            return Result(true, true, "Chế độ Tiết kiệm pin đã bật.")
        }

        val shell = ShellEngine.getInstance(appContext)
        if (!shell.state.value.isAdbReady) {
            return Result(false, false, "Hãy kết nối ADB/Shizuku rồi thử lại.")
        }

        val powerManager = appContext.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val alreadyManaged = prefs.getBoolean(KEY_MANAGED, false)
        val previousMode = if (alreadyManaged) {
            prefs.getBoolean(KEY_PREVIOUS_POWER_SAVE, false)
        } else {
            powerManager?.isPowerSaveMode ?: false
        }
        val result = try {
            shell.execute("cmd power set-mode 1", isBackground = false)
        } catch (t: Throwable) {
            return Result(false, false, "Không bật được Tiết kiệm pin qua ADB: ${t.localizedMessage ?: "lỗi hệ thống"}")
        }
        if (!result.isSuccess) {
            return Result(false, false, result.error.ifBlank { result.output.ifBlank { "ADB từ chối lệnh bật Tiết kiệm pin." } })
        }

        prefs.edit()
            .putBoolean(KEY_PREVIOUS_POWER_SAVE, previousMode)
            .putBoolean(KEY_MANAGED, true)
            .apply()
        return Result(true, true, "Đã bật Tiết kiệm pin Android qua ADB để giảm tải CPU/nền. Nhiệt độ sẽ hạ dần theo tải và môi trường.")
    }

    suspend fun restore(context: Context): Result {
        val appContext = context.applicationContext ?: context
        val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_MANAGED, false)) {
            return Result(true, false, "MagicTune chưa thay đổi chế độ Tiết kiệm pin.")
        }

        val shell = ShellEngine.getInstance(appContext)
        if (!shell.state.value.isAdbReady) {
            return Result(false, isEnabled(appContext), "Hãy kết nối ADB/Shizuku để khôi phục trạng thái Tiết kiệm pin trước đó.")
        }

        val previousMode = prefs.getBoolean(KEY_PREVIOUS_POWER_SAVE, false)
        val result = try {
            shell.execute("cmd power set-mode ${if (previousMode) 1 else 0}", isBackground = false)
        } catch (t: Throwable) {
            return Result(false, isEnabled(appContext), "Không khôi phục được chế độ pin: ${t.localizedMessage ?: "lỗi hệ thống"}")
        }
        if (!result.isSuccess) {
            return Result(false, isEnabled(appContext), result.error.ifBlank { result.output.ifBlank { "ADB từ chối lệnh khôi phục." } })
        }

        prefs.edit().putBoolean(KEY_MANAGED, false).apply()
        return Result(true, false, "Đã khôi phục chế độ Tiết kiệm pin về trạng thái trước khi bấm.")
    }

    suspend fun toggle(context: Context): Result {
        val appContext = context.applicationContext ?: context
        val managed = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_MANAGED, false)
        return if (managed && isEnabled(appContext)) restore(appContext) else enable(appContext)
    }
}
