package com.example.core.service

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast
import com.example.MainActivity
import com.example.core.shell.ShellEngine
import com.example.core.shell.ShellMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class MagicTuneTileService : TileService() {

    private val tileScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    companion object {
        private const val MIN_TILE_SYNC_INTERVAL_MS = 5_000L
        @Volatile
        private var lastTileSyncElapsedMs = 0L

        fun requestTileSync(context: Context, force: Boolean = false) {
            val now = android.os.SystemClock.elapsedRealtime()
            if (!force && (now - lastTileSyncElapsedMs < MIN_TILE_SYNC_INTERVAL_MS)) {
                return
            }
            lastTileSyncElapsedMs = now
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    requestListeningState(
                        context.applicationContext,
                        ComponentName(context.applicationContext, MagicTuneTileService::class.java)
                    )
                }
            } catch (_: Throwable) {}
        }
    }

    override fun onStartListening() {
        super.onStartListening()
        refreshTileVisual()
    }

    private fun refreshTileVisual() {
        try {
            val engine = ShellEngine.getInstance(applicationContext)
            val st = engine.state.value
            val isReady = st.isAdbReady
            qsTile?.apply {
                label = "MagicTune ADB"
                state = if (isReady) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    subtitle = when {
                        st.isWirelessAdbConnected && st.isShizukuRunning && st.isShizukuPermissionGranted ->
                            "Kép :${st.wirelessAdbPort}"
                        st.isWirelessAdbConnected ->
                            "WLAN :${st.wirelessAdbPort}"
                        st.mode == ShellMode.SHIZUKU && st.isShizukuRunning && st.isShizukuPermissionGranted ->
                            "Shizuku UID 2000"
                        engine.hasPairedBefore() ->
                            "Chạm nối nhanh"
                        else ->
                            "Chạm ghép 6 số"
                    }
                }
                updateTile()
            }
        } catch (_: Throwable) {}
    }

    override fun onClick() {
        super.onClick()
        val engine = try {
            ShellEngine.getInstance(applicationContext)
        } catch (_: Throwable) {
            null
        }
        val st = engine?.state?.value
        val (adbWifiOn, _) = engine?.checkAdbWifiSystemSetting() ?: (false to false)

        // Nếu đã ghép đôi trước đó và Gỡ lỗi Wi-Fi đang bật nhưng chưa kết nối -> nối thẳng ngầm siêu nhanh!
        if (engine != null && st != null && !st.isAdbReady && engine.hasPairedBefore() && adbWifiOn) {
            try {
                qsTile?.apply {
                    state = Tile.STATE_ACTIVE
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        subtitle = "Đang tự nối..."
                    }
                    updateTile()
                }
            } catch (_: Throwable) {}

            tileScope.launch {
                val (ok, connectedPort) = engine.autoConnectBestWirelessAdb()
                refreshTileVisual()
                launch(Dispatchers.Main) {
                    val msg = if (ok) {
                        "⚡ Đã tự động kết nối Direct WLAN ADB (Cổng $connectedPort)!"
                    } else {
                        "Chưa thấy cổng ADB mở — mở MagicTune để kiểm tra!"
                    }
                    Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
                }
                if (!ok) {
                    launch(Dispatchers.Main) {
                        openWlanCenter()
                    }
                }
            }
            return
        }

        openWlanCenter()
    }

    private fun openWlanCenter() {
        try {
            val intent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("TARGET_TAB", "SHIZUKU")
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val pendingIntent = PendingIntent.getActivity(
                    this,
                    4801,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                startActivityAndCollapse(pendingIntent)
            } else {
                launchActivityAndCollapseLegacy(intent)
            }
        } catch (_: Throwable) {}
    }

    @Suppress("DEPRECATION")
    @SuppressLint("StartActivityAndCollapseDeprecated")
    private fun launchActivityAndCollapseLegacy(intent: Intent) {
        startActivityAndCollapse(intent)
    }
}
