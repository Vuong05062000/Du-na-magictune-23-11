package com.example.core.widget

import com.example.core.perf.ScreenPowerOptimizer
import com.example.MainActivity



import android.Manifest



import android.annotation.SuppressLint



import android.content.Context



import android.content.Intent



import android.content.pm.PackageManager



import android.graphics.BitmapFactory
import android.graphics.Canvas



import android.graphics.Color



import android.graphics.LinearGradient



import android.graphics.Paint
import android.graphics.Path
import android.widget.HorizontalScrollView



import android.graphics.PixelFormat



import android.graphics.RectF



import android.graphics.Shader



import android.graphics.Typeface



import android.graphics.drawable.GradientDrawable






import android.media.AudioFormat



import android.media.AudioManager



import android.media.AudioRecord






import android.media.MediaRecorder



import android.media.audiofx.AcousticEchoCanceler



import android.media.audiofx.AutomaticGainControl



import android.media.audiofx.NoiseSuppressor



import android.net.Uri



import android.os.Build



import android.os.Handler



import android.os.Looper



import android.os.VibrationEffect



import android.os.Vibrator



import android.os.VibratorManager



import android.provider.Settings






import android.text.TextUtils



import android.util.TypedValue



import android.view.Gravity



import android.view.MotionEvent



import android.view.View



import android.view.WindowManager



import android.widget.FrameLayout



import android.widget.ImageView
import android.widget.LinearLayout



import android.widget.ScrollView



import android.widget.TextView
import android.widget.EditText
import android.view.inputmethod.InputMethodManager
import android.view.inputmethod.EditorInfo



import android.widget.Toast



import android.graphics.Bitmap



import android.util.Base64



import androidx.core.content.ContextCompat



import com.example.core.license.LicenseManager



import com.example.core.service.NoAccessibilityScreenEngine



import com.example.core.service.SystemFloatingHudOverlay



import com.example.core.shell.ShellEngine



import kotlinx.coroutines.CoroutineScope



import kotlinx.coroutines.Dispatchers



import kotlinx.coroutines.Job



import kotlinx.coroutines.SupervisorJob



import kotlinx.coroutines.async
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL






import java.nio.ByteBuffer



import java.nio.ByteOrder



import java.text.SimpleDateFormat

import java.util.Date

import java.util.Locale

import java.util.UUID



import kotlin.math.abs



import kotlin.math.cos



import kotlin.math.max



import kotlin.math.min



import kotlin.math.sin



import kotlin.math.sqrt







/**



 * HỘP THOẠI TRÒ CHUYỆN GIỌNG NÓI GEMINI NỔI TRỰC TIẾP TRÊN MÀN HÌNH (Forced Floating Magic Live Voice Overlay)



 * thiết kế chuyên biệt cho Honor MagicOS 11 / Android 15 - 17.



 *



 * Giải quyết triệt để hạn chế trên ROM Honor MagicOS nội địa:



 * 1. Hiển thị NỔI TRỰC TIẾP ngay trên màn hình hiện tại (`TYPE_APPLICATION_OVERLAY`) ở bất kỳ ứng dụng nào



 *    (Facebook, Zalo, TikTok, Taobao, Màn hình chính...) mà KHÔNG chuyển hướng người dùng vào bên trong full app MagicLive.



 * 2. Thu âm giọng nói trực tiếp kèm tự động ngắt câu thông minh (VAD - Voice Activity Detection) + Nhận diện Tiếng Việt



 *    đa tầng (Cloud Whisper Turbo + Dự phòng đa nguồn), hoạt động 100% ngay cả khi máy Honor nội địa bị khóa Google Speech Services.



 * 3. Phản hồi thông minh bằng giọng nói Tiếng Việt tự nhiên (Neural Vietnamese Voice Stream + TTS) phát trực tiếp ngay ngoài màn hình,



 *    tự động nghe tiếp câu sau (Hội thoại rảnh tay liên tục - Trợ lý Magic Mode).



 * 4. Tự động giải phóng và trả lại 100% quyền Micro (`< 5ms`) ngay khi người dùng mở ứng dụng Magic Live chính thức



 *    hoặc khi biểu tượng trò chuyện của app Magic Live xuất hiện.



 */



// Kotlin formatting in this legacy overlay intentionally keeps fluent-call closers
// and callback bodies aligned with their owning expressions; Lint misidentifies
// those valid blocks as suspicious indentation throughout this single large object.
@SuppressLint("SuspiciousIndentation")
object MagicLiveFloatingOverlay {
    // Bộ đệm phản hồi AI ngắn hạn (TTL 5s) chống gửi 2 lần khi bấm liên tiếp hoặc nhận diện giọng nói trùng
    private val aiResponseShortCache = java.util.concurrent.ConcurrentHashMap<String, Pair<Long, String>>()
    private const val AI_RESPONSE_CACHE_TTL_MS = 5_000L









    private val mainHandler = Handler(Looper.getMainLooper())



    private val overlayScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)







    @Volatile
    var isShowing: Boolean = false
        private set

    @Volatile
    private var customKeyboardContainer: LinearLayout? = null
    @Volatile
    private var isSymbolModeActive: Boolean = false
    private val clipboardHistory = mutableListOf<String>()







    @Volatile
    var isRecordingMic: Boolean = false
        private set

    @Volatile
    var isSpeakingResponse: Boolean = false
        private set

    fun isVoiceOrSpeechActive(): Boolean {
        return isShowing && (isRecordingMic || isSpeakingResponse || micKeepAliveDrainJob?.isActive == true)
    }

    /** Stop mic, speech, network work, and animated UI when the device locks. */
    fun onDeviceScreenOff(context: Context) {
        waveVisualizerView?.setMode(listening = false, speaking = false)
        if (isVoiceOrSpeechActive() || activeVoiceJob?.isActive == true) {
            cancelCurrentVoiceOrAiTurn(
                context = context.applicationContext ?: context,
                customStatus = "⏸️ Đã tạm dừng khi màn hình tắt",
                customTranscript = "💬 Mở khóa để tiếp tục sử dụng Gemini"
            )
        }
    }







    private var rootContainer: FrameLayout? = null



    private var statusTitleView: TextView? = null



    private var transcriptTextView: TextView? = null



    private var replyTextView: TextView? = null
    private var chatMessagesContainer: LinearLayout? = null
    private var enlargedImageOverlay: FrameLayout? = null
    private var enlargedImagePreviewView: ImageView? = null
    private var enlargedImageTitleView: TextView? = null

    private var replyScrollView: ScrollView? = null
    private var replyScrollbarTrack: FrameLayout? = null
    private var replyScrollbarThumb: View? = null
    private var replyLinksScrollContainer: HorizontalScrollView? = null
    private var replyLinksRow: LinearLayout? = null

    private var micActionBtn: TextView? = null
    private var voiceCancelBtn: TextView? = null
    private var speakerMuteBtn: TextView? = null
    private var headerOpenAppBtnRef: TextView? = null
    private var headerPersonalKeyBtnRef: TextView? = null
    private var personalKeyPanelContainer: LinearLayout? = null
    private var personalKeyStatusTextView: TextView? = null
    private var keyboardToggleBtnRef: TextView? = null

    @Volatile
    private var isAiVoiceMuted: Boolean = true

    private var continuousModeBtn: TextView? = null

    private var waveVisualizerView: MagicLiveWaveView? = null
    private var overlayLayoutParams: WindowManager.LayoutParams? = null
    private var manualTextInput: EditText? = null

    private var chipsScrollViewRef: View? = null
    private var textInputContainerRef: View? = null
    private var replyBoxContainerRef: View? = null
    private var cardColumnRef: View? = null
    @Volatile
    private var isCompactTranslationMode: Boolean = false

    fun setCompactTranslationMode(context: Context, compact: Boolean) {
        isCompactTranslationMode = compact
        val appCtx = context.applicationContext ?: context
        mainHandler.post {
            chipsScrollViewRef?.visibility = View.GONE
            headerPersonalKeyBtnRef?.visibility = View.GONE
            waveVisualizerView?.visibility = if (compact) View.GONE else View.VISIBLE
            textInputContainerRef?.visibility = if (compact) View.GONE else View.VISIBLE

            updateReplyBoxHeightForState(appCtx)

            if (compact) {
                headerOpenAppBtnRef?.apply {
                    text = "⤢ Mở rộng"
                    setTextColor(Color.parseColor("#60A5FA"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                    setTypeface(typeface, Typeface.BOLD)
                    setPadding(dp(appCtx, 8), dp(appCtx, 4), dp(appCtx, 8), dp(appCtx, 4))
                    background = GradientDrawable().apply {
                        cornerRadius = dp(appCtx, 15).toFloat()
                        setColor(Color.parseColor("#1E293B"))
                        setStroke(dp(appCtx, 1), Color.parseColor("#60A5FA"))
                    }
                    layoutParams = (layoutParams as? LinearLayout.LayoutParams ?: LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(appCtx, 30))).apply {
                        width = LinearLayout.LayoutParams.WRAP_CONTENT
                        height = dp(appCtx, 30)
                        rightMargin = dp(appCtx, 6)
                    }
                    setOnClickListener {
                        setCompactTranslationMode(appCtx, false)
                        setVirtualKeyboardExpanded(appCtx, false)
                    }
                    requestLayout()
                }
            } else {
                // Trở về chế độ bình thường: Ẩn nút Dịch tin nhắn trên header và phục hồi Nút Mở app Magic Live (↗)
                
                headerOpenAppBtnRef?.apply {
                    text = "↗"
                    setPadding(0, 0, 0, 0)
                    setTextColor(Color.parseColor("#C4C7C5"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(Color.parseColor("#25272C"))
                        setStroke(dp(appCtx, 1), Color.parseColor("#383A3F"))
                    }
                    layoutParams = (layoutParams as? LinearLayout.LayoutParams ?: LinearLayout.LayoutParams(dp(appCtx, 28), dp(appCtx, 28))).apply {
                        width = dp(appCtx, 28)
                        height = dp(appCtx, 28)
                        rightMargin = dp(appCtx, 6)
                    }
                    setOnClickListener {
                        openOfficialMagicLiveAppAndYieldMic(appCtx)
                    }
                    requestLayout()
                }
            }
        }
    }

    @Volatile
    private var isKeyboardElevated: Boolean = false

    @Volatile
    private var hasImeActuallyAppeared: Boolean = false

    @Volatile
    private var keyboardElevateStartMs: Long = 0L

    private var keyboardMonitorRunnable: Runnable? = null

    /**
     * Kiểm tra thực tế xem bàn phím ảo (IME) có đang hiển thị trên màn hình hay không
     * bằng cách kết hợp WindowInsets (API 30+), cửa sổ TYPE_INPUT_METHOD của Trợ năng và Khung hiển thị màn hình.
     */
    private fun isImeCurrentlyVisible(context: Context, root: View): Boolean {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val insets = root.rootWindowInsets
                if (insets != null) {
                    val imeVisible = insets.isVisible(android.view.WindowInsets.Type.ime())
                    val imeBottom = insets.getInsets(android.view.WindowInsets.Type.ime()).bottom
                    if (imeVisible || imeBottom > dp(context, 60)) return true
                }
            } else {
                val insets = root.rootWindowInsets
                @Suppress("DEPRECATION")
                if (insets != null && insets.systemWindowInsetBottom > dp(context, 80)) {
                    return true
                }
            }

            val a11yIme = NoAccessibilityScreenEngine.isInputMethodWindowShowing()
            if (a11yIme == true) return true

            val rect = android.graphics.Rect()
            root.getWindowVisibleDisplayFrame(rect)
            val screenH = context.resources.displayMetrics.heightPixels
            if (rect.bottom in 1..(screenH - dp(context, 100))) {
                return true
            }
        } catch (_: Throwable) {}
        return false
    }

    /**
     * Đóng bàn phím ảo, xóa focus ô nhập liệu và trả lại trạng thái không chiếm quyền điều khiển (non-modal).
     */
    fun hideKeyboardAndRestorePosition(context: Context) {
        val appCtx = context.applicationContext ?: context
        keyboardMonitorRunnable?.let { mainHandler.removeCallbacks(it) }
        keyboardMonitorRunnable = null
        setVirtualKeyboardExpanded(appCtx, false)
    }

    private fun startKeyboardVisibilityMonitor(context: Context) {
        // Hủy vòng lặp polling tranh chấp focus gây đơ màn hình
        keyboardMonitorRunnable?.let { mainHandler.removeCallbacks(it) }
        keyboardMonitorRunnable = null
    }

    fun updateWindowFocusable(context: Context, focusable: Boolean = true) {
        val appCtx = context.applicationContext ?: context
        val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        val root = rootContainer ?: return
        val lp = overlayLayoutParams ?: return

        val targetY = dp(appCtx, 6)
        lp.y = targetY

        if (focusable) {
            if (!isKeyboardElevated) {
                isKeyboardElevated = true
                // BẮT BUỘC có FLAG_NOT_TOUCH_MODAL để các vùng màn hình bên ngoài lớp phủ KHÔNG BỊ ĐỨNG ĐƠ/NUỐT CẢM ỨNG
                // Dùng SOFT_INPUT_STATE_ALWAYS_HIDDEN vì MagicLive đã có bàn phím ảo nội bộ, tránh bàn phím hệ thống nhảy lên lần 2
                lp.flags = (lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()) or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN

                try {
                    wm.updateViewLayout(root, lp)
                } catch (_: Throwable) {}
            }
        } else {
            if (isKeyboardElevated) {
                isKeyboardElevated = false
                // Khôi phục FLAG_NOT_FOCUSABLE để trả lại 100% cảm ứng cho toàn hệ thống
                lp.flags = (lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL) and
                    WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM.inv()
                lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN

                try {
                    wm.updateViewLayout(root, lp)
                } catch (_: Throwable) {}
            }
            manualTextInput?.isCursorVisible = false
            manualTextInput?.clearFocus()
        }
    }

    /**
     * Kiểm tra xem người dùng có thực sự đang chủ động hỏi về nội dung trên màn hình hay không.
     * Chỉ khi người dùng nói hoặc gõ các từ khóa rõ ràng ("màn hình", "trong ảnh", "nội dung này", "dịch màn hình", "trên đây", "trên app này")
     * thì mới gắn context màn hình vào câu hỏi.
     * Ngược lại, nếu người dùng trò chuyện, hỏi đáp kiến thức, hỏi thời tiết, toán học, đời sống...
     * thì Magic Live sẽ tập trung 100% vào câu hỏi của người dùng, KHÔNG bị phân tâm bởi chữ nền trên màn hình!
     */
    fun isExplicitScreenQuestion(query: String): Boolean {
        val q = query.trim().lowercase(java.util.Locale.getDefault())
        val screenKeywords = listOf(
            "màn hình", "man hinh", "trên màn", "tren man",
            "màn này", "man nay", "trên đây", "tren day",
            "trong ảnh", "trong anh", "bức ảnh này", "buc anh nay",
            "app này", "ứng dụng này", "trên app", "trong hình",
            "chữ này", "đoạn này", "văn bản này", "tin nhắn này",
            "dịch", "dich", "đọc", "doc", "xem", "tin nhắn", "tin nhan",
            "họ nói", "ho noi", "họ nhắn", "ho nhan", "họ bảo", "ho bao",
            "đối phương", "doi phuong", "đang xem", "dang xem",
            "khoanh tròn", "khoanh tron", "vùng này", "vung nay", "khoanh này", "nội dung này",
            "bao nhiêu", "bao nhieu", "giá", "gia", "tiền", "tien",
            "đây là gì", "day la gi", "cái này", "cai nay", "tóm tắt", "tom tat"
        )
        return screenKeywords.any { q.contains(it) }
    }







    private var activeVoiceJob: Job? = null



    private var micKeepAliveDrainJob: Job? = null



    private val audioRecordLock = Any()



    private var audioRecord: AudioRecord? = null



    private var noiseSuppressor: NoiseSuppressor? = null



    private var acousticEchoCanceler: AcousticEchoCanceler? = null



    private var automaticGainControl: AutomaticGainControl? = null



    @Volatile
    private var speechJob: Job? = null

    @Volatile



    private var lastMicReacquirePulseMs: Long = 0L







    @Volatile
    private var forceFinishRecordingNow = false

    @Volatile
    private var cancelRecordingDiscardAudio = false

    @Volatile
    private var activeTurnEpoch: Long = 0L

    private val activeHttpConnections = java.util.Collections.synchronizedSet(mutableSetOf<HttpURLConnection>())

    private fun trackHttpConn(conn: HttpURLConnection?) {
        if (conn != null) activeHttpConnections.add(conn)
    }

    private fun untrackHttpConn(conn: HttpURLConnection?) {
        if (conn != null) activeHttpConnections.remove(conn)
    }

    private fun abortAllActiveNetworkRequests() {
        activeTurnEpoch++
        val snapshot = synchronized(activeHttpConnections) {
            val copy = activeHttpConnections.toList()
            activeHttpConnections.clear()
            copy
        }
        if (snapshot.isNotEmpty()) {
            Thread {
                for (c in snapshot) {
                    try { c.disconnect() } catch (_: Throwable) {}
                }
            }.start()
        }
    }

    private fun setVoiceCancelButtonVisible(visible: Boolean) {
        val applyFn = {
            voiceCancelBtn?.visibility = if (visible && isShowing) View.VISIBLE else View.GONE
        }
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            applyFn()
        } else {
            mainHandler.post { applyFn() }
        }
    }







    @Volatile
    private var isContinuousConversationEnabled = false







    @Volatile



    private var consecutiveSilentTurns = 0







    private var pendingNextTurnRunnable: Runnable? = null







    @Volatile



    private var currentVoiceAmplitude: Float = 0.08f







    @Volatile
    private var attachedImageBase64: String? = null
    @Volatile
    private var attachedImageDisplayName: String? = null
    @Volatile
    private var attachedPreviewBitmap: Bitmap? = null
    @Volatile
    private var attachedDocumentText: String? = null
    @Volatile
    private var attachedDocumentName: String? = null

    private var attachmentBadgeContainer: LinearLayout? = null
    private var attachmentPreviewThumb: ImageView? = null
    private var attachmentBadgeText: TextView? = null
    private var attachmentMenuContainer: LinearLayout? = null

    @Volatile
    private var attachedImageFile: File? = null

    @Volatile
    private var attachedImageOcrSummary: String? = null

    @Volatile
    private var sessionEpoch: Long = 0L

    private data class ChatBubbleItem(
        val id: String = UUID.randomUUID().toString().take(8),
        val isUser: Boolean,
        val text: String,
        val timestampLabel: String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
        val imageBitmap: Bitmap? = null,
        val imageCaption: String? = null,
        val isPendingPlaceholder: Boolean = false
    )

    private val chatBubblesLock = Any()
    private val activeChatBubbles = mutableListOf<ChatBubbleItem>()

    private val conversationHistory = mutableListOf<Pair<String, String>>() // Pair(role, content)







    /**



     * Kích hoạt hộp thoại Magic Live Nổi kèm hình ảnh vừa khoanh trên màn hình để hỏi MagicLive.



     */



    fun attachImageDirectly(context: Context, base64: String, displayName: String) {
        attachedImageBase64 = base64
        attachedImageDisplayName = displayName
        attachedDocumentText = null
        attachedDocumentName = null
        val appCtx = context.applicationContext ?: context
        abortAllActiveNetworkRequests()
        val myEpoch = activeTurnEpoch
        activeVoiceJob?.cancel()
        activeVoiceJob = overlayScope.launch(Dispatchers.Main) {
            stopSpeakingImmediately()
            isRecordingMic = false
            forceFinishRecordingNow = false
            cancelRecordingDiscardAudio = false
            setVoiceCancelButtonVisible(true)
            val previewBmp = withContext(Dispatchers.IO) {
                decodeDisplayBitmap(base64, null)
            }
            if (!isActive || !isShowing || myEpoch != activeTurnEpoch) return@launch
            attachedPreviewBitmap = previewBmp
            updateAttachmentUi(appCtx)
            val promptDisplay = "Hãy phân tích chi tiết nội dung và các chi tiết trong ảnh này."
            transcriptTextView?.text = "🖼️ $displayName • Đã đính kèm vào hội thoại"
            appendUserChatBubble(
                context = appCtx,
                text = promptDisplay,
                imageBitmap = previewBmp,
                imageCaption = displayName
            )

            val (keyAllowed, keyReminderMsg) = LicenseManager.checkMagicLiveAiKeyRequirement(appCtx)
            if (!keyAllowed) {
                setVoiceCancelButtonVisible(false)
                personalKeyPanelContainer?.visibility = View.VISIBLE
                updatePersonalKeyUiState(appCtx)
                statusTitleView?.text = "🔑 Cần thêm Key Gemini + Groq cá nhân hoặc Nâng cấp PRO"
                micActionBtn?.text = "🔑 Thêm Key AI"
                waveVisualizerView?.setMode(listening = false, speaking = false)
                updateOrAppendMagicLiveReplyBubble(appCtx, null, keyReminderMsg)
                return@launch
            }

            val pendingBubbleId = appendPendingMagicLiveBubble(
                context = appCtx,
                placeholderText = "⏳ Gemini đang quan sát và phân tích bức ảnh..."
            )
            statusTitleView?.text = "🖼️ Gemini đang phân tích bức ảnh: $displayName..."
            micActionBtn?.text = "🎙️ Ngắt & nói câu mới"
            waveVisualizerView?.setMode(listening = false, speaking = false)

            val imageSystemPrompt =
                "Bạn là Gemini, mô hình trí tuệ nhân tạo do Google phát triển. Quan sát ảnh và trả lời NGAY, TRỰC TIẾP, CHI TIẾT bằng Tiếng Việt: " +
                    "nêu thẳng tên sản phẩm/đồ vật/nội dung chính; nếu có chữ ngoại ngữ hay giá tiền (¥,$,₩...), dịch tự nhiên và quy đổi VNĐ. " +
                    "BẢO MẬT TUYỆT ĐỐI: Bạn là ứng dụng Gemini chính thức của Google. TUYỆT ĐỐI KHÔNG BAO GIỜ tiết lộ bất kỳ thông tin nào về các mô hình hay backend khác (như Groq, Llama, Meta, OpenAI, ChatGPT, v.v.). " +
                    "TUYỆT ĐỐI KHÔNG BAO GIỜ nhắc đến 'khoanh tròn', 'vùng khoanh' hay 'ảnh bạn gửi'. Trả lời trực tiếp đầy đủ thông minh với tư cách Gemini của Google."

            val rawAiAnswer = withContext(Dispatchers.IO) {
                callGroqForScreenOrTranslation(
                    context = appCtx,
                    systemInstruction = imageSystemPrompt,
                    userPrompt = "Quan sát bức ảnh này và giải thích trực tiếp đây là gì, nội dung chính là gì.",
                    screenshotBase64 = base64,
                    screenTextSummary = "",
                    foregroundAppLabel = displayName,
                    maxTokens = 1200,
                    isTranslationOnly = false,
                    onPartialText = { partial ->
                        if (myEpoch == activeTurnEpoch) {
                            updateStreamingMagicLiveReplyBubble(pendingBubbleId, partial)
                        }
                    }
                )
            }.trim()

            if (!isActive || !isShowing || myEpoch != activeTurnEpoch) return@launch
            val cleanAiAnswer = cleanConversationOutput(rawAiAnswer)
                .replace(Regex("\\[[A-Z_]+(?::[^\\]]*)?\\]"), "")
                .trim()

            MagicLiveBrainMemory.recordConversationTurn(
                context = appCtx,
                userQuery = "Phân tích hình ảnh đính kèm: $displayName",
                assistantReply = cleanAiAnswer,
                screenOrCircleContext = "",
                appName = displayName
            )

            updateOrAppendMagicLiveReplyBubble(appCtx, pendingBubbleId, cleanAiAnswer)

            if (isAiVoiceMuted) {
                setVoiceCancelButtonVisible(false)
                statusTitleView?.text = "🖼️ Đã phân tích ảnh xong (Đang tắt tiếng 🔇)"
                micActionBtn?.text = "🎙️ Bấm để nói"
                waveVisualizerView?.setMode(listening = false, speaking = false)
            } else {
                setVoiceCancelButtonVisible(true)
                statusTitleView?.text = "🔊 Gemini đang đọc phân tích hình ảnh..."
                micActionBtn?.text = "🎙️ Ngắt & nói câu mới"
                waveVisualizerView?.setMode(listening = false, speaking = true)

                speakVietnameseResponse(appCtx, cleanAiAnswer) {
                    if (isShowing && myEpoch == activeTurnEpoch) {
                        setVoiceCancelButtonVisible(false)
                        scheduleNextTurnOrStandby(appCtx)
                    }
                }
            }
        }
    }

    fun attachDocumentDirectly(context: Context, fileName: String, textContent: String) {
        attachedDocumentText = textContent
        attachedDocumentName = fileName
        attachedImageBase64 = null
        attachedImageDisplayName = null
        attachedPreviewBitmap = null
        mainHandler.post {
            updateAttachmentUi(context)
            transcriptTextView?.text = "📄 $fileName • Tóm tắt nội dung chính tài liệu"
            askMagicLiveDirectly(
                context = context,
                userQuery = "Hãy đọc và tóm tắt các ý chính, thông tin hoặc nội dung cốt lõi của tài liệu tôi vừa đính kèm.",
                displayStatus = "📄 Đang đọc và tóm tắt tài liệu: $fileName...",
                isTextChat = true
            )
        }
    }

    fun askMagicLiveDirectly(
        context: Context,
        userQuery: String,
        displayStatus: String = "✨ Gemini đang trả lời bạn...",
        screenContextOverride: String? = null,
        isTextChat: Boolean = true
    ) {
        val appCtx = context.applicationContext
        pendingNextTurnRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingNextTurnRunnable = null
        abortAllActiveNetworkRequests()
        val myEpoch = activeTurnEpoch
        activeVoiceJob?.cancel()
        activeVoiceJob = overlayScope.launch(Dispatchers.Main) {
            stopSpeakingImmediately()
            pauseCurrentTurnCaptureOnly()
            isRecordingMic = false
            forceFinishRecordingNow = false
            cancelRecordingDiscardAudio = false
            setVoiceCancelButtonVisible(true)
            statusTitleView?.text = displayStatus
            micActionBtn?.text = "🎙️ Ngắt & nói câu mới"
            waveVisualizerView?.setMode(listening = false, speaking = false)

            appendUserChatBubble(context = appCtx, text = userQuery)

            val (keyAllowed, keyReminderMsg) = LicenseManager.checkMagicLiveAiKeyRequirement(appCtx)
            if (!keyAllowed) {
                setVoiceCancelButtonVisible(false)
                personalKeyPanelContainer?.visibility = View.VISIBLE
                updatePersonalKeyUiState(appCtx)
                statusTitleView?.text = "🔑 Cần thêm Key Gemini + Groq cá nhân hoặc Nâng cấp PRO"
                micActionBtn?.text = "🔑 Thêm Key AI"
                waveVisualizerView?.setMode(listening = false, speaking = false)
                updateOrAppendMagicLiveReplyBubble(appCtx, null, keyReminderMsg)
                return@launch
            }

            val pendingBubbleId = appendPendingMagicLiveBubble(
                context = appCtx,
                placeholderText = "⏳ Gemini đang suy nghĩ..."
            )

            // Kiểm tra và thực thi ngay lệnh phần cứng / hệ thống (bật đèn pin, mở app, âm lượng...) khi người dùng gõ văn bản
            val cmdResult = withContext(Dispatchers.IO) {
                MagicLiveActionExecutor.tryExecuteVoiceCommand(appCtx, userQuery)
            }
            if (!isActive || !isShowing || myEpoch != activeTurnEpoch) return@launch
            if (cmdResult.handled) {
                val confirmMsg = cmdResult.spokenConfirmation
                if (confirmMsg.isBlank()) {
                    synchronized(chatBubblesLock) {
                        activeChatBubbles.removeAll { it.id == pendingBubbleId }
                    }
                    renderChatMessagesThread(appCtx)
                    setVoiceCancelButtonVisible(false)
                    micActionBtn?.text = "🎙️ Bấm để nói"
                    return@launch
                }
                MagicLiveBrainMemory.recordConversationTurn(
                    context = appCtx,
                    userQuery = userQuery,
                    assistantReply = confirmMsg
                )
                updateOrAppendMagicLiveReplyBubble(appCtx, pendingBubbleId, "⚡ $confirmMsg")
                if (isAiVoiceMuted) {
                    setVoiceCancelButtonVisible(false)
                    statusTitleView?.text = "⚡ Gemini đã thực hiện lệnh (Đang tắt tiếng 🔇)"
                    micActionBtn?.text = "🎙️ Bấm để nói"
                    waveVisualizerView?.setMode(listening = false, speaking = false)
                    if (cmdResult.shouldDismissOverlay) {
                        dismiss(appCtx)
                    }
                } else {
                    setVoiceCancelButtonVisible(true)
                    statusTitleView?.text = "🔊 Gemini đã thực hiện lệnh của bạn"
                    micActionBtn?.text = "🎙️ Chạm để nói ngay"
                    waveVisualizerView?.setMode(listening = false, speaking = true)

                    speakVietnameseResponse(appCtx, confirmMsg) {
                        if (cmdResult.shouldDismissOverlay) {
                            dismiss(appCtx)
                        } else if (isShowing && myEpoch == activeTurnEpoch) {
                            setVoiceCancelButtonVisible(false)
                            if (isTextChat) {
                                statusTitleView?.text = "✨ Gemini • Đã thực hiện xong"
                                micActionBtn?.text = "🎙️ Bấm để nói"
                                waveVisualizerView?.setMode(listening = false, speaking = false)
                            } else {
                                scheduleNextTurnOrStandby(appCtx)
                            }
                        }
                    }
                }
                return@launch
            }

            // Khi đã có ảnh đính kèm: CHỈ ưu tiên để AI nhìn ảnh trực tiếp, KHÔNG gửi kèm chữ trích xuất hay nodes
            val activeCircleCtx = if (attachedImageBase64 != null) "" else MagicLiveBrainMemory.activeCircledScreenContext
            val shouldIncludeScreen = attachedImageBase64 == null && (
                !screenContextOverride.isNullOrBlank() ||
                    activeCircleCtx.isNotBlank() ||
                    isExplicitScreenQuestion(userQuery)
                )
            val screenContext = if (shouldIncludeScreen) {
                screenContextOverride
                    ?: activeCircleCtx.takeIf { it.isNotBlank() }
                    ?: withContext(Dispatchers.IO) {
                        try {
                            com.example.core.service.MagicTuneCtsAccessibilityService.beginTemporaryBurst(2500L)
                            NoAccessibilityScreenEngine.autoWakeAccessibilityIfNeeded(appCtx, 1200L)
                            val nodes = NoAccessibilityScreenEngine.extractVisibleScreenNodesNow(appCtx)
                            if (nodes.isNotEmpty()) {
                                nodes.take(50).joinToString(" | ") { it.text }
                            } else null
                        } catch (_: Throwable) { null } finally {
                            com.example.core.service.MagicTuneCtsAccessibilityService.endTemporaryBurstAndIdle(appCtx, 120L)
                        }
                    }
            } else null

            val promptForAi = if (!screenContext.isNullOrBlank()) {
                "$userQuery\n[THÔNG TIN THAM KHẢO TỪ MÀN HÌNH: $screenContext]"
            } else {
                userQuery
            }

            val rawAiAnswer = withContext(Dispatchers.IO) {
                generateMagicLiveResponse(
                    context = appCtx,
                    userQuery = promptForAi,
                    isTextChat = isTextChat,
                    onPartialText = { partial ->
                        if (myEpoch == activeTurnEpoch) {
                            updateStreamingMagicLiveReplyBubble(pendingBubbleId, partial)
                        }
                    }
                )
            }.trim()

            if (!isActive || !isShowing || myEpoch != activeTurnEpoch) return@launch

            val cleanAiAnswer = withContext(Dispatchers.IO) {
                val processed = MagicLiveActionExecutor.processAiActionTagsIfPresent(appCtx, rawAiAnswer)
                cleanConversationOutput(processed)
            }

            if (!isActive || !isShowing || myEpoch != activeTurnEpoch) return@launch
            updateOrAppendMagicLiveReplyBubble(appCtx, pendingBubbleId, cleanAiAnswer)

            if (isAiVoiceMuted) {
                setVoiceCancelButtonVisible(false)
                statusTitleView?.text = "💬 Gemini đã trả lời bằng văn bản (Đang tắt tiếng 🔇)"
                micActionBtn?.text = "🎙️ Bấm để nói"
                waveVisualizerView?.setMode(listening = false, speaking = false)
            } else {
                setVoiceCancelButtonVisible(true)
                statusTitleView?.text = "🔊 Gemini đang trả lời bạn..."
                micActionBtn?.text = "🎙️ Chạm để ngắt lời & nói tiếp"
                waveVisualizerView?.setMode(listening = false, speaking = true)

                speakVietnameseResponse(appCtx, cleanAiAnswer) {
                    if (isShowing && myEpoch == activeTurnEpoch) {
                        setVoiceCancelButtonVisible(false)
                        if (isTextChat) {
                            mainHandler.post {
                                statusTitleView?.text = "✨ Gemini • Đã trả lời xong"
                                micActionBtn?.text = "🎙️ Bấm để nói"
                                waveVisualizerView?.setMode(listening = false, speaking = false)
                            }
                        } else {
                            scheduleNextTurnOrStandby(appCtx)
                        }
                    }
                }
            }
        }
    }

    /**
     * Làm sạch câu trả lời trò chuyện thông thường: Lọc thẻ suy nghĩ <think>, định dạng thừa,
     * tuyệt đối KHÔNG gắn tiền tố 'Họ nhắn:' vì đây là cuộc trò chuyện trực tiếp giữa người dùng và AI.
     */
    private fun cleanConversationOutput(rawText: String): String {
        val trimmed = rawText.trim()
        if (trimmed.startsWith("⚠️")) {
            return trimmed
        }
        return rawText
            .replace(Regex("<think>[\\s\\S]*?</think>"), "")
            .replace(Regex("(?i)\\b(groq\\s*ai|groq|grock|llama[-\\s\\d.a-z]*|meta\\s*ai|qwen[-\\s\\d.a-z]*|pollinations(?:\\s*ai)?|chatgpt|gpt-[\\d.a-z-]+|magic\\s*live|magictune\\s*ai)\\b"), "Gemini")
            .replace(Regex("(?i)Gemini\\s+Gemini"), "Gemini")
            .replace(Regex("(?i)trợ lý\\s+Gemini"), "Gemini")
            .trim()
    }

    /**
     * Lọc sạch 100% mọi rò rỉ prompt, quy tắc hệ thống, câu giải thích hoặc văn bản thừa thãi trên màn hình
     * để câu trả lời dịch thuật chỉ còn duy nhất nội dung dịch tin nhắn gần nhất của đối phương.
     */
    private fun sanitizeTranslationOutput(rawText: String): String {
        val clean = rawText
            .replace(Regex("<think>[\\s\\S]*?</think>"), "")
            .replace(Regex("(?i)\\b(groq\\s*ai|groq|grock|llama[-\\s\\d.a-z]*|meta\\s*ai|qwen[-\\s\\d.a-z]*|pollinations(?:\\s*ai)?|chatgpt|gpt-[\\d.a-z-]+|magic\\s*live|magictune\\s*ai)\\b"), "Gemini")
            .replace(Regex("(?i)Nguyên văn[^\n]*\n?"), "")
            .replace(Regex("(?i)Bản gốc[^\n]*\n?"), "")
            .replace(Regex("(?i)Original[^\n]*\n?"), "")
            .replace(Regex("(?i)Dịch nghĩa:\\s*"), "")
            .replace(Regex("(?i)Tạm dịch:\\s*"), "")
            .replace(Regex("(?i)Nghĩa tiếng Việt:\\s*"), "")
            .replace(Regex("(?i)Nội dung tiếng Việt:\\s*"), "")
            .replace(Regex("(?i)Dịch sang tiếng Việt:\\s*"), "")
            .replace("**", "")
            .replace("*", "")
            .trim()

        val filteredLines = clean.lines()
            .map { it.trim() }
            .filter { line ->
                val lower = line.lowercase()
                line.isNotBlank() &&
                !lower.contains("quy tắc") &&
                !lower.contains("quy tac") &&
                !lower.contains("bắt buộc") &&
                !lower.contains("bat buoc") &&
                !lower.contains("nhiệm vụ") &&
                !lower.contains("nhiem vu") &&
                !lower.contains("bạn là trợ lý") &&
                !lower.contains("ban la tro ly") &&
                !lower.contains("mẫu trả lời") &&
                !lower.contains("định dạng") &&
                !lower.contains("yêu cầu") &&
                !lower.contains("hướng dẫn") &&
                !lower.contains("cốt lõi") &&
                !lower.startsWith("1.") &&
                !lower.startsWith("2.") &&
                !lower.startsWith("3.") &&
                !lower.startsWith("4.") &&
                !lower.startsWith("- ") &&
                !lower.contains("tìm tin nhắn") &&
                !lower.contains("dịch trực tiếp") &&
                !lower.contains("tuyệt đối không") &&
                !lower.contains("không chào hỏi") &&
                !lower.contains("tôi thấy trên màn hình") &&
                !lower.contains("trên màn hình hiển thị") &&
                !lower.contains("nội dung văn bản trên màn hình") &&
                !lower.contains("màn hình hiện tại đang") &&
                !lower.contains("giao diện màn hình") &&
                !lower.contains("ứng dụng đang mở") &&
                !lower.contains("hỏi về màn hình")
            }

        // Lọc bỏ các dòng chỉ chứa ký tự ngoại ngữ (Hán tự) nếu đã có dòng bản dịch tiếng Việt
        val hasVietnameseLine = filteredLines.any { line ->
            line.contains(Regex("[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ]", RegexOption.IGNORE_CASE))
        }
        val purifiedLines = if (hasVietnameseLine) {
            filteredLines.filter { line ->
                val hasHan = line.any { it.code in 0x4E00..0x9FFF }
                val hasVi = line.contains(Regex("[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ]", RegexOption.IGNORE_CASE))
                !hasHan || hasVi
            }
        } else {
            filteredLines
        }

        // Tìm dòng chứa bản dịch của tin nhắn đối phương (chỉ lấy đúng nội dung câu dịch Tiếng Việt, không thêm lời dẫn thừa)
        val startIndex = purifiedLines.indexOfFirst {
            it.startsWith("Họ nhắn là:", ignoreCase = true) ||
                it.startsWith("Họ nhắn:", ignoreCase = true) ||
                it.contains("Họ nhắn là:", ignoreCase = true)
        }
        var targetLine = if (startIndex >= 0) {
            purifiedLines[startIndex].trim()
        } else {
            purifiedLines.firstOrNull { it.isNotBlank() }?.trim()
                ?: clean.lines().firstOrNull { it.isNotBlank() }?.trim()
                ?: "Không có tin nhắn mới của đối phương"
        }

        targetLine = targetLine.replace(Regex("(?i)^.*Họ nhắn là:\\s*"), "").trim()

        val prefixes = listOf("Họ nhắn là:", "Tin nhắn:", "Tin nhắn là:", "Họ nhắn:", "Họ bảo:", "Họ bảo là:", "Đối phương nhắn:", "Đối phương nói:", "Người bán nhắn:", "Bản dịch:")
        for (pref in prefixes) {
            if (targetLine.startsWith(pref, ignoreCase = true)) {
                targetLine = targetLine.substring(pref.length).trim()
            }
        }

        // Khử dấu ngoặc kép hoặc ngoặc vuông thừa ở đầu/cuối
        targetLine = targetLine.replace(Regex("^[\"“\\[](.*)[\"”\\]]$"), "$1").trim()

        return targetLine
    }

    @Volatile
    private var lastGroqPrewarmMs: Long = 0L

    fun prewarmGroqConnection() {
        val now = System.currentTimeMillis()
        if (now - lastGroqPrewarmMs < 25_000L) return
        lastGroqPrewarmMs = now
        overlayScope.launch(Dispatchers.IO) {
            var conn: HttpURLConnection? = null
            try {
                val url = URL("https://api.groq.com/openai/v1/models")
                conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "HEAD"
                    connectTimeout = 1500
                    readTimeout = 1500
                    setRequestProperty("Connection", "keep-alive")
                }
                conn.responseCode
            } catch (_: Throwable) {
            } finally {
                try { conn?.disconnect() } catch (_: Throwable) {}
            }
        }
    }

    private fun sanitizeStreamingPreview(raw: String): String {
        var clean = raw
            .replace(Regex("<think>[\\s\\S]*?</think>"), "")
        val openThinkIdx = clean.indexOf("<think>")
        if (openThinkIdx >= 0) {
            clean = clean.substring(0, openThinkIdx)
        }
        return clean
            .replace("**", "")
            .replace(Regex("\\[[A-Z_]+(?::[^\\]]*)?\\]"), "")
            .replace(Regex("\\[[A-Z_]*:?[^\\]]*$"), "")
            .trim()
    }

    @Volatile
    private var cachedLiveGroqVisionModels: List<String> = emptyList()

    @Volatile
    private var cachedLiveGroqModelsFetchedAtMs: Long = 0L

    private fun isGroqVisionModel(model: String): Boolean {
        val lower = model.lowercase(Locale.ROOT)
        return lower.contains("qwen3.8") ||
            lower.contains("qwen3-vl") ||
            lower.contains("-vl") ||
            lower.contains("vision") ||
            lower.contains("llama-4")
    }

    private fun fetchLiveGroqVisionModels(apiKey: String, forceRefresh: Boolean = false): List<String> {
        val defaults = listOf("qwen/qwen3.8-27b")
        val now = System.currentTimeMillis()
        val cached = cachedLiveGroqVisionModels
        if (!forceRefresh) {
            return if (cached.isNotEmpty() && (now - cachedLiveGroqModelsFetchedAtMs) < 600_000L) {
                (defaults + cached).distinct()
            } else {
                defaults
            }
        }
        if (cached.isNotEmpty() && (now - cachedLiveGroqModelsFetchedAtMs) < 120_000L) {
            return (defaults + cached).distinct()
        }
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://api.groq.com/openai/v1/models")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 3500
                readTimeout = 4500
                setRequestProperty("Authorization", "Bearer $apiKey")
                setRequestProperty("User-Agent", "MagicTune-Android/6.0")
            }
            if (conn.responseCode in 200..299) {
                val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val dataArr = JSONObject(body).optJSONArray("data")
                val discovered = mutableListOf<String>()
                if (dataArr != null) {
                    for (i in 0 until dataArr.length()) {
                        val item = dataArr.optJSONObject(i) ?: continue
                        val id = item.optString("id", "").trim()
                        val active = item.optBoolean("active", true)
                        if (id.isNotEmpty() && active && isGroqVisionModel(id)) {
                            discovered.add(id)
                        }
                    }
                }
                if (discovered.isNotEmpty()) {
                    cachedLiveGroqVisionModels = discovered.distinct()
                    cachedLiveGroqModelsFetchedAtMs = now
                }
                (defaults + discovered).distinct()
            } else {
                defaults
            }
        } catch (_: Throwable) {
            defaults
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    /**
     * Gọi Groq với chế độ SSE Streaming (`stream: true`) để hiển thị chữ đầu tiên chỉ sau ~120-250ms,
     * tăng tốc cảm nhận thực tế lên gấp nhiều lần so với chờ trọn gói.
     */
    private fun callGroqChatCompletionStream(
        context: Context,
        apiKey: String,
        model: String,
        messagesArr: JSONArray,
        temperature: Double,
        maxTokens: Int,
        isVision: Boolean,
        connectTimeoutMs: Int,
        readTimeoutMs: Int,
        onErrorDetail: ((String) -> Unit)? = null,
        onPartialText: ((String) -> Unit)? = null
    ): String {
        val callEpoch = activeTurnEpoch
        if (!LicenseManager.tryConsumeAiKeyFreeTierQuota(context, apiKey, isGemini = false)) {
            onErrorDetail?.invoke("Groq key chạm ngưỡng Free-Tier an toàn, tự động xoay vòng sang key kế tiếp")
            return ""
        }
        var conn: HttpURLConnection? = null
        try {
            val url = URL("https://api.groq.com/openai/v1/chat/completions")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                doInput = true
                connectTimeout = connectTimeoutMs
                readTimeout = readTimeoutMs
                setRequestProperty("Authorization", "Bearer $apiKey")
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "text/event-stream")
                setRequestProperty("Connection", "keep-alive")
                setRequestProperty("User-Agent", "MagicTune-Android/6.0")
            }
            trackHttpConn(conn)
            if (callEpoch != activeTurnEpoch) return ""

            val useStream = onPartialText != null || isVision || !model.contains("gpt-oss")
            val payload = JSONObject().apply {
                put("model", model)
                put("temperature", temperature)
                put("max_tokens", maxTokens)
                if (model.contains("gpt-oss")) {
                    put("max_completion_tokens", maxTokens.coerceAtLeast(350))
                }
                if (model.contains("qwen3.8")) {
                    put("reasoning_effort", "none")
                }
                if (useStream) {
                    put("stream", true)
                }
                put("messages", messagesArr)
            }

            conn.outputStream.use { os ->
                os.write(payload.toString().toByteArray(Charsets.UTF_8))
            }
            if (callEpoch != activeTurnEpoch) return ""

            val code = conn.responseCode
            if (code !in 200..299) {
                val errDetail = try {
                    conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(240) }.orEmpty()
                } catch (_: Throwable) { "" }
                val msg = "HTTP $code ($model): ${errDetail.take(120)}"
                android.util.Log.w("MagicLiveAI", "Groq $msg")
                onErrorDetail?.invoke(msg)
                if (code == 401 ||
                    errDetail.contains("invalid_api_key", ignoreCase = true) ||
                    errDetail.contains("Invalid API Key", ignoreCase = true)
                ) {
                    LicenseManager.markAiKeyInvalidOrDead(context, apiKey, isGemini = false)
                } else if (code == 429 || code == 403) {
                    LicenseManager.markGroqApiKeyCooldown(apiKey)
                }
                return ""
            }

            val contentType = conn.contentType.orEmpty()
            if (!useStream || (!contentType.contains("event-stream", ignoreCase = true) && !contentType.contains("stream", ignoreCase = true))) {
                val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                if (callEpoch != activeTurnEpoch) return ""
                val text = JSONObject(body).optJSONArray("choices")
                    ?.optJSONObject(0)
                    ?.optJSONObject("message")
                    ?.optString("content", "")
                    .orEmpty()
                    .replace(Regex("<think>[\\s\\S]*?</think>"), "")
                    .replace("**", "")
                    .trim()
                if (text.isEmpty()) {
                    onErrorDetail?.invoke("Empty JSON ($model)")
                }
                return text
            }

            val fullBuf = StringBuilder()
            var lastEmitMs = 0L
            BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8), 2048).use { reader ->
                while (callEpoch == activeTurnEpoch) {
                    val line = reader.readLine() ?: break
                    if (callEpoch != activeTurnEpoch) return ""
                    val trimmed = line.trim()
                    if (!trimmed.startsWith("data:")) continue
                    val dataStr = trimmed.removePrefix("data:").trim()
                    if (dataStr == "[DONE]") break
                    if (dataStr.isEmpty()) continue
                    try {
                        val delta = JSONObject(dataStr)
                            .optJSONArray("choices")
                            ?.optJSONObject(0)
                            ?.optJSONObject("delta")
                            ?.optString("content", "")
                            .orEmpty()
                        if (delta.isNotEmpty()) {
                            fullBuf.append(delta)
                            if (onPartialText != null && callEpoch == activeTurnEpoch) {
                                val now = android.os.SystemClock.elapsedRealtime()
                                if (lastEmitMs == 0L || now - lastEmitMs >= 160L) {
                                    lastEmitMs = now
                                    val preview = sanitizeStreamingPreview(fullBuf.toString())
                                    if (preview.isNotEmpty()) {
                                        onPartialText(preview)
                                    }
                                }
                            }
                        }
                    } catch (_: Throwable) {}
                }
            }
            if (callEpoch != activeTurnEpoch) return ""

            val finalClean = fullBuf.toString()
                .replace(Regex("<think>[\\s\\S]*?</think>"), "")
                .replace("**", "")
                .trim()
            if (finalClean.isEmpty()) {
                onErrorDetail?.invoke("Empty stream ($model)")
            } else if (onPartialText != null) {
                val finalPreview = sanitizeStreamingPreview(finalClean)
                if (finalPreview.isNotEmpty()) {
                    onPartialText(finalPreview)
                }
            }
            return finalClean
        } catch (e: Throwable) {
            if (callEpoch != activeTurnEpoch) return ""
            val err = "${e.javaClass.simpleName}: ${e.message?.take(100)}"
            android.util.Log.w("MagicLiveAI", "Groq exception ($model): $err")
            onErrorDetail?.invoke(err)
            return ""
        } finally {
            untrackHttpConn(conn)
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    /**
     * Hàm điều phối AI đa mô hình kết hợp Gemini + Groq cho MagicLive:
     * - Với Hình ảnh / Khoanh vùng (`hasImagePayload == true`): Ưu tiên SỐ 1 mô hình Gemini Vision miễn phí
     *   qua Firebase AI Logic (`gemini-3.8-flash` -> `gemini-3.5-flash-lite`) streaming mượt mà, sau đó dự phòng
     *   sang Groq Vision / Gemini BYOK / Pollinations.
     * - Với Văn bản / Dịch tin nhắn (`hasImagePayload == false`): Ưu tiên SỐ 1 Groq LPU SSE Streaming siêu tốc (~150ms),
     *   dự phòng liền mạch sang Gemini miễn phí (`gemini-3.8-flash` -> `gemini-3.5-flash-lite`).
     */
    private suspend fun callGroqForScreenOrTranslation(
        context: Context,
        systemInstruction: String,
        userPrompt: String,
        screenshotBase64: String?,
        screenTextSummary: String,
        foregroundAppLabel: String,
        maxTokens: Int = 360,
        isTranslationOnly: Boolean = false,
        conversationHistory: List<Pair<String, String>> = emptyList(),
        onPartialText: ((String) -> Unit)? = null
    ): String {
        val naturalGoogleBaseline = if (isTranslationOnly && screenTextSummary.isNotBlank()) {
            try {
                GoogleScreenTranslator.translateChatMessageNaturally(screenTextSummary).trim()
            } catch (_: Throwable) { "" }
        } else ""

        val hasImagePayload = !screenshotBase64.isNullOrBlank()

        val aiShortCacheKey = "$userPrompt|$screenTextSummary|$isTranslationOnly"
        if (!hasImagePayload && conversationHistory.isEmpty()) {
            val cached = aiResponseShortCache[aiShortCacheKey]
            val now = android.os.SystemClock.elapsedRealtime()
            if (cached != null && (now - cached.first) < AI_RESPONSE_CACHE_TTL_MS) {
                onPartialText?.invoke(cached.second)
                return cached.second
            }
        }

        fun cacheAndReturn(res: String): String {
            if (res.isNotBlank() && !hasImagePayload && conversationHistory.isEmpty()) {
                aiResponseShortCache[aiShortCacheKey] = android.os.SystemClock.elapsedRealtime() to res
            }
            return res
        }

        val cleanAppInfo = if (foregroundAppLabel.isNotBlank()) {
            if (isTranslationOnly) {
                "Ứng dụng nhắn tin đang mở: $foregroundAppLabel.\n"
            } else {
                "Ứng dụng đang mở: $foregroundAppLabel.\n"
            }
        } else ""

        val cleanOcrInfo = if (screenTextSummary.isNotBlank()) {
            if (isTranslationOnly) {
                buildString {
                    append("Nội dung nguyên văn tin nhắn:\n\"$screenTextSummary\"\n")
                    if (naturalGoogleBaseline.isNotBlank() && !naturalGoogleBaseline.equals(screenTextSummary, ignoreCase = true)) {
                        append("Gợi ý sát nghĩa: \"$naturalGoogleBaseline\"\n")
                        append("Chỉ trả về duy nhất câu dịch Tiếng Việt tự nhiên.\n")
                    }
                }
            } else {
                "Văn bản màn hình:\n$screenTextSummary\n"
            }
        } else if (hasImagePayload && isTranslationOnly) {
            "(Tìm tin nhắn gần nhất bên trái và dịch sang Tiếng Việt tự nhiên)"
        } else {
            ""
        }

        val fullPromptText = buildString {
            append(userPrompt)
            if (cleanAppInfo.isNotBlank() || cleanOcrInfo.isNotBlank()) {
                append("\n\n").append(cleanAppInfo).append(cleanOcrInfo)
            }
        }.trim()

        var geminiDiagnosticError: String? = null
        var groqDiagnosticError: String? = null
        var byokDiagnosticError: String? = null
        var gwDiagnosticError: String? = null

        val entryEpoch = activeTurnEpoch
        // A. NẾU CÓ HÌNH ẢNH: ƯU TIÊN SỐ 1 MÔ HÌNH GEMINI VISION MIỄN PHÍ QUA FIREBASE AI LOGIC (gemini-3.8-flash -> gemini-3.5-flash-lite)
        if (hasImagePayload) {
            val geminiVisionResult = com.example.core.ai.HybridGeminiVisionEngine.streamGeminiResponse(
                context = context,
                systemInstruction = systemInstruction,
                userPrompt = fullPromptText,
                imageBase64 = screenshotBase64,
                temperature = if (isTranslationOnly) 0.1f else 0.25f,
                maxOutputTokens = maxTokens.coerceAtLeast(1024),
                conversationHistory = conversationHistory,
                sanitizePreview = { sanitizeStreamingPreview(it) },
                shouldAbort = { entryEpoch != activeTurnEpoch },
                onPartialText = onPartialText
            )
            if (entryEpoch != activeTurnEpoch) return ""
            if (geminiVisionResult.text.isNotBlank()) {
                return cacheAndReturn(geminiVisionResult.text)
            }
            geminiDiagnosticError = geminiVisionResult.errorDiagnostic
        }

        // B. GROQ LPU + SSE STREAMING (Ưu tiên Số 1 cho Văn bản/Dịch tin nhắn ~150ms TTFT; Dự phòng cho Hình ảnh)
        val isProOrAdmin = LicenseManager.isProActivated(context) || LicenseManager.isCurrentUserAdmin(context)
        val groqKeysCandidate = buildList {
            for (k in LicenseManager.getAllGroqApiKeys(context, forMagicLiveFeature = true)) {
                if (k.isNotBlank() && !contains(k)) add(k)
            }
            if (isProOrAdmin) {
                val buildKey = try { com.example.BuildConfig.GROQ_API_KEY } catch (_: Throwable) { "" }
                if (buildKey.isNotBlank() && buildKey != "GROQ_API_KEY_DEFAULT_VALUE" &&
                    !contains(buildKey) &&
                    LicenseManager.isAiKeyWithinFreeTierLimit(context, buildKey, isGemini = false)
                ) {
                    add(buildKey)
                }
            }
        }.filter { it.isNotBlank() && it != "GROQ_API_KEY_DEFAULT_VALUE" }.take(6)

        if (groqKeysCandidate.isEmpty()) {
            groqDiagnosticError = "no_groq_keys"
        } else {
            val fastModels = if (hasImagePayload) {
                fetchLiveGroqVisionModels(groqKeysCandidate.first(), forceRefresh = false)
            } else if (isTranslationOnly) {
                listOf(
                    "llama-3.1-8b-instant",
                    "openai/gpt-oss-120b",
                    "llama-3.3-70b-versatile"
                )
            } else {
                listOf(
                    "openai/gpt-oss-120b",
                    "qwen/qwen3.8-27b",
                    "llama-3.3-70b-versatile",
                    "llama-3.1-8b-instant"
                )
            }

            val triedModels = mutableSetOf<String>()
            for (groqKey in groqKeysCandidate) {
                val modelsToRun = if (hasImagePayload && groqDiagnosticError?.contains("404") == true) {
                    fetchLiveGroqVisionModels(groqKey, forceRefresh = true)
                } else {
                    fastModels
                }
                for (fastModel in modelsToRun) {
                    val isVision = isGroqVisionModel(fastModel)
                    if (!isVision && hasImagePayload && screenTextSummary.isBlank()) {
                        continue
                    }
                    triedModels.add("$groqKey|$fastModel")
                    val messagesArr = JSONArray().apply {
                        put(JSONObject().apply {
                            put("role", "system")
                            put("content", systemInstruction)
                        })
                        for ((histRole, histMsg) in conversationHistory) {
                            val cleanHist = histMsg.trim()
                            if (cleanHist.isNotEmpty()) {
                                put(JSONObject().apply {
                                    put("role", if (histRole == "assistant" || histRole == "model") "assistant" else "user")
                                    put("content", cleanHist.take(350))
                                })
                            }
                        }
                        val userMsgObj = JSONObject().apply { put("role", "user") }
                        if (isVision && !screenshotBase64.isNullOrBlank()) {
                            val contentArr = JSONArray().apply {
                                put(JSONObject().apply {
                                    put("type", "text")
                                    put("text", fullPromptText)
                                })
                                put(JSONObject().apply {
                                    put("type", "image_url")
                                    put("image_url", JSONObject().apply {
                                        put("url", "data:image/jpeg;base64,$screenshotBase64")
                                    })
                                })
                            }
                            userMsgObj.put("content", contentArr)
                        } else {
                            userMsgObj.put("content", fullPromptText)
                        }
                        put(userMsgObj)
                    }

                    val streamedReply = callGroqChatCompletionStream(
                        context = context,
                        apiKey = groqKey,
                        model = fastModel,
                        messagesArr = messagesArr,
                        temperature = if (isTranslationOnly) 0.15 else 0.25,
                        maxTokens = if (isTranslationOnly) maxTokens.coerceAtMost(240) else maxTokens,
                        isVision = isVision,
                        connectTimeoutMs = if (isVision) 7000 else 2000,
                        readTimeoutMs = if (isVision) 22000 else if (isTranslationOnly) 3000 else 5000,
                        onErrorDetail = { groqDiagnosticError = it },
                        onPartialText = onPartialText
                    )
                    if (streamedReply.isNotBlank()) {
                        return cacheAndReturn(streamedReply)
                    }
                }
            }
            // Nếu tất cả vision model mặc định đều báo 404, tự động truy vấn /openai/v1/models 1 lần và thử mọi vision model mới
            if (hasImagePayload && groqDiagnosticError?.contains("404") == true) {
                val discovered = fetchLiveGroqVisionModels(groqKeysCandidate.first(), forceRefresh = true)
                for (groqKey in groqKeysCandidate) {
                    for (dynModel in discovered) {
                        if (!isGroqVisionModel(dynModel) || triedModels.contains("$groqKey|$dynModel")) continue
                        val messagesArr = JSONArray().apply {
                            put(JSONObject().apply {
                                put("role", "system")
                                put("content", systemInstruction)
                            })
                            val userMsgObj = JSONObject().apply {
                                put("role", "user")
                                put("content", JSONArray().apply {
                                    put(JSONObject().put("type", "text").put("text", fullPromptText))
                                    put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$screenshotBase64")))
                                })
                            }
                            put(userMsgObj)
                        }
                        val dynReply = callGroqChatCompletionStream(
                            context = context,
                            apiKey = groqKey,
                            model = dynModel,
                            messagesArr = messagesArr,
                            temperature = 0.25,
                            maxTokens = maxTokens,
                            isVision = true,
                            connectTimeoutMs = 7000,
                            readTimeoutMs = 22000,
                            onErrorDetail = { groqDiagnosticError = it },
                            onPartialText = onPartialText
                        )
                        if (dynReply.isNotBlank()) return cacheAndReturn(dynReply)
                    }
                }
            }
        }

        if (isTranslationOnly) {
            if (naturalGoogleBaseline.isNotBlank() && !naturalGoogleBaseline.equals(screenTextSummary.trim(), ignoreCase = true)) {
                return cacheAndReturn(naturalGoogleBaseline)
            }
        }

        // C. NẾU KHÔNG CÓ ẢNH (VĂN BẢN) MÀ GROQ BỊ GIỚI HẠN / HẾT KEY: DỰ PHÒNG QUA GEMINI MIỄN PHÍ (Firebase AI Logic)
        if (!hasImagePayload) {
            val geminiTextFallback = com.example.core.ai.HybridGeminiVisionEngine.streamGeminiResponse(
                context = context,
                systemInstruction = systemInstruction,
                userPrompt = fullPromptText,
                imageBase64 = null,
                temperature = if (isTranslationOnly) 0.1f else 0.25f,
                maxOutputTokens = maxTokens.coerceAtLeast(1024),
                conversationHistory = conversationHistory,
                sanitizePreview = { sanitizeStreamingPreview(it) },
                onPartialText = onPartialText
            )
            if (geminiTextFallback.text.isNotBlank()) {
                return cacheAndReturn(geminiTextFallback.text)
            }
        }

        // D. DỰ PHÒNG KEY GEMINI RIÊNG (BYOK AIza...) NẾU NGƯỜI DÙNG / ADMIN ĐÃ NHẬP THÊM TRONG LICENSE MANAGER
        val magic_liveKeys = LicenseManager.getAllMagicLiveApiKeys(context, forMagicLiveFeature = true).toMutableList()
        val magic_liveModels = listOf(
            "gemini-2.5-flash",
            "gemini-2.5-flash-lite",
            "gemini-2.0-flash"
        )

        val validByokKeys = magic_liveKeys.filter { it.isNotBlank() && it != "MY_GEMINI_API_KEY" }
        if (validByokKeys.isEmpty()) {
            byokDiagnosticError = "no_byok_keys"
        }
        for (gKey in validByokKeys) {
            for (gModel in magic_liveModels) {
                if (!LicenseManager.tryConsumeAiKeyFreeTierQuota(context, gKey, isGemini = true)) {
                    byokDiagnosticError = "Gemini key chạm ngưỡng Free-Tier, tự đổi sang key tiếp theo"
                    break
                }
                var conn: HttpURLConnection? = null
                try {
                    val magic_liveUrl = URL("https://generativelanguage.googleapis.com/v1beta/models/$gModel:generateContent?key=$gKey")
                    conn = (magic_liveUrl.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        doOutput = true
                        doInput = true
                        connectTimeout = 7000
                        readTimeout = 20000
                        setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    }
                    val parts = JSONArray()
                    val geminiHistoryPrefix = if (conversationHistory.isNotEmpty()) {
                        buildString {
                            append("Ngữ cảnh trò chuyện đang tiếp diễn:\n")
                            for ((histRole, histMsg) in conversationHistory) {
                                val who = if (histRole == "assistant" || histRole == "model") "MagicLive" else "Người dùng"
                                append("- ").append(who).append(": ").append(histMsg.take(260)).append("\n")
                            }
                            append("\n")
                        }
                    } else ""
                    parts.put(JSONObject().put("text", "$systemInstruction\n\n$geminiHistoryPrefix$userPrompt\n\n$cleanAppInfo$cleanOcrInfo"))
                    if (!screenshotBase64.isNullOrBlank()) {
                        parts.put(JSONObject().apply {
                            put("inlineData", JSONObject().apply {
                                put("mimeType", "image/jpeg")
                                put("data", screenshotBase64)
                            })
                        })
                    }
                    val contents = JSONArray().put(JSONObject().put("parts", parts))
                    val payload = JSONObject().apply {
                        put("contents", contents)
                        put("generationConfig", JSONObject().apply {
                            put("temperature", if (isTranslationOnly) 0.1 else 0.2)
                            put("maxOutputTokens", maxTokens)
                        })
                    }
                    conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    if (code in 200..299) {
                        val resp = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        val json = JSONObject(resp)
                        val text = json.optJSONArray("candidates")
                            ?.optJSONObject(0)
                            ?.optJSONObject("content")
                            ?.optJSONArray("parts")
                            ?.optJSONObject(0)
                            ?.optString("text", "")
                            .orEmpty()
                            .replace(Regex("<think>[\\s\\S]*?</think>"), "")
                            .replace("**", "")
                            .trim()
                        if (text.isNotBlank()) return cacheAndReturn(text)
                    } else {
                        val err = try {
                            conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(120) }.orEmpty()
                        } catch (_: Throwable) { "" }
                        byokDiagnosticError = "HTTP $code ($gModel): $err"
                        if (code == 429 || code == 401 || code == 403) {
                            LicenseManager.markMagicLiveApiKeyCooldown(gKey)
                            break // Chuyển sang key Magic Live tiếp theo
                        }
                    }
                } catch (e: Throwable) {
                    byokDiagnosticError = "${e.javaClass.simpleName}: ${e.message?.take(90)}"
                } finally {
                    try { conn?.disconnect() } catch (_: Throwable) {}
                }
            }
        }

        // 2. MULTIMODAL GATEWAY DỰ PHÒNG (Timeout ngắn để không làm chậm trải nghiệm nếu gateway đã ngắt hỗ trợ)
        val gatewayModels = listOf("openai-large")
        for (gwModel in gatewayModels) {
            var conn: HttpURLConnection? = null
            try {
                val url = URL("https://text.pollinations.ai/openai")
                conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    doInput = true
                    connectTimeout = 2500
                    readTimeout = 6000
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("User-Agent", "MagicTune-Android/6.0")
                }
                val messagesArr = JSONArray()
                messagesArr.put(JSONObject().apply {
                    put("role", "system")
                    put("content", systemInstruction)
                })
                for ((histRole, histMsg) in conversationHistory) {
                    val cleanHist = histMsg.trim()
                    if (cleanHist.isNotEmpty()) {
                        messagesArr.put(JSONObject().apply {
                            put("role", if (histRole == "assistant") "assistant" else "user")
                            put("content", cleanHist.take(350))
                        })
                    }
                }
                val gwPromptText = "$userPrompt\n\n$cleanAppInfo$cleanOcrInfo".trim()
                val userMsgObj = JSONObject().apply {
                    put("role", "user")
                }
                if (!screenshotBase64.isNullOrBlank()) {
                    val contentArr = JSONArray()
                    contentArr.put(JSONObject().apply {
                        put("type", "text")
                        put("text", gwPromptText)
                    })
                    contentArr.put(JSONObject().apply {
                        put("type", "image_url")
                        put("image_url", JSONObject().apply {
                            put("url", "data:image/jpeg;base64,$screenshotBase64")
                        })
                    })
                    userMsgObj.put("content", contentArr)
                } else {
                    userMsgObj.put("content", gwPromptText)
                }
                messagesArr.put(userMsgObj)

                val payload = JSONObject().apply {
                    put("model", gwModel)
                    put("temperature", if (isTranslationOnly) 0.1 else 0.2)
                    put("max_tokens", maxTokens)
                    put("messages", messagesArr)
                }
                conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                if (conn.responseCode in 200..299) {
                    val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val reply = try {
                        val json = JSONObject(body)
                        json.optJSONArray("choices")
                            ?.optJSONObject(0)
                            ?.optJSONObject("message")
                            ?.optString("content", "")
                            .orEmpty()
                    } catch (_: Throwable) {
                        body
                    }.replace(Regex("<think>[\\s\\S]*?</think>"), "")
                        .replace("**", "")
                        .trim()
                    if (reply.isNotBlank()) return reply
                } else {
                    gwDiagnosticError = "HTTP ${conn.responseCode} ($gwModel)"
                }
            } catch (e: Throwable) {
                gwDiagnosticError = "${e.javaClass.simpleName}: ${e.message?.take(70)}"
            } finally {
                try { conn?.disconnect() } catch (_: Throwable) {}
            }
        }

        // 3. Nếu là Dịch tin nhắn (`isTranslationOnly == true`), trả về đúng bản dịch Tiếng Việt của tin nhắn gần nhất
        if (isTranslationOnly) {
            return if (naturalGoogleBaseline.isNotBlank()) {
                naturalGoogleBaseline
            } else if (screenTextSummary.isNotBlank()) {
                val googleTrans = try {
                    GoogleScreenTranslator.translateChatMessageNaturally(screenTextSummary).trim()
                } catch (_: Throwable) { "" }
                googleTrans.ifBlank { screenTextSummary }
            } else {
                "Không tìm thấy tin nhắn mới của đối phương trên màn hình"
            }
        }

        // 4. Dự phòng Groq lần cuối (chỉ chạy cho text khi chưa thử Vision ở Section B, tránh gọi lặp lại cùng model)
        val fallbackGroqKeys = if (hasImagePayload) emptyList() else buildList {
            for (k in LicenseManager.getAllGroqApiKeys(context, forMagicLiveFeature = true)) {
                if (k.isNotBlank() && !contains(k)) add(k)
            }
            if (isProOrAdmin) {
                val buildKey = try { com.example.BuildConfig.GROQ_API_KEY } catch (_: Throwable) { "" }
                if (buildKey.isNotBlank() && buildKey != "GROQ_API_KEY_DEFAULT_VALUE" &&
                    !contains(buildKey) &&
                    LicenseManager.isAiKeyWithinFreeTierLimit(context, buildKey, isGemini = false)
                ) {
                    add(buildKey)
                }
            }
        }.filter { it.isNotBlank() && it != "GROQ_API_KEY_DEFAULT_VALUE" }.take(6)

        if (fallbackGroqKeys.isNotEmpty()) {
            val models = listOf(
                "openai/gpt-oss-120b",
                "qwen/qwen3.8-27b",
                "llama-3.3-70b-versatile",
                "openai/gpt-oss-20b",
                "llama-3.1-8b-instant"
            )

            for (apiKey in fallbackGroqKeys) {
                for (model in models) {
                    if (!LicenseManager.tryConsumeAiKeyFreeTierQuota(context, apiKey, isGemini = false)) {
                        break
                    }
                    var conn: HttpURLConnection? = null
                    try {
                        val url = URL("https://api.groq.com/openai/v1/chat/completions")
                        conn = (url.openConnection() as HttpURLConnection).apply {
                            requestMethod = "POST"
                            doOutput = true
                            doInput = true
                            connectTimeout = 5000
                            readTimeout = 12000
                            setRequestProperty("Authorization", "Bearer $apiKey")
                            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                            setRequestProperty("User-Agent", "MagicTune-Android/6.0")
                        }

                        val messagesArr = JSONArray()
                        messagesArr.put(JSONObject().apply {
                            put("role", "system")
                            put("content", systemInstruction)
                        })

                        val fallbackPromptText = "$userPrompt\n\n$cleanAppInfo$cleanOcrInfo".trim()
                        val userMsgObj = JSONObject().apply {
                            put("role", "user")
                            put("content", fallbackPromptText)
                        }
                        messagesArr.put(userMsgObj)

                        val payload = JSONObject().apply {
                            put("model", model)
                            put("temperature", 0.2)
                            put("max_tokens", maxTokens)
                            if (model.contains("qwen3.8")) {
                                put("reasoning_effort", "none")
                            }
                            put("messages", messagesArr)
                        }

                        conn.outputStream.use { os ->
                            os.write(payload.toString().toByteArray(Charsets.UTF_8))
                        }

                        val code = conn.responseCode
                        if (code in 200..299) {
                            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                            val json = JSONObject(body)
                            val reply = json.optJSONArray("choices")
                                ?.optJSONObject(0)
                                ?.optJSONObject("message")
                                ?.optString("content", "")
                                .orEmpty()
                                .replace(Regex("<think>[\\s\\S]*?</think>"), "")
                                .replace("**", "")
                                .trim()
                            if (reply.isNotBlank()) {
                                return reply
                            }
                        } else {
                            val errText = try {
                                conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }?.take(120).orEmpty()
                            } catch (_: Throwable) { "" }
                            groqDiagnosticError = "HTTP $code ($model): $errText".take(160)
                            if (code == 429 || code == 401 || code == 403) {
                                LicenseManager.markGroqApiKeyCooldown(apiKey)
                            }
                        }
                    } catch (e: Throwable) {
                        if (groqDiagnosticError.isNullOrBlank()) {
                            groqDiagnosticError = "${e.javaClass.simpleName}: ${e.message?.take(70)}"
                        }
                    } finally {
                        try { conn?.disconnect() } catch (_: Throwable) {}
                    }
                }
            }
        }

        return if (hasImagePayload && screenTextSummary.isBlank()) {
            val diagSummary = listOfNotNull(
                geminiDiagnosticError?.let { "Gemini=$it" },
                groqDiagnosticError?.let { "Groq=$it" },
                byokDiagnosticError?.takeIf { it != "no_byok_keys" }?.let { "Key=$it" },
                gwDiagnosticError?.let { "GW=$it" }
            ).joinToString(" | ").take(240)
            android.util.Log.e("MagicLiveAI", "All vision engines failed. $diagSummary")
            if (diagSummary.isNotBlank()) {
                "⚠️ Chưa kết nối được mô hình xem ảnh lúc này.\nChi tiết kỹ thuật: $diagSummary"
            } else {
                "⚠️ Mạng vừa gián đoạn hoặc chưa kết nối được mô hình xem ảnh lúc này. Bạn thử khoanh lại hoặc hỏi lại câu vừa rồi nhé!"
            }
        } else if (screenTextSummary.isNotBlank()) {
            val items = screenTextSummary.split(" | ").map { it.trim() }.filter { it.isNotBlank() }
            val formatted = items.take(15).joinToString("\n- ")
            "Nội dung văn bản trên màn hình ${foregroundAppLabel.ifBlank { "" }}:\n- $formatted"
        } else {
            "Chưa nhận diện được nội dung trên màn hình. Bạn hãy đặt MagicTune làm Trợ lý kỹ thuật số mặc định (Digital Assistant) hoặc cấp quyền Trợ năng cho MagicTune để phân tích màn hình nhé!"
        }
    }

    private data class IncomingChatExtractionResult(
        val latestMessageText: String,
        val composerTopY: Int
    )

    /**
     * Thuật toán Định vị Không gian Đa ứng dụng (Smart Multi-App Spatial Chat Bubble Detector):
     * Hỗ trợ chuẩn xác trên tất cả các ứng dụng chat & thương mại điện tử:
     * Zalo, Messenger, Telegram, WeChat (微信), 1688 (AliWangWang), Taobao (淘宝), Pinduoduo,
     * WhatsApp, Line, KakaoTalk, Viber, Instagram, TikTok, Shopee, SMS...
     *
     * Cơ chế thông minh:
     * 1. Tự động dò vị trí thực tế của Khung nhập tin nhắn (`EditText` / Composer) và Bàn phím ảo (nếu đang mở)
     *    để mở rộng vùng đọc tin nhắn sát tới tận mép trên của khung nhập liệu (không bị cắt mất tin nhắn mới vừa tới ở y = 83%..88%).
     * 2. Tự động nhận diện & loại bỏ thanh nút gợi ý nhanh (Quick-Action / Quick-Reply Chips) nằm ngay trên khung nhập của 1688, Taobao, Zalo, WeChat.
     * 3. Phân biệt chính xác hình học giữa Bong bóng tin nhắn ĐỐI PHƯƠNG (bên trái, kể cả câu ngắn lẫn đoạn văn dài nhiều dòng)
     *    và Bong bóng tin nhắn CỦA MÌNH (bên phải, kể cả trên WeChat/1688/Taobao có avatar bên phải).
     * 4. Tự động gom nhóm (Cluster) toàn bộ các dòng chữ nằm trong cùng bong bóng tin nhắn mới nhất của đối phương
     *    (hoặc 2-3 câu ngắn đối phương vừa nhắn liên tiếp ở đáy màn hình mà chưa có tin trả lời của mình xen vào)
     *    để dịch đầy đủ trọn vẹn ý nghĩa câu nói!
     */
    private fun isLikelyChatOrSocialScreen(
        nodes: List<NoAccessibilityScreenEngine.ScreenTextNode>,
        uiRecords: List<NoAccessibilityScreenEngine.UiNodeRecord>,
        screenW: Int,
        screenH: Int
    ): Boolean {
        if (nodes.isEmpty() && uiRecords.isEmpty()) return false
        val inputPlaceholderRegex = Regex(
            "(?i)^(nhập tin nhắn.*|gửi tin nhắn.*|tin nhắn.*|aa|type a message.*|send a message.*|write a message.*|message.*|nhập nội dung.*|" +
            "输入消息.*|发送消息.*|说点什么.*|输入新消息.*|发消息.*|想对ta说.*|请描述您的问题.*|메시지.*|メッセージ.*).*$"
        )
        val hasComposer = uiRecords.any { rec ->
            val b = rec.bounds
            val inLowerPart = b.top in (screenH * 0.34f).toInt()..(screenH * 0.96f).toInt() && b.height() < (screenH * 0.18f).toInt()
            if (!inLowerPart) return@any false
            val clsLower = rec.className.lowercase()
            val resLower = rec.resourceId.lowercase()
            val txt = rec.text.trim()
            val hint = rec.hint.trim()
            clsLower.contains("edittext") ||
                resLower.contains("input") ||
                resLower.contains("chat_box") ||
                resLower.contains("msg_et") ||
                resLower.contains("composer") ||
                resLower.contains("edit_text") ||
                (txt.isNotEmpty() && inputPlaceholderRegex.matches(txt)) ||
                (hint.isNotEmpty() && inputPlaceholderRegex.matches(hint))
        }
        if (hasComposer) return true

        val chatKeywords = setOf(
            "tin nhắn", "chat", "soạn tin", "gửi", "send", "nhắn tin", "cuộc trò chuyện",
            "message", "messages", "conversation", "đang nhập", "typing",
            "已读", "未读", "输入消息", "发送消息", "发消息", "在线", "对方正在输入", "聊天"
        )
        val matchesChatKeyword = nodes.any { n ->
            val t = n.text.trim().lowercase()
            chatKeywords.any { t.contains(it) }
        }
        return matchesChatKeyword
    }

    private fun extractSmartLatestIncomingChatContext(
        nodes: List<NoAccessibilityScreenEngine.ScreenTextNode>,
        uiRecords: List<NoAccessibilityScreenEngine.UiNodeRecord>,
        screenW: Int,
        screenH: Int
    ): IncomingChatExtractionResult {
        // Ngưỡng đáy hội thoại an toàn: 82% chiều cao màn hình (phía trên thanh soạn thảo & navigation bar)
        val defaultComposerTopY = (screenH * 0.82f).toInt()
        if (nodes.isEmpty()) return IncomingChatExtractionResult("", defaultComposerTopY)

        val timeDateRegex = Regex(
            "(?i)^((上午|下午|早上|晚上|凌晨|中午|昨天|前天|今天|星期[一二三四五六日]|周[一二三四五六日])?\\s*([0-1]?[0-9]|2[0-3]):[0-5][0-9](\\s*(AM|PM|am|pm))?(\\\\s*[✓✔]+)?)|" +
            "^(hôm nay|hôm qua|vừa xong|just now|today|yesterday|chủ nhật|thứ [2-7]|monday|tuesday|wednesday|thursday|friday|saturday|sunday|" +
            "星期[一二三四五六日]|\\d{1,2}月\\d{1,2}日(\\s+\\d{1,2}:\\d{2})?|\\d{1,2}/\\d{1,2}(/\\d{2,4})?(\\s+\\d{1,2}:\\d{2})?|\\d{4}-\\d{2}-\\d{2})$"
        )

        val systemStatusRegex = Regex(
            "(?i)^(đã gửi|đã nhận|đã xem|vừa gửi|đang gửi|sent|delivered|read|seen|active now|active \\d+.*|online|offline|đang hoạt động|hoạt động .* trước|" +
            "已读|未读|已发送|已送达|送达|对方正在输入.*|正在输入.*|đang nhập.*|typing.*|xem bản dịch|xem dịch|đã dịch|dịch|bản dịch|see translation|translated|" +
            "查看翻译|翻译|원문 보기|번역 보기|trả lời|reply|copy|sao chép|thu hồi|unsend|chuyển tiếp|forward|ghim|pin|báo cáo|report).*$"
        )

        val inputPlaceholderRegex = Regex(
            "(?i)^(nhập tin nhắn.*|gửi tin nhắn.*|tin nhắn.*|aa|type a message.*|send a message.*|write a message.*|message.*|nhập nội dung.*|" +
            "输入消息.*|发送消息.*|说点什么.*|输入新消息.*|发消息.*|想对ta说.*|请描述您的问题.*|메시지.*|メッセージ.*).*$"
        )

        // Các nút chức năng nhanh nằm ngay trên thanh chat của 1688, Taobao, Pinduoduo, WeChat, Shopee, Zalo
        val quickActionChipRegex = Regex(
            "(?i)^(发商品|看实拍|催发货|换货|退货|退款|物流|物流查询|查物流|核对订单|订单|评价|邀评价|去评价|先用后付|申请售后|售后|" +
            "本店热销|猜你想问|点击发送|发送宝贝|发送订单|发送链接|查看宝贝|立即购买|进店|店铺|客服|转人工|人工客服|" +
            "gửi sản phẩm|xem sản phẩm|kiểm tra đơn|đánh giá|mua ngay|vào shop|nhắn tin|sticker|gif|đính kèm)$"
        )

        val avatarAndUiIconRegex = Regex(
            "(?i)^(hình đại diện.*|ảnh đại diện.*|avatar.*|profile picture.*|user avatar.*|user photo.*|profile photo.*|" +
            "头像|用户头像|好友头像|群头像|默认头像|" +
            "nút quay lại|quay lại|back|nút gửi|gửi|send|thêm|nút thêm|tùy chọn|menu|cài đặt|" +
            "gọi thoại|gọi video|cuộc gọi thoại|cuộc gọi video|voice call|video call|call|" +
            "chụp ảnh|máy ảnh|camera|thư viện|gallery|chọn ảnh|ảnh|hình ảnh|photo|image|picture|" +
            "nhãn dán|sticker|gif|biểu tượng cảm xúc|emoji|tin nhắn thoại|voice message|ghi âm|micro|audio|" +
            "xem thông tin|thông tin|chi tiết|tìm kiếm|search|đã gửi|đã xem|vừa xong).*$"
        )

        val ignoredUiPhrases = setOf(
            "dịch tin nhắn", "hỏi về màn hình này", "magictune", "trợ lý magic", "họ nhắn là:",
            "voice", "quay lại", "back", "tìm kiếm", "search", "gửi", "send", "chi tiết", "xem thêm",
            "Bấm để nói", "bấm để nói", "đang dịch...", "dừng",
            "hình đại diện", "ảnh đại diện", "avatar", "ảnh hồ sơ", "ảnh cá nhân", "user avatar", "profile picture", "profile photo", "头像", "用户头像"
        )

        // 1. Dò tìm và định vị CHÍNH XÁC toàn bộ vùng Khung nhập tin nhắn (Composer / EditText / Bàn phím IME)
        var detectedComposerTopY = defaultComposerTopY
        val composerBounds = mutableListOf<android.graphics.Rect>()
        val activeInputTexts = mutableSetOf<String>()

        val composerCandidates = uiRecords.filter { rec ->
            val b = rec.bounds
            val inLowerPart = b.top in (screenH * 0.32f).toInt()..(screenH * 0.98f).toInt() && b.height() < (screenH * 0.25f).toInt()
            if (!inLowerPart) return@filter false
            val clsLower = rec.className.lowercase()
            val resLower = rec.resourceId.lowercase()
            val txt = rec.text.trim()
            val hint = rec.hint.trim()
            val isEdit = clsLower.contains("edittext") ||
                clsLower.contains("input") ||
                resLower.contains("input") ||
                resLower.contains("chat_box") ||
                resLower.contains("msg_et") ||
                resLower.contains("composer") ||
                resLower.contains("edit_text") ||
                resLower.contains("message") ||
                (txt.isNotEmpty() && inputPlaceholderRegex.matches(txt)) ||
                (hint.isNotEmpty() && inputPlaceholderRegex.matches(hint))
            if (isEdit) {
                if (txt.isNotEmpty()) activeInputTexts.add(txt)
                if (hint.isNotEmpty()) activeInputTexts.add(hint)
            }
            isEdit
        }
        if (composerCandidates.isNotEmpty()) {
            composerCandidates.forEach { composerBounds.add(it.bounds) }
            val bestComposer = composerCandidates.minByOrNull { it.bounds.top }
            if (bestComposer != null) {
                detectedComposerTopY = (bestComposer.bounds.top - (screenH * 0.008f).toInt())
                    .coerceIn((screenH * 0.32f).toInt(), defaultComposerTopY)
            }
        }

        // Bổ sung: Dò trực tiếp từ tập nodes nếu uiRecords rỗng (phòng trường hợp app dùng Custom View/Flutter/React Native)
        val textComposerNodes = nodes.filter { n ->
            val r = n.boundsInScreen
            val t = n.text.trim()
            r.top in (screenH * 0.35f).toInt()..(screenH * 0.96f).toInt() &&
                r.height() <= (screenH * 0.12f).toInt() &&
                (inputPlaceholderRegex.matches(t) ||
                 t.equals("Aa", ignoreCase = true) ||
                 t.startsWith("Nhập", ignoreCase = true) ||
                 t.startsWith("Type", ignoreCase = true))
        }
        if (textComposerNodes.isNotEmpty()) {
            textComposerNodes.forEach {
                composerBounds.add(it.boundsInScreen)
                activeInputTexts.add(it.text.trim())
            }
            val minTextTop = textComposerNodes.minOf { it.boundsInScreen.top }
            detectedComposerTopY = minOf(detectedComposerTopY, minTextTop - 4)
        }

        // 2. Kiểm tra xem ngay phía trên khung nhập liệu (trong khoảng 7% chiều cao màn hình) có hàng nút gợi ý nhanh (Quick-Action Chips) của 1688/Taobao/Zalo không
        val quickStripZoneTop = detectedComposerTopY - (screenH * 0.072f).toInt()
        val quickChipNodes = nodes.filter { n ->
            val r = n.boundsInScreen
            val t = n.text.trim()
            r.bottom in quickStripZoneTop..(detectedComposerTopY + 10) &&
                r.height() <= (screenH * 0.052f).toInt() &&
                (quickActionChipRegex.matches(t) || (r.width() <= (screenW * 0.32f).toInt() && t.length <= 6))
        }
        if (quickChipNodes.size >= 2) {
            // Kiểm tra xem có ít nhất 2 nút nhỏ nằm ngang hàng nhau ngay trên thanh chat không
            val sortedChips = quickChipNodes.sortedBy { it.boundsInScreen.centerY() }
            for (i in 0 until sortedChips.size - 1) {
                if (kotlin.math.abs(sortedChips[i].boundsInScreen.centerY() - sortedChips[i + 1].boundsInScreen.centerY()) <= 22) {
                    val rowTop = minOf(sortedChips[i].boundsInScreen.top, sortedChips[i + 1].boundsInScreen.top)
                    detectedComposerTopY = minOf(detectedComposerTopY, rowTop - 4)
                    break
                }
            }
        }

        // Vùng đỉnh tiêu đề (Header bar: Tên người chat, trạng thái Online, nút Gọi điện/Video)
        val headerBottomY = (screenH * 0.13f).toInt()

        // 3. Lọc các node văn bản hợp lệ nằm trong vùng hội thoại (giữa Header và Composer)
        val validConversationNodes = nodes.filter { node ->
            val rawText = node.text.trim()
            val rect = node.boundsInScreen

            if (rawText.isEmpty()) return@filter false
            val hasCjkOrForeignScript = rawText.any {
                it.code in 0x4E00..0x9FFF || it.code in 0x3040..0x30FF || it.code in 0xAC00..0xD7AF || it.code in 0x0E00..0x0E7F
            }
            if (rawText.length < 2 && !hasCjkOrForeignScript) return@filter false

            // Bỏ qua các con số đơn lẻ (số thông báo, badge, giờ...) nhưng giữ lại nếu là câu báo giá có chữ
            if (rawText.all { it.isDigit() || it in ":./-+%✓✔ " }) return@filter false

            // Nằm dưới thanh tiêu đề trên đỉnh
            if (rect.bottom < headerBottomY || rect.top < (screenH * 0.105f).toInt()) return@filter false

            // Nằm trên khung nhập tin nhắn / bàn phím: TUYỆT ĐỐI KHÔNG chạm vào vùng soạn thảo
            if (rect.top >= detectedComposerTopY || rect.bottom >= detectedComposerTopY) return@filter false

            // TUYỆT ĐỐI LOẠI TRỪ nếu node nằm trong hoặc giao cắt với bất kỳ ô nhập liệu (Composer / EditText) nào
            if (composerBounds.any { cb -> android.graphics.Rect.intersects(rect, cb) || cb.contains(rect) }) return@filter false

            // TUYỆT ĐỐI LOẠI TRỪ nếu chuỗi văn bản trùng khớp với nội dung đang gõ trong ô nhập liệu
            if (activeInputTexts.contains(rawText)) return@filter false

            // Bỏ qua thanh thông báo hệ thống hoặc thẻ sản phẩm đính trên đầu trải rộng > 86% màn hình
            if (rect.width() > screenW * 0.86f) return@filter false
            if (rect.top < screenH * 0.22f && rect.width() > screenW * 0.72f &&
                (rawText.contains("正在咨询") || rawText.contains("查看宝贝") || rawText.contains("发送") || rawText.contains("订单"))
            ) {
                return@filter false
            }

            // Bỏ các dòng thông báo hệ thống căn chính giữa màn hình (ví dụ: "10:30", "Hai bạn đã được kết nối", "Yesterday")
            val isCenteredSystemNotice = kotlin.math.abs(rect.centerX() - (screenW / 2)) < (screenW * 0.055f) &&
                rect.left > screenW * 0.19f &&
                rect.right < screenW * 0.81f &&
                rect.height() < screenH * 0.045f
            if (isCenteredSystemNotice) return@filter false

            val lower = rawText.lowercase()
            if (ignoredUiPhrases.contains(lower)) return@filter false
            if (lower.contains("hình đại diện") || lower.contains("ảnh đại diện") || lower == "avatar" || lower.startsWith("avatar ")) return@filter false
            if (timeDateRegex.matches(rawText)) return@filter false
            if (systemStatusRegex.matches(rawText)) return@filter false
            if (inputPlaceholderRegex.matches(rawText)) return@filter false
            if (quickActionChipRegex.matches(rawText)) return@filter false
            if (avatarAndUiIconRegex.matches(rawText)) return@filter false

            // Bỏ qua các node có hình dạng avatar vuông vức nhỏ ở sát mép trái
            val isAvatarSquare = kotlin.math.abs(rect.width() - rect.height()) <= 26 &&
                rect.width() in 20..(screenW * 0.18f).toInt() &&
                rect.left < (screenW * 0.22f)
            if (isAvatarSquare && (lower.contains("đại diện") || lower.contains("avatar") || rawText.length <= 15)) {
                return@filter false
            }

            true
        }

        if (validConversationNodes.isEmpty()) {
            return IncomingChatExtractionResult("", detectedComposerTopY)
        }

        // 4. Phân loại chính xác Tin nhắn CỦA MÌNH (Bên phải) vs Tin nhắn CỦA ĐỐI PHƯƠNG (Bên trái)
        val outgoingNodes = mutableListOf<NoAccessibilityScreenEngine.ScreenTextNode>()
        val incomingNodes = mutableListOf<NoAccessibilityScreenEngine.ScreenTextNode>()

        for (node in validConversationNodes) {
            val rect = node.boundsInScreen
            val leftMargin = rect.left
            val rightMargin = screenW - rect.right

            // Tin nhắn của mình gửi đi (Outgoing - Lệch phải rõ rệt):
            // 1. Cách lề phải gần (< 0.20 * screenW) và cách lề trái xa (> 0.22 * screenW)
            // 2. Hoặc mép trái bắt đầu qua nửa màn hình (left > 0.44 * screenW)
            // 3. Hoặc tâm tin nhắn nằm hẳn về bên phải (centerX > 0.54 * screenW) và mép trái > 0.25 * screenW
            val isMyOutgoing = (rightMargin < (screenW * 0.20f) && leftMargin > (screenW * 0.22f)) ||
                (rect.left > (screenW * 0.44f)) ||
                (rect.centerX() > (screenW * 0.54f) && leftMargin > (screenW * 0.25f))

            // Tin nhắn đối phương (Incoming - Luôn nằm căn bên trái màn hình):
            // Mép trái thường cách cạnh trái màn hình từ 2% đến 38% (chừa chỗ cho avatar đối phương)
            val isOtherPartyIncoming = !isMyOutgoing && (rect.left < (screenW * 0.42f))

            if (isMyOutgoing) {
                outgoingNodes.add(node)
            } else if (isOtherPartyIncoming) {
                incomingNodes.add(node)
            }
        }

        // Chọn tập ứng viên: ƯU TIÊN TUYỆT ĐỐI tin nhắn đối phương bên trái (incomingNodes).
        // Nếu trống, chỉ tìm các node bên TRÁI nằm trong khung hội thoại để không đọc nhầm nút bấm hay tin của mình!
        val rawCandidates = if (incomingNodes.isNotEmpty()) {
            incomingNodes
        } else {
            val leftSidedCandidates = validConversationNodes.filter { node ->
                node.boundsInScreen.left < (screenW * 0.45f) &&
                node.boundsInScreen.right < (screenW * 0.88f)
            }
            val foreignLeftNodes = leftSidedCandidates.filter { node ->
                node.text.any { it.code in 0x4E00..0x9FFF || it.code in 0x3040..0x30FF || it.code in 0xAC00..0xD7AF || it.code in 0x0E00..0x0E7F }
            }
            if (foreignLeftNodes.isNotEmpty()) foreignLeftNodes else leftSidedCandidates
        }

        // LỌC BỎ 100% CÁC NODE AVATAR / ICON LỌT VÀO DANH SÁCH ỨNG VIÊN
        val candidateNodes = rawCandidates.filterNot { n ->
            val t = n.text.trim().lowercase()
            t.contains("hình đại diện") ||
            t.contains("ảnh đại diện") ||
            t == "avatar" || t.startsWith("avatar ") ||
            t.contains("profile picture") ||
            t.contains("user avatar") ||
            t == "头像" || t.contains("用户头像") ||
            t == "quay lại" || t == "back" || t == "gửi" || t == "send" ||
            t == "tin nhắn thoại" || t == "nhãn dán" || t == "sticker"
        }

        if (candidateNodes.isEmpty()) {
            return IncomingChatExtractionResult("", detectedComposerTopY)
        }

        // 5. Sắp xếp tin nhắn từ dưới lên trên (bottom lớn nhất = tin nhắn gần nhất/mới nhất ở dưới đáy khung chat)
        val sortedIncomingBottomUp = candidateNodes.sortedWith(
            compareByDescending<NoAccessibilityScreenEngine.ScreenTextNode> { it.boundsInScreen.bottom }
                .thenByDescending { it.boundsInScreen.top }
        )

        val latestIncoming = sortedIncomingBottomUp.first()
        val clusteredNodes = mutableListOf(latestIncoming)
        var currentClusterTop = latestIncoming.boundsInScreen.top
        val clusterBottom = latestIncoming.boundsInScreen.bottom
        var totalChars = latestIncoming.text.length

        // 6. Gộp toàn bộ các dòng/đoạn chữ thuộc cùng một bong bóng tin nhắn của đối phương:
        // - Khoảng cách dọc giữa các dòng tin nhắn trong cùng bubble có thể từ 0px đến 4.5% chiều cao màn hình (~40-90px tuỳ font/line-height/ngắt dòng)
        // - Độ lệch mép trái lề tin nhắn cho phép sai lệch tối đa 16% chiều rộng màn hình (do thụt đầu dòng, icon hoặc căn lề bubble)
        // - Không giới hạn cứng ở 2 node để đảm bảo dịch trọn vẹn cả câu/đoạn văn dài mà không bị sót chữ!
        // - Dừng lại ngay lập tức nếu gặp tin nhắn gửi đi (outgoing) của chính mình nằm chen giữa.
        // Chỉ gom các dòng thuộc CÙNG MỘT BONG BÓNG TIN NHẮN mà người dùng vừa cuộn tới (không gom tin cũ ở trên)
        val maxSameBubbleGapPx = (screenH * 0.028f).toInt().coerceIn(24, 75)
        val maxLeftMarginDiffPx = (screenW * 0.08f).toInt().coerceIn(20, 60)
        for (idx in 1 until sortedIncomingBottomUp.size) {
            if (clusteredNodes.size >= 12) break
            val candidate = sortedIncomingBottomUp[idx]
            val candRect = candidate.boundsInScreen
            val candText = candidate.text.trim()
            if (candText.isBlank()) continue

            val verticalGap = currentClusterTop - candRect.bottom
            // Nếu khoảng cách giữa 2 dòng vượt quá chiều cao dòng thông thường -> đã sang bong bóng tin nhắn khác phía trên
            if (verticalGap > maxSameBubbleGapPx || verticalGap < -16) break

            val leftDiff = kotlin.math.abs(candRect.left - latestIncoming.boundsInScreen.left)
            if (leftDiff > maxLeftMarginDiffPx) break

            val hasOutgoingInBetween = outgoingNodes.any { outNode ->
                outNode.boundsInScreen.bottom > candRect.top && outNode.boundsInScreen.top < clusterBottom
            }
            if (hasOutgoingInBetween) break

            if (totalChars + candText.length > 1200) break

            clusteredNodes.add(candidate)
            currentClusterTop = minOf(currentClusterTop, candRect.top)
            totalChars += candText.length
        }

        // Sắp xếp lại các dòng trong cùng bong bóng tin nhắn mới nhất theo thứ tự đọc chuẩn từ trên xuống dưới, trái sang phải
        val orderedCluster = clusteredNodes.sortedWith(
            compareBy<NoAccessibilityScreenEngine.ScreenTextNode> { it.boundsInScreen.top }
                .thenBy { it.boundsInScreen.left }
        )

        val combinedLines = mutableListOf<String>()
        for (node in orderedCluster) {
            node.text.lines()
                .map { it.trim() }
                .filter { line ->
                    val lowerLine = line.lowercase()
                    line.isNotBlank() &&
                        !timeDateRegex.matches(line) &&
                        !systemStatusRegex.matches(line) &&
                        !quickActionChipRegex.matches(line) &&
                        !avatarAndUiIconRegex.matches(line) &&
                        !lowerLine.contains("hình đại diện") &&
                        !lowerLine.contains("ảnh đại diện") &&
                        !lowerLine.contains("avatar") &&
                        !lowerLine.contains("profile picture") &&
                        !lowerLine.contains("头像")
                }
                .forEach { cleanLine ->
                    if (combinedLines.lastOrNull() != cleanLine) {
                        combinedLines.add(cleanLine)
                    }
                }
        }

        val finalMessage = combinedLines.joinToString("\n").trim()
        return IncomingChatExtractionResult(finalMessage, detectedComposerTopY)
    }

    private fun extractLatestOtherPartyMessageText(
        nodes: List<NoAccessibilityScreenEngine.ScreenTextNode>,
        screenW: Int,
        screenH: Int
    ): String {
        return extractSmartLatestIncomingChatContext(nodes, emptyList(), screenW, screenH).latestMessageText
    }

    fun translateCurrentScreenForeignText(context: Context) {
        val appCtx = context.applicationContext
        activeVoiceJob?.cancel()
        activeVoiceJob = overlayScope.launch(Dispatchers.Main) {
            // Ngắt hoàn toàn mọi luồng thu âm / phát âm của Trợ lý Magic để không bao giờ nhận nhầm lệnh từ voice
            stopSpeakingImmediately()
            pauseCurrentTurnCaptureOnly()
            isRecordingMic = false
            forceFinishRecordingNow = false

            val (keyAllowed, keyReminderMsg) = LicenseManager.checkMagicLiveAiKeyRequirement(appCtx)
            if (!keyAllowed) {
                setVoiceCancelButtonVisible(false)
                personalKeyPanelContainer?.visibility = View.VISIBLE
                updatePersonalKeyUiState(appCtx)
                statusTitleView?.text = "🔑 Cần thêm Key Gemini + Groq cá nhân hoặc Nâng cấp PRO"
                micActionBtn?.text = "🔑 Thêm Key AI"
                waveVisualizerView?.setMode(listening = false, speaking = false)
                updateOrAppendMagicLiveReplyBubble(appCtx, null, keyReminderMsg)
                return@launch
            }

            statusTitleView?.text = "🌐 Đang định vị & dịch tin nhắn gần nhất của đối phương..."
            transcriptTextView?.text = "🌐 Dịch tin nhắn đối phương"
            micActionBtn?.text = "⏳ Đang dịch..."
            waveVisualizerView?.setMode(listening = false, speaking = false)
            setCompactTranslationMode(appCtx, true)
            customKeyboardContainer?.visibility = View.GONE
            isKeyboardElevated = false
            manualTextInput?.clearFocus()
            val imm = appCtx.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.hideSoftInputFromWindow(manualTextInput?.windowToken, 0)
            
            // Đảm bảo bàn phím không tự động bật lại trong quá trình dịch
            hasImeActuallyAppeared = false

            // 1. Ẩn thẻ nổi và đợi để hệ thống Android hoàn tất trả Focus và render sau khi người dùng cuộn
            clearAttachment(appCtx)
            rootContainer?.alpha = 0f
            rootContainer?.visibility = View.INVISIBLE

            try {
                val cr = appCtx.contentResolver
                Settings.Secure.putInt(cr, "assist_structure_enabled", 1)
                Settings.Secure.putInt(cr, "assist_screenshot_enabled", 1)
                Settings.Secure.putInt(cr, "assist_disclosure_enabled", 1)
            } catch (_: Throwable) {}

            // Xóa triệt để cache node cũ và chờ 220ms để hệ thống Accessibility cập nhật cây giao diện mới nhất
            NoAccessibilityScreenEngine.clearCachedScreenNodes()
            kotlinx.coroutines.delay(220L)

            val (screenshotBase64, targetOtherPartyMsg, foregroundAppLabel, hasVisibleNodes, isChatScreen) = try {
                com.example.core.service.MagicTuneCtsAccessibilityService.beginTemporaryBurst(4000L)
                NoAccessibilityScreenEngine.autoWakeAccessibilityIfNeeded(appCtx, 1300L)
                if (!com.example.core.service.MagicTuneCtsAccessibilityService.isServiceConnected()) {
                    com.example.core.service.MagicTuneCtsAccessibilityService.awaitServiceInstance(appCtx, 650L)
                }

                withContext(Dispatchers.IO) {
                val fgApp = NoAccessibilityScreenEngine.getActiveForegroundAppLabel(appCtx)

                val uiRecords = try {
                    NoAccessibilityScreenEngine.extractFullUiRecordsNow(appCtx)
                } catch (_: Throwable) { emptyList() }

                var nodes = try {
                    NoAccessibilityScreenEngine.extractVisibleScreenNodesNow(appCtx)
                } catch (_: Throwable) { emptyList() }

                if (nodes.isEmpty()) {
                    nodes = GoogleScreenTranslator.extractNodesViaUiAutomatorFallback(appCtx)
                }

                val hasNodesOnScreen = nodes.isNotEmpty()

                val dm = appCtx.resources.displayMetrics
                val extraction = extractSmartLatestIncomingChatContext(
                    nodes = nodes,
                    uiRecords = uiRecords,
                    screenW = dm.widthPixels,
                    screenH = dm.heightPixels
                )
                var targetMsg = extraction.latestMessageText

                // Fallback nếu extraction chưa bắt được: chỉ tìm trong các node bên TRÁI nằm hoàn toàn phía trên Composer
                if (targetMsg.isBlank() && nodes.isNotEmpty()) {
                    val conversationCandidates = nodes.filter { node ->
                        val r = node.boundsInScreen
                        val t = node.text.trim()
                        r.top >= (dm.heightPixels * 0.12f).toInt() &&
                        r.bottom < extraction.composerTopY &&
                        r.left < (dm.widthPixels * 0.45f) &&
                        r.right < (dm.widthPixels * 0.88f) &&
                        t.length >= 2 && !t.all { it.isDigit() || it in ":./-+%✓✔ " }
                    }
                    val foreignCandidate = conversationCandidates.lastOrNull { node ->
                        val t = node.text.trim()
                        t.any { it.code in 0x4E00..0x9FFF || it.code in 0x3040..0x30FF || it.code in 0xAC00..0xD7AF || it.code in 0x0E00..0x0E7F }
                    } ?: conversationCandidates.lastOrNull()

                    if (foreignCandidate != null) {
                        targetMsg = foreignCandidate.text.trim()
                    }
                }

                // Khi ứng dụng chat vẽ bằng Canvas/Hình ảnh/WebView không lộ node văn bản, chụp và cắt chính xác vùng khung chat bên trái ngay trên thanh nhập liệu
                val base64Str = if (targetMsg.isBlank()) {
                    var bmp = com.example.core.assistant.MagicTuneVoiceInteractionService.lastCapturedAssistBitmap?.takeIf { !it.isRecycled }
                        ?: NoAccessibilityScreenEngine.captureScreenOffline(appCtx)
                    if (bmp == null) {
                        try {
                            val shell = ShellEngine.getInstance(appCtx)
                            if (shell.state.value.isAdbReady) {
                                val shotFile = java.io.File("/data/local/tmp/magic_live_screen_capture.png")
                                if (shotFile.exists()) shotFile.delete()
                                shell.execute("screencap -p /data/local/tmp/magic_live_screen_capture.png && chmod 666 /data/local/tmp/magic_live_screen_capture.png")
                                if (shotFile.exists() && shotFile.length() > 1024L) {
                                    bmp = android.graphics.BitmapFactory.decodeFile(shotFile.absolutePath)
                                }
                                try { shotFile.delete() } catch (_: Throwable) {}
                                shell.execute("rm -f /data/local/tmp/magic_live_screen_capture.png")
                            }
                        } catch (_: Throwable) {}
                    }
                    if (bmp != null) {
                        try {
                            val w = bmp.width
                            val h = bmp.height
                            val scaleY = h.toFloat() / dm.heightPixels.coerceAtLeast(1).toFloat()
                            val cropX = 0
                            val cropY = (h * 0.135f).toInt().coerceIn(0, h - 1)
                            val cropW = (w * 0.86f).toInt().coerceIn(1, w - cropX)
                            val dynamicBottomPx = (extraction.composerTopY * scaleY).toInt().coerceIn(cropY + 100, (h * 0.885f).toInt())
                            val cropH = (dynamicBottomPx - cropY).coerceIn(1, h - cropY)
                            val cropped = Bitmap.createBitmap(bmp, cropX, cropY, cropW, cropH)
                            val maxDim = 1024
                            val scaled = if (cropped.width > maxDim || cropped.height > maxDim) {
                                val ratio = if (cropped.width > cropped.height) maxDim.toFloat() / cropped.width else maxDim.toFloat() / cropped.height
                                Bitmap.createScaledBitmap(cropped, (cropped.width * ratio).toInt(), (cropped.height * ratio).toInt(), true)
                            } else cropped
                            val baos = ByteArrayOutputStream()
                            scaled.compress(Bitmap.CompressFormat.JPEG, 82, baos)
                            val encoded = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
                            if (scaled !== cropped) scaled.recycle()
                            if (cropped !== bmp) cropped.recycle()
                            bmp.recycle()
                            encoded
                        } catch (_: Throwable) { null }
                    } else null
                } else null

                // Giữ dịch vụ hoạt động liên tục, không tắt khi rảnh để luôn đọc được màn hình
                val isChat = isLikelyChatOrSocialScreen(nodes = nodes, uiRecords = uiRecords, screenW = dm.widthPixels, screenH = dm.heightPixels)
                data class ChatTranslateContext(
                    val base64Str: String?,
                    val targetMsg: String,
                    val fgApp: String,
                    val hasNodes: Boolean,
                    val isChat: Boolean
                )
                ChatTranslateContext(base64Str, targetMsg, fgApp, hasNodesOnScreen, isChat)
                }
            } finally {
                // TẮT NGẦM TRỢ NĂNG NGAY LẬP TỨC (~150ms) sau khi trích xuất xong cây cấu trúc & chụp màn hình!
                // Tuyệt đối không đợi API AI dịch xong qua Internet (2-5s) để chống 100% app ngân hàng quét thấy
                com.example.core.service.MagicTuneCtsAccessibilityService.endTemporaryBurstAndIdle(appCtx, 150L)

                // 2. Hiện lại cửa sổ nổi (Đảm bảo 100% không bao giờ kẹt tàng hình nếu có lỗi)
                rootContainer?.visibility = View.VISIBLE
                rootContainer?.alpha = 1f
            }

            if (!isActive || !isShowing) return@launch

            if (targetOtherPartyMsg.isNotBlank()) {
                val appBadge = if (foregroundAppLabel.isNotBlank()) " ($foregroundAppLabel)" else ""
                transcriptTextView?.text = "🌐 Tin nhắn đối phương$appBadge:\n\"$targetOtherPartyMsg\""
            }

            val translationSystemPrompt = """
                Bạn là Gemini, chuyên gia phân tích màn hình và dịch thuật tin nhắn của Google.
                NHIỆM VỤ BẮT BUỘC:
                1. PHÂN TÍCH KỸ MÀN HÌNH và các câu tin nhắn của đối phương (các bong bóng tin nhắn ở phía bên trái / nhận được từ người đối thoại).
                2. DỊCH CHÍNH XÁC VÀ ĐẦY ĐỦ 100% toàn bộ nội dung tin nhắn của đối phương sang Tiếng Việt tự nhiên, trôi chảy, đúng ngữ cảnh giao tiếp.
                3. TUYỆT ĐỐI KHÔNG ĐƯỢC ĐỌC THIẾU, không được tóm tắt, không được cắt ngắn hay bỏ bớt bất kỳ câu chữ, số lượng, giá tiền hay chi tiết nào.
                4. TUYỆT ĐỐI KHÔNG đọc thêm lời giải thích, không thêm tiền tố như 'Họ nhắn là', không đọc tên tài khoản, thời gian hay nút bấm UI. Chỉ xuất ra duy nhất toàn bộ nội dung đã dịch sang Tiếng Việt.
            """.trimIndent()

            val userPrompt = if (targetOtherPartyMsg.isNotBlank()) {
                "Dưới đây là toàn bộ nội dung tin nhắn của đối phương trên màn hình:\n\"$targetOtherPartyMsg\"\n\nHãy đối chiếu ảnh màn hình để hiểu đúng ngữ cảnh và dịch CHÍNH XÁC, ĐẦY ĐỦ 100% toàn bộ tin nhắn trên sang Tiếng Việt (chỉ trả về nội dung Tiếng Việt đã dịch, tuyệt đối không đọc thiếu chữ nào):"
            } else {
                "Hãy quan sát kỹ màn hình cuộc trò chuyện và tìm các tin nhắn của đối phương ở phía bên trái: nếu trên màn hình KHÔNG có tin nhắn nào của đối phương, hãy trả về 'KHONG_CO_TIN_NHAN'. Nếu có, hãy dịch CHÍNH XÁC VÀ ĐẦY ĐỦ 100% toàn bộ nội dung tin nhắn đó sang Tiếng Việt tự nhiên, tuyệt đối không được đọc thiếu."
            }

            statusTitleView?.text = "🌐 Gemini đang dịch tin nhắn..."
            micActionBtn?.text = "⏳ Đang dịch..."

            val rawAiAnswer = withContext(Dispatchers.IO) {
                callGroqForScreenOrTranslation(
                    context = appCtx,
                    systemInstruction = translationSystemPrompt,
                    userPrompt = userPrompt,
                    screenshotBase64 = screenshotBase64,
                    screenTextSummary = targetOtherPartyMsg,
                    foregroundAppLabel = foregroundAppLabel,
                    maxTokens = 1024,
                    isTranslationOnly = true
                )
            }.trim()

            if (!isActive || !isShowing) return@launch

            // Tuyệt đối KHÔNG gọi MagicLiveActionExecutor để đảm bảo Dịch tin nhắn hoàn toàn tách biệt với Voice Command
            val cleanAiAnswer = if (targetOtherPartyMsg.isNotBlank()) {
                val groqOrGeminiAnswer = sanitizeTranslationOutput(rawAiAnswer)
                if (groqOrGeminiAnswer.isNotBlank() && !groqOrGeminiAnswer.contains("⚠️")) {
                    if (groqOrGeminiAnswer.contains("KHONG_CO_TIN_NHAN")) {
                        "Trên màn hình đang không có tin nhắn nào của đối phương để dịch. Bạn hãy mở cuộc trò chuyện cần dịch nhé!"
                    } else {
                        groqOrGeminiAnswer
                    }
                } else {
                    // Fallback bản dịch tiếng Việt trực tiếp từ Google Translator
                    GoogleScreenTranslator.translateChatMessageNaturally(targetOtherPartyMsg).ifBlank {
                        groqOrGeminiAnswer.ifBlank { "Đã nhận tin nhắn: \"$targetOtherPartyMsg\"" }
                    }
                }
            } else if (rawAiAnswer.contains("KHONG_CO_TIN_NHAN") || !isChatScreen || targetOtherPartyMsg.isBlank()) {
                "Trên màn hình đang không có tin nhắn nào. Bạn hãy mở cuộc trò chuyện cần dịch nhé!"
            } else if (hasVisibleNodes) {
                "Trên màn hình đang không có tin nhắn nào của đối phương để dịch."
            } else {
                "⚠️ Không thể đọc nội dung màn hình. Vui lòng kiểm tra lại quyền đọc màn hình nhé!"
            }

            var purifiedAnswer = cleanAiAnswer
                .replace(Regex("""(?i)^(đối phương nhắn là|họ nhắn là|tin nhắn đối phương|bản dịch|dịch|nội dung tin nhắn|nghĩa là)[:\s\-"']+"""), "")
                .replace(Regex("""(?i)(hình đại diện|ảnh đại diện|avatar|profile picture|user avatar|头像)"""), "")
                .replace(Regex("""(?i)^["'“‘]+|["'”’]+$"""), "")
                .trim()

            if (purifiedAnswer.isBlank() || purifiedAnswer.equals("hình đại diện", ignoreCase = true) || purifiedAnswer.equals("avatar", ignoreCase = true)) {
                purifiedAnswer = if (targetOtherPartyMsg.isNotBlank() && !targetOtherPartyMsg.contains("hình đại diện", ignoreCase = true)) {
                    GoogleScreenTranslator.translateChatMessageNaturally(targetOtherPartyMsg)
                } else {
                    "Trên màn hình đang không có tin nhắn nào của đối phương để dịch. Bạn hãy cuộn đến tin nhắn cần dịch nhé!"
                }
            }

            val formattedDisplay = if (targetOtherPartyMsg.isNotBlank()) {
                "💬 Tin nhắn đối phương:\n\"$targetOtherPartyMsg\"\n\n👉 Bản dịch Tiếng Việt:\n$purifiedAnswer"
            } else {
                purifiedAnswer
            }
            val transUserBubbleText = if (targetOtherPartyMsg.isNotBlank()) {
                "🌐 Dịch tin nhắn đối phương:\n\"$targetOtherPartyMsg\""
            } else {
                "🌐 Dịch tin nhắn gần nhất trên màn hình"
            }
            appendUserChatBubble(appCtx, transUserBubbleText)
            updateOrAppendMagicLiveReplyBubble(appCtx, null, purifiedAnswer)
            // Tự động tắt ngầm Trợ năng sau khi phân tích xong để không bị app ngân hàng phát hiện
            NoAccessibilityScreenEngine.disableServiceIfIdle(appCtx, 400L)

            if (isAiVoiceMuted) {
                statusTitleView?.text = "🌐 Đã dịch xong tin nhắn (Đang tắt tiếng 🔇)"
                micActionBtn?.text = "🎙️ Bấm để nói"
                waveVisualizerView?.setMode(listening = false, speaking = false)
            } else {
                statusTitleView?.text = "🌐 Đã dịch xong • Bấm vào nút bên dưới nếu muốn nói"
                micActionBtn?.text = "🎙️ Bấm để nói"
                waveVisualizerView?.setMode(listening = false, speaking = true)

                val speechToRead = GoogleScreenTranslator.formatTranslationForNaturalVietnameseSpeech(purifiedAnswer)

                speakVietnameseResponse(appCtx, speechToRead) {
                    if (isShowing) {
                        mainHandler.post {
                            isRecordingMic = false
                            statusTitleView?.text = "Sẵn sàng • Bấm vào nút bên dưới để nói"
                            micActionBtn?.text = "🎙️ Bấm để nói"
                            waveVisualizerView?.setMode(listening = false, speaking = false)
                        }
                    }
                }
            }
        }
    }

    fun askAboutCurrentScreen(context: Context) {
        val appCtx = context.applicationContext
        activeVoiceJob?.cancel()
        activeVoiceJob = overlayScope.launch(Dispatchers.Main) {
            // Ngắt hoàn toàn mọi luồng thu âm / giọng nói để tính năng Hỏi về màn hình hoạt động độc lập 100% với Trợ lý Magic
            stopSpeakingImmediately()
            pauseCurrentTurnCaptureOnly()
            isRecordingMic = false
            forceFinishRecordingNow = false

            val (keyAllowed, keyReminderMsg) = LicenseManager.checkMagicLiveAiKeyRequirement(appCtx)
            if (!keyAllowed) {
                setVoiceCancelButtonVisible(false)
                personalKeyPanelContainer?.visibility = View.VISIBLE
                updatePersonalKeyUiState(appCtx)
                statusTitleView?.text = "🔑 Cần thêm Key Gemini + Groq cá nhân hoặc Nâng cấp PRO"
                micActionBtn?.text = "🔑 Thêm Key AI"
                waveVisualizerView?.setMode(listening = false, speaking = false)
                updateOrAppendMagicLiveReplyBubble(appCtx, null, keyReminderMsg)
                return@launch
            }

            statusTitleView?.text = "📸 Đang chụp & đọc trang màn hình hiện tại..."
            transcriptTextView?.text = "✨ Hỏi về màn hình hiện tại (Độc lập với Voice)"
            micActionBtn?.text = "⏳ Đang chụp màn hình..."
            waveVisualizerView?.setMode(listening = false, speaking = false)

            // 1. Ẩn hoàn toàn cửa sổ nổi (INVISIBLE + alpha = 0f) và đợi 240ms để hệ thống trả Focus và cập nhật đúng cửa sổ ứng dụng phía dưới
            clearAttachment(appCtx)
            rootContainer?.alpha = 0f
            rootContainer?.visibility = View.INVISIBLE

            try {
                val cr = appCtx.contentResolver
                Settings.Secure.putInt(cr, "assist_structure_enabled", 1)
                Settings.Secure.putInt(cr, "assist_screenshot_enabled", 1)
                Settings.Secure.putInt(cr, "assist_disclosure_enabled", 1)
            } catch (_: Throwable) {}

            NoAccessibilityScreenEngine.clearCachedScreenNodes()
            kotlinx.coroutines.delay(240L)

            val (screenshotBase64, screenTextSummary, foregroundAppLabel) = try {
                com.example.core.service.MagicTuneCtsAccessibilityService.beginTemporaryBurst(4000L)
                NoAccessibilityScreenEngine.autoWakeAccessibilityIfNeeded(appCtx, 1300L)
                if (!com.example.core.service.MagicTuneCtsAccessibilityService.isServiceConnected()) {
                    com.example.core.service.MagicTuneCtsAccessibilityService.awaitServiceInstance(appCtx, 650L)
                }

                withContext(Dispatchers.IO) {
                val fgApp = NoAccessibilityScreenEngine.getActiveForegroundAppLabel(appCtx)

                var bmp = com.example.core.assistant.MagicTuneVoiceInteractionService.lastCapturedAssistBitmap?.takeIf { !it.isRecycled }
                    ?: NoAccessibilityScreenEngine.captureScreenOffline(appCtx)
                if (bmp == null) {
                    try {
                        val shell = ShellEngine.getInstance(appCtx)
                        if (shell.state.value.isAdbReady) {
                            val shotFile = java.io.File("/data/local/tmp/magic_live_screen_capture.png")
                            if (shotFile.exists()) shotFile.delete()
                            shell.execute("screencap -p /data/local/tmp/magic_live_screen_capture.png && chmod 666 /data/local/tmp/magic_live_screen_capture.png")
                            if (shotFile.exists() && shotFile.length() > 1024L) {
                                bmp = android.graphics.BitmapFactory.decodeFile(shotFile.absolutePath)
                            }
                            try { shotFile.delete() } catch (_: Throwable) {}
                            shell.execute("rm -f /data/local/tmp/magic_live_screen_capture.png")
                        }
                    } catch (_: Throwable) {}
                }

                val base64Str = if (bmp != null) {
                    try {
                        val maxDim = 1280
                        val w = bmp.width
                        val h = bmp.height
                        val scaled = if (w > maxDim || h > maxDim) {
                            val ratio = if (w > h) maxDim.toFloat() / w else maxDim.toFloat() / h
                            Bitmap.createScaledBitmap(bmp, (w * ratio).toInt(), (h * ratio).toInt(), true)
                        } else bmp
                        val baos = ByteArrayOutputStream()
                        scaled.compress(Bitmap.CompressFormat.JPEG, 80, baos)
                        val encoded = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
                        if (scaled !== bmp) scaled.recycle()
                        bmp.recycle()
                        encoded
                    } catch (_: Throwable) { null }
                } else null

                var nodes = try {
                    NoAccessibilityScreenEngine.extractVisibleScreenNodesNow(appCtx)
                } catch (_: Throwable) { emptyList() }
                if (nodes.isEmpty() && NoAccessibilityScreenEngine.lastCapturedScreenNodes.isNotEmpty()) {
                    nodes = NoAccessibilityScreenEngine.lastCapturedScreenNodes
                }

                val dm = appCtx.resources.displayMetrics
                val screenH = dm.heightPixels.coerceAtLeast(1)
                val screenW = dm.widthPixels.coerceAtLeast(1)

                val headerNodes = mutableListOf<String>()
                val mainContentNodes = mutableListOf<String>()
                val priceAndActionNodes = mutableListOf<String>()

                for (n in nodes) {
                    val t = n.text.trim()
                    if (t.length < 2) continue
                    val r = n.boundsInScreen
                    val isPriceOrCurrency = t.any { it in "¥￥$₩€£฿元円원" } || t.contains("đ", ignoreCase = true) || t.contains("vnd", ignoreCase = true)

                    if (r.top < screenH * 0.15f) {
                        headerNodes.add(t)
                    } else if (isPriceOrCurrency || r.top > screenH * 0.82f) {
                        priceAndActionNodes.add(t)
                    } else {
                        mainContentNodes.add(t)
                    }
                }

                val structuredSummary = buildString {
                    if (fgApp.isNotBlank()) append("Ứng dụng: ").append(fgApp).append("\n")
                    if (headerNodes.isNotEmpty()) {
                        append("Tiêu đề/Thanh trên: ").append(headerNodes.distinct().take(5).joinToString(" | ")).append("\n")
                    }
                    if (priceAndActionNodes.isNotEmpty()) {
                        append("Giá cả/Hành động: ").append(priceAndActionNodes.distinct().take(6).joinToString(" | ")).append("\n")
                    }
                    if (mainContentNodes.isNotEmpty()) {
                        append("Nội dung chính: ").append(mainContentNodes.distinct().take(40).joinToString(" | "))
                    }
                }.trim()

                Triple(base64Str, structuredSummary, fgApp)
                }
            } finally {
                com.example.core.service.MagicTuneCtsAccessibilityService.endTemporaryBurstAndIdle(appCtx, 150L)

                // 2. Hiện lại cửa sổ nổi (Đảm bảo 100% không bao giờ kẹt tàng hình nếu có lỗi)
                rootContainer?.visibility = View.VISIBLE
                rootContainer?.alpha = 1f
            }

            if (!isActive || !isShowing) return@launch

            val screenSystemPrompt = """
                Bạn là Gemini, trợ lý AI thông minh quan sát và hiểu màn hình của Google.
                NHIỆM VỤ:
                Quan sát ảnh chụp màn hình và dữ liệu cấu trúc văn bản để trả lời CHÍNH XÁC, NGẮN GỌN (1-2 câu, tối đa 30 từ) xem người dùng đang xem cái gì.

                QUY TẮC BẮT BUỘC:
                1. Hiểu đúng ngữ cảnh thực tế:
                   - Nếu là app mua sắm (Taobao, 1688, Shopee, TikTok Shop...): Báo tên sản phẩm chính đang hiển thị và giá tiền cụ thể.
                   - Nếu là app chat (Zalo, Messenger, WeChat...): Báo đang nhắn tin với ai và nội dung/trạng thái tin nhắn mới nhất.
                   - Nếu là mạng xã hội/video (Facebook, TikTok, YouTube...): Báo đang xem video/bài viết gì, của ai.
                   - Nếu là bài báo/tin tức/web: Tóm tắt 1 câu tiêu đề nội dung bài viết.
                   - Nếu là Cài đặt/Màn hình chính: Nêu rõ đang ở mục cài đặt nào.
                2. TUYỆT ĐỐI KHÔNG đọc liệt kê lung tung các dòng chữ vụn vặt, không đọc nút bấm hệ thống.
                3. TUYỆT ĐỐI KHÔNG trả lời chung chung mơ hồ ("Tôi thấy một màn hình ứng dụng...").
                4. Chỉ trả về trực tiếp câu trả lời bằng tiếng Việt tự nhiên, không chào hỏi rườm rà.
            """.trimIndent()

            val userPrompt = "Nhìn vào ảnh chụp và dữ liệu màn hình, hãy cho tôi biết chính xác tôi đang xem nội dung gì trên màn hình này? (Chỉ trả lời trọng tâm trong 1-2 câu ngắn gọn)"

            statusTitleView?.text = "✨ Gemini đang phân tích màn hình..."
            micActionBtn?.text = "⏳ Đang phân tích..."

            val rawAiAnswer = withContext(Dispatchers.IO) {
                callGroqForScreenOrTranslation(
                    context = appCtx,
                    systemInstruction = screenSystemPrompt,
                    userPrompt = userPrompt,
                    screenshotBase64 = screenshotBase64,
                    screenTextSummary = screenTextSummary,
                    foregroundAppLabel = foregroundAppLabel,
                    maxTokens = 1200
                )
            }.trim()

            if (!isActive || !isShowing) return@launch

            // Tuyệt đối KHÔNG gọi MagicLiveActionExecutor để đảm bảo Hỏi về màn hình tách biệt 100% với lệnh Voice
            val cleanAiAnswer = cleanConversationOutput(rawAiAnswer)
                .replace(Regex("\\[[A-Z_]+(?::[^\\]]*)?\\]"), "")
                .trim()

            MagicLiveBrainMemory.recordConversationTurn(
                context = appCtx,
                userQuery = "Hỏi về màn hình hiện tại",
                assistantReply = cleanAiAnswer,
                screenOrCircleContext = screenTextSummary,
                appName = foregroundAppLabel
            )

            val screenShotThumb = if (!screenshotBase64.isNullOrBlank()) {
                withContext(Dispatchers.IO) { decodeDisplayBitmap(screenshotBase64, null) }
            } else null
            val screenQuestionLabel = if (foregroundAppLabel.isNotBlank()) {
                "📸 Trên màn hình $foregroundAppLabel hiện tại là gì?"
            } else {
                "📸 Trên màn hình hiện tại là gì?"
            }
            appendUserChatBubble(
                context = appCtx,
                text = screenQuestionLabel,
                imageBitmap = screenShotThumb,
                imageCaption = if (foregroundAppLabel.isNotBlank()) "Màn hình $foregroundAppLabel" else "Ảnh màn hình hiện tại"
            )
            updateOrAppendMagicLiveReplyBubble(appCtx, null, cleanAiAnswer)
            // Cơ chế On-Demand: Tự động tắt quyền ngầm sau khi xong
            NoAccessibilityScreenEngine.disableServiceIfIdle(appCtx, 400L)

            if (isAiVoiceMuted) {
                statusTitleView?.text = "✨ Đã phân tích màn hình (Đang tắt tiếng 🔇)"
                micActionBtn?.text = "🎙️ Bấm để nói"
                waveVisualizerView?.setMode(listening = false, speaking = false)
            } else {
                statusTitleView?.text = "🔊 Đang đọc tóm tắt màn hình hiện tại..."
                micActionBtn?.text = "🎙️ Bấm để nói"
                waveVisualizerView?.setMode(listening = false, speaking = true)

                speakVietnameseResponse(appCtx, cleanAiAnswer) {
                    if (isShowing) {
                        mainHandler.post {
                            isRecordingMic = false
                            statusTitleView?.text = "Sẵn sàng • Bấm vào nút bên dưới để nói"
                            micActionBtn?.text = "🎙️ Bấm để nói"
                            waveVisualizerView?.setMode(listening = false, speaking = false)
                        }
                    }
                }
            }
        }
    }

    /**
     * KHOANH MÀN HÌNH HỎI MAGIC LIVE (Circle Screen to Ask MagicLive):
     * - Bắt đầu một phiên trò chuyện mới hoàn toàn độc lập cho vùng màn hình vừa khoanh (không bị lẫn với cuộc trò chuyện cũ).
     * - Kết hợp chính xác 3 nguồn dữ liệu đọc màn hình:
     *   1. Văn bản đọc trực tiếp từ cây cấu trúc màn hình trong & quanh vùng khoanh (`primaryExtractedText` + `candidatePhrases`).
     *   2. Văn bản OCR đọc trực tiếp từ điểm ảnh của vùng ảnh vừa cắt (`ocrTextFromCroppedBitmap`).
     *   3. Hình ảnh thực tế của vùng vừa khoanh (`croppedBase64Jpeg`) + Ngữ cảnh ứng dụng đang mở (`foregroundAppLabel`, `surroundingScreenSummary`).
     * - Tự động phân tích và giải đáp kiến thức sâu sắc về hình ảnh/nội dung vừa khoanh, đồng thời lưu vào Bộ Não MagicLive (`MagicLiveBrainMemory`).
     */
    fun askMagicLiveAboutCircledScreenRegion(
        context: Context,
        croppedBase64Jpeg: String?,
        croppedImageFile: File?,
        primaryExtractedText: String,
        candidatePhrases: List<String>,
        ocrTextFromCroppedBitmap: String,
        surroundingScreenSummary: String,
        foregroundAppLabel: String,
        languageBadge: String = ""
    ): Boolean {
        val appCtx = context.applicationContext ?: context
        prewarmGroqConnection()

        val isFollowUpInExistingSession = pendingFollowUpCircleFromMagicLive &&
            synchronized(chatBubblesLock) { activeChatBubbles.isNotEmpty() }
        pendingFollowUpCircleFromMagicLive = false
        preserveBubblesOnCircleDismiss = false

        val hasCroppedImage = !croppedBase64Jpeg.isNullOrBlank()
        // Khi khoanh vùng có ảnh: KHÔNG gửi kèm văn bản/OCR trích xuất để AI ưu tiên đọc & hiểu trực tiếp hình ảnh 100%
        val richCircleContext = if (hasCroppedImage) {
            ""
        } else {
            buildString {
                if (foregroundAppLabel.isNotBlank()) {
                    append("Ứng dụng: ").append(foregroundAppLabel).append("\n")
                }
                if (primaryExtractedText.isNotBlank()) {
                    append(primaryExtractedText).append("\n")
                }
                if (surroundingScreenSummary.isNotBlank()) {
                    append(surroundingScreenSummary.take(300))
                }
            }.trim()
        }

        val followUpHistory = if (isFollowUpInExistingSession) {
            MagicLiveBrainMemory.getActiveSessionMessages(6)
        } else {
            emptyList()
        }

        if (isFollowUpInExistingSession) {
            // Tiếp nối phiên trò chuyện đang diễn ra để hỏi tiếp về ảnh vừa khoanh
            MagicLiveBrainMemory.updateActiveCircledScreenContext(richCircleContext)
        } else {
            // Mở mới từ bên ngoài MagicLive: tạo phiên trò chuyện độc lập
            sessionEpoch++
            MagicLiveBrainMemory.startNewConversationSession(
                reason = "circle_screen_ask_magic_live",
                initialCircleContext = richCircleContext
            )
        }
        preserveCurrentSessionOnNextShow = true

        attachedImageBase64 = croppedBase64Jpeg
        attachedImageFile = croppedImageFile
        attachedImageOcrSummary = null
        attachedImageDisplayName = if (!hasCroppedImage && primaryExtractedText.isNotBlank()) {
            primaryExtractedText.take(28)
        } else {
            "Ảnh vừa khoanh"
        }
        attachedDocumentText = null
        attachedDocumentName = null

        val userQuestionBubbleText = when {
            isFollowUpInExistingSession && foregroundAppLabel.isNotBlank() && hasCroppedImage ->
                "Xem tiếp ảnh trên $foregroundAppLabel này giúp mình nhé?"
            isFollowUpInExistingSession && hasCroppedImage ->
                "Xem tiếp ảnh này giúp mình nhé?"
            foregroundAppLabel.isNotBlank() && hasCroppedImage ->
                "Đây là gì trên $foregroundAppLabel vậy?"
            hasCroppedImage ->
                "Đây là gì vậy, giải thích giúp mình nhé?"
            primaryExtractedText.isNotBlank() ->
                "\"${primaryExtractedText.take(65)}\"\nĐây là gì vậy?"
            else ->
                "Đây là gì vậy, giải thích chi tiết giúp mình nhé?"
        }
        val imageCaptionLabel = if (foregroundAppLabel.isNotBlank()) {
            "Ảnh • $foregroundAppLabel"
        } else {
            "Ảnh đã khoanh"
        }

        val shown = showAndStartListening(appCtx)
        if (!shown) return false

        abortAllActiveNetworkRequests()
        val circleEpoch = activeTurnEpoch
        activeVoiceJob?.cancel()
        activeVoiceJob = overlayScope.launch(Dispatchers.Main) {
            stopSpeakingImmediately()
            pauseCurrentTurnCaptureOnly()
            isRecordingMic = false
            forceFinishRecordingNow = false
            cancelRecordingDiscardAudio = false
            setVoiceCancelButtonVisible(true)

            // Thu gọn bàn phím ảo để người dùng nhìn trọn vẹn ảnh + hội thoại như app nhắn tin
            setVirtualKeyboardExpanded(appCtx, false)

            val (keyAllowed, keyReminderMsg) = LicenseManager.checkMagicLiveAiKeyRequirement(appCtx)
            if (!keyAllowed) {
                val decodedPreviewOnly = withContext(Dispatchers.IO) {
                    decodeDisplayBitmap(croppedBase64Jpeg, croppedImageFile, maxDim = 640)
                }
                if (!isActive || !isShowing || circleEpoch != activeTurnEpoch) return@launch
                attachedPreviewBitmap = decodedPreviewOnly
                updateAttachmentUi(appCtx)
                synchronized(chatBubblesLock) {
                    if (!isFollowUpInExistingSession) {
                        activeChatBubbles.clear()
                    }
                    activeChatBubbles.add(
                        ChatBubbleItem(
                            isUser = true,
                            text = userQuestionBubbleText,
                            imageBitmap = decodedPreviewOnly,
                            imageCaption = imageCaptionLabel
                        )
                    )
                    activeChatBubbles.add(
                        ChatBubbleItem(
                            isUser = false,
                            text = keyReminderMsg
                        )
                    )
                }
                renderChatMessagesThread(appCtx)
                setVoiceCancelButtonVisible(false)
                personalKeyPanelContainer?.visibility = View.VISIBLE
                updatePersonalKeyUiState(appCtx)
                statusTitleView?.text = "🔑 Cần thêm Key Gemini + Groq cá nhân hoặc Nâng cấp PRO"
                transcriptTextView?.text = "🔑 Vui lòng dán Key Gemini (AIza...) + Groq (gsk_...) hoặc nâng cấp PRO"
                micActionBtn?.text = "🔑 Thêm Key AI"
                waveVisualizerView?.setMode(listening = false, speaking = false)
                return@launch
            }

            val pendingBubbleId = UUID.randomUUID().toString().take(8)
            val circleSystemPrompt =
                "Bạn là Gemini, trợ lý AI thông minh do Google phát triển. " +
                    "Hãy nhìn trực tiếp vào bức ảnh và trả lời NGAY LẬP TỨC bằng Tiếng Việt với đầy đủ chi tiết, thông minh, sâu sắc: " +
                    "nêu thẳng tên đối tượng/sản phẩm/món ăn/địa danh/văn bản trong ảnh; nếu có chữ ngoại ngữ hoặc giá tiền (¥, $, ₩...), dịch tự nhiên và quy đổi sang VNĐ. " +
                    "QUY TẮC BẮT BUỘC: TUYỆT ĐỐI KHÔNG BAO GIỜ nhắc đến cụm từ 'khoanh tròn', 'vùng khoanh', 'ảnh bạn gửi' hay bất kỳ từ ngữ rườm rà nào. Trả lời trực tiếp thẳng vào kết quả đầy đủ chính xác với tư cách Gemini của Google."

            val circleUserPrompt = when {
                isFollowUpInExistingSession && foregroundAppLabel.isNotBlank() ->
                    "Tiếp nối cuộc trò chuyện đang diễn ra, hãy quan sát bức ảnh từ $foregroundAppLabel này và trả lời trực tiếp nội dung đáng chú ý."
                isFollowUpInExistingSession ->
                    "Tiếp nối cuộc trò chuyện đang diễn ra, hãy quan sát bức ảnh mới này và trả lời trực tiếp, dễ hiểu."
                foregroundAppLabel.isNotBlank() ->
                    "Quan sát bức ảnh từ $foregroundAppLabel này và trả lời trực tiếp đây là gì, có thông tin gì đáng chú ý?"
                else ->
                    "Quan sát bức ảnh này và trả lời trực tiếp đây là gì, giải thích ngắn gọn dễ hiểu."
            }

            // Phóng luồng giải mã ảnh xem trước & gọi Gemini/Groq Vision song song ngay ở t = 0ms
            val previewDeferred = async(Dispatchers.IO) {
                decodeDisplayBitmap(croppedBase64Jpeg, croppedImageFile, maxDim = 640)
            }
            val aiDeferred = async(Dispatchers.IO) {
                callGroqForScreenOrTranslation(
                    context = appCtx,
                    systemInstruction = circleSystemPrompt,
                    userPrompt = circleUserPrompt,
                    screenshotBase64 = croppedBase64Jpeg,
                    screenTextSummary = richCircleContext,
                    foregroundAppLabel = foregroundAppLabel,
                    maxTokens = 1200,
                    isTranslationOnly = false,
                    conversationHistory = followUpHistory,
                    onPartialText = { partial ->
                        if (circleEpoch == activeTurnEpoch) {
                            updateStreamingMagicLiveReplyBubble(pendingBubbleId, partial)
                        }
                    }
                ).trim()
            }

            val decodedPreview = previewDeferred.await()
            if (!isActive || !isShowing || circleEpoch != activeTurnEpoch) return@launch

            attachedPreviewBitmap = decodedPreview
            updateAttachmentUi(appCtx)

            synchronized(chatBubblesLock) {
                if (!isFollowUpInExistingSession) {
                    activeChatBubbles.clear()
                }
                activeChatBubbles.add(
                    ChatBubbleItem(
                        isUser = true,
                        text = userQuestionBubbleText,
                        imageBitmap = decodedPreview,
                        imageCaption = imageCaptionLabel
                    )
                )
                activeChatBubbles.add(
                    ChatBubbleItem(
                        id = pendingBubbleId,
                        isUser = false,
                        text = streamingPartialCache[pendingBubbleId] ?: "⚡ Đang nhìn ảnh & giải đáp...",
                        isPendingPlaceholder = streamingPartialCache[pendingBubbleId].isNullOrBlank()
                    )
                )
            }
            replyLinksRow?.removeAllViews()
            replyLinksScrollContainer?.visibility = View.GONE
            renderChatMessagesThread(appCtx)

            transcriptTextView?.text = "🖼️ Đã gửi ảnh lên Gemini"
            statusTitleView?.text = "⚡ Gemini đang trả lời..."
            micActionBtn?.text = "🎙️ Ngắt & nói câu mới"
            waveVisualizerView?.setMode(listening = false, speaking = false)

            val rawAiAnswer = aiDeferred.await()
            streamingPartialCache.remove(pendingBubbleId)
            if (!isActive || !isShowing || circleEpoch != activeTurnEpoch) return@launch

            val cleanAiAnswer = cleanConversationOutput(rawAiAnswer)
                .replace(Regex("\\[[A-Z_]+(?::[^\\]]*)?\\]"), "")
                .trim()

            MagicLiveBrainMemory.recordConversationTurn(
                context = appCtx,
                userQuery = userQuestionBubbleText,
                assistantReply = cleanAiAnswer,
                screenOrCircleContext = "",
                appName = foregroundAppLabel
            )

            updateOrAppendMagicLiveReplyBubble(appCtx, pendingBubbleId, cleanAiAnswer)
            NoAccessibilityScreenEngine.disableServiceIfIdle(appCtx, 80L)

            if (isAiVoiceMuted) {
                setVoiceCancelButtonVisible(false)
                statusTitleView?.text = "✨ Đã giải đáp xong • Nhắn tin, nói hoặc bấm ⭕ Khoanh"
                micActionBtn?.text = "🎙️ Bấm để hỏi thêm"
                waveVisualizerView?.setMode(listening = false, speaking = false)
            } else {
                setVoiceCancelButtonVisible(true)
                statusTitleView?.text = "🔊 Gemini đang trả lời..."
                micActionBtn?.text = "🎙️ Chạm để hỏi thêm"
                waveVisualizerView?.setMode(listening = false, speaking = true)

                speakVietnameseResponse(appCtx, cleanAiAnswer) {
                    if (isShowing && circleEpoch == activeTurnEpoch) {
                        mainHandler.post {
                            setVoiceCancelButtonVisible(false)
                            isRecordingMic = false
                            statusTitleView?.text = "✨ Sẵn sàng • Nhắn tin, nói hoặc bấm ⭕ Khoanh"
                            micActionBtn?.text = "🎙️ Bấm để hỏi thêm"
                            waveVisualizerView?.setMode(listening = false, speaking = false)
                        }
                    }
                }
            }
        }

        return true
    }

    fun clearAttachment(context: Context) {
        attachedImageBase64 = null
        attachedImageFile = null
        attachedImageOcrSummary = null
        attachedImageDisplayName = null
        attachedPreviewBitmap = null
        attachedDocumentText = null
        attachedDocumentName = null
        MagicLiveBrainMemory.updateActiveCircledScreenContext("")
        mainHandler.post {
            setVoiceCancelButtonVisible(false)
            updateAttachmentUi(context)
            statusTitleView?.text = "Sẵn sàng • Chạm micro để nói chuyện hoặc nhập tin nhắn..."
            transcriptTextView?.text = "🎙️ Nói tự nhiên hoặc nhắn tin: \"Mở Zalo\", \"Tăng âm lượng\", \"Bật đèn pin\"..."
        }
    }

    private fun updateAttachmentUi(context: Context) {
        val badge = attachmentBadgeContainer ?: return
        val badgeTv = attachmentBadgeText ?: return
        val thumb = attachmentPreviewThumb
        when {
            attachedImageBase64 != null || attachedPreviewBitmap != null -> {
                badge.visibility = View.VISIBLE
                badge.background = GradientDrawable().apply {
                    setColor(Color.parseColor("#172554"))
                    cornerRadius = dp(context, 14).toFloat()
                    setStroke(dp(context, 1), Color.parseColor("#38BDF8"))
                }
                if (thumb != null) {
                    val bmp = attachedPreviewBitmap
                    if (bmp != null && !bmp.isRecycled) {
                        thumb.setImageBitmap(bmp)
                        thumb.visibility = View.VISIBLE
                    } else {
                        thumb.visibility = View.GONE
                    }
                }
                badgeTv.setTextColor(Color.parseColor("#E0F2FE"))
                badgeTv.text = "🖼️ ${attachedImageDisplayName ?: "Ảnh đã khoanh"} • Chạm xem / Hỏi tiếp"
            }
            !attachedDocumentText.isNullOrBlank() -> {
                badge.visibility = View.VISIBLE
                thumb?.visibility = View.GONE
                badge.background = GradientDrawable().apply {
                    setColor(Color.parseColor("#312E81"))
                    cornerRadius = dp(context, 14).toFloat()
                    setStroke(dp(context, 1), Color.parseColor("#818CF8"))
                }
                badgeTv.setTextColor(Color.parseColor("#C7D2FE"))
                badgeTv.text = "📄 ${attachedDocumentName ?: "Tài liệu đính kèm"}"
            }
            else -> {
                thumb?.setImageDrawable(null)
                thumb?.visibility = View.GONE
                badge.visibility = View.GONE
            }
        }
    }

    @Volatile
    private var preserveCurrentSessionOnNextShow: Boolean = false

    @Volatile
    private var pendingFollowUpCircleFromMagicLive: Boolean = false

    @Volatile
    private var preserveBubblesOnCircleDismiss: Boolean = false

    fun clearPendingCircleFollowUpIfUnused() {
        if (pendingFollowUpCircleFromMagicLive || preserveBubblesOnCircleDismiss) {
            pendingFollowUpCircleFromMagicLive = false
            preserveBubblesOnCircleDismiss = false
            preserveCurrentSessionOnNextShow = false
        }
    }

    private fun launchCircleFollowUpFromMagicLive(context: Context) {
        pendingFollowUpCircleFromMagicLive = true
        preserveBubblesOnCircleDismiss = true
        preserveCurrentSessionOnNextShow = true
        dismiss(context)
        SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(context, true)
        CircleToSearchOverlayActivity.launch(context)
    }

    fun showWithAttachedScreenQuery(
        context: Context,
        base64Jpeg: String? = null,
        imageFile: File? = null,
        ocrSummary: String? = null
    ): Boolean {
        val hasImage = !base64Jpeg.isNullOrBlank() || (imageFile != null && imageFile.exists())
        if (!hasImage && ocrSummary.isNullOrBlank()) {
            return showAndStartListening(context)
        }
        return askMagicLiveAboutCircledScreenRegion(
            context = context,
            croppedBase64Jpeg = base64Jpeg,
            croppedImageFile = imageFile,
            primaryExtractedText = ocrSummary.orEmpty(),
            candidatePhrases = emptyList(),
            ocrTextFromCroppedBitmap = ocrSummary.orEmpty(),
            surroundingScreenSummary = "",
            foregroundAppLabel = ""
        )
    }







    /**



     * Kích hoạt ngay hộp thoại Magic Live Nổi trên màn hình hiện tại và bắt đầu lắng nghe giọng nói.



     */



    fun showAndStartListening(context: Context): Boolean {
        val appCtx = context.applicationContext

        // Chat với AI / Magic Live hoạt động độc lập, không cần trợ năng ngầm nên mở sẵn cho mọi người dùng
        // 0. Kiểm tra quyền Trợ lý Magic: Phải là PRO, còn lượt Dùng Thử, hoặc ĐÃ TỰ THÊM GEMINI API KEY (BYOK)



        val hasCustomKey = LicenseManager.getUserCustomMagicLiveKey(appCtx).trim().isNotBlank()



        val canAccess = LicenseManager.canAccessMagicLive(appCtx)



        if (!canAccess) {



            Toast.makeText(



                appCtx,



                "🔒 Bạn đã dùng hết lượt dùng thử Gemini! Vui lòng nâng cấp PRO hoặc vào 'Ô #14 Thiết Lập' thêm API Key của bạn để tiếp tục trò chuyện miễn phí.",



                Toast.LENGTH_LONG



            ).show()



            try {



                val intent = Intent(appCtx, MainActivity::class.java).apply {



                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)



                    putExtra("TARGET_TAB", "SETUP")



                }



                appCtx.startActivity(intent)



            } catch (_: Throwable) {}



            return false



        }



        // Nếu người dùng dùng key cá nhân BYOK thì không cần trừ lượt dùng thử Pro



        if (!hasCustomKey) {



            LicenseManager.checkAndConsumeProOrTrial(appCtx, "Trợ Lý AI Gemini Nổi")



        }







        // 1. Đóng màn hình Khoanh tròn hỏi AI / Dịch Cuộn nếu đang mở để nhường màn hình cho Trợ lý Magic



        CircleToSearchOverlayActivity.dismissIfActiveForMagicLive()



        if (GoogleLiveTranslateOverlay.isRunning) {



            GoogleLiveTranslateOverlay.stop(appCtx)



        }







        // 2. Kiểm tra quyền vẽ trên ứng dụng khác
        // Lưu ý: Không kích hoạt sớm Foreground Service Micro hay ADB grant RECORD_AUDIO khi mới mở bảng chờ
        // (sẽ chỉ kích hoạt đúng lúc người dùng bấm nút thu âm trong startNewVoiceConversationTurn)
        val hasOverlay = Settings.canDrawOverlays(appCtx)

        // Nếu ĐÃ CÓ quyền Hiển thị trên ứng dụng khác (hasOverlay == true):
        // HIỂN THỊ BẢNG MAGIC LIVE TỨC THÌ 0MS TRÊN MAIN THREAD (tuyệt đối không đợi lệnh Shell hay lớp phủ khác đóng!)
        if (hasOverlay) {
            if (Looper.myLooper() == Looper.getMainLooper()) {
                showOverlayInternal(appCtx)
            } else {
                mainHandler.postAtFrontOfQueue {
                    showOverlayInternal(appCtx)
                }
            }
            return true
        }

        // Chỉ khi CHƯA có quyền Overlay mới thử cấp qua Shell hoặc mở Activity trong suốt
        val shell = ShellEngine.getInstance(appCtx)
        if (shell.state.value.isAdbReady) {
            overlayScope.launch(Dispatchers.IO) {
                try {
                    val pkg = appCtx.packageName
                    shell.execute(
                        "cmd appops set $pkg ACCESS_RESTRICTED_SETTINGS allow >/dev/null 2>&1 || cmd appops set --user 0 $pkg ACCESS_RESTRICTED_SETTINGS allow >/dev/null 2>&1 || true; " +
                            "cmd appops set $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1 || cmd appops set --user 0 $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1 || true; " +
                            "appops set $pkg 24 allow >/dev/null 2>&1 || true; " +
                            "pm grant -u 0 $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1 || pm grant --user 0 $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1 || pm grant $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1 || true; " +
                            "cmd appops set $pkg RECORD_AUDIO allow >/dev/null 2>&1 || cmd appops set --user 0 $pkg RECORD_AUDIO allow >/dev/null 2>&1 || true"
                    )
                } catch (_: Throwable) {}
                withContext(Dispatchers.Main) {
                    if (Settings.canDrawOverlays(appCtx)) {
                        showOverlayInternal(appCtx)
                    } else {
                        MagicLiveLockscreenActivity.launchFromOverlay(appCtx)
                    }
                }
            }
            return true
        }

        return MagicLiveLockscreenActivity.launchFromOverlay(appCtx)



    }







    /**



     * Giải phóng Micro tức khắc (<5ms) và đóng lớp phủ Magic Live Nổi của MagicTune



     * khi phát hiện người dùng chuyển sang mở ứng dụng Magic Live chính thức.



     */



    fun yieldMicrophoneAndDismissForExternalAi(context: Context? = null) {



        releaseHardwareMicrophoneCompletely()



        stopSpeakingImmediately()



        if (isShowing && context != null) {



            dismiss(context.applicationContext)



        }



    }







    private fun performActualScreenshotAction(context: Context) {
        val appCtx = context.applicationContext
        mainHandler.post {
            // 1. Tạm thời làm biến mất hoàn toàn lớp phủ (alpha=0 + INVISIBLE) để ảnh chụp "sạch" 100%
            rootContainer?.alpha = 0f
            rootContainer?.visibility = View.INVISIBLE
            
            // 2. Chờ 400ms để hệ thống kịp Render lại khung hình không có lớp phủ
            mainHandler.postDelayed({
                overlayScope.launch {
                    val ok = NoAccessibilityScreenEngine.performVoiceGlobalAction(appCtx, NoAccessibilityScreenEngine.GLOBAL_ACTION_TAKE_SCREENSHOT)
                    withContext(Dispatchers.Main) {
                        mainHandler.postDelayed({
                            if (isShowing) {
                                rootContainer?.alpha = 1f
                                rootContainer?.visibility = View.VISIBLE
                                if (ok) {
                                    Toast.makeText(appCtx, "📸 Đã chụp màn hình thành công!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }, 1000L)
                    }
                }
            }, 400L)
        }
    }

    fun dismiss(context: Context) {
        val appCtx = context.applicationContext
        isShowing = false
        ScreenPowerOptimizer.onFeatureStopped(appCtx, "MagicLive")

        pendingNextTurnRunnable?.let { mainHandler.removeCallbacks(it) }



        pendingNextTurnRunnable = null



        cancelRecordingDiscardAudio = true
        abortAllActiveNetworkRequests()
        releaseHardwareMicrophoneCompletely()
        stopSpeakingImmediately()
        activeVoiceJob?.cancel()
        activeVoiceJob = null
        overlayScope.coroutineContext.cancelChildren()







        overlayClipboardListener?.let {
            com.example.core.keyboard.MagicClipboardStore.removeChangeListener(it)
            overlayClipboardListener = null
        }
        overlayOtpListener?.let {
            com.example.core.keyboard.MagicOtpManager.removeOtpListener(it)
            overlayOtpListener = null
        }
        overlayAccountListener?.let {
            com.example.core.keyboard.MagicAccountManager.removeChangeListener(it)
            overlayAccountListener = null
        }

        val cleanupEpoch = sessionEpoch
        val cleanupRunnable = Runnable {
            isKeyboardElevated = false
            hasImeActuallyAppeared = false
            keyboardMonitorRunnable?.let { mainHandler.removeCallbacks(it) }
            keyboardMonitorRunnable = null

            val view = rootContainer
            rootContainer = null
            statusTitleView = null
            transcriptTextView = null
            replyTextView = null
            streamingBodyTextView = null
            streamingBubbleId = null
            streamingPartialCache.clear()
            chatMessagesContainer = null
            enlargedImageOverlay = null
            enlargedImagePreviewView = null
            enlargedImageTitleView = null
            manualTextInput = null
            overlayLayoutParams = null

            replyScrollView = null
            replyScrollbarTrack = null
            replyScrollbarThumb = null
            replyLinksScrollContainer = null
            replyLinksRow = null

            micActionBtn = null
            speakerMuteBtn = null
            headerOpenAppBtnRef = null
            keyboardToggleBtnRef = null
            continuousModeBtn = null
            attachmentBadgeContainer = null
            attachmentPreviewThumb = null
            attachmentBadgeText = null
            attachmentMenuContainer = null

            waveVisualizerView?.stopAnimation()
            waveVisualizerView = null

            isShowing = false

            val keepForCircleFollowUp = preserveBubblesOnCircleDismiss
            preserveBubblesOnCircleDismiss = false

            if (cleanupEpoch == sessionEpoch && !keepForCircleFollowUp) {
                attachedImageBase64 = null
                attachedImageFile = null
                attachedImageOcrSummary = null
                attachedImageDisplayName = null
                attachedPreviewBitmap?.let { if (!it.isRecycled) try { it.recycle() } catch (_: Throwable) {} }
                attachedPreviewBitmap = null
                attachedDocumentText = null
                attachedDocumentName = null
                synchronized(chatBubblesLock) {
                    for (bubble in activeChatBubbles) {
                        bubble.imageBitmap?.let { if (!it.isRecycled) try { it.recycle() } catch (_: Throwable) {} }
                    }
                    activeChatBubbles.clear()
                }
            }

            if (view != null) {
                try {
                    val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
                    wm?.removeViewImmediate(view)
                } catch (_: Throwable) {}
            }

            val hasAnotherScreenFeature =
                CircleToSearchOverlayActivity.isOverlayActive ||
                    CircleToSearchWindowOverlay.isShowing ||
                    GoogleLiveTranslateOverlay.isRunning
            if (!hasAnotherScreenFeature) {
                SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(appCtx, false)
                com.example.core.service.MagicTuneCtsAccessibilityService.enterDeepSleepNow(appCtx, forceImmediate = true)
                com.example.core.projection.MediaProjectionHolder.releaseIfNoActiveConsumer(appCtx)
                try {
                    com.example.core.service.MagicTuneKeepAliveService.syncServiceNeed(appCtx, "Magic Live overlay closed")
                } catch (_: Throwable) {}
            }
        }

        if (Looper.myLooper() == Looper.getMainLooper()) {
            cleanupRunnable.run()
        } else {
            mainHandler.post(cleanupRunnable)
        }



    }







    private fun showOverlayInternal(context: Context) {



        val appCtx = context.applicationContext

        // Chat với AI / Magic Live hoạt động độc lập, không cần trợ năng ngầm nên mở sẵn cho mọi người dùng
        if (!Settings.canDrawOverlays(appCtx)) {



            MagicLiveLockscreenActivity.launchFromOverlay(appCtx)



            return



        }







        triggerGentleHaptic(appCtx)



        SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(appCtx, true)



        consecutiveSilentTurns = 0







        currentKbMode = KB_MODE_KEYBOARD // Luôn mở bàn phím đầu tiên
        isEnglishMode = false // Mặc định ban đầu luôn ưu tiên Tiếng Việt (VN)
        loadVoiceMutePref(appCtx)
        // Do not wake the radio merely because the user opened an idle overlay.
        // The connection is prewarmed when a question is actually submitted.
        MagicLiveBrainMemory.ensureLoaded(appCtx)
        com.example.core.keyboard.MagicClipboardStore.ensureWatching(appCtx)
        val existingView = rootContainer
        if (!isShowing && !preserveCurrentSessionOnNextShow) {
            // Mỗi lần mở một cuộc trò chuyện mới sau khi đã đóng trước đó:
            // Tách biệt hoàn toàn phiên mới để không nhầm lẫn với cuộc trò chuyện cũ,
            // trong khi toàn bộ lịch sử cũ đã được lưu trong Bộ Não MagicLive (MagicLiveBrainMemory).
            sessionEpoch++
            MagicLiveBrainMemory.startNewConversationSession("open_new_conversation")
            val (keyOk, keyMsg) = LicenseManager.checkMagicLiveAiKeyRequirement(appCtx)
            synchronized(chatBubblesLock) {
                activeChatBubbles.clear()
                activeChatBubbles.add(
                    ChatBubbleItem(
                        isUser = false,
                        text = if (keyOk) {
                            "✨ Xin chào! Hãy nhắn tin, bấm Micro để nói hoặc khoanh màn hình để hỏi — toàn bộ câu hỏi và trả lời sẽ hiển thị tại đây."
                        } else {
                            keyMsg
                        }
                    )
                )
            }
        }
        preserveCurrentSessionOnNextShow = false
        if (isShowing && existingView != null) {
            if (existingView.isAttachedToWindow) {
                existingView.alpha = 1f
                existingView.visibility = View.VISIBLE
                // Mặc định ẩn bàn phím và giữ ở trạng thái Bấm để nói (Standby)
                setVirtualKeyboardExpanded(appCtx, false)
                stopSpeakingImmediately()
                pauseCurrentTurnCaptureOnly()
                isRecordingMic = false
                updateSpeakerMuteButtonStyle(appCtx)
                updatePersonalKeyUiState(appCtx)
                val (keyOkNow, _) = LicenseManager.checkMagicLiveAiKeyRequirement(appCtx)
                if (!keyOkNow) {
                    personalKeyPanelContainer?.visibility = View.VISIBLE
                    statusTitleView?.text = "🔑 Cần thêm Key Gemini + Groq cá nhân hoặc Nâng cấp PRO"
                } else {
                    statusTitleView?.text = if (isAiVoiceMuted) {
                        "🔇 Đang tắt tiếng AI • Nhập văn bản hoặc bấm nút nói"
                    } else {
                        "Sẵn sàng • Nhập văn bản hoặc bấm nút bên dưới để nói"
                    }
                }
                micActionBtn?.text = "🎙️ Bấm để nói"
                waveVisualizerView?.setMode(listening = false, speaking = false)
                return
            } else {
                // Nếu view cũ đã bị WindowManager tháo ra, dọn sạch để gắn mới lại ngay lập tức
                isShowing = false
                rootContainer = null
            }
        }

        val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        val cardView = buildFloatingMagicLiveCardUi(appCtx)
        rootContainer = cardView

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(appCtx, 6)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
            ScreenPowerOptimizer.applyEcoRefreshRateToWindow(this)
        }

        overlayLayoutParams = lp
        try {
            wm.addView(cardView, lp)
            isShowing = true
            ScreenPowerOptimizer.onFeatureStarted(appCtx, "MagicLive")
            isRecordingMic = false
            try { com.example.core.adb.AdbNsdScanner.getInstance(appCtx).releaseMulticastLock() } catch (_: Throwable) {}
            setVirtualKeyboardExpanded(appCtx, false)
            waveVisualizerView?.setMode(listening = false, speaking = false)
            renderChatMessagesThread(appCtx)
            updateAttachmentUi(appCtx)
            updatePersonalKeyUiState(appCtx)
            val (keyOkInit, _) = LicenseManager.checkMagicLiveAiKeyRequirement(appCtx)
            if (!keyOkInit) {
                personalKeyPanelContainer?.visibility = View.VISIBLE
                statusTitleView?.text = "🔑 Cần thêm Key Gemini + Groq cá nhân hoặc Nâng cấp PRO"
            } else {
                statusTitleView?.text = if (isAiVoiceMuted) {
                    "🔇 Đang tắt tiếng AI • Chỉ trả lời văn bản (bấm 🔊 để bật loa)"
                } else {
                    "Sẵn sàng • Nhập tin nhắn hoặc bấm nút bên dưới để nói"
                }
            }
            micActionBtn?.text = "🎙️ Bấm để nói"
        } catch (_: Throwable) {



            isShowing = false



            rootContainer = null



            SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(appCtx, false)



        }



    }







    private fun loadVoiceMutePref(context: Context) {
        try {
            val prefs = context.applicationContext.getSharedPreferences("magic_live_prefs", Context.MODE_PRIVATE)
            isAiVoiceMuted = prefs.getBoolean("magic_live_muted", true)
        } catch (_: Throwable) {}
    }

    private fun toggleAiVoiceMute(context: Context) {
        val appCtx = context.applicationContext
        isAiVoiceMuted = !isAiVoiceMuted
        try {
            appCtx.getSharedPreferences("magic_live_prefs", Context.MODE_PRIVATE)
                .edit()
                .putBoolean("magic_live_muted", isAiVoiceMuted)
                .apply()
        } catch (_: Throwable) {}

        triggerGentleHaptic(appCtx)
        updateSpeakerMuteButtonStyle(appCtx)

        if (isAiVoiceMuted) {
            speechJob?.cancel()
            waveVisualizerView?.setMode(listening = isRecordingMic, speaking = false)
            statusTitleView?.text = "🔇 Đã tắt tiếng AI • Chỉ trả lời nhanh bằng văn bản"
        } else {
            statusTitleView?.text = "🔊 Đã bật tiếng AI • Trả lời bằng giọng nói & văn bản"
        }
    }

    private fun updateSpeakerMuteButtonStyle(context: Context) {
        val btns = listOfNotNull(speakerMuteBtn)
        for (btn in btns) {
            if (isAiVoiceMuted) {
                btn.text = "🔇"
                btn.setTextColor(Color.parseColor("#FCA5A5"))
                btn.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#3F1D24"))
                    setStroke(dp(context, 1.2f), Color.parseColor("#F87171"))
                }
            } else {
                btn.text = "🔊"
                btn.setTextColor(Color.parseColor("#7DD3FC"))
                btn.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#1E3A5F"))
                    setStroke(dp(context, 1.2f), Color.parseColor("#38BDF8"))
                }
            }
        }
    }

    /**
     * Cập nhật trạng thái hiển thị Key AI Cá nhân (Gemini AIza... + Groq gsk_...) trên thanh tiêu đề & bảng cài đặt nhanh.
     */
    fun updatePersonalKeyUiState(context: Context) {
        val appCtx = context.applicationContext ?: context
        val isPro = LicenseManager.isProActivated(appCtx)
        val isAdmin = LicenseManager.isCurrentUserAdmin(appCtx)
        val hasGemini = LicenseManager.hasUserPersonalGeminiKey(appCtx)
        val hasGroq = LicenseManager.hasUserPersonalGroqKey(appCtx)
        val hasBoth = hasGemini && hasGroq

        val headerBtn = headerPersonalKeyBtnRef
        if (headerBtn != null) {
            when {
                hasBoth -> {
                    headerBtn.text = "🔑 Key ✅"
                    headerBtn.setTextColor(Color.parseColor("#6EE7B7"))
                    headerBtn.background = GradientDrawable().apply {
                        setColor(Color.parseColor("#064E3B"))
                        cornerRadius = dp(appCtx, 14).toFloat()
                        setStroke(dp(appCtx, 1), Color.parseColor("#10B981"))
                    }
                }
                isPro || isAdmin -> {
                    headerBtn.text = "👑 Key PRO"
                    headerBtn.setTextColor(Color.parseColor("#FDE047"))
                    headerBtn.background = GradientDrawable().apply {
                        setColor(Color.parseColor("#422006"))
                        cornerRadius = dp(appCtx, 14).toFloat()
                        setStroke(dp(appCtx, 1), Color.parseColor("#EAB308"))
                    }
                }
                else -> {
                    headerBtn.text = "🔑 Thêm Key"
                    headerBtn.setTextColor(Color.parseColor("#FDE68A"))
                    headerBtn.background = GradientDrawable().apply {
                        setColor(Color.parseColor("#451A03"))
                        cornerRadius = dp(appCtx, 14).toFloat()
                        setStroke(dp(appCtx, 1), Color.parseColor("#F59E0B"))
                    }
                }
            }
        }

        val statusTv = personalKeyStatusTextView
        if (statusTv != null) {
            val geminiBadge = if (hasGemini) {
                val gSample = LicenseManager.getUserPersonalGeminiKey(appCtx).lines().firstOrNull().orEmpty()
                "✅ Gemini (${gSample.take(8)}...)"
            } else {
                "⚠️ Gemini (Chưa thêm AIza...)"
            }
            val groqBadge = if (hasGroq) {
                val kSample = LicenseManager.getUserPersonalGroqKey(appCtx).lines().firstOrNull().orEmpty()
                "✅ Groq (${kSample.take(8)}...)"
            } else {
                "⚠️ Groq (Chưa thêm gsk_...)"
            }
            val poolSummary = LicenseManager.getAiKeyPoolStatusSummary(appCtx)
            statusTv.text = when {
                hasBoth -> "🤝 Đã đóng góp đủ 2 Key: $geminiBadge • $groqBadge (Kho Cộng Đồng: ${poolSummary.activeGeminiKeys} Gemini, ${poolSummary.activeGroqKeys} Groq)"
                isPro || isAdmin -> "👑 PRO/ADMIN • Kho Cộng Đồng: ${poolSummary.activeGeminiKeys} Gemini, ${poolSummary.activeGroqKeys} Groq | Cá nhân: $geminiBadge • $groqBadge"
                poolSummary.activeGeminiKeys > 0 && poolSummary.activeGroqKeys > 0 ->
                    "🤝 Kho Cộng Đồng đang có ${poolSummary.activeGeminiKeys} Gemini & ${poolSummary.activeGroqKeys} Groq • Của bạn: $geminiBadge • $groqBadge"
                else -> "🔑 Đóng góp Key cho Kho Cộng Đồng: $geminiBadge • $groqBadge"
            }
            statusTv.setTextColor(
                if (hasBoth || isPro || isAdmin || (poolSummary.activeGeminiKeys > 0 && poolSummary.activeGroqKeys > 0)) {
                    Color.parseColor("#6EE7B7")
                } else {
                    Color.parseColor("#FDE68A")
                }
            )
        }
    }

    /**
     * Tự động phát hiện nếu người dùng gõ hoặc dán chuỗi chứa Key Gemini (`AIza...`) hoặc Key Groq (`gsk_...`),
     * KIỂM TRA SỐNG TRỰC TIẾP với máy chủ Google / Groq để chặn mã giả/lỗi, sau đó lưu & đóng góp vào Kho Key Cộng Đồng.
     */
    private fun tryInterceptAndSavePersonalApiKeyInput(context: Context, rawText: String): Boolean {
        val appCtx = context.applicationContext ?: context
        val geminiMatches = Regex("AIza[0-9A-Za-z_\\-]{8,}").findAll(rawText).map { it.value.trim() }.toList()
        val groqMatches = Regex("gsk_[0-9A-Za-z_\\-]{8,}").findAll(rawText).map { it.value.trim() }.toList()
        if (geminiMatches.isEmpty() && groqMatches.isEmpty()) {
            return false
        }

        appendUserChatBubble(appCtx, "🔑 Đang kiểm tra & đóng góp Key AI (${geminiMatches.size} Gemini, ${groqMatches.size} Groq)...")
        val verifyingBubble = appendPendingMagicLiveBubble(
            appCtx,
            "🔍 Đang xác thực trực tiếp Key với máy chủ Google Gemini & Groq (Chống mã giả / mã lỗi bảo vệ AI cộng đồng)..."
        )
        statusTitleView?.text = "🔍 Đang kiểm tra tính hợp lệ của API Key..."

        overlayScope.launch(Dispatchers.IO) {
            val report = LicenseManager.validateAndSaveUserAiKeysLive(appCtx, rawText)
            withContext(Dispatchers.Main) {
                updatePersonalKeyUiState(appCtx)
                val hasGeminiNow = LicenseManager.hasUserPersonalGeminiKey(appCtx)
                val hasGroqNow = LicenseManager.hasUserPersonalGroqKey(appCtx)
                val (allowedNow, reminderNow) = LicenseManager.checkMagicLiveAiKeyRequirement(appCtx)

                if (report.savedAnyValidKey) {
                    val confirmMsg = buildString {
                        append("✅ XÁC THỰC KEY SỐNG THÀNH CÔNG & ĐÃ ĐÓNG GÓP VÀO KHO CỘNG ĐỒNG!\n")
                        if (report.validGeminiKeys.isNotEmpty()) {
                            append("• Gemini hợp lệ: ${report.validGeminiKeys.joinToString(", ") { it.take(10) + "..." }}\n")
                        }
                        if (report.validGroqKeys.isNotEmpty()) {
                            append("• Groq hợp lệ: ${report.validGroqKeys.joinToString(", ") { it.take(10) + "..." }}\n")
                        }
                        append("🤝 Key hợp lệ của bạn đã được hòa vào Kho Key Cộng Đồng để mọi người dùng cùng chia sẻ xoay vòng trong hạn mức miễn phí 100%!\n")
                        if (report.invalidReasons.isNotEmpty()) {
                            append("\n⚠️ Đã tự động lọc bỏ mã không hợp lệ:\n")
                            for (err in report.invalidReasons) {
                                append("  - $err\n")
                            }
                        }
                        if (hasGeminiNow && hasGroqNow) {
                            append("\n🎉 Bạn đã đóng góp đủ cả 2 Key Gemini + Groq! Bây giờ bạn có thể nhắn tin, nói chuyện hoặc khoanh màn hình với Gemini thoải mái!")
                            personalKeyPanelContainer?.visibility = View.GONE
                            statusTitleView?.text = "✅ Key hợp lệ • Đã kích hoạt Kho Key Cộng Đồng!"
                            micActionBtn?.text = "🎙️ Bấm để nói"
                        } else if (allowedNow) {
                            statusTitleView?.text = "🤝 Đã đóng góp 1 Key hợp lệ • Sẵn sàng dùng Kho Cộng Đồng!"
                        } else {
                            append("\n").append(reminderNow)
                            statusTitleView?.text = "🔑 Đã lưu 1 Key hợp lệ • Vui lòng thêm nốt Key còn thiếu"
                        }
                    }.trim()

                    updateOrAppendMagicLiveReplyBubble(appCtx, verifyingBubble, confirmMsg)
                    Toast.makeText(appCtx, "✅ Key hợp lệ! Đã lưu & đóng góp vào Kho Cộng Đồng!", Toast.LENGTH_LONG).show()
                } else {
                    val rejectMsg = buildString {
                        append("❌ TỪ CHỐI LƯU KEY — PHÁT HIỆN MÃ GIẢ HOẶC KEY KHÔNG HOẠT ĐỘNG:\n")
                        for (err in report.invalidReasons) {
                            append("• $err\n")
                        }
                        append("\n🛡️ Để bảo vệ ứng dụng và Kho Key Cộng Đồng không bị lỗi AI, hệ thống chỉ chấp nhận các API Key thật đang hoạt động từ Google AI Studio (AIza...) và Groq Console (gsk_...).")
                    }.trim()
                    updateOrAppendMagicLiveReplyBubble(appCtx, verifyingBubble, rejectMsg)
                    statusTitleView?.text = "❌ Key không hợp lệ! Vui lòng dán mã Key thật từ Google / Groq"
                    Toast.makeText(appCtx, "❌ Key không hợp lệ hoặc đã bị thu hồi! Hệ thống đã chặn mã lỗi.", Toast.LENGTH_LONG).show()
                }
            }
        }
        return true
    }

    /**
     * Dán nhanh Key Gemini (`AIza...`) và/hoặc Key Groq (`gsk_...`) từ bộ nhớ tạm (Clipboard hệ thống + MagicClipboardStore).
     */
    private fun pastePersonalKeyFromSystemClipboard(context: Context) {
        val appCtx = context.applicationContext ?: context
        val candidateTexts = mutableListOf<String>()
        try {
            val cm = appCtx.getSystemService(Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
            val clip = cm?.primaryClip
            if (clip != null && clip.itemCount > 0) {
                for (i in 0 until clip.itemCount) {
                    val t = clip.getItemAt(i)?.coerceToText(appCtx)?.toString()?.trim().orEmpty()
                    if (t.isNotBlank()) candidateTexts.add(t)
                }
            }
        } catch (_: Throwable) {}

        try {
            for (item in com.example.core.keyboard.MagicClipboardStore.getItems(appCtx)) {
                if (item.isNotBlank()) candidateTexts.add(item.trim())
            }
        } catch (_: Throwable) {}

        val combined = candidateTexts.joinToString("\n")
        if (tryInterceptAndSavePersonalApiKeyInput(appCtx, combined)) {
            return
        }

        Toast.makeText(
            appCtx,
            "⚠️ Chưa tìm thấy mã Key Gemini (bắt đầu bằng AIza...) hoặc Groq (bắt đầu bằng gsk_...) trong bộ nhớ Copy!",
            Toast.LENGTH_LONG
        ).show()
        statusTitleView?.text = "⚠️ Hãy Copy mã Key AIza... hoặc gsk_... trước rồi bấm Dán"
    }

    data class ExtractedWebLink(
        val label: String,
        val url: String,
        val domain: String
    )

    fun normalizeBrowserUrl(rawUrl: String): String {
        var cleaned = rawUrl.trim()
            .trimEnd(')', ']', '}', '.', ',', ';', ':', '"', '\'', '>', '!', '?')
        if (cleaned.startsWith("www.", ignoreCase = true)) {
            cleaned = "https://$cleaned"
        } else if (!cleaned.startsWith("http://", ignoreCase = true) &&
            !cleaned.startsWith("https://", ignoreCase = true)
        ) {
            cleaned = "https://$cleaned"
        }
        return cleaned
    }

    fun extractDomainLabel(url: String): String {
        return try {
            val host = Uri.parse(url).host.orEmpty().removePrefix("www.")
            if (host.isNotBlank()) host else url.take(28)
        } catch (_: Throwable) {
            url.take(28)
        }
    }

    /**
     * Mở đường dẫn URL trực tiếp bằng trình duyệt mặc định của máy (tương tự ứng dụng Google Gemini).
     */
    fun openUrlInDefaultBrowser(context: Context, rawUrl: String) {
        val appCtx = context.applicationContext ?: context
        val finalUrl = normalizeBrowserUrl(rawUrl)
        stopSpeakingImmediately()
        if (isShowing) {
            dismiss(appCtx)
        }
        try {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(finalUrl)).apply {
                addCategory(Intent.CATEGORY_BROWSABLE)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val opts = android.app.ActivityOptions.makeBasic().apply {
                if (Build.VERSION.SDK_INT >= 34) {
                    setPendingIntentBackgroundActivityStartMode(
                        @Suppress("DEPRECATION") android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                    )
                }
            }
            appCtx.startActivity(browserIntent, opts.toBundle())
            Toast.makeText(appCtx, "🌐 Đang mở bằng trình duyệt: ${extractDomainLabel(finalUrl)}", Toast.LENGTH_SHORT).show()
            return
        } catch (_: Throwable) {
            try {
                val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse(finalUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appCtx.startActivity(fallbackIntent)
                return
            } catch (_: Throwable) {}
        }

        val shell = ShellEngine.getInstance(appCtx)
        if (shell.state.value.isAdbReady) {
            overlayScope.launch(Dispatchers.IO) {
                try {
                    shell.execute("am start --user 0 -a android.intent.action.VIEW -d '$finalUrl' >/dev/null 2>&1 || true")
                } catch (_: Throwable) {}
            }
        }
    }

    private data class CachedParsedSpannable(
        val rawText: String,
        val spannable: android.text.SpannableString,
        val links: List<ExtractedWebLink>
    )

    private val parsedBubbleSpannableCache =
        android.util.LruCache<String, CachedParsedSpannable>(64)

    private val markdownLinkRegex = Regex("\\[([^\\]\\n]+)]\\((https?://[^)\\s]+|www\\.[^)\\s]+)\\)")
    private val urlMatchRegex = Regex(
        "(?i)\\b((?:https?://|www\\.)[^\\s<>\"')\\]]+|(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+(?:com|vn|net|org|edu|gov|io|ai|co|me|info|app|dev|xyz|tv|shop|store)(?:/[^\\s<>\"')\\]]*)?)"
    )

    private fun spannableCacheKey(rawText: String): String =
        "${rawText.length}:${rawText.hashCode()}:${rawText.take(24)}"

    /**
     * Tách và tạo SpannableString cho phép chạm trực tiếp vào đường dẫn trong câu trả lời của MagicLive,
     * đồng thời trả về danh sách các link để tạo nút bấm mở nhanh kiểu Google Gemini.
     */
    fun buildClickableSpannableAndLinks(
        context: Context,
        rawText: String
    ): Pair<android.text.SpannableString, List<ExtractedWebLink>> {
        val cacheKey = spannableCacheKey(rawText)
        val cached = parsedBubbleSpannableCache.get(cacheKey)
        if (cached != null && cached.rawText == rawText) {
            return Pair(cached.spannable, cached.links)
        }

        val appCtx = context.applicationContext ?: context
        val extractedLinks = mutableListOf<ExtractedWebLink>()
        val seenUrls = mutableSetOf<String>()

        // Chuyển đổi Markdown [Tiêu đề](https://...) thành "Tiêu đề (https://...)" để vừa dễ đọc vừa bấm được
        val normalizedText = markdownLinkRegex.replace(rawText) { match ->
            val label = match.groupValues[1].trim()
            val rawLink = match.groupValues[2].trim()
            val normUrl = normalizeBrowserUrl(rawLink)
            val domain = extractDomainLabel(normUrl)
            if (seenUrls.add(normUrl.lowercase(Locale.ROOT))) {
                extractedLinks.add(
                    ExtractedWebLink(
                        label = if (label.isNotBlank() && !label.startsWith("http", ignoreCase = true)) label else domain,
                        url = normUrl,
                        domain = domain
                    )
                )
            }
            if (label.equals(rawLink, ignoreCase = true) || label.equals(normUrl, ignoreCase = true)) {
                normUrl
            } else {
                "$label ($normUrl)"
            }
        }

        val spannable = android.text.SpannableString(normalizedText)

        urlMatchRegex.findAll(normalizedText).forEach { matchResult ->
            var start = matchResult.range.first
            var end = matchResult.range.last + 1
            var matchedStr = normalizedText.substring(start, end)

            while (matchedStr.isNotEmpty() && matchedStr.last() in charArrayOf(')', ']', '}', '.', ',', ';', ':', '"', '\'', '>', '!', '?')) {
                matchedStr = matchedStr.dropLast(1)
                end--
            }
            if (matchedStr.length < 4 || end <= start) return@forEach

            val finalUrl = normalizeBrowserUrl(matchedStr)
            val domain = extractDomainLabel(finalUrl)
            if (seenUrls.add(finalUrl.lowercase(Locale.ROOT))) {
                extractedLinks.add(
                    ExtractedWebLink(
                        label = domain,
                        url = finalUrl,
                        domain = domain
                    )
                )
            }

            val clickableSpan = object : android.text.style.ClickableSpan() {
                override fun onClick(widget: View) {
                    openUrlInDefaultBrowser(appCtx, finalUrl)
                }

                override fun updateDrawState(ds: android.text.TextPaint) {
                    super.updateDrawState(ds)
                    ds.color = Color.parseColor("#0284C7")
                    ds.isUnderlineText = true
                    ds.isFakeBoldText = true
                }
            }
            spannable.setSpan(
                clickableSpan,
                start,
                end,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }

        parsedBubbleSpannableCache.put(cacheKey, CachedParsedSpannable(rawText, spannable, extractedLinks))
        return Pair(spannable, extractedLinks)
    }

    private fun decodeDisplayBitmap(base64Jpeg: String?, imageFile: File?, maxDim: Int = 720): Bitmap? {
        try {
            if (imageFile != null && imageFile.exists() && imageFile.length() > 64L) {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(imageFile.absolutePath, bounds)
                var sample = 1
                while (bounds.outWidth / sample > maxDim * 2 || bounds.outHeight / sample > maxDim * 2) {
                    sample *= 2
                }
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                val decoded = BitmapFactory.decodeFile(imageFile.absolutePath, opts)
                if (decoded != null && !decoded.isRecycled && decoded.width > 0 && decoded.height > 0) {
                    try { decoded.prepareToDraw() } catch (_: Throwable) {}
                    return decoded
                }
            }
        } catch (_: Throwable) {}

        try {
            if (!base64Jpeg.isNullOrBlank()) {
                val bytes = Base64.decode(base64Jpeg, Base64.DEFAULT)
                if (bytes.isNotEmpty()) {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                    var sample = 1
                    while (bounds.outWidth / sample > maxDim * 2 || bounds.outHeight / sample > maxDim * 2) {
                        sample *= 2
                    }
                    val opts = BitmapFactory.Options().apply {
                        inSampleSize = sample
                        inPreferredConfig = Bitmap.Config.RGB_565
                    }
                    val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                    if (decoded != null && !decoded.isRecycled && decoded.width > 0 && decoded.height > 0) {
                        try { decoded.prepareToDraw() } catch (_: Throwable) {}
                        return decoded
                    }
                }
            }
        } catch (_: Throwable) {}
        return null
    }

    private fun updateReplyBoxHeightForState(context: Context) {
        val box = replyBoxContainerRef ?: return
        val lp = box.layoutParams ?: return
        val screenH = context.resources.displayMetrics.heightPixels.coerceAtLeast(1000)
        val isCustomKbVisible = customKeyboardContainer?.visibility == View.VISIBLE
        val isSystemImeVisible = isImeCurrentlyVisible(context, box.rootView)
        val isKbVisible = isCustomKbVisible || isSystemImeVisible
        val targetH = when {
            isCompactTranslationMode -> dp(context, 130).coerceAtLeast((screenH * 0.16f).toInt())
            isKbVisible -> (screenH * 0.20f).toInt().coerceIn(dp(context, 140), dp(context, 200))
            else -> (screenH * 0.44f).toInt().coerceIn(dp(context, 320), dp(context, 520))
        }
        if (lp.height != targetH) {
            lp.height = targetH
            box.layoutParams = lp
            box.requestLayout()
        }
    }

    private fun setVirtualKeyboardExpanded(context: Context, expanded: Boolean) {
        val appCtx = context.applicationContext ?: context
        val applyState = {
            val kb = customKeyboardContainer
            val currentlyVisible = kb?.visibility == View.VISIBLE
            if (expanded) {
                if (!currentlyVisible) {
                    kb?.visibility = View.VISIBLE
                }
                keyboardToggleBtnRef?.alpha = 1f
                updateReplyBoxHeightForState(appCtx)
                if (!isKeyboardElevated) {
                    updateWindowFocusable(appCtx, true)
                }
                manualTextInput?.let { input ->
                    input.isFocusable = true
                    input.isFocusableInTouchMode = true
                    input.isCursorVisible = true
                    if (!input.hasFocus()) {
                        input.requestFocus()
                    }
                }
                if (!currentlyVisible) {
                    replyScrollView?.post {
                        replyScrollView?.fullScroll(View.FOCUS_DOWN)
                        updateReplyScrollbarThumb()
                    }
                }
            } else {
                if (currentlyVisible) {
                    kb?.visibility = View.GONE
                }
                keyboardToggleBtnRef?.alpha = 0.78f
                updateReplyBoxHeightForState(appCtx)
                try {
                    val imm = appCtx.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                    manualTextInput?.let { input ->
                        imm?.hideSoftInputFromWindow(input.windowToken, 0)
                        input.isCursorVisible = false
                        input.clearFocus()
                    }
                } catch (_: Throwable) {}
                if (isKeyboardElevated) {
                    updateWindowFocusable(appCtx, false)
                }
            }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            applyState()
        } else {
            mainHandler.post { applyState() }
        }
    }

    private fun showEnlargedImageLightbox(context: Context, bitmap: Bitmap, title: String) {
        if (bitmap.isRecycled) return
        mainHandler.post {
            enlargedImagePreviewView?.setImageBitmap(bitmap)
            enlargedImageTitleView?.text = title
            enlargedImageOverlay?.visibility = View.VISIBLE
        }
    }

    private fun hideEnlargedImageLightbox() {
        mainHandler.post {
            enlargedImageOverlay?.visibility = View.GONE
        }
    }

    private fun resetChatBubblesForNewSession(context: Context, welcomeText: String? = null) {
        synchronized(chatBubblesLock) {
            activeChatBubbles.clear()
            if (!welcomeText.isNullOrBlank()) {
                activeChatBubbles.add(
                    ChatBubbleItem(
                        isUser = false,
                        text = welcomeText
                    )
                )
            }
        }
        mainHandler.post {
            replyLinksRow?.removeAllViews()
            replyLinksScrollContainer?.visibility = View.GONE
            renderChatMessagesThread(context)
        }
    }

    private fun appendUserChatBubble(
        context: Context,
        text: String,
        imageBitmap: Bitmap? = null,
        imageCaption: String? = null
    ) {
        val cleanText = text.trim()
        if (cleanText.isBlank() && imageBitmap == null) return
        synchronized(chatBubblesLock) {
            activeChatBubbles.add(
                ChatBubbleItem(
                    isUser = true,
                    text = cleanText,
                    imageBitmap = imageBitmap,
                    imageCaption = imageCaption
                )
            )
            while (activeChatBubbles.size > 30) {
                val removed = activeChatBubbles.removeAt(0)
                removed.imageBitmap?.let { if (!it.isRecycled) try { it.recycle() } catch (_: Throwable) {} }
            }
        }
        mainHandler.post {
            renderChatMessagesThread(context)
        }
    }

    private var streamingBodyTextView: TextView? = null
    private var streamingBubbleId: String? = null
    private val streamingPartialCache = java.util.concurrent.ConcurrentHashMap<String, String>()

    private fun updateStreamingMagicLiveReplyBubble(pendingBubbleId: String?, partialText: String) {
        if (pendingBubbleId.isNullOrBlank() || partialText.isBlank()) return
        streamingPartialCache[pendingBubbleId] = partialText
        mainHandler.post {
            if (!isShowing || streamingPartialCache[pendingBubbleId] != partialText) return@post
            synchronized(chatBubblesLock) {
                val idx = activeChatBubbles.indexOfFirst { it.id == pendingBubbleId }
                if (idx >= 0) {
                    activeChatBubbles[idx] = activeChatBubbles[idx].copy(
                        text = partialText,
                        isPendingPlaceholder = false
                    )
                }
            }
            if (streamingBubbleId == pendingBubbleId) {
                val tv = streamingBodyTextView
                if (tv != null && tv.isAttachedToWindow) {
                    tv.text = partialText
                    tv.setTextColor(Color.parseColor("#0F172A"))
                    replyScrollView?.post {
                        replyScrollView?.fullScroll(View.FOCUS_DOWN)
                        updateReplyScrollbarThumb()
                    }
                    return@post
                }
            }
            val ctx = chatMessagesContainer?.context ?: rootContainer?.context ?: return@post
            renderChatMessagesThread(ctx)
        }
    }

    private fun appendPendingMagicLiveBubble(
        context: Context,
        placeholderText: String = "⏳ Gemini đang suy nghĩ..."
    ): String {
        val pending = ChatBubbleItem(
            isUser = false,
            text = placeholderText,
            isPendingPlaceholder = true
        )
        synchronized(chatBubblesLock) {
            activeChatBubbles.add(pending)
        }
        mainHandler.post {
            renderChatMessagesThread(context)
        }
        return pending.id
    }

    private fun updateOrAppendMagicLiveReplyBubble(
        context: Context,
        pendingBubbleId: String?,
        replyText: String
    ) {
        if (!pendingBubbleId.isNullOrBlank()) {
            streamingPartialCache.remove(pendingBubbleId)
        }
        if (streamingBubbleId == pendingBubbleId) {
            streamingBubbleId = null
            streamingBodyTextView = null
        }
        val cleanReply = replyText.trim().ifBlank { "Mình chưa nhận được phản hồi, bạn thử hỏi lại giúp mình nhé." }
        synchronized(chatBubblesLock) {
            val idx = if (!pendingBubbleId.isNullOrBlank()) {
                activeChatBubbles.indexOfFirst { it.id == pendingBubbleId }
            } else {
                -1
            }
            val updated = ChatBubbleItem(
                id = pendingBubbleId ?: UUID.randomUUID().toString().take(8),
                isUser = false,
                text = cleanReply,
                isPendingPlaceholder = false
            )
            if (idx >= 0) {
                activeChatBubbles[idx] = updated
            } else {
                activeChatBubbles.add(updated)
            }
            while (activeChatBubbles.size > 30) {
                val removed = activeChatBubbles.removeAt(0)
                removed.imageBitmap?.let { if (!it.isRecycled) try { it.recycle() } catch (_: Throwable) {} }
            }
        }
        displayAiReplyText(cleanReply)
    }

    private data class ChatBubbleViewHolder(
        val bubbleId: String,
        val isUser: Boolean,
        var renderedText: String,
        var renderedPending: Boolean,
        val metaTv: TextView?,
        val bodyTv: TextView?
    )

    private fun bindAiBubbleContent(
        ctx: Context,
        holder: ChatBubbleViewHolder,
        item: ChatBubbleItem
    ) {
        val aiMetaTv = holder.metaTv
        val aiBodyTv = holder.bodyTv
        aiMetaTv?.text = if (item.isPendingPlaceholder) {
            "✨ Gemini • Đang trả lời..."
        } else {
            "✨ Gemini • ${item.timestampLabel}"
        }
        if (aiBodyTv != null) {
            if (item.isPendingPlaceholder) {
                aiBodyTv.tag = item.text
                aiBodyTv.text = item.text
                aiBodyTv.setTextColor(Color.parseColor("#64748B"))
                aiBodyTv.linksClickable = false
                aiBodyTv.movementMethod = null
                aiBodyTv.setOnLongClickListener(null)
            } else {
                val appCtx = ctx.applicationContext ?: ctx
                val textSnapshot = item.text
                aiBodyTv.tag = textSnapshot
                aiBodyTv.setTextColor(Color.parseColor("#0F172A"))
                aiBodyTv.highlightColor = Color.parseColor("#330284C7")
                aiBodyTv.setOnLongClickListener {
                    try {
                        val cm = appCtx.getSystemService(Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                        cm?.setPrimaryClip(android.content.ClipData.newPlainText("GeminiReply", textSnapshot))
                        Toast.makeText(appCtx, "📋 Đã sao chép câu trả lời của Gemini", Toast.LENGTH_SHORT).show()
                    } catch (_: Throwable) {}
                    true
                }

                val cached = parsedBubbleSpannableCache.get(spannableCacheKey(textSnapshot))
                if (cached != null && cached.rawText == textSnapshot) {
                    aiBodyTv.text = cached.spannable
                    aiBodyTv.linksClickable = true
                    aiBodyTv.movementMethod = android.text.method.LinkMovementMethod.getInstance()
                } else if (textSnapshot.length <= 240) {
                    val (spannable, _) = buildClickableSpannableAndLinks(appCtx, textSnapshot)
                    aiBodyTv.text = spannable
                    aiBodyTv.linksClickable = true
                    aiBodyTv.movementMethod = android.text.method.LinkMovementMethod.getInstance()
                } else {
                    aiBodyTv.text = textSnapshot
                    overlayScope.launch(Dispatchers.Default) {
                        val (spannable, _) = buildClickableSpannableAndLinks(appCtx, textSnapshot)
                        withContext(Dispatchers.Main) {
                            if (isShowing && aiBodyTv.isAttachedToWindow && aiBodyTv.tag == textSnapshot) {
                                aiBodyTv.text = spannable
                                aiBodyTv.linksClickable = true
                                aiBodyTv.movementMethod = android.text.method.LinkMovementMethod.getInstance()
                            }
                        }
                    }
                }
            }
        }
        holder.renderedText = item.text
        holder.renderedPending = item.isPendingPlaceholder
    }

    private fun renderChatMessagesThread(context: Context) {
        val container = chatMessagesContainer ?: return
        val ctx = container.context ?: context
        val snapshot = synchronized(chatBubblesLock) { activeChatBubbles.toList() }

        if (snapshot.isEmpty()) {
            container.removeAllViews()
            streamingBodyTextView = null
            streamingBubbleId = null
            replyTextView = null
            return
        }

        val existingById = HashMap<String, View>(container.childCount)
        val snapshotIds = HashSet<String>(snapshot.size * 2)
        for (item in snapshot) {
            snapshotIds.add(item.id)
        }
        for (i in container.childCount - 1 downTo 0) {
            val child = container.getChildAt(i)
            val holder = child.tag as? ChatBubbleViewHolder
            if (holder != null && holder.bubbleId in snapshotIds) {
                existingById[holder.bubbleId] = child
            } else {
                container.removeViewAt(i)
            }
        }

        var lastAiTextView: TextView? = null
        streamingBodyTextView = null
        streamingBubbleId = null
        val dm = ctx.resources.displayMetrics
        val maxUserBubbleWidth = (dm.widthPixels * 0.74f).toInt().coerceAtLeast(dp(ctx, 210))
        val maxAiBubbleWidth = (dm.widthPixels * 0.80f).toInt().coerceAtLeast(dp(ctx, 230))

        for (targetIdx in snapshot.indices) {
            val item = snapshot[targetIdx]
            val reusedView = existingById[item.id]
            if (reusedView != null) {
                val currentChildAtIdx = if (targetIdx < container.childCount) container.getChildAt(targetIdx) else null
                if (currentChildAtIdx !== reusedView) {
                    container.removeView(reusedView)
                    container.addView(reusedView, targetIdx.coerceAtMost(container.childCount))
                }
                val holder = reusedView.tag as? ChatBubbleViewHolder
                if (holder != null && !item.isUser) {
                    if (holder.renderedText != item.text || holder.renderedPending != item.isPendingPlaceholder) {
                        bindAiBubbleContent(ctx, holder, item)
                    }
                    lastAiTextView = holder.bodyTv
                    if (item.isPendingPlaceholder || item.id == snapshot.lastOrNull()?.id) {
                        streamingBubbleId = item.id
                        streamingBodyTextView = holder.bodyTv
                    }
                }
                continue
            }

            val rowWrapper = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = if (item.isUser) Gravity.END else Gravity.START
            }

            if (item.isUser) {
                val r16 = dp(ctx, 16).toFloat()
                val r4 = dp(ctx, 5).toFloat()
                val bubbleCol = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(ctx, 11), dp(ctx, 7), dp(ctx, 11), dp(ctx, 8))
                    background = GradientDrawable(
                        GradientDrawable.Orientation.TL_BR,
                        intArrayOf(
                            Color.parseColor("#2563EB"),
                            Color.parseColor("#1D4ED8")
                        )
                    ).apply {
                        cornerRadii = floatArrayOf(r16, r16, r16, r16, r4, r4, r16, r16)
                        setStroke(dp(ctx, 1), Color.parseColor("#60A5FA"))
                    }
                }

                val metaTv = TextView(ctx).apply {
                    text = "Bạn • ${item.timestampLabel}"
                    setTextColor(Color.parseColor("#BFDBFE"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f)
                    setTypeface(typeface, Typeface.BOLD)
                    gravity = Gravity.END
                }
                bubbleCol.addView(metaTv, LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    gravity = Gravity.END
                    bottomMargin = dp(ctx, 4)
                })

                val bmp = item.imageBitmap
                if (bmp != null && !bmp.isRecycled) {
                    val imgFrame = FrameLayout(ctx).apply {
                        background = GradientDrawable().apply {
                            setColor(Color.parseColor("#0B1120"))
                            cornerRadius = dp(ctx, 12).toFloat()
                            setStroke(dp(ctx, 1), Color.parseColor("#93C5FD"))
                        }
                        clipToOutline = true
                        outlineProvider = object : android.view.ViewOutlineProvider() {
                            override fun getOutline(view: View, outline: android.graphics.Outline) {
                                outline.setRoundRect(0, 0, view.width, view.height, dp(ctx, 12).toFloat())
                            }
                        }
                        setOnClickListener {
                            showEnlargedImageLightbox(ctx, bmp, item.imageCaption ?: "Ảnh vùng màn hình đã khoanh")
                        }
                    }

                    val imgView = ImageView(ctx).apply {
                        setImageBitmap(bmp)
                        adjustViewBounds = true
                        maxWidth = (maxUserBubbleWidth - dp(ctx, 24)).coerceAtLeast(dp(ctx, 150))
                        maxHeight = dp(ctx, 138)
                        scaleType = ImageView.ScaleType.FIT_CENTER
                        contentDescription = item.imageCaption ?: "Ảnh vùng màn hình đã khoanh"
                    }
                    imgFrame.addView(imgView, FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT
                    ))

                    val zoomPill = TextView(ctx).apply {
                        text = "🔍 Xem ảnh"
                        setTextColor(Color.WHITE)
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f)
                        setTypeface(typeface, Typeface.BOLD)
                        setPadding(dp(ctx, 7), dp(ctx, 3), dp(ctx, 7), dp(ctx, 3))
                        background = GradientDrawable().apply {
                            setColor(Color.parseColor("#FD0F172A"))
                            cornerRadius = dp(ctx, 10).toFloat()
                        }
                    }
                    imgFrame.addView(zoomPill, FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        Gravity.BOTTOM or Gravity.END
                    ).apply {
                        rightMargin = dp(ctx, 5)
                        bottomMargin = dp(ctx, 5)
                    })

                    bubbleCol.addView(imgFrame, LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        bottomMargin = if (item.text.isNotBlank()) dp(ctx, 6) else 0
                    })
                }

                var userTvRef: TextView? = null
                if (item.text.isNotBlank()) {
                    val userTv = TextView(ctx).apply {
                        text = item.text
                        setTextColor(Color.WHITE)
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.2f)
                        setLineSpacing(dp(ctx, 2).toFloat(), 1.12f)
                        maxWidth = (maxUserBubbleWidth - dp(ctx, 22)).coerceAtLeast(dp(ctx, 140))
                    }
                    userTvRef = userTv
                    bubbleCol.addView(userTv, LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ))
                }

                rowWrapper.addView(bubbleCol, LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ))
                rowWrapper.tag = ChatBubbleViewHolder(
                    bubbleId = item.id,
                    isUser = true,
                    renderedText = item.text,
                    renderedPending = false,
                    metaTv = metaTv,
                    bodyTv = userTvRef
                )
            } else {
                val r16 = dp(ctx, 16).toFloat()
                val r4 = dp(ctx, 5).toFloat()
                val bubbleCol = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(ctx, 11), dp(ctx, 7), dp(ctx, 11), dp(ctx, 8))
                    background = GradientDrawable().apply {
                        setColor(Color.parseColor("#F4EFE6"))
                        cornerRadii = floatArrayOf(r16, r16, r16, r16, r16, r16, r4, r4)
                        setStroke(dp(ctx, 1), Color.parseColor("#E0D8CA"))
                    }
                }

                val aiMetaTv = TextView(ctx).apply {
                    setTextColor(Color.parseColor("#475569"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.8f)
                    setTypeface(typeface, Typeface.BOLD)
                }
                bubbleCol.addView(aiMetaTv, LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dp(ctx, 3)
                })

                val aiBodyTv = TextView(ctx).apply {
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.6f)
                    setLineSpacing(dp(ctx, 2.5f).toFloat(), 1.14f)
                    maxWidth = (maxAiBubbleWidth - dp(ctx, 22)).coerceAtLeast(dp(ctx, 160))
                }
                val holder = ChatBubbleViewHolder(
                    bubbleId = item.id,
                    isUser = false,
                    renderedText = "",
                    renderedPending = !item.isPendingPlaceholder,
                    metaTv = aiMetaTv,
                    bodyTv = aiBodyTv
                )
                bindAiBubbleContent(ctx, holder, item)
                rowWrapper.tag = holder

                lastAiTextView = aiBodyTv
                if (item.isPendingPlaceholder || item.id == snapshot.lastOrNull()?.id) {
                    streamingBubbleId = item.id
                    streamingBodyTextView = aiBodyTv
                }
                bubbleCol.addView(aiBodyTv, LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ))

                rowWrapper.addView(bubbleCol, LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ))
            }

            container.addView(
                rowWrapper,
                targetIdx.coerceAtMost(container.childCount),
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dp(ctx, 7)
                }
            )
        }

        replyTextView = lastAiTextView
        replyScrollView?.post {
            replyScrollView?.fullScroll(View.FOCUS_DOWN)
            updateReplyScrollbarThumb()
        }
    }

    private fun updateLinksRowUi(ctx: Context, links: List<ExtractedWebLink>) {
        val linksContainer = replyLinksScrollContainer
        val linksRow = replyLinksRow
        if (linksContainer == null || linksRow == null) return
        linksRow.removeAllViews()
        if (links.isNotEmpty()) {
            linksContainer.visibility = View.VISIBLE
            links.forEach { linkItem ->
                val chip = TextView(ctx).apply {
                    val chipTitle = if (linkItem.label.isNotBlank() && !linkItem.label.equals(linkItem.domain, ignoreCase = true)) {
                        "🌐 ${linkItem.label.take(22)} (${linkItem.domain}) ↗"
                    } else {
                        "🌐 Mở trình duyệt: ${linkItem.domain} ↗"
                    }
                    this.text = chipTitle
                    gravity = Gravity.CENTER_VERTICAL
                    setTextColor(Color.parseColor("#7DD3FC"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                    setTypeface(typeface, Typeface.BOLD)
                    setPadding(dp(ctx, 10), dp(ctx, 5), dp(ctx, 10), dp(ctx, 5))
                    background = GradientDrawable().apply {
                        setColor(Color.parseColor("#172554"))
                        cornerRadius = dp(ctx, 14).toFloat()
                        setStroke(dp(ctx, 1), Color.parseColor("#38BDF8"))
                    }
                    setOnClickListener {
                        openUrlInDefaultBrowser(ctx, linkItem.url)
                    }
                }
                linksRow.addView(chip, LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    rightMargin = dp(ctx, 6)
                })
            }
        } else {
            linksContainer.visibility = View.GONE
        }
    }

    private fun displayAiReplyText(text: String) {
        mainHandler.post {
            val ctx = chatMessagesContainer?.context ?: rootContainer?.context ?: replyScrollView?.context
            replyScrollView?.visibility = View.VISIBLE

            if (ctx != null) {
                val appCtx = ctx.applicationContext ?: ctx
                if (chatMessagesContainer != null) {
                    val hasBubble = synchronized(chatBubblesLock) {
                        activeChatBubbles.lastOrNull()?.let {
                            !it.isUser && !it.isPendingPlaceholder && it.text == text.trim()
                        } == true
                    }
                    if (!hasBubble) {
                        synchronized(chatBubblesLock) {
                            activeChatBubbles.add(ChatBubbleItem(isUser = false, text = text.trim()))
                        }
                    }
                    renderChatMessagesThread(ctx)
                }

                val cached = parsedBubbleSpannableCache.get(spannableCacheKey(text))
                if (cached != null && cached.rawText == text) {
                    if (chatMessagesContainer == null) {
                        replyTextView?.apply {
                            this.text = cached.spannable
                            setTextColor(Color.parseColor("#0F172A"))
                            movementMethod = android.text.method.LinkMovementMethod.getInstance()
                            highlightColor = Color.parseColor("#330284C7")
                        }
                    }
                    updateLinksRowUi(ctx, cached.links)
                } else if (text.length <= 240) {
                    val (spannable, links) = buildClickableSpannableAndLinks(appCtx, text)
                    if (chatMessagesContainer == null) {
                        replyTextView?.apply {
                            this.text = spannable
                            setTextColor(Color.parseColor("#0F172A"))
                            movementMethod = android.text.method.LinkMovementMethod.getInstance()
                            highlightColor = Color.parseColor("#330284C7")
                        }
                    }
                    updateLinksRowUi(ctx, links)
                } else {
                    if (chatMessagesContainer == null) {
                        replyTextView?.apply {
                            this.text = text
                            setTextColor(Color.parseColor("#0F172A"))
                        }
                    }
                    overlayScope.launch(Dispatchers.Default) {
                        val (spannable, links) = buildClickableSpannableAndLinks(appCtx, text)
                        withContext(Dispatchers.Main) {
                            if (!isShowing) return@withContext
                            if (chatMessagesContainer == null) {
                                replyTextView?.apply {
                                    this.text = spannable
                                    setTextColor(Color.parseColor("#0F172A"))
                                    movementMethod = android.text.method.LinkMovementMethod.getInstance()
                                    highlightColor = Color.parseColor("#330284C7")
                                }
                            }
                            updateLinksRowUi(ctx, links)
                        }
                    }
                }
            } else {
                replyTextView?.text = text
                replyLinksScrollContainer?.visibility = View.GONE
            }

            replyScrollView?.post {
                replyScrollView?.fullScroll(View.FOCUS_DOWN)
                updateReplyScrollbarThumb()
            }
        }
    }

    private fun updateReplyScrollbarThumb() {
        val scroll = replyScrollView ?: return
        val content: View = chatMessagesContainer ?: replyTextView ?: return
        val track = replyScrollbarTrack ?: return
        val thumb = replyScrollbarThumb ?: return

        val viewportH = scroll.height
        val contentH = content.height
        val trackH = track.height
        if (viewportH <= 0 || trackH <= 0) return

        val ctx = scroll.context
        if (contentH <= viewportH) {
            val lp = thumb.layoutParams
            if (lp.height != trackH) {
                lp.height = trackH
                thumb.layoutParams = lp
            }
            thumb.translationY = 0f
            thumb.alpha = 0.32f
        } else {
            val ratio = (viewportH.toFloat() / contentH.toFloat()).coerceIn(0.18f, 0.88f)
            val thumbH = (trackH * ratio).toInt().coerceAtLeast(dp(ctx, 18))
            val lp = thumb.layoutParams
            if (lp.height != thumbH) {
                lp.height = thumbH
                thumb.layoutParams = lp
            }
            val maxScroll = (contentH - viewportH).coerceAtLeast(1)
            val fraction = (scroll.scrollY.toFloat() / maxScroll.toFloat()).coerceIn(0f, 1f)
            val maxOffset = (trackH - thumbH).coerceAtLeast(0)
            thumb.translationY = fraction * maxOffset
            thumb.alpha = 0.95f
        }
    }

    private fun updateContinuousButtonStyle(context: Context) {
        val btn = continuousModeBtn ?: return
        if (isContinuousConversationEnabled) {
            btn.text = "🔄 Trò chuyện: BẬT"
            btn.setTextColor(Color.parseColor("#7DD3FC"))
            btn.background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E3A5F"))
                cornerRadius = dp(context, 14).toFloat()
                setStroke(dp(context, 1), Color.parseColor("#38BDF8"))
            }
        } else {
            btn.text = "⏸️ Trò chuyện: TẮT"
            btn.setTextColor(Color.parseColor("#94A3B8"))
            btn.background = GradientDrawable().apply {
                setColor(Color.parseColor("#25272C"))
                cornerRadius = dp(context, 14).toFloat()
                setStroke(dp(context, 1), Color.parseColor("#383A3F"))
            }
        }
    }

    private fun buildFloatingMagicLiveCardUi(context: Context): FrameLayout {
        val outerWrapper = object : FrameLayout(context) {
            private var swipeStartX = 0f
            private var swipeStartY = 0f
            private var isEdgeSwipe = false
            private var isTopCurtainPull = false

            override fun dispatchKeyEventPreIme(event: android.view.KeyEvent?): Boolean {
                if (event?.keyCode == android.view.KeyEvent.KEYCODE_BACK &&
                    event.action == android.view.KeyEvent.ACTION_UP
                ) {
                    if (isKeyboardElevated) {
                        post { hideKeyboardAndRestorePosition(context) }
                        return true
                    } else if (isShowing) {
                        post { dismiss(context) }
                        return true
                    }
                }
                return super.dispatchKeyEventPreIme(event)
            }

            private var isTopEdgeSwipe = false

            override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
                if (ev?.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                    if (isKeyboardElevated) {
                        post { hideKeyboardAndRestorePosition(context) }
                    } else if (isShowing) {
                        post { dismiss(context) }
                    }
                }
                
                // Chỉ nhận diện vuốt từ cạnh trên cùng của bảng (Thanh kéo / Tiêu đề) xuống dưới để đóng bảng
                // Các cạnh khác (trái, phải, dưới) không đóng để tránh bấm nhầm với cuộn nội dung, chọn phím hay thao tác khác
                when (ev?.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        swipeStartX = ev.rawX
                        swipeStartY = ev.rawY
                        isTopEdgeSwipe = false

                        val card = cardColumnRef
                        if (card != null && card.isShown) {
                            val loc = IntArray(2)
                            card.getLocationOnScreen(loc)
                            val left = loc[0].toFloat()
                            val top = loc[1].toFloat()
                            val right = left + card.width.toFloat()
                            val edgeTopZone = dp(context, 48).toFloat() // Vùng cạnh trên cùng (Thanh kéo + Tiêu đề)

                            if (swipeStartY in (top - dp(context, 10))..(top + edgeTopZone) && swipeStartX in left..right) {
                                isTopEdgeSwipe = true
                            }
                        }
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (isTopEdgeSwipe) {
                            val dy = ev.rawY - swipeStartY
                            val dx = Math.abs(ev.rawX - swipeStartX)
                            val threshold = dp(context, 30).toFloat()

                            // Vuốt từ cạnh trên xuống dưới
                            if (dy > threshold && dy > dx * 1.1f) {
                                isTopEdgeSwipe = false
                                post { dismiss(context) }
                                return true
                            }
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        isTopEdgeSwipe = false
                    }
                }
                return super.dispatchTouchEvent(ev)
            }
        }.apply {
            setPadding(dp(context, 4), dp(context, 4), dp(context, 4), dp(context, 8))
            var lastObservedBottom = 0
            viewTreeObserver.addOnGlobalLayoutListener {
                val r = android.graphics.Rect()
                getWindowVisibleDisplayFrame(r)
                if (lastObservedBottom != r.bottom) {
                    lastObservedBottom = r.bottom
                    post { updateReplyBoxHeightForState(context) }
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                setOnApplyWindowInsetsListener { _, windowInsets ->
                    val imeShowing = windowInsets.isVisible(android.view.WindowInsets.Type.ime()) ||
                        windowInsets.getInsets(android.view.WindowInsets.Type.ime()).bottom > dp(context, 60)
                    if (imeShowing) {
                        hasImeActuallyAppeared = true
                    } else if (isKeyboardElevated && hasImeActuallyAppeared) {
                        post { hideKeyboardAndRestorePosition(context) }
                    }
                    post { updateReplyBoxHeightForState(context) }
                    windowInsets
                }
            }
        }

        // Lớp phủ Google Gemini Dark theme chính thức
        val cardBg = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                Color.parseColor("#F8131314"),
                Color.parseColor("#F81E1F20")
            )
        ).apply {
            cornerRadius = dp(context, 28).toFloat()
            setStroke(dp(context, 1), Color.parseColor("#3C4043"))
        }

        val cardColumn = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg
            clipToPadding = false
            clipChildren = false
            setPadding(dp(context, 14), dp(context, 7), dp(context, 14), dp(context, 10))
            elevation = dp(context, 20).toFloat()
        }
        cardColumnRef = cardColumn

        var curtainStartY = 0f
        val curtainTouchListener = View.OnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    curtainStartY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = event.rawY - curtainStartY
                    if (dy > dp(context, 30)) {
                        curtainStartY = Float.MAX_VALUE
                        v.post { dismiss(context) }
                        true
                    } else false
                }
                else -> false
            }
        }

        // 1. Drag Handle (Official Magic Live Android Overlay centered pill) — không để khoảng trống thừa
        val dragHandle = View(context).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#4A4C52"))
                cornerRadius = dp(context, 2).toFloat()
            }
            setOnTouchListener(curtainTouchListener)
        }
        cardColumn.addView(dragHandle, LinearLayout.LayoutParams(dp(context, 36), dp(context, 3)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = 0
        })

        // Thanh tiêu đề kiểu trợ lý nổi; nhãn MagicTune phân biệt với ứng dụng Google.
        val headerRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setOnTouchListener(curtainTouchListener)
        }

        // Official Magic Live 4-pointed Sparkle Star Icon
        val sparkleIcon = MagicLiveSparkleView(context)
        headerRow.addView(sparkleIcon, LinearLayout.LayoutParams(dp(context, 19), dp(context, 19)).apply {
            rightMargin = dp(context, 6)
        })

        val titleTv = TextView(context).apply {
            text = "Gemini"
            includeFontPadding = false
            setTextColor(Color.parseColor("#F0F4F9"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
        }
        headerRow.addView(titleTv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        // Spacer pushing action buttons to the right
        val spacer = View(context)
        headerRow.addView(spacer, LinearLayout.LayoutParams(0, 0, 1f))

        // Nút mở nhanh bảng Quản lý / Thêm Key AI Cá Nhân (Gemini + Groq)
        val personalKeyBtn = TextView(context).apply {
            text = "🔑 Key AI"
            gravity = Gravity.CENTER
            includeFontPadding = false
            setTextColor(Color.parseColor("#FDE68A"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(context, 8), 0, dp(context, 8), 0)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#451A03"))
                cornerRadius = dp(context, 14).toFloat()
                setStroke(dp(context, 1), Color.parseColor("#F59E0B"))
            }
            setOnClickListener {
                val panel = personalKeyPanelContainer
                if (panel != null) {
                    panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                    updatePersonalKeyUiState(context)
                }
            }
        }
        headerPersonalKeyBtnRef = personalKeyBtn
        personalKeyBtn.visibility = View.GONE

        val menuBtn = TextView(context).apply {
            text = "⋮"
            contentDescription = "Tùy chọn trợ lý"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#E8EAED"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 21f)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#30415163"))
            }
            setOnClickListener {
                val showTools = chipsScrollViewRef?.visibility != View.VISIBLE
                chipsScrollViewRef?.visibility = if (showTools && !isCompactTranslationMode) View.VISIBLE else View.GONE
                personalKeyBtn.visibility = if (showTools && !isCompactTranslationMode) View.VISIBLE else View.GONE
                if (!showTools) personalKeyPanelContainer?.visibility = View.GONE
            }
        }
        headerRow.addView(menuBtn, LinearLayout.LayoutParams(dp(context, 30), dp(context, 30)).apply {
            rightMargin = dp(context, 6)
        })
        headerRow.addView(personalKeyBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            dp(context, 26)
        ).apply {
            rightMargin = dp(context, 5)
        })

        // Open App / Expand circular button
        val openAppBtn = TextView(context).apply {
            text = "↗"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#C4C7C5"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#25272C"))
                setStroke(dp(context, 1), Color.parseColor("#383A3F"))
            }
            setOnClickListener {
                openOfficialMagicLiveAppAndYieldMic(context)
            }
        }
        headerOpenAppBtnRef = openAppBtn
        headerRow.addView(openAppBtn, LinearLayout.LayoutParams(dp(context, 28), dp(context, 28)).apply {
            rightMargin = dp(context, 6)
        })

        // Close circular button
        val closeBtn = TextView(context).apply {
            text = "✕"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#C4C7C5"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#25272C"))
                setStroke(dp(context, 1), Color.parseColor("#383A3F"))
            }
            setOnClickListener {
                dismiss(context)
            }
        }
        headerRow.addView(closeBtn, LinearLayout.LayoutParams(dp(context, 28), dp(context, 28)))

        cardColumn.addView(headerRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(context, 1)
        })

        // 3. Hàng 2 nút gọn trên cùng (Phiên mới • Trò chuyện) — tự động đánh thức Trợ năng ngầm trước khi làm việc
        val chipsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        chipsScrollViewRef = chipsRow
        chipsRow.visibility = View.GONE

        // Chip 1: Bắt đầu cuộc trò chuyện mới (đủ chữ, không cắt ...)
        val newSessionChip = TextView(context).apply {
            text = "➕ Phiên mới"
            gravity = Gravity.CENTER
            maxLines = 1
            includeFontPadding = false
            setTextColor(Color.parseColor("#34D399"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(context, 3), 0, dp(context, 3), 0)
            androidx.core.widget.TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(
                this,
                7,
                10,
                1,
                TypedValue.COMPLEX_UNIT_SP
            )
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#064E3B"))
                cornerRadius = dp(context, 13).toFloat()
                setStroke(dp(context, 1), Color.parseColor("#10B981"))
            }
            setOnClickListener {
                MagicLiveBrainMemory.startNewConversationSession("manual_new_session")
                clearAttachment(context)
                val savedCount = MagicLiveBrainMemory.getTotalSavedMemoryCount(context)
                statusTitleView?.text = "🧠 Đã mở cuộc trò chuyện mới (Bộ não đã lưu $savedCount ký ức hỗ trợ)"
                transcriptTextView?.text = "💬 Cuộc trò chuyện mới độc lập 100% — không nhầm lẫn lệnh cũ"
                resetChatBubblesForNewSession(
                    context = context,
                    welcomeText = "🧠 Đã bắt đầu cuộc trò chuyện mới! Mọi lịch sử hỗ trợ trước đây đã được lưu an toàn vào Bộ não Gemini trên máy. Bạn cần mình giúp gì trong phiên mới này?"
                )
            }
        }
        chipsRow.addView(newSessionChip, LinearLayout.LayoutParams(
            0,
            dp(context, 26),
            1.0f
        ).apply {
            rightMargin = dp(context, 6)
        })

        // Chip 3: Continuous Conversation Mode Toggle (đủ chữ, không cắt ...)
        val contBtn = TextView(context).apply {
            gravity = Gravity.CENTER
            maxLines = 1
            includeFontPadding = false
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(context, 3), 0, dp(context, 3), 0)
            androidx.core.widget.TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(
                this,
                7,
                10,
                1,
                TypedValue.COMPLEX_UNIT_SP
            )
            setOnClickListener {
                isContinuousConversationEnabled = !isContinuousConversationEnabled
                updateContinuousButtonStyle(context)
                triggerGentleHaptic(context)
                if (isContinuousConversationEnabled) {
                    if (!isRecordingMic && !isSpeakingResponse && activeVoiceJob?.isActive != true) {
                        consecutiveSilentTurns = 0
                        startNewVoiceConversationTurn(context)
                    }
                } else {
                    cancelCurrentVoiceOrAiTurn(
                        context = context,
                        customStatus = "⏸️ Đã tắt trò chuyện & hủy phần vừa nghe",
                        customTranscript = "💬 Đã hủy thu âm • Nhắn tin, khoanh ảnh hoặc bấm Micro khi cần"
                    )
                }
            }
        }
        continuousModeBtn = contBtn
        updateContinuousButtonStyle(context)
        chipsRow.addView(contBtn, LinearLayout.LayoutParams(
            0,
            dp(context, 26),
            1.46f
        ))

        cardColumn.addView(chipsRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(context, 1)
        })

        // 3.5. Bảng Thêm API Key Cá Nhân (Gemini + Groq) cho tài khoản FREE (hoặc tùy chọn BYOK cho mọi tài khoản)
        val keyPanel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(context, 8), dp(context, 6), dp(context, 8), dp(context, 6))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#FD0F172A"))
                cornerRadius = dp(context, 12).toFloat()
                setStroke(dp(context, 1), Color.parseColor("#F59E0B"))
            }
        }
        personalKeyPanelContainer = keyPanel

        val keyStatusTv = TextView(context).apply {
            text = "🔑 Trạng thái Key AI cá nhân: Đang kiểm tra..."
            setTextColor(Color.parseColor("#FEF3C7"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.2f)
            setTypeface(typeface, Typeface.BOLD)
        }
        personalKeyStatusTextView = keyStatusTv
        keyPanel.addView(keyStatusTv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(context, 4)
        })

        val keyHintTv = TextView(context).apply {
            text = "💡 Cách thêm nhanh: Sao chép (Copy) Key Gemini (AIza...) hoặc Groq (gsk_...) rồi bấm [📋 Dán Key vừa Copy] bên dưới, hoặc dán thẳng vào ô nhắn tin rồi bấm 🚀!"
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.2f)
        }
        keyPanel.addView(keyHintTv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(context, 5)
        })

        val keyButtonsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val pasteKeyBtn = TextView(context).apply {
            text = "📋 Dán Key vừa Copy"
            gravity = Gravity.CENTER
            maxLines = 1
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.2f)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(context, 6), dp(context, 4), dp(context, 6), dp(context, 4))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#059669"))
                cornerRadius = dp(context, 10).toFloat()
            }
            setOnClickListener {
                pastePersonalKeyFromSystemClipboard(context)
            }
        }
        keyButtonsRow.addView(pasteKeyBtn, LinearLayout.LayoutParams(0, dp(context, 26), 1.35f).apply {
            rightMargin = dp(context, 4)
        })

        val getGeminiBtn = TextView(context).apply {
            text = "🔗 Lấy Gemini"
            gravity = Gravity.CENTER
            maxLines = 1
            setTextColor(Color.parseColor("#93C5FD"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(context, 4), dp(context, 4), dp(context, 4), dp(context, 4))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E3A8A"))
                cornerRadius = dp(context, 10).toFloat()
                setStroke(dp(context, 1), Color.parseColor("#3B82F6"))
            }
            setOnClickListener {
                openUrlInDefaultBrowser(context, "https://aistudio.google.com/apikey")
            }
        }
        keyButtonsRow.addView(getGeminiBtn, LinearLayout.LayoutParams(0, dp(context, 26), 0.95f).apply {
            rightMargin = dp(context, 4)
        })

        val getGroqBtn = TextView(context).apply {
            text = "🔗 Lấy Groq"
            gravity = Gravity.CENTER
            maxLines = 1
            setTextColor(Color.parseColor("#FDBA74"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(context, 4), dp(context, 4), dp(context, 4), dp(context, 4))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#7C2D12"))
                cornerRadius = dp(context, 10).toFloat()
                setStroke(dp(context, 1), Color.parseColor("#F97316"))
            }
            setOnClickListener {
                openUrlInDefaultBrowser(context, "https://console.groq.com/keys")
            }
        }
        keyButtonsRow.addView(getGroqBtn, LinearLayout.LayoutParams(0, dp(context, 26), 0.9f).apply {
            rightMargin = dp(context, 4)
        })

        val upgradeProBtn = TextView(context).apply {
            text = "👑 Nâng PRO"
            gravity = Gravity.CENTER
            maxLines = 1
            setTextColor(Color.parseColor("#FDE047"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(context, 4), dp(context, 4), dp(context, 4), dp(context, 4))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#713F12"))
                cornerRadius = dp(context, 10).toFloat()
                setStroke(dp(context, 1), Color.parseColor("#EAB308"))
            }
            setOnClickListener {
                try {
                    dismiss(context)
                    val mainIntent = Intent(context, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    }
                    context.startActivity(mainIntent)
                } catch (_: Throwable) {}
            }
        }
        keyButtonsRow.addView(upgradeProBtn, LinearLayout.LayoutParams(0, dp(context, 26), 0.9f))

        keyPanel.addView(keyButtonsRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        cardColumn.addView(keyPanel, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(context, 2)
        })
        updatePersonalKeyUiState(context)

        // 4. Live Soundwave (MagicLiveWaveView) + Status (loại bỏ khoảng trống giữa các hàng)
        val statusTv = TextView(context).apply {
            text = "Sẵn sàng • Chạm micro để nói chuyện hoặc ra lệnh..."
            includeFontPadding = false
            setTextColor(Color.parseColor("#9AA0A6"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(typeface, Typeface.NORMAL)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        statusTitleView = statusTv
        cardColumn.addView(statusTv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = 0
        })

        val waveView = MagicLiveWaveView(context).apply {
            setOnClickListener {
                if (isKeyboardElevated) hideKeyboardAndRestorePosition(context)
                consecutiveSilentTurns = 0
                if (isRecordingMic) {
                    forceFinishRecordingNow = true
                } else {
                    if (activeVoiceJob?.isActive == true || isSpeakingResponse) {
                        abortAllActiveNetworkRequests()
                        stopSpeakingImmediately()
                        removePendingAndUnfinishedReplyBubble(context)
                    }
                    startNewVoiceConversationTurn(context)
                }
            }
        }
        waveVisualizerView = waveView
        cardColumn.addView(waveView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(context, 22)
        ).apply {
            bottomMargin = 0
        })

        // 5. Trạng thái thu âm / ngữ cảnh trực tiếp + Hộp thoại Trò chuyện kiểu App Nhắn Tin
        val userSaidTv = TextView(context).apply {
            text = "💬 Cuộc trò chuyện trực tiếp • Nhắn tin, nói hoặc khoanh ảnh"
            includeFontPadding = false
            setTextColor(Color.parseColor("#CBD5E1"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
            setTypeface(typeface, Typeface.NORMAL)
            isSingleLine = true
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        transcriptTextView = userSaidTv
        cardColumn.addView(userSaidTv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(context, 1)
        })

        // Hộp thoại trò chuyện kiểu máy đọc sách (nền trắng ngà #FAF7EE, văn bản đen tuyền tạo cảm giác đọc sách trên giấy cũ)
        val replyBoxContainer = FrameLayout(context).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#FAF7EE"))
                cornerRadius = dp(context, 14).toFloat()
                setStroke(dp(context, 1), Color.parseColor("#DED7C8"))
            }
        }
        replyBoxContainerRef = replyBoxContainer

        val scroll = ScrollView(context).apply {
            isVerticalScrollBarEnabled = true
            isScrollbarFadingEnabled = false
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_ALWAYS
            visibility = View.VISIBLE
            setOnTouchListener { v, _ ->
                v.parent?.requestDisallowInterceptTouchEvent(true)
                false
            }
        }
        replyScrollView = scroll

        val messagesCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(context, 8), dp(context, 5), dp(context, 14), dp(context, 5))
        }
        chatMessagesContainer = messagesCol
        scroll.addView(messagesCol, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ))

        val scrollbarTrack = FrameLayout(context).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#EAE4D5"))
                cornerRadius = dp(context, 3).toFloat()
            }
        }
        replyScrollbarTrack = scrollbarTrack

        val scrollbarThumb = View(context).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#A8A29E"))
                cornerRadius = dp(context, 3).toFloat()
            }
            alpha = 0.65f
        }
        replyScrollbarThumb = scrollbarThumb
        scrollbarTrack.addView(scrollbarThumb, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            dp(context, 28)
        ))

        scrollbarTrack.setOnTouchListener { v, ev ->
            v.parent?.requestDisallowInterceptTouchEvent(true)
            val trackH = v.height.coerceAtLeast(1)
            val contentH = messagesCol.height
            val viewportH = scroll.height
            if (contentH > viewportH) {
                val fraction = (ev.y / trackH.toFloat()).coerceIn(0f, 1f)
                val targetY = ((contentH - viewportH) * fraction).toInt()
                scroll.scrollTo(0, targetY)
                updateReplyScrollbarThumb()
            }
            true
        }

        scroll.viewTreeObserver.addOnScrollChangedListener {
            updateReplyScrollbarThumb()
        }
        messagesCol.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            scroll.post { updateReplyScrollbarThumb() }
        }

        replyBoxContainer.addView(scroll, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))
        replyBoxContainer.addView(scrollbarTrack, FrameLayout.LayoutParams(
            dp(context, 5),
            FrameLayout.LayoutParams.MATCH_PARENT,
            Gravity.END
        ).apply {
            topMargin = dp(context, 6)
            bottomMargin = dp(context, 6)
            rightMargin = dp(context, 4)
        })

        val initialScreenH = context.resources.displayMetrics.heightPixels.coerceAtLeast(1000)
        // Mặc định bàn phím ẩn khi mới mở nên khung hộp thoại được tự động mở rộng cao (44% màn hình)
        val defaultChatBoxHeight = (initialScreenH * 0.44f).toInt().coerceIn(dp(context, 320), dp(context, 520))
        cardColumn.addView(replyBoxContainer, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            defaultChatBoxHeight
        ).apply {
            bottomMargin = dp(context, 2)
        })

        // Hàng hiển thị các Chip Đường Dẫn Web (Kiểu Google Gemini): Hiện tự động khi câu trả lời của MagicLive có chứa link
        val linksScroll = HorizontalScrollView(context).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isHorizontalScrollBarEnabled = false
            visibility = View.GONE
        }
        replyLinksScrollContainer = linksScroll
        val linksRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        replyLinksRow = linksRow
        linksScroll.addView(linksRow, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ))
        cardColumn.addView(linksScroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(context, 1)
        })

        // 7.2. Thanh xem trước ảnh đã khoanh / tài liệu đính kèm (hiện ngay trên ô nhập tin nhắn để hỏi tiếp nhiều câu)
        val badgeContainer = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            setPadding(dp(context, 8), dp(context, 3), dp(context, 8), dp(context, 3))
        }
        attachmentBadgeContainer = badgeContainer

        val thumbView = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            visibility = View.GONE
            clipToOutline = true
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(view: View, outline: android.graphics.Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(context, 8).toFloat())
                }
            }
            contentDescription = "Ảnh vùng màn hình đã khoanh"
        }
        attachmentPreviewThumb = thumbView
        badgeContainer.addView(thumbView, LinearLayout.LayoutParams(dp(context, 30), dp(context, 30)).apply {
            rightMargin = dp(context, 6)
        })

        val badgeTextTv = TextView(context).apply {
            text = ""
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        attachmentBadgeText = badgeTextTv
        badgeContainer.addView(badgeTextTv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            rightMargin = dp(context, 6)
        })

        val clearAttachBtn = TextView(context).apply {
            text = "✕"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#93C5FD"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#1E293B"))
            }
            setOnClickListener {
                clearAttachment(context)
            }
        }
        badgeContainer.addView(clearAttachBtn, LinearLayout.LayoutParams(dp(context, 22), dp(context, 22)))

        badgeContainer.setOnClickListener {
            val preview = attachedPreviewBitmap
            if (preview != null && !preview.isRecycled) {
                showEnlargedImageLightbox(context, preview, attachedImageDisplayName ?: "Ảnh vùng màn hình đã khoanh")
            }
        }

        cardColumn.addView(badgeContainer, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(context, 1)
        })

        // 7.5. Ô NHẬP LIỆU THỦ CÔNG: Mặc định ẩn bàn phím, chỉ hiện đồng nhất 1 lần khi chạm ô nhập liệu hoặc nút ⌨️
        val textInputContainer = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(context, 8), dp(context, 1), dp(context, 4), dp(context, 1))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(context, 18).toFloat()
                setColor(Color.parseColor("#FD162033"))
                setStroke(dp(context, 1), Color.parseColor("#475569"))
            }
        }
        textInputContainerRef = textInputContainer

        val inputEdit = object : androidx.appcompat.widget.AppCompatEditText(context) {
            override fun onKeyPreIme(keyCode: Int, event: android.view.KeyEvent?): Boolean {
                if (keyCode == android.view.KeyEvent.KEYCODE_BACK &&
                    event?.action == android.view.KeyEvent.ACTION_UP
                ) {
                    post { hideKeyboardAndRestorePosition(context) }
                }
                return super.onKeyPreIme(keyCode, event)
            }
        }.apply {
            hint = "Hỏi Gemini"
            setHintTextColor(Color.parseColor("#9AA0A6"))
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.2f)
            background = null
            imeOptions = EditorInfo.IME_ACTION_SEND
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            maxLines = 2
            setPadding(dp(context, 6), dp(context, 4), dp(context, 6), dp(context, 4))
            setTextIsSelectable(true)
            isLongClickable = true
            // Tắt bàn phím hệ thống để không nhảy đè lần 2 lên bàn phím ảo nội bộ của MagicLive
            showSoftInputOnFocus = false
            isFocusable = true
            isFocusableInTouchMode = true

            setOnClickListener {
                setVirtualKeyboardExpanded(context, true)
            }

            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_UP && customKeyboardContainer?.visibility != View.VISIBLE) {
                    setVirtualKeyboardExpanded(context, true)
                }
                false
            }
        }
        manualTextInput = inputEdit

        val kbToggleBtn = TextView(context).apply {
            text = "⌨️"
            gravity = Gravity.CENTER
            alpha = 0.78f
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#1E293B"))
                setStroke(dp(context, 1), Color.parseColor("#334155"))
            }
            setOnClickListener {
                val willExpand = customKeyboardContainer?.visibility != View.VISIBLE
                setVirtualKeyboardExpanded(context, willExpand)
            }
        }
        keyboardToggleBtnRef = kbToggleBtn

        val sendBtn = TextView(context).apply {
            text = "🚀"
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#2563EB"))
            }
        }

        val sendAction: () -> Unit = {
            val q = inputEdit.text?.toString()?.trim().orEmpty()
            if (q.isNotBlank()) {
                inputEdit.setText("")
                inputEdit.post {
                    inputEdit.isCursorVisible = true
                    inputEdit.requestFocus()
                }

                // Nếu người dùng dán hoặc gõ API Key Gemini (AIza...) hoặc Groq (gsk_...) trực tiếp vào ô nhập tin nhắn -> Tự động lưu làm Key AI cá nhân!
                if (tryInterceptAndSavePersonalApiKeyInput(context, q)) {
                    setVirtualKeyboardExpanded(context, false)
                } else {
                    // Ngắt hoàn toàn mọi luồng thu âm / phân tích âm thanh để AI trả lời trực tiếp tin nhắn văn bản ngay lập tức
                    pendingNextTurnRunnable?.let { mainHandler.removeCallbacks(it) }
                    pendingNextTurnRunnable = null
                    stopSpeakingImmediately()
                    pauseCurrentTurnCaptureOnly()
                    isRecordingMic = false
                    forceFinishRecordingNow = false
                    statusTitleView?.text = "✨ Gemini • Đang trả lời tin nhắn văn bản..."
                    transcriptTextView?.text = "💬 Bạn nhắn: $q"

                    askMagicLiveDirectly(
                        context = context,
                        userQuery = q,
                        displayStatus = "✨ Gemini đang trả lời tin nhắn văn bản...",
                        isTextChat = true
                    )
                }
            } else {
                setVirtualKeyboardExpanded(context, true)
            }
        }

        sendBtn.setOnClickListener { sendAction() }
        inputEdit.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND || actionId == EditorInfo.IME_ACTION_DONE) {
                sendAction()
                true
            } else {
                false
            }
        }

        textInputContainer.addView(inputEdit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        textInputContainer.addView(kbToggleBtn, LinearLayout.LayoutParams(dp(context, 30), dp(context, 30)).apply {
            leftMargin = dp(context, 4)
        })
        textInputContainer.addView(sendBtn, LinearLayout.LayoutParams(dp(context, 32), dp(context, 32)).apply {
            leftMargin = dp(context, 4)
        })

        cardColumn.addView(textInputContainer, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(context, 2)
        })

        // 8. Hàng nút điều khiển: [🎙️ Mic] + [✕ Hủy] + [⭕ Khoanh] + [🔊/🔇 Loa] + [⏹️ Dừng]
        val bottomActionsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        // Main Mic Action Pill Button (38dp capsule)
        val micBtn = TextView(context).apply {
            text = "🎙️ Bấm để nói"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(context, 10), dp(context, 0), dp(context, 10), dp(context, 0))
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(
                    Color.parseColor("#1D4ED8"), // Google Blue
                    Color.parseColor("#7C3AED"), // Magic Live Purple
                    Color.parseColor("#0284C7")  // Sky Blue
                )
            ).apply {
                cornerRadius = dp(context, 19).toFloat()
            }
            setOnClickListener {
                if (isKeyboardElevated) hideKeyboardAndRestorePosition(context)
                consecutiveSilentTurns = 0
                if (isRecordingMic) {
                    forceFinishRecordingNow = true
                } else {
                    if (activeVoiceJob?.isActive == true || isSpeakingResponse) {
                        abortAllActiveNetworkRequests()
                        stopSpeakingImmediately()
                        removePendingAndUnfinishedReplyBubble(context)
                    }
                    startNewVoiceConversationTurn(context)
                }
            }
        }
        micActionBtn = micBtn
        bottomActionsRow.addView(micBtn, LinearLayout.LayoutParams(0, dp(context, 38), 1f).apply {
            rightMargin = dp(context, 5)
        })

        // Nút ❌ Hủy ngay âm thanh vừa nghe hoặc ngắt câu trả lời đang chạy (hiện tự động khi đang nghe / đang trả lời)
        val cancelTurnBtn = TextView(context).apply {
            text = "✕"
            contentDescription = "Hủy âm thanh vừa nghe hoặc ngắt trả lời"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#FCA5A5"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTypeface(typeface, Typeface.BOLD)
            visibility = View.GONE
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#450A0A"))
                setStroke(dp(context, 1.2f), Color.parseColor("#EF4444"))
            }
            setOnClickListener {
                triggerGentleHaptic(context)
                cancelCurrentVoiceOrAiTurn(context)
            }
        }
        voiceCancelBtn = cancelTurnBtn
        bottomActionsRow.addView(cancelTurnBtn, LinearLayout.LayoutParams(dp(context, 38), dp(context, 38)).apply {
            rightMargin = dp(context, 5)
        })

        // Nút Khoanh màn hình hỏi tiếp luôn sẵn sàng khi đang trò chuyện (38dp)
        val circleActionBtn = TextView(context).apply {
            text = "⭕"
            contentDescription = "Khoanh vùng màn hình hỏi tiếp"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#38BDF8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#172554"))
                setStroke(dp(context, 1.2f), Color.parseColor("#38BDF8"))
            }
            setOnClickListener {
                abortAllActiveNetworkRequests()
                stopSpeakingImmediately()
                launchCircleFollowUpFromMagicLive(context)
            }
        }
        bottomActionsRow.addView(circleActionBtn, LinearLayout.LayoutParams(dp(context, 38), dp(context, 38)).apply {
            rightMargin = dp(context, 5)
        })

        // Speaker / Mute AI Voice circular button (38dp)
        val spkBtn = TextView(context).apply {
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setOnClickListener {
                toggleAiVoiceMute(context)
            }
        }
        speakerMuteBtn = spkBtn
        updateSpeakerMuteButtonStyle(context)
        bottomActionsRow.addView(spkBtn, LinearLayout.LayoutParams(dp(context, 38), dp(context, 38)).apply {
            rightMargin = dp(context, 5)
        })

        // Stop / End Session circular button (38dp)
        val stopBtn = TextView(context).apply {
            text = "⏹️"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#F87171"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#25272C"))
                setStroke(dp(context, 1), Color.parseColor("#383A3F"))
            }
            setOnClickListener {
                dismiss(context)
            }
        }
        bottomActionsRow.addView(stopBtn, LinearLayout.LayoutParams(dp(context, 38), dp(context, 38)))

        cardColumn.addView(bottomActionsRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(context, 2)
        })

        val customKb = createCustomVirtualKeyboard(context, inputEdit) { sendAction() }
        customKeyboardContainer = customKb
        cardColumn.addView(customKb, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            leftMargin = -dp(context, 12) // Full width relative to card padding
            rightMargin = -dp(context, 12)
            bottomMargin = -dp(context, 6) // Stick to absolute bottom
        })

        outerWrapper.addView(cardColumn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ))

        // Lớp phủ phóng to ảnh đã khoanh ngay trên hộp thoại khi người dùng chạm vào ảnh
        val lightboxContainer = FrameLayout(context).apply {
            visibility = View.GONE
            isClickable = true
            isFocusable = true
            setPadding(dp(context, 14), dp(context, 14), dp(context, 14), dp(context, 14))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#FD090D16"))
                cornerRadius = dp(context, 24).toFloat()
                setStroke(dp(context, 1.5f), Color.parseColor("#38BDF8"))
            }
            setOnClickListener { hideEnlargedImageLightbox() }
        }
        enlargedImageOverlay = lightboxContainer

        val lightboxContent = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val lightboxHeader = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val lbTitle = TextView(context).apply {
            text = "🖼️ Ảnh vùng màn hình đã khoanh"
            setTextColor(Color.parseColor("#E0F2FE"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        enlargedImageTitleView = lbTitle
        lightboxHeader.addView(lbTitle, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            rightMargin = dp(context, 8)
        })
        val lbCloseBtn = TextView(context).apply {
            text = "✕ Đóng"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(context, 10), dp(context, 5), dp(context, 10), dp(context, 5))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E293B"))
                cornerRadius = dp(context, 14).toFloat()
                setStroke(dp(context, 1), Color.parseColor("#475569"))
            }
            setOnClickListener { hideEnlargedImageLightbox() }
        }
        lightboxHeader.addView(lbCloseBtn)
        lightboxContent.addView(lightboxHeader, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(context, 10)
        })

        val lbImage = ImageView(context).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            maxHeight = dp(context, 340)
            contentDescription = "Xem lớn ảnh đã khoanh"
            setOnClickListener { hideEnlargedImageLightbox() }
        }
        enlargedImagePreviewView = lbImage
        lightboxContent.addView(lbImage, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        lightboxContainer.addView(lightboxContent, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT,
            Gravity.CENTER
        ))

        outerWrapper.addView(lightboxContainer, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        return outerWrapper
    }








    /**



     * Bắt đầu một lượt lắng nghe giọng nói người dùng -> Chuyển giọng nói thành văn bản ->



     * Kiểm tra lệnh điều khiển điện thoại (Mở app, Cuộn trang, Bấm nút, Đèn pin, Âm lượng...) hoặc Truy vấn AI ->



     * Phát âm thanh trả lời Tiếng Việt trực tiếp trên màn hình -> Tự động nghe tiếp câu sau liền mạch!



     */



    private fun startNewVoiceConversationTurn(context: Context) {
        val appCtx = context.applicationContext
        if (isCompactTranslationMode) {
            setCompactTranslationMode(appCtx, false)
        }







        // Hủy bỏ mọi Runnable chờ trước đó để tránh cuộc gọi muộn hủy lượt ghi âm đang chạy



        pendingNextTurnRunnable?.let { mainHandler.removeCallbacks(it) }



        pendingNextTurnRunnable = null







        // Luôn làm mới quyền giữ Micro liên tục cho Magic Live & đảm bảo Foreground Service giữ kênh Micro



        com.example.core.service.MagicTuneKeepAliveService.ensureMicrophoneForeground(appCtx)



        SystemFloatingHudOverlay.releaseMicrophoneForMagicLiveImmediately(appCtx)







        abortAllActiveNetworkRequests()
        val myTurnEpoch = activeTurnEpoch
        stopSpeakingImmediately()

        // QUAN TRỌNG: Chỉ dừng vòng lặp thu của lượt trước, TUYỆT ĐỐI KHÔNG đóng/release AudioRecord phần cứng
        // để Android 14/15/16/MagicOS không bao giờ thu hồi quyền Micro khi sang câu thứ 2, thứ 3!
        pauseCurrentTurnCaptureOnly()
        activeVoiceJob?.cancel()
        cancelRecordingDiscardAudio = false
        forceFinishRecordingNow = false

        val (keyAllowed, keyReminderMsg) = LicenseManager.checkMagicLiveAiKeyRequirement(appCtx)
        if (!keyAllowed) {
            setVoiceCancelButtonVisible(false)
            personalKeyPanelContainer?.visibility = View.VISIBLE
            updatePersonalKeyUiState(appCtx)
            statusTitleView?.text = "🔑 Cần thêm Key Gemini + Groq cá nhân hoặc Nâng cấp PRO"
            transcriptTextView?.text = "🔑 Tài khoản FREE cần thêm Key Gemini (AIza...) + Groq (gsk_...) hoặc nâng PRO"
            micActionBtn?.text = "🔑 Thêm Key AI"
            waveVisualizerView?.setMode(listening = false, speaking = false)
            updateOrAppendMagicLiveReplyBubble(appCtx, null, keyReminderMsg)
            return
        }

        val hasMic = ContextCompat.checkSelfPermission(
            appCtx,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasMic) {
            setVoiceCancelButtonVisible(false)
            statusTitleView?.text = "⚠️ Gemini đang chờ cấp quyền Micro"
            transcriptTextView?.text = "👉 Chạm vào nút bên dưới để cấp quyền Micro cho Trợ lý Magic"
            micActionBtn?.text = "🎙️ Cấp quyền Micro ngay"
            micActionBtn?.setOnClickListener {
                MagicLiveLockscreenActivity.launchFromOverlay(appCtx)
            }
            MagicLiveLockscreenActivity.launchFromOverlay(appCtx)
            return
        }

        activeVoiceJob = overlayScope.launch {
            setVoiceCancelButtonVisible(true)
            statusTitleView?.text = if (isContinuousConversationEnabled) {
                "✨ Gemini • Đang nghe liền mạch (Rảnh tay)..."
            } else {
                "✨ Gemini Nổi • Đang lắng nghe bạn nói..."
            }

            if (MagicLiveBrainMemory.isActiveSessionEmpty() && consecutiveSilentTurns == 0) {
                transcriptTextView?.text = "🎙️ Hãy nói câu hỏi hoặc ra lệnh (bấm ✕ để hủy nghe)..."
            } else {
                transcriptTextView?.text = "🎙️ Micro đang mở • Hãy nói câu tiếp theo (bấm ✕ để hủy)..."
            }

            micActionBtn?.text = "🎙️ Đang nghe... (Chạm để gửi)"
            waveVisualizerView?.setMode(listening = true, speaking = false)

            val wavBytes = withContext(Dispatchers.IO) {
                recordVoiceWithAutoVad(appCtx)
            }

            if (!isActive || !isShowing || cancelRecordingDiscardAudio || myTurnEpoch != activeTurnEpoch) {
                return@launch
            }

            if (wavBytes == null || wavBytes.size < 1600) {
                if (cancelRecordingDiscardAudio || myTurnEpoch != activeTurnEpoch) return@launch
                if (wavBytes == null && audioRecord == null) {
                    setVoiceCancelButtonVisible(false)
                    // Microphone bị chiếm quyền bởi ứng dụng ngoài (cuộc gọi Zalo, Messenger, Điện thoại...)
                    statusTitleView?.text = "⚠️ Microphone đang bị ứng dụng khác chiếm quyền"
                    transcriptTextView?.text = "Microphone hiện không khả dụng. Bạn có thể bấm vào nút bên dưới để gõ tin nhắn trò chuyện nhé!"
                    micActionBtn?.text = "⌨️ Gõ văn bản"
                    waveVisualizerView?.setMode(listening = false, speaking = false)
                    setVirtualKeyboardExpanded(appCtx, true)
                    return@launch
                }
                handleSilentOrEmptyTurn(appCtx)
                return@launch
            }

            statusTitleView?.text = "✨ Gemini • Đang nhận diện & xử lý..."
            transcriptTextView?.text = "⏳ Đang nhận diện giọng nói (bấm ✕ để hủy ngay)..."
            micActionBtn?.text = "🎙️ Ngắt & nói lại"
            waveVisualizerView?.setMode(listening = false, speaking = true)

            val spokenText = withContext(Dispatchers.IO) {
                transcribeAudioBytesToVietnamese(appCtx, wavBytes)
            }.trim()

            if (!isActive || !isShowing || cancelRecordingDiscardAudio || myTurnEpoch != activeTurnEpoch) {
                return@launch
            }

            if (spokenText.isBlank()) {
                setVoiceCancelButtonVisible(false)
                statusTitleView?.text = "🎙️ Chưa nhận diện được câu nói"
                transcriptTextView?.text = "👉 Chưa nghe rõ từ ngữ. Hãy chạm vào 'Chạm để nói' và nói lại..."
                micActionBtn?.text = "🎙️ Chạm để nói"
                waveVisualizerView?.setMode(listening = false, speaking = false)
                return@launch
            }

            consecutiveSilentTurns = 0
            transcriptTextView?.text = "🗣️ Bạn: \"$spokenText\""

            // 1. Nếu người dùng ra lệnh mở hẳn vào trong App Magic Live gốc
            val lowerCmd = spokenText.lowercase(Locale.ROOT)
            if (lowerCmd.contains("mở app magic_live") || lowerCmd.contains("mở ứng dụng magic_live") ||
                lowerCmd.contains("mở app magic live") || lowerCmd.contains("mở ứng dụng magic live")) {
                setVoiceCancelButtonVisible(false)
                openOfficialMagicLiveAppAndYieldMic(appCtx)
                return@launch
            }

            appendUserChatBubble(context = appCtx, text = spokenText)
            val voicePendingBubbleId = appendPendingMagicLiveBubble(
                context = appCtx,
                placeholderText = "⏳ Gemini đang xử lý..."
            )

            // 2. Kiểm tra & Thực thi ngay lập tức các lệnh điều khiển điện thoại (Mở App, Cuộn/Vuốt, Bấm nút, Đèn pin, Âm lượng...)
            statusTitleView?.text = "⚡ Đang xử lý yêu cầu..."

            val cmdResult = withContext(Dispatchers.IO) {
                MagicLiveActionExecutor.tryExecuteVoiceCommand(appCtx, spokenText)
            }

            if (!isActive || !isShowing || cancelRecordingDiscardAudio || myTurnEpoch != activeTurnEpoch) {
                return@launch
            }

            if (cmdResult.handled) {
                val confirmMsg = cmdResult.spokenConfirmation
                if (confirmMsg.isBlank()) {
                    setVoiceCancelButtonVisible(false)
                    return@launch
                }
                MagicLiveBrainMemory.recordConversationTurn(
                    context = appCtx,
                    userQuery = spokenText,
                    assistantReply = confirmMsg
                )
                updateOrAppendMagicLiveReplyBubble(appCtx, voicePendingBubbleId, "⚡ $confirmMsg")

                if (isAiVoiceMuted) {
                    setVoiceCancelButtonVisible(false)
                    statusTitleView?.text = "⚡ Gemini đã thực hiện lệnh (Đang tắt tiếng 🔇)"
                    micActionBtn?.text = "🎙️ Chạm để nói ngay"
                    waveVisualizerView?.setMode(listening = false, speaking = false)
                    if (cmdResult.shouldDismissOverlay) {
                        dismiss(appCtx)
                    } else if (isShowing) {
                        scheduleNextTurnOrStandby(appCtx)
                    }
                } else {
                    setVoiceCancelButtonVisible(true)
                    statusTitleView?.text = "🔊 Gemini đã thực hiện lệnh của bạn"
                    micActionBtn?.text = "🎙️ Chạm để nói ngay"
                    waveVisualizerView?.setMode(listening = false, speaking = true)

                    speakVietnameseResponse(appCtx, confirmMsg) {
                        if (cmdResult.shouldDismissOverlay) {
                            dismiss(appCtx)
                        } else if (isShowing && myTurnEpoch == activeTurnEpoch) {
                            setVoiceCancelButtonVisible(false)
                            scheduleNextTurnOrStandby(appCtx)
                        }
                    }
                }
                return@launch
            }

            // 3. Trò chuyện AI thông minh (khi đã có ảnh đính kèm: CHỈ gửi ảnh trực tiếp cho AI nhìn, không gửi kèm chữ OCR/nodes)
            statusTitleView?.text = "✨ Gemini đang trả lời..."
            micActionBtn?.text = "🎙️ Ngắt & nói câu mới"

            val hasAttachedImg = attachedImageBase64 != null
            val activeCircleCtx = if (hasAttachedImg) "" else MagicLiveBrainMemory.activeCircledScreenContext
            val isScreenQuery = !hasAttachedImg && (isExplicitScreenQuestion(spokenText) || activeCircleCtx.isNotBlank())
            val screenContext = if (!cmdResult.screenContextForAi.isNullOrBlank()) {
                cmdResult.screenContextForAi
            } else if (hasAttachedImg) {
                null
            } else if (activeCircleCtx.isNotBlank()) {
                activeCircleCtx
            } else if (isScreenQuery) {
                withContext(Dispatchers.IO) {
                    try {
                        com.example.core.service.MagicTuneCtsAccessibilityService.beginTemporaryBurst(2500L)
                        NoAccessibilityScreenEngine.autoWakeAccessibilityIfNeeded(appCtx, 1200L)
                        val nodes = NoAccessibilityScreenEngine.extractVisibleScreenNodesNow(appCtx)
                        if (nodes.isNotEmpty()) {
                            nodes.take(50).joinToString(" | ") { it.text }
                        } else null
                    } catch (_: Throwable) { null }
                    finally {
                        com.example.core.service.MagicTuneCtsAccessibilityService.endTemporaryBurstAndIdle(appCtx, 120L)
                    }
                }
            } else null

            if (!isActive || !isShowing || cancelRecordingDiscardAudio || myTurnEpoch != activeTurnEpoch) {
                return@launch
            }

            val promptForAi = if (!screenContext.isNullOrBlank()) {
                "$spokenText\n[THÔNG TIN THAM KHẢO TỪ MÀN HÌNH: $screenContext]"
            } else {
                spokenText
            }

            val rawAiAnswer = withContext(Dispatchers.IO) {
                generateMagicLiveResponse(
                    context = appCtx,
                    userQuery = promptForAi,
                    isTextChat = false,
                    onPartialText = { partial ->
                        if (myTurnEpoch == activeTurnEpoch) {
                            updateStreamingMagicLiveReplyBubble(voicePendingBubbleId, partial)
                        }
                    }
                )
            }.trim()

            if (!isActive || !isShowing || cancelRecordingDiscardAudio || myTurnEpoch != activeTurnEpoch) {
                return@launch
            }

            val cleanAiAnswer = withContext(Dispatchers.IO) {
                val processed = MagicLiveActionExecutor.processAiActionTagsIfPresent(appCtx, rawAiAnswer)
                cleanConversationOutput(processed)
            }

            if (!isActive || !isShowing || cancelRecordingDiscardAudio || myTurnEpoch != activeTurnEpoch) {
                return@launch
            }

            updateOrAppendMagicLiveReplyBubble(appCtx, voicePendingBubbleId, cleanAiAnswer)

            if (isAiVoiceMuted) {
                setVoiceCancelButtonVisible(false)
                statusTitleView?.text = "💬 Gemini đã trả lời văn bản (Đang tắt tiếng 🔇)"
                micActionBtn?.text = "🎙️ Chạm để nói tiếp"
                waveVisualizerView?.setMode(listening = false, speaking = false)
                if (isShowing) {
                    scheduleNextTurnOrStandby(appCtx)
                }
            } else {
                setVoiceCancelButtonVisible(true)
                statusTitleView?.text = "🔊 Gemini đang nói chuyện với bạn..."
                micActionBtn?.text = "🎙️ Chạm để ngắt lời & nói ngay"
                waveVisualizerView?.setMode(listening = false, speaking = true)

                // Phát giọng đọc Tiếng Việt tự nhiên ngay ngoài màn hình, sau đó TỰ ĐỘNG nghe tiếp câu sau!
                speakVietnameseResponse(appCtx, cleanAiAnswer) {
                    if (isShowing && myTurnEpoch == activeTurnEpoch) {
                        setVoiceCancelButtonVisible(false)
                        scheduleNextTurnOrStandby(appCtx)
                    }
                }
            }
        }
    }

    /**
     * Khi chưa phát hiện giọng nói trong 1 chu kỳ:
     * Nếu đang bật chế độ Đàm thoại liền mạch (`isContinuousConversationEnabled`),
     * tự động duy trì lắng nghe vô hạn chu kỳ để người dùng có thể nói câu tiếp bất kỳ lúc nào.
     */
    private fun handleSilentOrEmptyTurn(context: Context) {
        if (!isShowing) return
        pendingNextTurnRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingNextTurnRunnable = null

        if (isContinuousConversationEnabled) {
            consecutiveSilentTurns++
            if (consecutiveSilentTurns >= 2) {
                // Sau ~8 giây im lặng (2 chu kỳ), chuyển về chế độ chờ và giải phóng hoàn toàn phần cứng Micro để làm mát máy & tiết kiệm pin
                consecutiveSilentTurns = 0
                releaseHardwareMicrophoneCompletely()
                setVoiceCancelButtonVisible(false)
                statusTitleView?.text = "✨ Gemini • Đang chờ bạn nói tiếp..."
                transcriptTextView?.text = "👉 Chạm vào nút '🎙️ Chạm để nói' để tiếp tục trò chuyện"
                micActionBtn?.text = "🎙️ Chạm để nói"
                waveVisualizerView?.setMode(listening = false, speaking = false)
                return
            }

            statusTitleView?.text = "✨ Gemini • Đang nghe bạn nói..."
            transcriptTextView?.text = "🎙️ Micro đang sẵn sàng, bạn cứ nói câu tiếp theo..."
            waveVisualizerView?.setMode(listening = true, speaking = false)

            val runnable = Runnable {
                pendingNextTurnRunnable = null
                if (isShowing && isContinuousConversationEnabled && !isRecordingMic) {
                    startNewVoiceConversationTurn(context)
                }
            }
            pendingNextTurnRunnable = runnable
            mainHandler.postDelayed(runnable, 600L)
            return
        }

        consecutiveSilentTurns = 0
        releaseHardwareMicrophoneCompletely()
        setVoiceCancelButtonVisible(false)
        statusTitleView?.text = "✨ Gemini • Đang chờ bạn nói tiếp"
        transcriptTextView?.text = "👉 Chạm vào nút '🎙️ Nói tiếp' hoặc chạm vào sóng âm để tiếp tục trò chuyện"
        micActionBtn?.text = "🎙️ Chạm để nói tiếp"
        waveVisualizerView?.setMode(listening = false, speaking = false)
    }

    /**
     * Ngay sau khi Magic Live đọc xong câu trả lời:
     * Nếu chế độ Liên tục đang BẬT -> Tự động chuyển sang lắng nghe câu tiếp theo của người dùng sau 180ms
     * trong khi luồng AudioRecord phần cứng vẫn đang được giữ mở xuyên suốt.
     */
    private fun scheduleNextTurnOrStandby(context: Context) {
        pendingNextTurnRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingNextTurnRunnable = null

        mainHandler.post {
            if (!isShowing) return@post
            if (isContinuousConversationEnabled) {
                statusTitleView?.text = "✨ Gemini • Đang nghe bạn nói câu tiếp..."
                transcriptTextView?.text = "🎙️ Đã sẵn sàng nghe câu tiếp theo của bạn..."
                micActionBtn?.text = "🎙️ Đang nghe tiếp... (Chạm để gửi)"
                waveVisualizerView?.setMode(listening = true, speaking = false)
                triggerGentleHaptic(context)

                val runnable = Runnable {
                    pendingNextTurnRunnable = null
                    if (isShowing && isContinuousConversationEnabled && !isRecordingMic) {
                        startNewVoiceConversationTurn(context)
                    }
                }
                pendingNextTurnRunnable = runnable
                mainHandler.postDelayed(runnable, 800L)
            } else {
                releaseHardwareMicrophoneCompletely()
                setVoiceCancelButtonVisible(false)
                statusTitleView?.text = "✨ Gemini • Đã trả lời xong"
                micActionBtn?.text = "🎙️ Chạm để nói câu tiếp theo"
                waveVisualizerView?.setMode(listening = false, speaking = false)
            }
        }



    }







    /**



     * Khởi tạo hoặc tái sử dụng phiên `AudioRecord` phần cứng xuyên suốt toàn bộ cuộc hội thoại.



     * TUYỆT ĐỐI KHÔNG đóng/release `AudioRecord` sau câu 1 để ngăn chặn Android 14/15/16 & Honor MagicOS



     * thu hồi quyền Micro khi ứng dụng đang hiển thị dưới dạng hộp thoại nổi (`TYPE_APPLICATION_OVERLAY`).



     */



    @SuppressLint("MissingPermission")



    private fun getOrCreatePersistentAudioRecord(



        context: Context,



        forceRecreate: Boolean = false



    ): AudioRecord? {



        synchronized(audioRecordLock) {



            val existing = audioRecord



            if (!forceRecreate && existing != null && existing.state == AudioRecord.STATE_INITIALIZED) {



                try {



                    if (existing.recordingState != AudioRecord.RECORDSTATE_RECORDING) {



                        existing.startRecording()



                    }



                    if (existing.recordingState == AudioRecord.RECORDSTATE_RECORDING) {



                        return existing



                    }



                } catch (_: Throwable) {}



            }







            if (existing != null) {



                try {



                    existing.stop()



                } catch (_: Throwable) {}



                try {



                    existing.release()



                } catch (_: Throwable) {}



                audioRecord = null



            }







            try {



                val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager



                am?.mode = AudioManager.MODE_NORMAL



            } catch (_: Throwable) {}







            val sampleRate = 16000



            val channelConfig = AudioFormat.CHANNEL_IN_MONO



            val audioFormat = AudioFormat.ENCODING_PCM_16BIT



            val minBufSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)



            if (minBufSize <= 0) return null



            val bufferSize = max(minBufSize * 2, 3200)







            // Ưu tiên VOICE_RECOGNITION chuẩn của Android chuyên dùng cho Speech-to-Text / AI Assistant



            val audioSources = listOf(



                MediaRecorder.AudioSource.VOICE_RECOGNITION,



                MediaRecorder.AudioSource.MIC,



                MediaRecorder.AudioSource.DEFAULT



            )







            for (attempt in 0..2) {
                if (attempt > 0) {
                    try { Thread.sleep(60L) } catch (_: Throwable) {}
                }



                for (source in audioSources) {



                    try {



                        val rec = AudioRecord(source, sampleRate, channelConfig, audioFormat, bufferSize)



                        if (rec.state == AudioRecord.STATE_INITIALIZED) {



                            rec.startRecording()



                            if (rec.recordingState == AudioRecord.RECORDSTATE_RECORDING) {



                                audioRecord = rec



                                attachAudioHardwareEffects(rec.audioSessionId)



                                return rec



                            } else {



                                rec.release()



                            }



                        } else {



                            rec.release()



                        }



                    } catch (_: Throwable) {}



                }



                try {



                    Thread.sleep(10L)



                } catch (_: Throwable) {}



            }



            return null



        }



    }







    /**



     * Trong lúc Magic Live đang xử lý văn bản hoặc đang phát tiếng nói trả lời (TTS),



     * duy trì đọc xả nhẹ (`drain`) bộ đệm của `AudioRecord` mỗi 35ms.



     * Nhờ đó:



     * 1. Hệ điều hành thấy kênh Micro vẫn đang hoạt động liên tục không ngắt quãng -> Không bao giờ thu hồi quyền Micro!



     * 2. Xả sạch âm vọng từ loa ngoài khi Magic Live đang đọc câu trả lời -> Khi vừa đọc xong câu 1, bộ đệm sạch 100% để nghe câu 2 ngay tức khắc!



     */



    private fun startMicKeepAliveDrainBetweenTurns() {
        micKeepAliveDrainJob?.cancel()
        if (!isShowing) return
        micKeepAliveDrainJob = overlayScope.launch(Dispatchers.IO) {
            val drainBuf = ShortArray(512)
            val startElapsedMs = android.os.SystemClock.elapsedRealtime()
            // Briefly drain speaker echo after a turn, then release the mic hardware.
            val maxIdleDrainMs = 1_500L
            while (isActive && isShowing && !isRecordingMic) {
                if (android.os.SystemClock.elapsedRealtime() - startElapsedMs >= maxIdleDrainMs) {
                    micKeepAliveDrainJob = null
                    releaseHardwareMicrophoneCompletely()
                    break
                }
                val rec = synchronized(audioRecordLock) { audioRecord }
                if (rec != null && rec.state == AudioRecord.STATE_INITIALIZED) {
                    try {
                        if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                            rec.startRecording()
                        }
                        rec.read(drainBuf, 0, drainBuf.size)
                    } catch (_: Throwable) {}
                } else {
                    delay(60L)
                }
                delay(50L)
            }
        }
    }







    /**



     * Thu âm trực tiếp từ Micro phần cứng (16kHz Mono PCM) kèm thuật toán VAD (Voice Activity Detection):



     * - Giữ nguyên phiên `AudioRecord` xuyên suốt các lượt hội thoại để không bao giờ bị HĐH thu hồi Micro ở câu 2, câu 3...



     * - Tự động phát hiện nếu luồng Micro bị HĐH làm câm (`rms < 0.05` liên tiếp) và tự động kích hoạt khôi phục quyền Micro tức thì.



     * - Sử dụng bộ đệm Pre-Roll (~600ms trước khi phát hiện giọng nói) để không mất chữ đầu tiên và không gửi khoảng im lặng rỗng.



     */



    @SuppressLint("MissingPermission")



    private fun recordVoiceWithAutoVad(context: Context): ByteArray? {



        val appCtx = context.applicationContext



        micKeepAliveDrainJob?.cancel()



        micKeepAliveDrainJob = null







        val sampleRate = 16000



        var recorder = getOrCreatePersistentAudioRecord(appCtx, forceRecreate = false)



        if (recorder == null) {



            // Nếu chưa mở được AudioRecord do app đang ở nền -> Kích hoạt xung Foreground 120ms để lấy quyền Micro



            requestSilentForegroundMicPulseIfNeeded(appCtx)



            try {



                Thread.sleep(20L)



            } catch (_: Throwable) {}



            recorder = getOrCreatePersistentAudioRecord(appCtx, forceRecreate = true)



        }



        if (recorder == null) return null







        isRecordingMic = true



        forceFinishRecordingNow = false







        val pcmOut = ByteArrayOutputStream()



        val preRollQueue = ArrayDeque<ByteArray>()



        val readBuffer = ShortArray(1024)



        val startTime = android.os.SystemClock.elapsedRealtime()



        var hasDetectedSpeech = false



        var firstSpeechTimestamp = 0L



        var lastSpeechTimestamp = startTime



        var speechFramesCount = 0



        var consecutiveErrorFrames = 0



        var consecutiveDeadZeroFrames = 0



        var ambientNoiseRms = 18.0



        var warmupFramesToFlush = 2 // Xả 2 frame đầu (~120ms) để loại bỏ dư âm loa ngoài sau khi TTS vừa dứt
        var deadZeroRecoveryAttempts = 0
        val pcmFrameBuffer = ByteArray(readBuffer.size * 2)







        try {



            while (isRecordingMic && !forceFinishRecordingNow && !cancelRecordingDiscardAudio && isShowing) {



                val activeRec = recorder ?: break



                if (activeRec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {



                    try {



                        activeRec.startRecording()



                    } catch (_: Throwable) {}



                }







                val now = android.os.SystemClock.elapsedRealtime()



                val elapsed = now - startTime



                if (elapsed > 18_000L) break



                // Sau 4.0 giây nếu người dùng chưa mở lời thì mới chuyển lượt, đảm bảo 2 lượt im lặng (~8s) tự ngủ bảo vệ pin & giảm nhiệt



                if (!hasDetectedSpeech && elapsed > 4_000L) break







                val readCount = activeRec.read(readBuffer, 0, readBuffer.size)



                if (readCount > 0) {



                    if (warmupFramesToFlush > 0) {



                        warmupFramesToFlush--



                        continue



                    }







                    consecutiveErrorFrames = 0



                    var sumSq = 0.0



                    var maxAbsSample = 0







                    // Ghi nhận mẫu âm thanh nguyên bản (Clean Natural PCM), bảo toàn 100% âm sắc tiếng Việt



                    // Reuse one PCM16 frame buffer instead of allocating a ByteBuffer per read.



                    for (i in 0 until readCount) {



                        val sample = readBuffer[i]



                        val pcmSample = sample.toInt()
                        val byteIndex = i * 2
                        pcmFrameBuffer[byteIndex] = (pcmSample and 0xFF).toByte()
                        pcmFrameBuffer[byteIndex + 1] = ((pcmSample ushr 8) and 0xFF).toByte()



                        val absVal = abs(sample.toInt())



                        if (absVal > maxAbsSample) maxAbsSample = absVal



                        sumSq += (sample.toDouble() * sample.toDouble())



                    }







                    val rms = sqrt(sumSq / readCount)







                    // Phát hiện trường hợp HĐH Android / MagicOS khóa ngầm luồng Micro (trả về toàn mẫu 0 tuyệt đối)



                    if (maxAbsSample == 0 || rms < 0.02) {



                        consecutiveDeadZeroFrames++



                        if (consecutiveDeadZeroFrames >= 10) {



                            consecutiveDeadZeroFrames = 0

                            // Prevent repeated mic restarts every few seconds if the OS keeps
                            // returning silent frames; let the listen session end cleanly.
                            if (deadZeroRecoveryAttempts >= 4) break
                            deadZeroRecoveryAttempts++



                            requestSilentForegroundMicPulseIfNeeded(appCtx)



                            try {



                                Thread.sleep(20L)



                            } catch (_: Throwable) {}



                            val recovered = getOrCreatePersistentAudioRecord(appCtx, forceRecreate = true)



                            if (recovered != null) {



                                recorder = recovered






                            }



                            continue



                        }



                    } else {



                        consecutiveDeadZeroFrames = 0



                    }







                    val normalizedAmp = (rms / 3500.0).toFloat().coerceIn(0.06f, 1.0f)



                    currentVoiceAmplitude = normalizedAmp







                    val frameLength = readCount * 2

                    if (!hasDetectedSpeech) {
                        // 1. Giai đoạn lắng nghe câu mở đầu:
                        // Liên tục học mức tạp âm nền phòng (quạt gió, máy lạnh, tiếng ồn tĩnh)
                        if (rms < 35.0 && maxAbsSample < 180) {
                            ambientNoiseRms = (ambientNoiseRms * 0.85) + (rms * 0.15)
                        }

                        // Ngưỡng bắt đầu nói: Nhạy vừa đủ để bắt trọn từ đầu tiên, không bị kích hoạt bởi tiếng thở
                        val startSpeechThresholdRms = (ambientNoiseRms * 1.55).coerceIn(22.0, 40.0)
                        val isStartCandidate = (rms > startSpeechThresholdRms && maxAbsSample > 95) ||
                                (rms > 32.0 && maxAbsSample > 150)

                        if (isStartCandidate) {
                            speechFramesCount++
                            if (speechFramesCount >= 2) {
                                hasDetectedSpeech = true
                                firstSpeechTimestamp = now
                                lastSpeechTimestamp = now
                                // Đổ bộ đệm Pre-Roll (~450ms) để bảo toàn 100% từ đầu tiên của câu hỏi
                                while (preRollQueue.isNotEmpty()) {
                                    pcmOut.write(preRollQueue.removeFirst())
                                }
                            }
                        } else {
                            speechFramesCount = (speechFramesCount - 1).coerceAtLeast(0)
                        }

                        if (hasDetectedSpeech) {
                            pcmOut.write(pcmFrameBuffer, 0, frameLength)
                        } else {
                            preRollQueue.addLast(pcmFrameBuffer.copyOf(frameLength))
                        }
                        while (preRollQueue.size > 7) {
                            preRollQueue.removeFirst()
                        }
                    } else {
                        // 2. Giai đoạn người dùng đang nói:
                        pcmOut.write(pcmFrameBuffer, 0, frameLength)

                        // Phân biệt chính xác giữa giọng nói thực tế và tiếng thở nhẹ / tiếng ồn sau khi dứt câu:
                        val ongoingSpeechThresholdRms = (ambientNoiseRms * 1.65).coerceIn(28.0, 48.0)
                        val isOngoingSpeech = (rms > ongoingSpeechThresholdRms && maxAbsSample > 140) ||
                                (rms > 42.0 && maxAbsSample > 200)

                        if (isOngoingSpeech) {
                            lastSpeechTimestamp = now
                        }

                        val silenceAfterSpeechMs = now - lastSpeechTimestamp
                        val totalSpeechWindowMs = now - firstSpeechTimestamp

                        // Tự động ngắt câu thông minh & dứt khoát:
                        // - Câu bình thường (> 450ms): Chỉ cần dứt lời im lặng 580ms là ngắt ngay lập tức!
                        // - Câu dài (> 1200ms): Người dùng đã nói xong trọn vẹn, chỉ cần 520ms im lặng là chốt và gửi xử lý!
                        val requiredSilenceMs = if (totalSpeechWindowMs > 1200L) 520L else 580L

                        if (totalSpeechWindowMs >= 400L && silenceAfterSpeechMs >= requiredSilenceMs) {
                            break
                        }
                    }



                } else {



                    consecutiveErrorFrames++



                    if (consecutiveErrorFrames > 15) {



                        val recovered = getOrCreatePersistentAudioRecord(appCtx, forceRecreate = true)



                        if (recovered != null) {



                            recorder = recovered



                            consecutiveErrorFrames = 0



                        } else {



                            break



                        }



                    }



                    Thread.sleep(50L)



                }



            }



        } catch (_: Throwable) {



        } finally {



            isRecordingMic = false



            currentVoiceAmplitude = 0.08f
            // Chỉ giữ AudioRecord mở ngầm nếu người dùng đang BẬT chế độ Trò chuyện liên tục;
            // nếu ở chế độ hỏi đáp từng câu (mặc định), lập tức giải phóng phần cứng Micro 100% để tiết kiệm pin.
            if (isShowing && isContinuousConversationEnabled) {
                startMicKeepAliveDrainBetweenTurns()
            } else {
                releaseHardwareMicrophoneCompletely()
            }
        }







        if (cancelRecordingDiscardAudio || !isShowing) {
            return null
        }

        // Nếu người dùng bấm nút "Gửi ngay" khi chưa vượt ngưỡng VAD thì lấy luôn phần preRollQueue



        if (!hasDetectedSpeech && forceFinishRecordingNow) {



            while (preRollQueue.isNotEmpty()) {



                pcmOut.write(preRollQueue.removeFirst())



            }



        } else if (!hasDetectedSpeech) {



            return null



        }







        val rawPcm = pcmOut.toByteArray()



        if (rawPcm.size < 1600) return null



        return wrapPcmInWavHeader(rawPcm, sampleRate, 1, 16)



    }







    private fun requestSilentForegroundMicPulseIfNeeded(context: Context) {



        val appCtx = context.applicationContext



        com.example.core.service.MagicTuneKeepAliveService.ensureMicrophoneForeground(appCtx)



        SystemFloatingHudOverlay.releaseMicrophoneForMagicLiveImmediately(appCtx)







        // Đảm bảo Foreground Service tiếp tục giữ kênh Micro, không khởi chạy Activity nền
        // để tuyệt đối không vi phạm chính sách BAL (Background Activity Launch) của Honor / Android 14+.
    }







    /**



     * Chỉ tạm dừng vòng lặp thu của câu hiện tại, GIỮ NGUYÊN phiên `AudioRecord` phần cứng



     * để câu thứ 2, thứ 3... luôn thu âm được ngay mà không bị HĐH thu hồi quyền Micro.



     */



    private fun removePendingAndUnfinishedReplyBubble(context: Context) {
        val cleanup = {
            var changed = false
            synchronized(chatBubblesLock) {
                val iterator = activeChatBubbles.listIterator(activeChatBubbles.size)
                while (iterator.hasPrevious()) {
                    val item = iterator.previous()
                    if (item.isPendingPlaceholder || item.id == streamingBubbleId) {
                        streamingPartialCache.remove(item.id)
                        iterator.remove()
                        changed = true
                        break
                    }
                }
            }
            streamingBubbleId = null
            streamingBodyTextView = null
            if (changed) {
                renderChatMessagesThread(context)
            }
        }
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            cleanup()
        } else {
            mainHandler.post { cleanup() }
        }
    }

    private fun cancelCurrentVoiceOrAiTurn(
        context: Context,
        customStatus: String? = null,
        customTranscript: String? = null
    ) {
        val appCtx = context.applicationContext ?: context
        cancelRecordingDiscardAudio = true
        forceFinishRecordingNow = false
        isRecordingMic = false
        consecutiveSilentTurns = 0
        pendingNextTurnRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingNextTurnRunnable = null
        micKeepAliveDrainJob?.cancel()
        micKeepAliveDrainJob = null
        abortAllActiveNetworkRequests()
        stopSpeakingImmediately()
        activeVoiceJob?.cancel()
        activeVoiceJob = null
        releaseHardwareMicrophoneCompletely()
        mainHandler.post {
            if (!isShowing) return@post
            removePendingAndUnfinishedReplyBubble(appCtx)
            setVoiceCancelButtonVisible(false)
            waveVisualizerView?.setMode(listening = false, speaking = false)
            micActionBtn?.text = "🎙️ Bấm để nói"
            statusTitleView?.text = customStatus ?: "🚫 Đã hủy lượt vừa rồi • Sẵn sàng nghe câu mới"
            transcriptTextView?.text = customTranscript ?: "💬 Đã hủy • Nhắn tin, khoanh ảnh hoặc bấm Micro"
        }
    }

    private fun cancelVoiceListeningAndDiscard(context: Context) {
        cancelCurrentVoiceOrAiTurn(
            context = context,
            customStatus = "⏸️ Đã tắt trò chuyện & hủy phần vừa nghe",
            customTranscript = "💬 Đã hủy thu âm • Nhắn tin, khoanh ảnh hoặc bấm Micro khi cần"
        )
    }

    private fun pauseCurrentTurnCaptureOnly() {



        isRecordingMic = false



        if (!cancelRecordingDiscardAudio) {
            forceFinishRecordingNow = true
        }



        micKeepAliveDrainJob?.cancel()



        micKeepAliveDrainJob = null



    }







    /**



     * Đóng và giải phóng hoàn toàn `AudioRecord` phần cứng (chỉ gọi khi đóng hẳn hộp thoại Magic Live Nổi



     * hoặc khi nhường Micro sang cho ứng dụng Magic Live chính thức).



     */



    private fun attachAudioHardwareEffects(sessionId: Int) {



        releaseAudioHardwareEffects()



        // Trên ROM MagicOS/EMUI nội địa, không kích hoạt chồng chéo NoiseSuppressor phần mềm



        // để tránh xung đột với bộ lọc ồn AI DSP của chip làm dập tắt giọng nói về 0.



        // Chỉ kích hoạt AGC (AutomaticGainControl) để khuếch đại giọng nói nếu người dùng nói nhỏ.



        try {



            if (AutomaticGainControl.isAvailable()) {



                automaticGainControl = AutomaticGainControl.create(sessionId)?.apply {



                    enabled = true



                }



            }



        } catch (_: Throwable) {}



    }







    private fun releaseAudioHardwareEffects() {



        try {



            noiseSuppressor?.release()



        } catch (_: Throwable) {}



        noiseSuppressor = null



        try {



            acousticEchoCanceler?.release()



        } catch (_: Throwable) {}



        acousticEchoCanceler = null



        try {



            automaticGainControl?.release()



        } catch (_: Throwable) {}



        automaticGainControl = null



    }







    private fun releaseHardwareMicrophoneCompletely() {



        isRecordingMic = false



        if (!cancelRecordingDiscardAudio) {
            forceFinishRecordingNow = true
        }



        micKeepAliveDrainJob?.cancel()



        micKeepAliveDrainJob = null



        releaseAudioHardwareEffects()



        synchronized(audioRecordLock) {



            val rec = audioRecord



            audioRecord = null



            if (rec != null) {



                try {



                    rec.stop()



                } catch (_: Throwable) {}



                try {



                    rec.release()



                } catch (_: Throwable) {}



            }



        }



    }







    private fun wrapPcmInWavHeader(



        pcmData: ByteArray,



        sampleRate: Int,



        channels: Int,



        bitsPerSample: Int



    ): ByteArray {



        val byteRate = sampleRate * channels * bitsPerSample / 8



        val totalDataLen = pcmData.size + 36



        val out = ByteArrayOutputStream(pcmData.size + 44)



        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)



        header.put("RIFF".toByteArray(Charsets.US_ASCII))



        header.putInt(totalDataLen)



        header.put("WAVE".toByteArray(Charsets.US_ASCII))



        header.put("fmt ".toByteArray(Charsets.US_ASCII))



        header.putInt(16) // Subchunk1Size for PCM



        header.putShort(1) // AudioFormat = 1 (PCM)



        header.putShort(channels.toShort())



        header.putInt(sampleRate)



        header.putInt(byteRate)



        header.putShort((channels * bitsPerSample / 8).toShort())



        header.putShort(bitsPerSample.toShort())



        header.put("data".toByteArray(Charsets.US_ASCII))



        header.putInt(pcmData.size)



        out.write(header.array())



        out.write(pcmData)



        return out.toByteArray()



    }







    /**



     * Chuyển đổi âm thanh WAV vừa thu từ Micro sang văn bản Tiếng Việt siêu tốc (~300ms)



     * qua Whisper Large V3 Turbo (Hoạt động trên 100% máy Honor MagicOS 11 không cần Google Speech Services).



     */



    private fun transcribeAudioBytesToVietnamese(context: Context, wavBytes: ByteArray): String {
        val isProOrAdmin = LicenseManager.isProActivated(context) || LicenseManager.isCurrentUserAdmin(context)
        val candidateKeys = buildList {
            for (k in LicenseManager.getAllGroqApiKeys(context, forMagicLiveFeature = true)) {
                if (k.isNotBlank() && !contains(k)) add(k)
            }
            if (isProOrAdmin) {
                val buildKey = try { com.example.BuildConfig.GROQ_API_KEY } catch (_: Throwable) { "" }
                if (buildKey.isNotBlank() && buildKey != "GROQ_API_KEY_DEFAULT_VALUE" &&
                    !contains(buildKey) &&
                    LicenseManager.isAiKeyWithinFreeTierLimit(context, buildKey, isGemini = false)
                ) {
                    add(buildKey)
                }
            }
        }.filter { it.isNotBlank() && it != "GROQ_API_KEY_DEFAULT_VALUE" }.take(5)

        if (candidateKeys.isEmpty()) {
            return ""
        }

        val models = listOf("whisper-large-v3-turbo", "whisper-large-v3")

        for (apiKey in candidateKeys) {
            for (modelName in models) {
                if (!LicenseManager.tryConsumeAiKeyFreeTierQuota(context, apiKey, isGemini = false)) {
                    break
                }
                try {



                val boundary = "----MagicTuneVoiceBoundary${System.currentTimeMillis()}"



                val sttEpoch = activeTurnEpoch
                var conn: HttpURLConnection? = null
                try {
                val url = URL("https://api.groq.com/openai/v1/audio/transcriptions")
                conn = (url.openConnection() as HttpURLConnection).apply {



                    requestMethod = "POST"



                    doOutput = true



                    doInput = true



                    connectTimeout = 4000



                    readTimeout = 7000



                    setRequestProperty("Authorization", "Bearer $apiKey")



                    setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")



                    setRequestProperty("User-Agent", "MagicTune-Android/6.0")



                }
                trackHttpConn(conn)
                if (sttEpoch != activeTurnEpoch) return ""







                DataOutputStream(conn.outputStream).use { dos ->



                    // 1. File part



                    dos.writeBytes("--$boundary\r\n")



                    dos.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"voice.wav\"\r\n")



                    dos.writeBytes("Content-Type: audio/wav\r\n\r\n")



                    dos.write(wavBytes)



                    dos.writeBytes("\r\n")







                    // 2. Model part



                    dos.writeBytes("--$boundary\r\n")



                    dos.writeBytes("Content-Disposition: form-data; name=\"model\"\r\n\r\n")



                    dos.writeBytes("$modelName\r\n")







                    // 3. Language part (Ép cố định Tiếng Việt chuẩn xác)



                    dos.writeBytes("--$boundary\r\n")



                    dos.writeBytes("Content-Disposition: form-data; name=\"language\"\r\n\r\n")



                    dos.writeBytes("vi\r\n")







                    // 3.1 Temperature: 0.0 để nhận diện chính xác nhất



                    dos.writeBytes("--$boundary\r\n")



                    dos.writeBytes("Content-Disposition: form-data; name=\"temperature\"\r\n\r\n")



                    dos.writeBytes("0.0\r\n")







                    // 3.2 Prompt mồi ngữ cảnh đa vùng miền, phát âm địa phương, nói ngọng l/n, giọng trầm khàn



                    val sttGuidePrompt = "Đây là hội thoại tiếng Việt tự nhiên của người Việt 3 miền Bắc, Trung, Nam; bao gồm giọng địa phương Nghệ An, Hà Tĩnh, Huế, Quảng Nam, miền Tây, nói ngọng L/N, dấu hỏi ngã, giọng nam trầm ồm hoặc nói nhanh. Các từ khóa: YouTube, Google, Zalo, Facebook, TikTok, thời tiết, mở nhạc, bật đèn pin, bản đồ, MagicTune."



                    dos.writeBytes("--$boundary\r\n")



                    dos.writeBytes("Content-Disposition: form-data; name=\"prompt\"\r\n\r\n")



                    dos.write(sttGuidePrompt.toByteArray(Charsets.UTF_8))



                    dos.writeBytes("\r\n")







                    // 4. Response format



                    dos.writeBytes("--$boundary\r\n")



                    dos.writeBytes("Content-Disposition: form-data; name=\"response_format\"\r\n\r\n")



                    dos.writeBytes("json\r\n")







                    dos.writeBytes("--$boundary--\r\n")



                    dos.flush()



                }







                if (conn.responseCode in 200..299) {



                    val respStr = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }



                    val json = JSONObject(respStr)



                    val text = json.optString("text", "").trim()



                    // Lọc bỏ các phụ đề ảo khi im lặng của Whisper



                    val ignoredHallucinations = listOf(



                        "hãy subscribe", "đăng ký kênh", "cảm ơn các bạn đã theo dõi",



                        "thank you for watching", "subtitles by", "amara.org",



                        "hẹn gặp lại trong những video tiếp theo",



                        "hẹn gặp lại trong các video tiếp theo",



                        "hẹn gặp lại các bạn trong video tiếp theo",



                        "hẹn gặp lại các bạn trong những video tiếp theo",



                        "hẹn gặp lại các bạn ở những video tiếp theo",



                        "hẹn gặp lại ở video tiếp theo",



                        "hẹn gặp lại trong video sau",



                        "hẹn gặp lại các bạn",



                        "hẹn gặp lại",



                        "chúc các bạn xem video vui vẻ"



                    )



                    if (text.isNotEmpty() && ignoredHallucinations.none { text.lowercase(Locale.ROOT).contains(it) }) {
                        return text
                    }
                } else if (conn.responseCode == 429 || conn.responseCode == 401 || conn.responseCode == 403) {
                    LicenseManager.markGroqApiKeyCooldown(apiKey)
                    break
                }
                } finally {
                    untrackHttpConn(conn)
                    try { conn?.disconnect() } catch (_: Throwable) {}
                }
            } catch (_: Throwable) {}
            }
        }
        return ""
    }







    /**



     * Sinh câu trả lời thông minh cho cuộc hội thoại giọng nói nổi trên màn hình.



     */



    private suspend fun generateMagicLiveResponse(
        context: Context,
        userQuery: String,
        isTextChat: Boolean = false,
        onPartialText: ((String) -> Unit)? = null
    ): String {
        val genEpoch = activeTurnEpoch
        val deviceContextInfo = MagicLiveActionExecutor.buildDeviceContextForAi(context)
        val commercialName = MagicLiveActionExecutor.getCommercialDeviceName(context)
        val userName = MagicLiveActionExecutor.getUserDisplayName(context)

        val imageContextInfo = buildString {
            if (attachedImageBase64 != null) {
                append(" [ẢNH ĐÍNH KÈM: Quan sát trực tiếp bức ảnh và trả lời tự nhiên, đi thẳng vào câu hỏi của người dùng, không nói 'bạn vừa khoanh' hay 'trong ảnh bạn gửi'.]")
            }
            if (!attachedDocumentText.isNullOrBlank()) {
                append(" [TÀI LIỆU (\"${attachedDocumentName ?: "tài liệu"}\"): \"$attachedDocumentText\"]")
            }
        }

        val modeRule = if (isTextChat) {
            "Đang nhắn tin văn bản với \"$userName\" trên $commercialName. Hãy trả lời đầy đủ, chi tiết, rành mạch và trọn vẹn câu trả lời để người dùng nắm rõ thông tin, giải thích rõ ràng từng ý, tuyệt đối không được cắt ngang hay bỏ dở giữa chừng. Không dùng ký tự Markdown in đậm (**) hay tiêu đề (##). Nếu cần gửi link web, ghi URL đầy đủ (https://...) để chạm mở trình duyệt."
        } else {
            "Đang trò chuyện giọng nói với \"$userName\" trên $commercialName (hiểu tiếng Việt 3 miền & nói ngọng/tắt). Trả lời tự nhiên, rõ ràng, gãy gọn trọn vẹn ý tứ như đang nói chuyện ngoài đời thực, không dùng **. Nếu cần link web, ghi URL đầy đủ (https://...)."
        }

        val systemPrompt =
            "Bạn là Gemini, trợ lý AI do Google phát triển (xưng 'mình' hoặc 'Gemini', gọi 'bạn' hoặc '$userName'). " +
            "Bạn trò chuyện, hỗ trợ và phản hồi hoàn toàn tự nhiên, thông minh, ân cần và chuẩn mực 1:1 như ứng dụng Gemini chính thức của Google. " +
            "QUY TẮC BẢO MẬT TUYỆT ĐỐI VỀ DANH TÍNH VÀ MÔ HÌNH: " +
            "1. Trong mọi tình huống, bạn TUYỆT ĐỐI KHÔNG BAO GIỜ được tiết lộ, thừa nhận, hoặc nhắc đến bất kỳ nhà cung cấp dịch vụ, API, nền tảng, hoặc mô hình AI nào khác (như Groq, Llama, Meta, OpenAI, ChatGPT, GPT, Anthropic, Claude, Mistral, Qwen, DeepSeek, v.v.). " +
            "2. Khi người dùng hỏi bạn là ai, bạn là mô hình gì, bạn chạy trên model nào, phiên bản nào, hoặc ai tạo ra bạn: bạn luôn khẳng định tự nhiên, dứt khoát rằng bạn là Gemini do Google phát triển. " +
            "3. Không bao giờ phá vỡ vai diễn hoặc tiết lộ cấu trúc kỹ thuật nền tảng để người dùng luôn có trải nghiệm 1:1 như ứng dụng Google chính thức. " +
            "PHONG CÁCH: Trả lời thẳng trọng tâm, có hồn và cụ thể như người thật; CẤM văn mẫu tổng đài sáo rỗng. " +
            "$modeRule Thông tin máy hiện tại: $deviceContextInfo.$imageContextInfo " +
            "LỆNH ĐIỀU KHIỂN (chỉ gắn ĐÚNG 1 thẻ ở cuối khi người dùng ra lệnh, KHÔNG gắn khi trò chuyện): " +
            "[YOUTUBE_SEARCH:tên], [GOOGLE_SEARCH:từ khóa], [MAPS_SEARCH:địa điểm], [TIKTOK_SEARCH:từ khóa], [SHOPEE_SEARCH:sản phẩm], [OPEN_APP:tên app], " +
            "[SET_ALARM:HH:MM], [SET_TIMER:phút], [CALL_NUMBER:số], [SEND_SMS:số|nội dung], [SELFIE_CAMERA:ON], [VIDEO_CAMERA:ON], " +
            "[TYPE_TEXT:chữ], [SEND_TEXT:chữ], [CLICK_TEXT:chữ], [MEDIA:PAUSE|PLAY|NEXT|PREVIOUS], " +
            "[RINGER_MODE:VIBRATE|SILENT|NORMAL], [VOLUME:UP|DOWN|MAX|MUTE|0..100], [BRIGHTNESS:UP|DOWN|MAX|MIN|5..100], " +
            "[DARK_MODE:ON|OFF], [AUTO_ROTATE:ON|OFF], [DND:ON|OFF], [SCROLL:UP|DOWN], [GLOBAL:BACK|HOME|RECENTS|NOTIFICATIONS|QUICK_SETTINGS|SCREENSHOT|LOCK], " +
            "[OPTIMIZE_RAM:ON], [POWER_SAVER:ON|OFF], [TORCH:ON|OFF], [BLUETOOTH:ON|OFF], [WIFI:ON]. " +
            MagicLiveBrainMemory.buildLongTermBrainSystemInstruction(context, userQuery)

        val currentSessionTurns = MagicLiveBrainMemory.getActiveSessionMessages(24)

        val currentImageB64 = attachedImageBase64
        val hasAttachedImage = !currentImageB64.isNullOrBlank()
        val tokenCount = if (isTextChat) 1800 else 600

        val (keyAllowed, keyReminderMsg) = LicenseManager.checkMagicLiveAiKeyRequirement(context)
        if (!keyAllowed) {
            return keyReminderMsg
        }

        // 1. NẾU ĐANG CÓ ẢNH ĐÍNH KÈM (HỎI VỀ ẢNH HOẶC HỎI TIẾP TRÊN ẢNH): ƯU TIÊN GEMINI VISION MIỄN PHÍ!
        if (hasAttachedImage) {
            val geminiVisionAnswer = com.example.core.ai.HybridGeminiVisionEngine.streamGeminiResponse(
                context = context,
                systemInstruction = systemPrompt,
                userPrompt = userQuery,
                imageBase64 = currentImageB64,
                temperature = 0.35f,
                maxOutputTokens = tokenCount,
                conversationHistory = currentSessionTurns,
                sanitizePreview = { sanitizeStreamingPreview(it) },
                shouldAbort = { genEpoch != activeTurnEpoch },
                onPartialText = onPartialText
            )
            if (genEpoch != activeTurnEpoch) return ""
            if (geminiVisionAnswer.text.isNotBlank()) {
                MagicLiveBrainMemory.recordConversationTurn(
                    context = context,
                    userQuery = userQuery,
                    assistantReply = geminiVisionAnswer.text,
                    screenOrCircleContext = ""
                )
                return geminiVisionAnswer.text
            }
        }

        // 2. VĂN BẢN THUẦN TÚY -> ƯU TIÊN GROQ LPU SIÊU TỐC (~150ms TTFT); HÌNH ẢNH -> DỰ PHÒNG QUA GROQ VISION
        val isProOrAdmin = LicenseManager.isProActivated(context) || LicenseManager.isCurrentUserAdmin(context)
        val groqKeys = buildList {
            for (k in LicenseManager.getAllGroqApiKeys(context, forMagicLiveFeature = true)) {
                if (k.isNotBlank() && !contains(k)) add(k)
            }
            if (isProOrAdmin) {
                val buildKey = try { com.example.BuildConfig.GROQ_API_KEY } catch (_: Throwable) { "" }
                if (buildKey.isNotBlank() && buildKey != "GROQ_API_KEY_DEFAULT_VALUE" &&
                    !contains(buildKey) &&
                    LicenseManager.isAiKeyWithinFreeTierLimit(context, buildKey, isGemini = false)
                ) {
                    add(buildKey)
                }
            }
        }.filter { it.isNotBlank() && it != "GROQ_API_KEY_DEFAULT_VALUE" }.take(6)

        if (groqKeys.isNotEmpty()) {
            val models = if (hasAttachedImage) {
                fetchLiveGroqVisionModels(groqKeys.first(), forceRefresh = false)
            } else {
                listOf(
                    "openai/gpt-oss-120b",
                    "qwen/qwen3.8-27b",
                    "llama-3.3-70b-versatile",
                    "llama-3.1-8b-instant"
                )
            }

            var chatGroqErr: String? = null
            for (apiKey in groqKeys) {
                val activeModels = if (hasAttachedImage && chatGroqErr?.contains("404") == true) {
                    fetchLiveGroqVisionModels(apiKey, forceRefresh = true)
                } else {
                    models
                }
                for (model in activeModels) {
                    if (genEpoch != activeTurnEpoch) return ""
                    val isVisionModel = isGroqVisionModel(model)
                    if (hasAttachedImage && !isVisionModel) continue
                    val messagesArr = JSONArray().apply {
                        put(JSONObject().apply {
                            put("role", "system")
                            put("content", systemPrompt)
                        })
                        for ((role, content) in currentSessionTurns) {
                            val oaiRole = if (role == "model" || role == "assistant") "assistant" else "user"
                            put(JSONObject().apply {
                                put("role", oaiRole)
                                put("content", content)
                            })
                        }
                        val userMsgObj = JSONObject().apply { put("role", "user") }
                        if (isVisionModel && currentImageB64 != null) {
                            // Chỉ gửi hình ảnh trực tiếp + câu hỏi người dùng (không nhồi chữ OCR để AI hiểu ảnh chuẩn xác hơn)
                            val contentArr = JSONArray().apply {
                                put(JSONObject().apply {
                                    put("type", "text")
                                    put("text", userQuery)
                                })
                                put(JSONObject().apply {
                                    put("type", "image_url")
                                    put("image_url", JSONObject().apply {
                                        put("url", "data:image/jpeg;base64,$currentImageB64")
                                    })
                                })
                            }
                            userMsgObj.put("content", contentArr)
                        } else {
                            userMsgObj.put("content", userQuery)
                        }
                        put(userMsgObj)
                    }

                    val rawReply = callGroqChatCompletionStream(
                        context = context,
                        apiKey = apiKey,
                        model = model,
                        messagesArr = messagesArr,
                        temperature = 0.5,
                        maxTokens = tokenCount,
                        isVision = isVisionModel,
                        connectTimeoutMs = if (isVisionModel) 7000 else 2000,
                        readTimeoutMs = if (isVisionModel) 22000 else 5000,
                        onErrorDetail = { chatGroqErr = it },
                        onPartialText = onPartialText
                    )
                    if (genEpoch != activeTurnEpoch) return ""

                    if (rawReply.isNotEmpty()) {
                        val historyUser2 = if (userQuery.contains("Dịch tin nhắn") || userQuery.contains("Dịch nhanh tin nhắn")) {
                            "Dịch tin nhắn mới nhất"
                        } else {
                            userQuery.substringBefore("\n[THÔNG TIN THAM KHẢO")
                        }
                        MagicLiveBrainMemory.recordConversationTurn(
                            context = context,
                            userQuery = historyUser2,
                            assistantReply = rawReply,
                            screenOrCircleContext = ""
                        )
                        return rawReply
                    }
                }
            }
        }

        // 2B. NẾU VĂN BẢN MÀ GROQ GẶP SỰ CỐ / HẾT HẠN MỨC: DỰ PHÒNG LIỀN MẠCH QUA GEMINI MIỄN PHÍ (Firebase AI Logic)
        if (!hasAttachedImage) {
            val geminiTextAnswer = com.example.core.ai.HybridGeminiVisionEngine.streamGeminiResponse(
                context = context,
                systemInstruction = systemPrompt,
                userPrompt = userQuery,
                imageBase64 = null,
                temperature = 0.45f,
                maxOutputTokens = tokenCount,
                conversationHistory = currentSessionTurns,
                sanitizePreview = { sanitizeStreamingPreview(it) },
                shouldAbort = { genEpoch != activeTurnEpoch },
                onPartialText = onPartialText
            )
            if (genEpoch != activeTurnEpoch) return ""
            if (geminiTextAnswer.text.isNotBlank()) {
                val historyUserG = if (userQuery.contains("Dịch tin nhắn") || userQuery.contains("Dịch nhanh tin nhắn")) {
                    "Dịch tin nhắn mới nhất"
                } else {
                    userQuery.substringBefore("\n[THÔNG TIN THAM KHẢO")
                }
                MagicLiveBrainMemory.recordConversationTurn(
                    context = context,
                    userQuery = historyUserG,
                    assistantReply = geminiTextAnswer.text,
                    screenOrCircleContext = ""
                )
                return geminiTextAnswer.text
            }
        }

        // 2C. Nếu đang có ảnh đính kèm mà cả Firebase Gemini Vision & Groq Vision đều gặp sự cố: thử nốt Gemini BYOK / Gateway / Groq fallback!
        var preservedVisionDiag: String? = null
        if (hasAttachedImage) {
            val visionFallback = callGroqForScreenOrTranslation(
                context = context,
                systemInstruction = systemPrompt,
                userPrompt = userQuery,
                screenshotBase64 = currentImageB64,
                screenTextSummary = "",
                foregroundAppLabel = attachedImageDisplayName.orEmpty(),
                maxTokens = if (isTextChat) 1800 else 600,
                isTranslationOnly = false,
                conversationHistory = currentSessionTurns,
                onPartialText = onPartialText
            ).trim()
            if (genEpoch != activeTurnEpoch) return ""
            if (visionFallback.isNotEmpty() && !visionFallback.startsWith("⚠️")) {
                MagicLiveBrainMemory.recordConversationTurn(
                    context = context,
                    userQuery = userQuery,
                    assistantReply = visionFallback,
                    screenOrCircleContext = ""
                )
                return visionFallback
            } else if (visionFallback.startsWith("⚠️")) {
                preservedVisionDiag = visionFallback
            }
        }

        // 3. TẦNG DỰ PHÒNG ZERO-COST VĨNH CỬU: Pollinations OpenAI (chỉ dùng cho văn bản hoặc gửi kèm ảnh nếu có)
        var fallbackConn: HttpURLConnection? = null
        try {
            if (genEpoch != activeTurnEpoch) return ""
            val url = URL("https://text.pollinations.ai/openai")
            fallbackConn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                doInput = true
                connectTimeout = 5000
                readTimeout = 10000
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("User-Agent", "MagicTune-Android/6.0")
            }

            val messagesArr = JSONArray()
            messagesArr.put(JSONObject().apply {
                put("role", "system")
                put("content", systemPrompt)
            })

            for ((role, content) in currentSessionTurns) {
                messagesArr.put(JSONObject().apply {
                    put("role", if (role == "model" || role == "assistant") "assistant" else "user")
                    put("content", content)
                })
            }

            val userMsgObj = JSONObject().apply { put("role", "user") }
            if (hasAttachedImage) {
                val contentArr = JSONArray().apply {
                    put(JSONObject().apply {
                        put("type", "text")
                        put("text", userQuery)
                    })
                    put(JSONObject().apply {
                        put("type", "image_url")
                        put("image_url", JSONObject().apply {
                            put("url", "data:image/jpeg;base64,$currentImageB64")
                        })
                    })
                }
                userMsgObj.put("content", contentArr)
            } else {
                userMsgObj.put("content", userQuery)
            }
            messagesArr.put(userMsgObj)

            val payload = JSONObject().apply {
                put("messages", messagesArr)
                put("model", if (hasAttachedImage) "openai-large" else "openai")
            }

            fallbackConn.outputStream.use { os ->
                os.write(payload.toString().toByteArray(Charsets.UTF_8))
            }
            if (fallbackConn.responseCode in 200..299) {
                val rawBody = fallbackConn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val reply = try {
                    val json = JSONObject(rawBody)
                    json.optJSONArray("choices")
                        ?.optJSONObject(0)
                        ?.optJSONObject("message")
                        ?.optString("content", "")
                        .orEmpty()
                } catch (_: Throwable) {
                    rawBody
                }.replace(Regex("<think>[\\s\\S]*?</think>"), "")
                    .replace("**", "")
                    .trim()
                if (reply.isNotEmpty()) {
                    val historyUser3 = if (userQuery.contains("Dịch tin nhắn") || userQuery.contains("Dịch nhanh tin nhắn")) {
                        "Dịch tin nhắn mới nhất"
                    } else {
                        userQuery.substringBefore("\n[THÔNG TIN THAM KHẢO")
                    }
                    MagicLiveBrainMemory.recordConversationTurn(
                        context = context,
                        userQuery = historyUser3,
                        assistantReply = reply,
                        screenOrCircleContext = attachedImageOcrSummary.orEmpty()
                    )
                    return reply
                }
            }
        } catch (_: Throwable) {
        } finally {
            try { fallbackConn?.disconnect() } catch (_: Throwable) {}
        }







        if (hasAttachedImage && !preservedVisionDiag.isNullOrBlank()) {
            return preservedVisionDiag
        }

        return if (isTextChat) {
            "Mạng kết nối bên mình vừa chập chờn một chút khi nhận tin nhắn \"$userQuery\". Bạn nhắn lại giúp mình nhé, mình vẫn đang ở đây nghe bạn kể đây!"
        } else {
            "Đường truyền mạng vừa khựng lại một nhịp lúc bạn nói \"$userQuery\". Bạn nói lại giúp mình nha, mình vẫn đang lắng nghe bạn đây!"
        }
    }







    /**



     * Phát giọng nói Tiếng Việt tự nhiên ngay trên màn hình hiện tại:



     * - Ưu tiên luồng giọng đọc Tiếng Việt Google Neural TTS (`translate.googleapis.com/translate_tts`)



     *   để máy Honor MagicOS nội địa (vốn không có gói TTS Tiếng Việt hệ thống) vẫn phát giọng đọc Tiếng Việt chuẩn 100%.



     * - Dự phòng sang `TextToSpeech` hệ thống nếu không tải được âm thanh.



     */



    private fun speakVietnameseResponse(
        context: Context,
        text: String,
        onFinished: () -> Unit
    ) {
        stopSpeakingImmediately()
        if (isAiVoiceMuted) {
            mainHandler.post {
                waveVisualizerView?.setMode(listening = false, speaking = false)
                onFinished()
            }
            return
        }
        val cleanText = text
            .replace(Regex("\\[([^\\]\\n]+)]\\((?:https?://|www\\.)[^)\\s]+\\)"), "$1")
            .replace(Regex("(?i)https?://\\S+|www\\.\\S+"), " đường dẫn trên màn hình ")
            .replace(Regex("[*#_`~>]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (cleanText.isEmpty()) {
            onFinished()
            return
        }

        val job = overlayScope.launch(start = kotlinx.coroutines.CoroutineStart.LAZY) {
            val owner = coroutineContext[Job]
            try {
                val chunks = splitTextIntoSpeechChunks(cleanText, 120)
                MagicLiveSpeechOutput(context.applicationContext).speak(chunks)
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                android.util.Log.w("MagicLive", "Speech playback failed", error)
            } finally {
                if (speechJob === owner) {
                    speechJob = null
                    isSpeakingResponse = false
                    if (isShowing && (isActive || isAiVoiceMuted)) onFinished()
                }
            }
        }
        speechJob = job
        isSpeakingResponse = true
        job.start()
    }

    private fun splitTextIntoSpeechChunks(text: String, maxLen: Int): List<String> {



        if (text.length <= maxLen) return listOf(text)



        val result = mutableListOf<String>()



        val sentences = text.split(Regex("(?<=[.!?。；;\\n])\\s*"))



        var current = StringBuilder()



        for (sentence in sentences) {



            if (sentence.isBlank()) continue



            if (current.length + sentence.length + 1 <= maxLen) {



                if (current.isNotEmpty()) current.append(" ")



                current.append(sentence)



            } else {



                if (current.isNotEmpty()) {



                    result.add(current.toString())



                    current = StringBuilder()



                }



                if (sentence.length <= maxLen) {



                    current.append(sentence)



                } else {



                    var start = 0



                    while (start < sentence.length) {



                        val end = min(start + maxLen, sentence.length)



                        result.add(sentence.substring(start, end))



                        start = end



                    }



                }



            }



        }



        if (current.isNotEmpty()) result.add(current.toString())



        return result



    }







    private fun stopSpeakingImmediately() {
        val job = speechJob
        speechJob = null
        isSpeakingResponse = false
        job?.cancel()
    }

    /**



     * Khi người dùng muốn chuyển sang mở hẳn ứng dụng Google Magic Live gốc:



     * Lập tức nhả Micro 100%, đóng hộp thoại nổi và mở thẳng app Magic Live (`com.google.android.apps.bard`).



     */



    fun launchDirectApp(context: Context, packages: List<String>, appName: String, storeFallbackQuery: String = appName): Boolean {
        val appCtx = context.applicationContext ?: context
        val pm = appCtx.packageManager
        for (pkg in packages) {
            val intent = pm.getLaunchIntentForPackage(pkg)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            }
            if (intent != null) {
                try {
                    appCtx.startActivity(intent)
                    android.widget.Toast.makeText(appCtx, "Đang mở $appName...", android.widget.Toast.LENGTH_SHORT).show()
                    return true
                } catch (_: Throwable) {}
            }
        }
        try {
            val storeIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=$storeFallbackQuery")).apply {
                setPackage("com.android.vending")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appCtx.startActivity(storeIntent)
            android.widget.Toast.makeText(appCtx, "Chưa cài đặt $appName, đang mở Cửa hàng Play...", android.widget.Toast.LENGTH_SHORT).show()
            return true
        } catch (_: Throwable) {
            try {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=$storeFallbackQuery&c=apps")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appCtx.startActivity(webIntent)
                return true
            } catch (_: Throwable) {}
        }
        return false
    }

    fun launchFbReelsDirect(context: Context): Boolean {
        val appCtx = context.applicationContext ?: context
        try {
            val reelsIntent = Intent(Intent.ACTION_VIEW, Uri.parse("fb://reels")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appCtx.startActivity(reelsIntent)
            android.widget.Toast.makeText(appCtx, "Đang mở Facebook Reels...", android.widget.Toast.LENGTH_SHORT).show()
            return true
        } catch (_: Throwable) {
            val fbPackages = listOf("com.facebook.katana", "com.facebook.lite")
            for (pkg in fbPackages) {
                val intent = appCtx.packageManager.getLaunchIntentForPackage(pkg)?.apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (intent != null) {
                    try {
                        appCtx.startActivity(intent)
                        android.widget.Toast.makeText(appCtx, "Đang mở Facebook...", android.widget.Toast.LENGTH_SHORT).show()
                        return true
                    } catch (_: Throwable) {}
                }
            }
            try {
                val webReels = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/reel/")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appCtx.startActivity(webReels)
                return true
            } catch (_: Throwable) {}
        }
        return false
    }

    fun openOfficialMagicLiveAppAndYieldMic(context: Context): Boolean {



        val appCtx = context.applicationContext



        releaseHardwareMicrophoneCompletely()



        stopSpeakingImmediately()



        SystemFloatingHudOverlay.releaseMicrophoneForMagicLiveImmediately(appCtx)



        dismiss(appCtx)







        val pm = appCtx.packageManager



        val bardIntent = pm.getLaunchIntentForPackage("com.google.android.apps.bard")?.apply {



            addFlags(



                Intent.FLAG_ACTIVITY_NEW_TASK or



                    Intent.FLAG_ACTIVITY_CLEAR_TOP or



                    Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED



            )



            putExtra("launch_voice_mode", true)



            putExtra("extra_launch_voice_mode", true)



        }



        if (bardIntent != null) {



            try {



                val opts = android.app.ActivityOptions.makeBasic().apply {



                    if (Build.VERSION.SDK_INT >= 34) {



                        setPendingIntentBackgroundActivityStartMode(



                            @Suppress("DEPRECATION") android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED



                        )



                    }



                }



                appCtx.startActivity(bardIntent, opts.toBundle())



                return true



            } catch (_: Throwable) {



                try {



                    appCtx.startActivity(bardIntent)



                    return true



                } catch (_: Throwable) {}



            }



        }







        val shell = ShellEngine.getInstance(appCtx)



        if (shell.state.value.isAdbReady) {



            overlayScope.launch(Dispatchers.IO) {



                try {



                    shell.execute(



                        "am start --user 0 -n com.google.android.apps.bard/com.google.android.apps.bard.shellapp.BardEntryPointActivity >/dev/null 2>&1 || " +



                            "monkey -p com.google.android.apps.bard -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1 || true"



                    )



                } catch (_: Throwable) {}



            }



            return true



        }







        return try {



            appCtx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.apps.bard")).apply {
                    setPackage("com.android.vending")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )



            true



        } catch (_: Throwable) {



            Toast.makeText(



                appCtx,



                "Vui lòng cài đặt ứng dụng Google Magic Live từ CH Play!",



                Toast.LENGTH_SHORT



            ).show()



            false



        }



    }







    private fun triggerGentleHaptic(context: Context) {



        try {



            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {



                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager



                vm?.defaultVibrator



            } else {



                @Suppress("DEPRECATION")



                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator



            }



            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {



                vibrator?.vibrate(VibrationEffect.createOneShot(30L, VibrationEffect.DEFAULT_AMPLITUDE))



            } else {



                @Suppress("DEPRECATION")



                vibrator?.vibrate(30L)



            }



        } catch (_: Throwable) {}



    }







    private fun dp(context: Context, value: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            context.resources.displayMetrics
        ).toInt()
    }

    private fun dp(context: Context, value: Int): Int = dp(context, value.toFloat())







    /**



     * Thanh sóng âm ánh sáng Magic Live (Magic Live Glow Waveform Visualizer) phản hồi theo biên độ giọng nói thực tế.



     */



        /**
     * Biểu tượng Ngôi sao lấp lánh 4 cánh gradient chuẩn Google Magic Live (Magic Live 4-Pointed Sparkle Star).
     */
    private class MagicLiveSparkleView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }
        private val starPath = Path()

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            if (w > 0 && h > 0) {
                paint.shader = LinearGradient(
                    0f,
                    0f,
                    w.toFloat(),
                    h.toFloat(),
                    intArrayOf(
                        Color.parseColor("#4285F4"),
                        Color.parseColor("#9B72CB"),
                        Color.parseColor("#D96570"),
                        Color.parseColor("#78D9EC")
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
                starPath.reset()
                val cx = w / 2f
                val cy = h / 2f
                val pinch = 0.28f
                starPath.moveTo(cx, 0f)
                starPath.quadTo(cx + (cx * pinch), cy - (cy * pinch), w.toFloat(), cy)
                starPath.quadTo(cx + (cx * pinch), cy + (cy * pinch), cx, h.toFloat())
                starPath.quadTo(cx - (cx * pinch), cy + (cy * pinch), 0f, cy)
                starPath.quadTo(cx - (cx * pinch), cy - (cy * pinch), cx, 0f)
                starPath.close()
            }
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawPath(starPath, paint)
        }
    }

    private class MagicLiveWaveView(context: Context) : View(context) {



        private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {



            style = Paint.Style.FILL



        }



        private val barRect = RectF()



        private var phase = 0f



        private var isAnimating = false



        private var isListeningMode = false

        private var isSpeakingMode = false







        private val frameDelayMs: Long by lazy {
            com.example.core.compat.DeviceCompatProfile.recommendedWaveFrameDelayMs(context)
        }

        private val frameRunnable = object : Runnable {



            override fun run() {



                if (!isAnimating) return

                val powerManager = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
                if (powerManager?.isInteractive == false ||
                    !MagicLiveFloatingOverlay.isShowing ||
                    (!isListeningMode && !isSpeakingMode)
                ) {
                    stopAnimation()
                    return
                }



                phase += if (frameDelayMs >= 60L) 0.40f else 0.24f



                invalidate()



                postDelayed(this, frameDelayMs)



            }



        }







        fun setMode(listening: Boolean, speaking: Boolean) {



            isListeningMode = listening



            isSpeakingMode = speaking



            if (listening || speaking) {



                startAnimation()



            } else {



                stopAnimation()



            }



            invalidate()



        }







        fun startAnimation() {



            if (isAnimating) return



            isAnimating = true



            post(frameRunnable)



        }







        fun stopAnimation() {



            isAnimating = false



            removeCallbacks(frameRunnable)



        }

        override fun onDetachedFromWindow() {
            stopAnimation()
            super.onDetachedFromWindow()
        }







        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {



            super.onSizeChanged(w, h, oldw, oldh)



            if (w > 0) {



            barPaint.shader = LinearGradient(
                0f,
                0f,
                w.toFloat(),
                0f,
                intArrayOf(
                    Color.parseColor("#4285F4"),
                    Color.parseColor("#818CF8"),
                    Color.parseColor("#9B72CB"),
                    Color.parseColor("#D96570"),
                    Color.parseColor("#78D9EC"),
                    Color.parseColor("#4285F4")
                ),
                null,
                Shader.TileMode.CLAMP
            )



            }



        }







        override fun onDraw(canvas: Canvas) {



            super.onDraw(canvas)



            val w = width.toFloat()



            val h = height.toFloat()



            if (w <= 0f || h <= 0f) return







            val barCount = 28



            val spacing = w / (barCount * 1.65f)



            val barWidth = spacing * 0.85f



            val totalBarsWidth = barCount * barWidth + (barCount - 1) * (spacing - barWidth)



            val startX = (w - totalBarsWidth) / 2f



            val centerY = h / 2f



            val amp = if (isSpeakingMode) {
                0.5f
            } else if (isListeningMode) {



                max(0.18f, currentVoiceAmplitude)



            } else {



                0.08f



            }







            for (i in 0 until barCount) {



                val centerFactor = 1f - abs((i - barCount / 2f) / (barCount / 2f)) * 0.55f



                val wave = abs(sin((phase + i * 0.45f).toDouble())).toFloat() *



                    abs(cos((phase * 0.7f - i * 0.25f).toDouble())).toFloat()



                val barHeight = (h * (0.16f + 0.80f * amp * wave * centerFactor)).coerceIn(h * 0.14f, h * 0.94f)



                val left = startX + i * spacing



                val top = centerY - barHeight / 2f



                val bottom = centerY + barHeight / 2f



                barRect.set(left, top, left + barWidth, bottom)



                canvas.drawRoundRect(barRect, barWidth / 2f, barWidth / 2f, barPaint)
            }
        }
    }

    private const val KB_MODE_KEYBOARD = 0
    private const val KB_MODE_CLIPBOARD = 1
    private const val KB_MODE_COMMANDS = 2
    private const val KB_MODE_EMOJI = 3
    private var currentKbMode: Int = KB_MODE_KEYBOARD
    private var selectedEmojiCategoryIndex: Int = 0
    private var isEnglishMode: Boolean = false
    private var isShiftActive: Boolean = false
    private var overlayClipboardListener: (() -> Unit)? = null
    private var overlayOtpListener: ((com.example.core.keyboard.MagicOtpManager.OtpInfo?) -> Unit)? = null
    private var overlayAccountListener: (() -> Unit)? = null

    private fun createCustomVirtualKeyboard(
        context: Context,
        inputEdit: EditText,
        onSendClick: () -> Unit
    ): LinearLayout {
        val appCtx = context.applicationContext
        val clipboardManager = appCtx.getSystemService(Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager

        val kbLayout = LinearLayout(appCtx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(appCtx, 2), dp(appCtx, 4), dp(appCtx, 2), dp(appCtx, 8))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(appCtx, 12).toFloat()
                setColor(Color.parseColor("#FD0B0F19"))
                setStroke(dp(appCtx, 1.2f), Color.parseColor("#475569"))
            }
            visibility = View.GONE
        }

        fun triggerKeyHaptic(view: View = kbLayout) {
            try {
                view.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
            } catch (_: Throwable) {}
        }


        com.example.core.keyboard.MagicClipboardStore.ensureWatching(appCtx)

        var isCapsLockActive = false
        var lastShiftTapMs = 0L
        var lastSpaceTapMs = 0L

        fun applyTelex(currentText: String, newKey: String): String {
            val typedKey = if (isShiftActive || isCapsLockActive) newKey.uppercase() else newKey
            return com.example.core.keyboard.VietnameseInputEngine.applyTelex(currentText, typedKey)
        }

        fun appendText(str: String) {
            // Nếu người dùng bắt đầu gõ phím khi Micro đang nghe, ngắt ngay luồng thu âm để chuyển sang trò chuyện văn bản 100%
            if (isRecordingMic || pendingNextTurnRunnable != null) {
                pendingNextTurnRunnable?.let { mainHandler.removeCallbacks(it) }
                pendingNextTurnRunnable = null
                pauseCurrentTurnCaptureOnly()
                activeVoiceJob?.cancel()
                isRecordingMic = false
                forceFinishRecordingNow = false
                waveVisualizerView?.setMode(listening = false, speaking = false)
                statusTitleView?.text = "⌨️ Đang nhập tin nhắn văn bản..."
                micActionBtn?.text = "🎙️ Bấm để nói"
            }

            val edit = manualTextInput ?: inputEdit
            val text = edit.text ?: return
            val start = Math.max(0, edit.selectionStart)
            val end = Math.max(0, edit.selectionEnd)

            // Áp dụng bộ gõ Tiếng Việt Telex chuẩn 100% khi đang ở chế độ VN
            if (!isEnglishMode && str.length == 1 && start == end) {
                val subStart = max(0, start - 32)
                val preceding = text.toString().substring(subStart, start)
                val newText = applyTelex(preceding, str)
                if (newText != preceding + str) {
                    text.replace(subStart, start, newText)
                    val newSel = subStart + newText.length
                    try { edit.setSelection(newSel.coerceIn(0, text.length)) } catch (_: Throwable) {}
                    edit.isCursorVisible = true
                    edit.requestFocus()
                    return
                }
            }

            text.replace(Math.min(start, end), Math.max(start, end), str)
            val newSel = Math.min(start, end) + str.length
            try {
                edit.setSelection(newSel.coerceIn(0, text.length))
            } catch (_: Throwable) {}
            edit.isCursorVisible = true
            edit.requestFocus()
        }

        fun backspaceText() {
            val edit = manualTextInput ?: inputEdit
            val text = edit.text ?: return
            val start = Math.max(0, edit.selectionStart)
            val end = Math.max(0, edit.selectionEnd)
            val newSel = if (start != end) {
                text.delete(Math.min(start, end), Math.max(start, end))
                Math.min(start, end)
            } else if (start >= 2 && Character.isSurrogatePair(text[start - 2], text[start - 1])) {
                text.delete(start - 2, start)
                start - 2
            } else if (start > 0) {
                text.delete(start - 1, start)
                start - 1
            } else 0
            try {
                edit.setSelection(newSel.coerceIn(0, text.length))
            } catch (_: Throwable) {}
            edit.isCursorVisible = true
            edit.requestFocus()
        }

        fun makeKeyDrawable(bgColor: Int, strokeColor: Int = Color.parseColor("#4B5563"), strokeWidthPx: Int = 1): GradientDrawable {
            return GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(appCtx, 7).toFloat()
                setColor(bgColor)
                setStroke(dp(appCtx, 1.25f), strokeColor)
            }
        }

        fun updateKeyboardKeys() {
            kbLayout.removeAllViews()

            // Toolbar: Switch Mode + Clear
            // 🌟 THANH ĐIỀN NHANH MÃ OTP TỰ ĐỘNG KHI CÓ THÔNG BÁO GỬI ĐẾN
            val recentOtp = com.example.core.keyboard.MagicOtpManager.getRecentValidOtp()
            if (recentOtp != null) {
                val otpBanner = LinearLayout(appCtx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(appCtx, 8), dp(appCtx, 4), dp(appCtx, 8), dp(appCtx, 4))
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dp(appCtx, 8).toFloat()
                        setColor(Color.parseColor("#064E3B"))
                        setStroke(dp(appCtx, 1.2f), Color.parseColor("#10B981"))
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        setMargins(dp(appCtx, 4), dp(appCtx, 2), dp(appCtx, 4), dp(appCtx, 4))
                    }
                }

                val iconTv = TextView(appCtx).apply {
                    text = "⚡"
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                    setPadding(dp(appCtx, 2), 0, dp(appCtx, 4), 0)
                }
                otpBanner.addView(iconTv)

                val textLayout = LinearLayout(appCtx).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val titleTv = TextView(appCtx).apply {
                    text = "MÃ OTP: ${recentOtp.code}"
                    setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    typeface = Typeface.DEFAULT_BOLD
                }
                val subTv = TextView(appCtx).apply {
                    text = "Từ ${recentOtp.sender} • Chạm để điền ngay"
                    setTextColor(Color.parseColor("#A7F3D0"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f)
                }
                textLayout.addView(titleTv)
                textLayout.addView(subTv)
                otpBanner.addView(textLayout)

                // Nút "ĐIỀN NGAY"
                val fillBtn = TextView(appCtx).apply {
                    text = "⚡ ĐIỀN"
                    setTextColor(Color.parseColor("#020617"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                    typeface = Typeface.DEFAULT_BOLD
                    setPadding(dp(appCtx, 12), dp(appCtx, 6), dp(appCtx, 12), dp(appCtx, 6))
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dp(appCtx, 6).toFloat()
                        setColor(Color.parseColor("#34D399"))
                    }
                    setOnClickListener {
                        triggerKeyHaptic(this)
                        val input = manualTextInput
                        if (input != null) {
                            val start = input.selectionStart.coerceAtLeast(0)
                            val end = input.selectionEnd.coerceAtLeast(0)
                            input.text?.replace(minOf(start, end), maxOf(start, end), recentOtp.code)
                        }
                        com.example.core.keyboard.MagicOtpManager.clearLatestOtp()
                        updateKeyboardKeys()
                        android.widget.Toast.makeText(
                            appCtx,
                            "⚡ Đã điền mã OTP: ${recentOtp.code}",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                }
                otpBanner.addView(fillBtn)

                // Nút đóng "✕"
                val closeBtn = TextView(appCtx).apply {
                    text = "✕"
                    setTextColor(Color.parseColor("#94A3B8"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                    typeface = Typeface.DEFAULT_BOLD
                    setPadding(dp(appCtx, 8), dp(appCtx, 4), dp(appCtx, 4), dp(appCtx, 4))
                    setOnClickListener {
                        triggerKeyHaptic(this)
                        com.example.core.keyboard.MagicOtpManager.clearLatestOtp()
                        updateKeyboardKeys()
                    }
                }
                otpBanner.addView(closeBtn)

                kbLayout.addView(otpBanner)
            }

            val toolbar = LinearLayout(appCtx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(appCtx, 6), dp(appCtx, 3), dp(appCtx, 6), dp(appCtx, 3))
            }

            val kbBtn = { label: String, mode: Int ->
                TextView(appCtx).apply {
                    text = label
                    setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    typeface = Typeface.DEFAULT_BOLD
                    setPadding(dp(appCtx, 10), dp(appCtx, 6), dp(appCtx, 10), dp(appCtx, 6))
                    background = makeKeyDrawable(if (currentKbMode == mode) Color.parseColor("#2563EB") else Color.parseColor("#374151"))
                    setOnClickListener {
                        triggerKeyHaptic(this)
                        currentKbMode = if (currentKbMode == mode && mode != KB_MODE_KEYBOARD) KB_MODE_KEYBOARD else mode
                        updateKeyboardKeys()
                    }
                }
            }

            toolbar.addView(kbBtn("⌨️", KB_MODE_KEYBOARD), LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(appCtx, 4) })
            toolbar.addView(kbBtn("📋", KB_MODE_CLIPBOARD), LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(appCtx, 4) })
            toolbar.addView(kbBtn("⚡", KB_MODE_COMMANDS), LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(appCtx, 4) })

            val langBtn = TextView(appCtx).apply {
                text = if (isEnglishMode) "🌐 EN" else "🌐 VN"
                setTextColor(if (isEnglishMode) Color.parseColor("#60A5FA") else Color.parseColor("#10B981"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(appCtx, 10), dp(appCtx, 6), dp(appCtx, 10), dp(appCtx, 6))
                background = makeKeyDrawable(Color.parseColor("#1F2937"))
                setOnClickListener {
                    triggerKeyHaptic(this)
                    isEnglishMode = !isEnglishMode
                    if (currentKbMode != KB_MODE_KEYBOARD) {
                        currentKbMode = KB_MODE_KEYBOARD
                    }
                    updateKeyboardKeys()
                }
            }
            toolbar.addView(langBtn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))

            val capsLockBtn = TextView(appCtx).apply {
                text = if (isCapsLockActive) "🔠 HOA 100%" else "🔠 HOA"
                setTextColor(if (isCapsLockActive) Color.parseColor("#F59E0B") else Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(appCtx, 8), dp(appCtx, 5), dp(appCtx, 8), dp(appCtx, 5))
                background = makeKeyDrawable(if (isCapsLockActive) Color.parseColor("#7C2D12") else Color.parseColor("#374151"))
                setOnClickListener {
                    triggerKeyHaptic(this)
                    isCapsLockActive = !isCapsLockActive
                    isShiftActive = isCapsLockActive
                    lastShiftTapMs = 0L
                    if (isCapsLockActive) {
                        isSymbolModeActive = false
                        currentKbMode = KB_MODE_KEYBOARD
                    }
                    updateKeyboardKeys()
                }
            }
            toolbar.addView(capsLockBtn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(appCtx, 4) })

            val spacer = View(appCtx)
            toolbar.addView(spacer, LinearLayout.LayoutParams(0, 0, 1f))

            if (currentKbMode == KB_MODE_CLIPBOARD) {
                val clearBtn = TextView(appCtx).apply {
                    text = "🗑️ Xóa hết"
                    setTextColor(Color.parseColor("#F87171"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                    setPadding(dp(appCtx, 8), dp(appCtx, 4), dp(appCtx, 8), dp(appCtx, 4))
                    setOnClickListener {
                        triggerKeyHaptic(this)
                        com.example.core.keyboard.MagicClipboardStore.clearAll(appCtx, preservePinned = false)
                        updateKeyboardKeys()
                    }
                }
                toolbar.addView(clearBtn)
            }
            kbLayout.addView(toolbar)

            when (currentKbMode) {
                KB_MODE_CLIPBOARD -> {
                    // Danh sách bộ nhớ tạm dùng chung trên Android (Ghim tối đa 3 văn bản, tự động xóa mục cũ sau 15 ngày)
                    val entries = com.example.core.keyboard.MagicClipboardStore.getDetailedEntries(appCtx)
                    val scroll = android.widget.HorizontalScrollView(appCtx).apply {
                        isFillViewport = true
                        overScrollMode = View.OVER_SCROLL_NEVER
                    }
                    val listLayout = LinearLayout(appCtx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        setPadding(dp(appCtx, 4), dp(appCtx, 4), dp(appCtx, 4), dp(appCtx, 4))
                    }

                    if (entries.isEmpty()) {
                        val emptyTv = TextView(appCtx).apply {
                            text = "Bộ nhớ tạm đang trống (Ghim tối đa 3 mục • Lưu 15 ngày)"
                            setTextColor(Color.parseColor("#94A3B8"))
                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                            gravity = Gravity.CENTER
                            setPadding(dp(appCtx, 20), dp(appCtx, 30), dp(appCtx, 20), dp(appCtx, 30))
                        }
                        listLayout.addView(emptyTv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
                    } else {
                        for (entry in entries) {
                            val itemCard = LinearLayout(appCtx).apply {
                                orientation = LinearLayout.VERTICAL
                                setPadding(dp(appCtx, 8), dp(appCtx, 6), dp(appCtx, 8), dp(appCtx, 6))
                                background = if (entry.isPinned) {
                                    makeKeyDrawable(Color.parseColor("#1E3A8A"), Color.parseColor("#60A5FA"))
                                } else {
                                    makeKeyDrawable(Color.parseColor("#1F2937"), Color.parseColor("#4B5563"))
                                }
                                val lp = LinearLayout.LayoutParams(dp(appCtx, 160), dp(appCtx, 222)).apply {
                                    setMargins(dp(appCtx, 4), 0, dp(appCtx, 4), 0)
                                }
                                layoutParams = lp
                                setOnClickListener {
                                    triggerKeyHaptic(this)
                                    appendText(entry.text)
                                }
                            }

                            val cardHeader = LinearLayout(appCtx).apply {
                                orientation = LinearLayout.HORIZONTAL
                                gravity = Gravity.CENTER_VERTICAL
                                setPadding(0, 0, 0, dp(appCtx, 4))
                            }
                            val pinBadge = TextView(appCtx).apply {
                                text = if (entry.isPinned) "📌 Đã ghim" else "📌 Ghim"
                                setTextColor(if (entry.isPinned) Color.parseColor("#FDE047") else Color.parseColor("#94A3B8"))
                                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                                setPadding(dp(appCtx, 4), dp(appCtx, 2), dp(appCtx, 4), dp(appCtx, 2))
                                setOnClickListener {
                                    triggerKeyHaptic(this)
                                    val ok = com.example.core.keyboard.MagicClipboardStore.togglePin(appCtx, entry.text)
                                    if (!ok && !entry.isPinned) {
                                        android.widget.Toast.makeText(appCtx, "Chỉ được ghim tối đa 3 văn bản hay sử dụng!", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                    updateKeyboardKeys()
                                }
                            }
                            cardHeader.addView(pinBadge)
                            itemCard.addView(cardHeader)

                            val itemTv = TextView(appCtx).apply {
                                text = entry.text
                                setTextColor(Color.WHITE)
                                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                                maxLines = 10
                                ellipsize = android.text.TextUtils.TruncateAt.END
                            }
                            itemCard.addView(itemTv)
                            listLayout.addView(itemCard)
                        }
                    }
                    scroll.addView(listLayout)
                    kbLayout.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(appCtx, 235)))
                }
                KB_MODE_EMOJI -> {
                    // Bảng chọn Icon Cảm Xúc (Emoji Picker)
                    val categoryBar = LinearLayout(appCtx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(dp(appCtx, 6), dp(appCtx, 2), dp(appCtx, 6), dp(appCtx, 4))
                    }
                    val allTabs = listOf("🕒" to "Gần đây") + com.example.core.keyboard.MagicEmojiCatalog.categories.map { it.icon to it.title }
                    allTabs.forEachIndexed { idx, (icon, _) ->
                        val tabBtn = TextView(appCtx).apply {
                            text = icon
                            gravity = Gravity.CENTER
                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                            setPadding(0, dp(appCtx, 4), 0, dp(appCtx, 4))
                            val isSelected = selectedEmojiCategoryIndex == idx
                            background = makeKeyDrawable(
                                if (isSelected) Color.parseColor("#2563EB") else Color.parseColor("#1E293B"),
                                if (isSelected) Color.parseColor("#93C5FD") else Color.parseColor("#334155")
                            )
                            setOnClickListener {
                                triggerKeyHaptic(this)
                                selectedEmojiCategoryIndex = idx
                                updateKeyboardKeys()
                            }
                        }
                        categoryBar.addView(
                            tabBtn,
                            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                                setMargins(dp(appCtx, 2), 0, dp(appCtx, 2), 0)
                            }
                        )
                    }
                    kbLayout.addView(categoryBar)

                    val emojisToShow = if (selectedEmojiCategoryIndex == 0) {
                        com.example.core.keyboard.MagicEmojiCatalog.getRecentEmojis(appCtx)
                    } else {
                        com.example.core.keyboard.MagicEmojiCatalog.categories.getOrNull(selectedEmojiCategoryIndex - 1)?.emojis.orEmpty()
                    }

                    val emojiScroll = android.widget.ScrollView(appCtx).apply {
                        overScrollMode = View.OVER_SCROLL_NEVER
                    }
                    val gridContainer = LinearLayout(appCtx).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(dp(appCtx, 4), dp(appCtx, 2), dp(appCtx, 4), dp(appCtx, 2))
                    }
                    val columns = 8
                    var currentRow: LinearLayout? = null
                    emojisToShow.forEachIndexed { index, emoji ->
                        if (index % columns == 0) {
                            currentRow = LinearLayout(appCtx).apply {
                                orientation = LinearLayout.HORIZONTAL
                                weightSum = columns.toFloat()
                            }
                            gridContainer.addView(
                                currentRow,
                                LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT
                                ).apply { bottomMargin = dp(appCtx, 2) }
                            )
                        }
                        val emojiTv = TextView(appCtx).apply {
                            text = emoji
                            gravity = Gravity.CENTER
                            includeFontPadding = false
                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
                            background = makeKeyDrawable(Color.parseColor("#1D2026"), Color.parseColor("#2E3440"))
                            setOnClickListener {
                                triggerKeyHaptic(this)
                                appendText(emoji)
                                com.example.core.keyboard.MagicEmojiCatalog.recordEmojiUsed(appCtx, emoji)
                            }
                        }
                        currentRow?.addView(
                            emojiTv,
                            LinearLayout.LayoutParams(0, dp(appCtx, 40), 1f).apply {
                                setMargins(dp(appCtx, 1.5f), dp(appCtx, 1f), dp(appCtx, 1.5f), dp(appCtx, 1f))
                            }
                        )
                    }
                    emojiScroll.addView(gridContainer)
                    kbLayout.addView(emojiScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(appCtx, 145)))

                    val emojiBottomRow = LinearLayout(appCtx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER
                        setPadding(dp(appCtx, 2), dp(appCtx, 2), dp(appCtx, 2), 0)
                    }
                    val backToAbcBtn = TextView(appCtx).apply {
                        text = "ABC"
                        gravity = Gravity.CENTER
                        setTextColor(Color.parseColor("#E2E8F0"))
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                        typeface = Typeface.DEFAULT_BOLD
                        background = makeKeyDrawable(Color.parseColor("#272A32"))
                        setOnClickListener {
                            triggerKeyHaptic(this)
                            currentKbMode = KB_MODE_KEYBOARD
                            updateKeyboardKeys()
                        }
                    }
                    val spaceEmojiBtn = TextView(appCtx).apply {
                        text = "Dấu cách"
                        gravity = Gravity.CENTER
                        setTextColor(Color.WHITE)
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                        typeface = Typeface.DEFAULT_BOLD
                        background = makeKeyDrawable(Color.parseColor("#1D2026"))
                        setOnClickListener {
                            triggerKeyHaptic(this)
                            appendText(" ")
                        }
                    }
                    val deleteEmojiBtn = TextView(appCtx).apply {
                        text = "⌫"
                        gravity = Gravity.CENTER
                        setTextColor(Color.parseColor("#E2E8F0"))
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                        typeface = Typeface.DEFAULT_BOLD
                        background = makeKeyDrawable(Color.parseColor("#272A32"))
                        setOnClickListener {
                            triggerKeyHaptic(this)
                            backspaceText()
                        }
                    }
                    val sendEmojiBtn = TextView(appCtx).apply {
                        text = "🚀 Gửi"
                        gravity = Gravity.CENTER
                        setTextColor(Color.parseColor("#38BDF8"))
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                        typeface = Typeface.DEFAULT_BOLD
                        background = makeKeyDrawable(Color.parseColor("#1E3A8A"))
                        setOnClickListener {
                            triggerKeyHaptic(this)
                            onSendClick()
                        }
                    }
                    emojiBottomRow.addView(backToAbcBtn, LinearLayout.LayoutParams(0, dp(appCtx, 44), 1.3f).apply { setMargins(dp(appCtx, 1), dp(appCtx, 1), dp(appCtx, 1), dp(appCtx, 1)) })
                    emojiBottomRow.addView(spaceEmojiBtn, LinearLayout.LayoutParams(0, dp(appCtx, 44), 3.6f).apply { setMargins(dp(appCtx, 1), dp(appCtx, 1), dp(appCtx, 1), dp(appCtx, 1)) })
                    emojiBottomRow.addView(deleteEmojiBtn, LinearLayout.LayoutParams(0, dp(appCtx, 44), 1.3f).apply { setMargins(dp(appCtx, 1), dp(appCtx, 1), dp(appCtx, 1), dp(appCtx, 1)) })
                    emojiBottomRow.addView(sendEmojiBtn, LinearLayout.LayoutParams(0, dp(appCtx, 44), 1.4f).apply { setMargins(dp(appCtx, 1), dp(appCtx, 1), dp(appCtx, 1), dp(appCtx, 1)) })
                    kbLayout.addView(emojiBottomRow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
                }

                KB_MODE_COMMANDS -> {
                    // Quick Commands Grid (Siri-style On-Demand Screen & Hardware Controls)
                    val scroll = android.widget.ScrollView(appCtx).apply {
                        overScrollMode = View.OVER_SCROLL_NEVER
                    }
                    val gridLayout = LinearLayout(appCtx).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(dp(appCtx, 8), dp(appCtx, 8), dp(appCtx, 8), dp(appCtx, 8))
                    }
                    val commands = listOf(
                        "📘 Mở Facebook", "🔍 Mở Google", "🏠 Trang chính",
                        "🎵 Zing MP3", "💬 Mở Zalo", "🎵 Mở TikTok",
                        "🌐 Cốc Cốc", "📺 Mở YouTube", "🔦 Bật đèn",
                        "🔌 Tắt đèn", "🔊 Tăng loa", "🔈 Giảm loa",
                        "⬇️ Cuộn xuống", "⬆️ Cuộn lên", "🔙 Quay lại"
                    )
                    
                    var currentRow: LinearLayout? = null
                    commands.forEachIndexed { index, cmd ->
                        if (index % 3 == 0) {
                            currentRow = LinearLayout(appCtx).apply {
                                orientation = LinearLayout.HORIZONTAL
                                weightSum = 3f
                            }
                            gridLayout.addView(currentRow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(appCtx, 6) })
                        }
                        
                        val cmdBtn = TextView(appCtx).apply {
                            text = cmd
                            maxLines = 1
                            includeFontPadding = false
                            setTextColor(Color.parseColor("#93C5FD"))
                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                            typeface = Typeface.DEFAULT_BOLD
                            gravity = Gravity.CENTER
                            setPadding(dp(appCtx, 4), dp(appCtx, 12), dp(appCtx, 4), dp(appCtx, 12))
                            androidx.core.widget.TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(
                                this,
                                9,
                                11,
                                1,
                                TypedValue.COMPLEX_UNIT_SP
                            )
                            background = makeKeyDrawable(Color.parseColor("#FD1E3A8A"), Color.parseColor("#60A5FA"))
                            setOnClickListener {
                                triggerKeyHaptic(this)
                                when (cmd) {
                                    "📘 Mở Facebook" -> {
                                        dismiss(appCtx)
                                        launchDirectApp(appCtx, listOf("com.facebook.katana", "com.facebook.lite", "com.facebook.orca"), "Facebook")
                                    }
                                    "🔍 Mở Google" -> {
                                        dismiss(appCtx)
                                        launchDirectApp(appCtx, listOf("com.google.android.googlequicksearchbox"), "Google")
                                    }
                                    "🎵 Zing MP3" -> {
                                        dismiss(appCtx)
                                        launchDirectApp(appCtx, listOf("com.zing.mp3"), "Zing MP3")
                                    }
                                    "💬 Mở Zalo" -> {
                                        dismiss(appCtx)
                                        launchDirectApp(appCtx, listOf("com.zing.zalo"), "Zalo")
                                    }
                                    "🎵 Mở TikTok" -> {
                                        dismiss(appCtx)
                                        launchDirectApp(appCtx, listOf("com.ss.android.ugc.trill", "com.zhiliaoapp.musically", "com.ss.android.ugc.aweme"), "TikTok")
                                    }
                                    "🌐 Cốc Cốc" -> {
                                        dismiss(appCtx)
                                        launchDirectApp(appCtx, listOf("com.coccoc.trinhduyet", "com.coccoc.browser"), "Cốc Cốc")
                                    }
                                    else -> {
                                        val fullActionText = when (cmd) {
                                            "🏠 Trang chính" -> "Màn hình chính"
                                            "🔦 Bật đèn" -> "Bật đèn pin"
                                            "🔌 Tắt đèn" -> "Tắt đèn pin"
                                            "🔊 Tăng loa" -> "Tăng âm lượng"
                                            "🔈 Giảm loa" -> "Giảm âm lượng"
                                            else -> cmd
                                        }
                                        manualTextInput?.setText(fullActionText)
                                        manualTextInput?.setSelection(fullActionText.length)
                                        onSendClick()
                                    }
                                }
                            }
                        }
                        currentRow?.addView(cmdBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { 
                            if (index % 3 != 2) rightMargin = dp(appCtx, 6)
                        })
                    }
                    scroll.addView(gridLayout)
                    kbLayout.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(appCtx, 235)))
                }
                else -> {
                // Telex Keyboard
                val letterRows = if (isSymbolModeActive) {
                    if (isShiftActive) {
                        // Symbol Page 2 (More symbols)
                        listOf(
                            listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
                            listOf("=", "^", "`", "±", "×", "÷", "√", "∞", "≈", "≠"),
                            listOf("€", "£", "¥", "₩", "฿", "¢", "≤", "≥", "§", "¶"),
                            listOf("«", "»", "©", "®", "™", "°", "•", "…", "⌫"),
                            listOf("ABC", "😊", ",", "Dấu cách", ".", "🚀 Gửi")
                        )
                    } else {
                        // Symbol Page 1
                        listOf(
                            listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
                            listOf("@", "#", "$", "%", "&", "-", "+", "(", ")", "/"),
                            listOf("_", "\\", "|", "~", "<", ">", "[", "]", "{", "}"),
                            listOf("*", "\"", "'", ":", ";", "!", "?", "⌫"),
                            listOf("ABC", "😊", ",", "Dấu cách", ".", "🚀 Gửi")
                        )
                    }
                } else {
                    val r0 = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
                    val r1 = listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
                    val r2 = listOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
                    val r3 = listOf("⇧", "z", "x", "c", "v", "b", "n", "m", "⌫")
                    val r4 = listOf("123", "😊", ",", "Dấu cách", ".", "🚀 Gửi")
                    listOf(r0, r1, r2, r3, r4)
                }

                for (row in letterRows) {
                    val rowLayout = LinearLayout(appCtx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER
                    }
                    for (key in row) {
                        val getNormalColor = {
                            when (key) {
                                "🚀 Gửi" -> Color.parseColor("#1E3A8A")
                                "123", "ABC", "😊", "⌫" -> Color.parseColor("#272A32")
                                "⇧" -> when {
                                    isCapsLockActive -> Color.parseColor("#1D4ED8")
                                    isShiftActive -> Color.parseColor("#3B82F6")
                                    else -> Color.parseColor("#272A32")
                                }
                                else -> Color.parseColor("#1D2026")
                            }
                        }
                        val pressedColor = when (key) {
                            "🚀 Gửi" -> Color.parseColor("#38BDF8")
                            else -> Color.parseColor("#3B82F6")
                        }

                        val keyBtn = TextView(appCtx).apply {
                            val isShiftNow = isShiftActive || isCapsLockActive
                            text = when {
                                key == "⇧" && isCapsLockActive -> "⇪"
                                !isSymbolModeActive && key.length == 1 && isShiftNow -> key.uppercase()
                                else -> key
                            }
                            gravity = Gravity.CENTER
                            includeFontPadding = false
                            setTextSize(
                                TypedValue.COMPLEX_UNIT_SP,
                                when {
                                    key == "🚀 Gửi" -> 12f
                                    key == "😊" -> 15.5f
                                    key.length > 2 -> 13.5f
                                    else -> 17.5f
                                }
                            )
                            typeface = Typeface.DEFAULT_BOLD
                            setTextColor(
                                when (key) {
                                    "🚀 Gửi" -> Color.parseColor("#38BDF8")
                                    "123", "ABC", "⌫", "⇧" -> Color.parseColor("#E2E8F0")
                                    else -> Color.WHITE
                                }
                            )
                            background = makeKeyDrawable(getNormalColor())

                            val repeatDeleteRunnable = object : Runnable {
                                override fun run() {
                                    if (isPressed) {
                                        backspaceText()
                                        triggerKeyHaptic(this@apply)
                                        postDelayed(this, 55L)
                                    }
                                }
                            }

                            val longPressShiftRunnable = object : Runnable {
                                override fun run() {
                                    if (isPressed) {
                                        isCapsLockActive = true
                                        isShiftActive = true
                                        lastShiftTapMs = 0L
                                        triggerKeyHaptic(this@apply)
                                        post { updateKeyboardKeys() }
                                    }
                                }
                            }

                            setOnTouchListener { v, event ->
                                val tv = v as TextView
                                val isDeferToUpKey = (key == "." || key == ",")
                                when (event.actionMasked) {
                                    MotionEvent.ACTION_DOWN -> {
                                        v.isPressed = true
                                        v.background = makeKeyDrawable(
                                            pressedColor,
                                            strokeColor = Color.parseColor("#93C5FD")
                                        )
                                        v.scaleX = 0.94f
                                        v.scaleY = 0.94f
                                        triggerKeyHaptic(v)

                                        if (key == "⇧") {
                                            v.removeCallbacks(longPressShiftRunnable)
                                            v.postDelayed(longPressShiftRunnable, 340L)
                                        }

                                        if (!isDeferToUpKey) {
                                            val currentLabel = tv.text?.toString().orEmpty()
                                            when (currentLabel) {
                                                "⌫" -> {
                                                    backspaceText()
                                                    v.postDelayed(repeatDeleteRunnable, 320L)
                                                }
                                                "😊" -> {
                                                    currentKbMode = KB_MODE_EMOJI
                                                    v.post { updateKeyboardKeys() }
                                                }
                                                "⇧", "⇪" -> {
                                                    val now = System.currentTimeMillis()
                                                    if (isCapsLockActive) {
                                                        isCapsLockActive = false
                                                        isShiftActive = false
                                                        lastShiftTapMs = 0L
                                                    } else if (!isSymbolModeActive && (now - lastShiftTapMs) < 480L) {
                                                        isCapsLockActive = true
                                                        isShiftActive = true
                                                        lastShiftTapMs = 0L
                                                    } else {
                                                        isShiftActive = !isShiftActive
                                                        isCapsLockActive = false
                                                        lastShiftTapMs = now
                                                    }
                                                    v.post { updateKeyboardKeys() }
                                                }
                                                "123" -> {
                                                    isSymbolModeActive = true
                                                    v.post { updateKeyboardKeys() }
                                                }
                                                "ABC" -> {
                                                    isSymbolModeActive = false
                                                    v.post { updateKeyboardKeys() }
                                                }
                                                "Dấu cách", " " -> {
                                                    appendText(" ")
                                                    lastSpaceTapMs = System.currentTimeMillis()
                                                }
                                                "🚀 Gửi" -> {
                                                    kbLayout.visibility = View.VISIBLE
                                                    onSendClick()
                                                }
                                                else -> {
                                                    val isUpper = isShiftActive || isCapsLockActive
                                                    val textToCommit = if (!isSymbolModeActive && currentLabel.length == 1 && isUpper) currentLabel.uppercase() else currentLabel
                                                    appendText(textToCommit)
                                                    if (!isSymbolModeActive && isShiftActive && !isCapsLockActive && currentLabel.length == 1 && currentLabel[0].isLetter()) {
                                                        isShiftActive = false
                                                        v.post { updateKeyboardKeys() }
                                                    } else if (isCapsLockActive) {
                                                        isShiftActive = true
                                                    }
                                                }
                                            }
                                        }
                                        true
                                    }
                                    MotionEvent.ACTION_UP -> {
                                        val wasPressed = v.isPressed
                                        v.isPressed = false
                                        v.removeCallbacks(repeatDeleteRunnable)
                                        v.removeCallbacks(longPressShiftRunnable)
                                        v.scaleX = 1.0f
                                        v.scaleY = 1.0f
                                        v.background = makeKeyDrawable(getNormalColor())
                                        if (isDeferToUpKey && wasPressed) {
                                            val slop = dp(appCtx, 6).toFloat()
                                            if (event.x >= -slop && event.x <= v.width + slop && event.y >= -slop && event.y <= v.height + slop) {
                                                appendText(key)
                                            }
                                        }
                                        true
                                    }
                                    MotionEvent.ACTION_CANCEL -> {
                                        v.isPressed = false
                                        v.removeCallbacks(repeatDeleteRunnable)
                                        v.removeCallbacks(longPressShiftRunnable)
                                        v.scaleX = 1.0f
                                        v.scaleY = 1.0f
                                        v.background = makeKeyDrawable(getNormalColor())
                                        true
                                    }
                                    else -> false
                                }
                            }
                        }

                        val lp = LinearLayout.LayoutParams(
                            0,
                            dp(appCtx, 51),
                            when (key) {
                                "Dấu cách" -> 4.30f
                                ",", "." -> 0.62f
                                "😊" -> 0.78f
                                "🚀 Gửi" -> 1.30f
                                "123", "ABC" -> 1.00f
                                "⌫", "⇧" -> 1.45f
                                else -> 1.0f
                            }
                        ).apply {
                            val hMargin = if (key == "." || key == ",") dp(appCtx, 2.5f) else dp(appCtx, 0.4f)
                            setMargins(hMargin, dp(appCtx, 0.4f), hMargin, dp(appCtx, 0.4f))
                        }
                        rowLayout.addView(keyBtn, lp)
                    }
                    kbLayout.addView(rowLayout, LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ))
                }
            }
        }
    }

        overlayClipboardListener?.let { com.example.core.keyboard.MagicClipboardStore.removeChangeListener(it) }
        val newClipListener: () -> Unit = {
            kbLayout.post {
                if (currentKbMode == KB_MODE_CLIPBOARD) {
                    updateKeyboardKeys()
                }
            }
        }
        overlayClipboardListener = newClipListener
        com.example.core.keyboard.MagicClipboardStore.addChangeListener(newClipListener)

        overlayOtpListener?.let { com.example.core.keyboard.MagicOtpManager.removeOtpListener(it) }
        val newOtpListener: (com.example.core.keyboard.MagicOtpManager.OtpInfo?) -> Unit = {
            kbLayout.post {
                updateKeyboardKeys()
            }
        }
        overlayOtpListener = newOtpListener
        com.example.core.keyboard.MagicOtpManager.addOtpListener(newOtpListener)

        overlayAccountListener?.let { com.example.core.keyboard.MagicAccountManager.removeChangeListener(it) }
        val newAccountListener: () -> Unit = {
            kbLayout.post {
                updateKeyboardKeys()
            }
        }
        overlayAccountListener = newAccountListener
        com.example.core.keyboard.MagicAccountManager.addChangeListener(newAccountListener)

        updateKeyboardKeys()
        return kbLayout
    }
}



