package com.example.core.widget

import android.app.ActivityManager
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.util.Log
import android.widget.Toast
import android.provider.Settings
import com.example.MainActivity
import com.example.core.license.LicenseManager
import com.example.core.service.NoAccessibilityScreenEngine
import com.example.core.service.AutoWakeupPatrolManager
import com.example.core.shell.ShellEngine
import java.text.Normalizer
import java.util.Locale
import kotlin.math.roundToInt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Bộ Thực Thi Lệnh Điều Khiển Điện Thoại Bằng Giọng Nói (MagicLiveActionExecutor).
 *
 * Cho phép người dùng ra lệnh bằng Tiếng Việt tự nhiên ngay trong khi đàm thoại rảnh tay với Magic Live Nổi:
 * - Mở bất kỳ ứng dụng nào trên máy (Zalo, Facebook, TikTok, YouTube, Shopee, Taobao, 1688, Máy ảnh, Cài đặt, Bản đồ...).
 * - Tìm kiếm trực tiếp trên YouTube, Google, Bản đồ Google Maps.
 * - Thao tác giao diện trực tiếp: Cuộn xuống, Cuộn lên, Vuốt trái/phải, Quay lại, Về màn hình chính, Mở đa nhiệm,
 *   Kéo thanh thông báo, Chụp màn hình, Khóa màn hình, hoặc "Bấm vào [Tên nút bất kỳ trên màn hình]".
 * - Điều khiển phần cứng: Bật/Tắt đèn pin, Tăng/Giảm/Đặt mức âm lượng, Tăng/Giảm độ sáng, Bật/Tắt Wi-Fi, Bluetooth,
 *   Kích hoạt Khoanh tròn hỏi AI hoặc Dịch Cuộn Trực Tiếp.
 */
object MagicLiveActionExecutor {

    private val executorScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    /**
     * Nhận diện tên thương mại chính thức của thiết bị (ví dụ: Honor Magic 6 Pro thay vì mã nội địa BVL-AN16).
     */
    /**
     * Lấy tên người dùng đang hiển thị trên ứng dụng MagicTune (từ FirebaseAuth hoặc bộ nhớ đệm tài khoản / SharedPreferences).
     */
    fun getUserDisplayName(context: Context? = null): String {
        return try {
            val u = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser
            val name = u?.displayName?.trim()
            val emailPrefix = u?.email?.substringBefore("@")?.trim()
            when {
                !name.isNullOrBlank() -> name
                !emailPrefix.isNullOrBlank() -> emailPrefix
                context != null -> {
                    val sp = context.getSharedPreferences("magictune_user_pref", Context.MODE_PRIVATE)
                    val cachedName = sp.getString("user_display_name", "")?.trim().orEmpty()
                    val cachedEmail = sp.getString("user_email", "")?.trim().orEmpty()
                    when {
                        cachedName.isNotBlank() -> cachedName
                        cachedEmail.isNotBlank() && cachedEmail.contains("@") -> cachedEmail.substringBefore("@")
                        else -> "bạn"
                    }
                }
                else -> "bạn"
            }
        } catch (_: Throwable) {
            "bạn"
        }
    }

    fun getCommercialDeviceName(context: Context? = null): String {
        val model = Build.MODEL.trim()
        val manufacturer = Build.MANUFACTURER.trim()

        val knownHonorModels = mapOf(
            "BVL-AN16" to "Honor Magic 6 Pro",
            "BVL-AN00" to "Honor Magic 6 Pro",
            "BVL-AN20" to "Honor Magic 6 Ultimate",
            "BVL-N49" to "Honor Magic 6 RSR Porsche Design",
            "PGT-AN10" to "Honor Magic 5 Pro",
            "PGT-AN00" to "Honor Magic 5 Pro",
            "PGT-AN20" to "Honor Magic 5 Ultimate",
            "FRI-AN00" to "Honor Magic 7",
            "FRI-AN10" to "Honor Magic 7 Pro",
            "VER-AN10" to "Honor Magic V2",
            "VER-AN00" to "Honor Magic V2",
            "FCP-AN10" to "Honor Magic V3",
            "FCP-AN00" to "Honor Magic V3",
            "ANY-AN00" to "Honor 50",
            "FNE-AN00" to "Honor 70",
            "REA-AN00" to "Honor 90",
            "REA-NX9" to "Honor 90",
            "MAG-AN00" to "Honor 100",
            "MAG-AN10" to "Honor 100 Pro",
            "AMP-AN00" to "Honor 200",
            "AMP-AN10" to "Honor 200 Pro",
            "BRN-AL00" to "Honor X9b",
            "ALI-NX1" to "Honor X9b",
            "CLK-AN00" to "Honor 90 Lite",
            "REA-AN10" to "Honor 90 Pro",
            "FLT-AN00" to "Honor 300",
            "FLT-AN10" to "Honor 300 Pro",
            "FRI-AN20" to "Honor Magic 7 RSR",
            "FCA-AN00" to "Honor Magic Vs3",
            "BKC-AN00" to "Honor Magic V Flip",
            "WKG-AN00" to "Honor X50"
        )

        for ((mKey, mName) in knownHonorModels) {
            if (model.equals(mKey, ignoreCase = true) || model.contains(mKey, ignoreCase = true)) {
                return mName
            }
        }

        val propMarketing = try {
            val clz = Class.forName("android.os.SystemProperties")
            val getMethod = clz.getMethod("get", String::class.java)
            val p1 = getMethod.invoke(null, "ro.config.marketing_name") as? String
            val p2 = getMethod.invoke(null, "ro.product.model.display") as? String
            val p3 = getMethod.invoke(null, "ro.product.vendor.marketname") as? String
            listOfNotNull(p1, p2, p3).firstOrNull { it.isNotBlank() }
        } catch (_: Throwable) {
            null
        }

        if (!propMarketing.isNullOrBlank()) {
            return propMarketing.trim()
        }

        return if (model.startsWith(manufacturer, ignoreCase = true)) {
            model
        } else {
            "$manufacturer $model".trim()
        }
    }

    fun readSystemProperty(key: String): String {
        return try {
            val clz = Class.forName("android.os.SystemProperties")
            val getMethod = clz.getMethod("get", String::class.java, String::class.java)
            (getMethod.invoke(null, key, "") as? String)?.trim().orEmpty()
        } catch (_: Throwable) { "" }
    }

    fun getSocMarketingName(): String {
        val rawSoc = try {
            val p1 = readSystemProperty("ro.soc.model")
            val p2 = readSystemProperty("ro.board.platform")
            val p3 = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) Build.SOC_MODEL else ""
            val p4 = Build.HARDWARE
            listOf(p1, p2, p3, p4).firstOrNull { !it.isNullOrBlank() }?.trim().orEmpty()
        } catch (_: Throwable) { "" }

        val lower = rawSoc.lowercase(Locale.ROOT)
        return when {
            lower.contains("sm8950") || lower.contains("mahua") -> "Snapdragon 8 Elite Gen 3"
            lower.contains("sm8850") || lower.contains("kaanapali") -> "Snapdragon 8 Elite Gen 2"
            lower.contains("sm8750") || lower.contains("sun") -> "Snapdragon 8 Elite"
            lower.contains("sm8650") || lower.contains("pineapple") -> "Snapdragon 8 Gen 3"
            lower.contains("sm8550") || lower.contains("kalama") -> "Snapdragon 8 Gen 2"
            lower.contains("sm8475") || lower.contains("cape") -> "Snapdragon 8+ Gen 1"
            lower.contains("sm8450") || lower.contains("taro") -> "Snapdragon 8 Gen 1"
            lower.contains("sm7550") || lower.contains("crow") -> "Snapdragon 7 Gen 3"
            lower.contains("sm7435") || lower.contains("parrot") -> "Snapdragon 6 Gen 1"
            lower.contains("mt6993") || lower.contains("k6993") -> "MediaTek Dimensity 9500"
            lower.contains("mt6991") || lower.contains("k6991") -> "MediaTek Dimensity 9400"
            lower.contains("mt6989") || lower.contains("k6989") -> "MediaTek Dimensity 9300"
            lower.contains("mt6985") -> "MediaTek Dimensity 9200"
            lower.contains("mt6897") -> "MediaTek Dimensity 8300"
            lower.contains("mt6877") -> "MediaTek Dimensity 900"
            rawSoc.isNotBlank() -> rawSoc
            else -> "Qualcomm Snapdragon / MediaTek Dimensity"
        }
    }

    fun getMagicOsVersion(): String {
        val propKeys = listOf(
            "ro.build.version.magic",
            "ro.build.magic.version",
            "ro.honor.build.version.magic",
            "ro.magic.version.display",
            "ro.build.version.emui"
        )
        for (k in propKeys) {
            val v = readSystemProperty(k)
            if (v.isNotBlank()) {
                return if (v.startsWith("MagicOS", ignoreCase = true)) v else "MagicOS $v"
            }
        }
        return "MagicOS"
    }

    data class DeviceRealtimeInfo(
        val commercialName: String,
        val rawModel: String,
        val manufacturer: String,
        val soc: String,
        val magicOsVersion: String,
        val androidVersion: String,
        val sdkInt: Int,
        val batteryPct: Int,
        val isCharging: Boolean,
        val chargingWatt: Double,
        val chargingTitle: String,
        val batteryTempC: Double,
        val batteryVoltageV: Double,
        val ramAvailGb: Double,
        val ramTotalGb: Double,
        val ramUsedPct: Int,
        val romAvailGb: Double,
        val romTotalGb: Double,
        val romUsedPct: Int,
        val refreshRateHz: Int
    )

    fun getDeviceRealtimeInfo(context: Context): DeviceRealtimeInfo {
        val appCtx = context.applicationContext
        val commercialName = getCommercialDeviceName(appCtx)
        val rawModel = Build.MODEL.trim()
        val manufacturer = Build.MANUFACTURER.trim()
        val soc = getSocMarketingName()
        val magicOs = getMagicOsVersion()
        val androidVer = Build.VERSION.RELEASE
        val sdk = Build.VERSION.SDK_INT

        val chargeData = try {
            BatteryInfoReader.read(appCtx, null)
        } catch (_: Throwable) {
            BatteryChargeData(
                batteryPct = 85, voltageV = 4.2, currentWatts = 0.5,
                isCharging = false, speedTitle = "Đang dùng pin",
                minutesToFull = 0, isSlowCharge = false,
                phoneDisplayName = commercialName, estimatedUsageText = ""
            )
        }

        val batteryIntent = try {
            appCtx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        } catch (_: Throwable) { null }
        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val tempC = if (tempTenths > 0) tempTenths / 10.0 else 32.5

        var ramTotal = 16.0
        var ramAvail = 8.0
        var ramPct = 50
        try {
            val am = appCtx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            if (am != null) {
                val memInfo = ActivityManager.MemoryInfo()
                am.getMemoryInfo(memInfo)
                val t = memInfo.totalMem.toDouble() / (1024.0 * 1024.0 * 1024.0)
                val a = memInfo.availMem.toDouble() / (1024.0 * 1024.0 * 1024.0)
                if (t > 0) {
                    ramTotal = t
                    ramAvail = a
                    val used = (t - a).coerceAtLeast(0.0)
                    ramPct = ((used / t) * 100.0).roundToInt().coerceIn(0, 100)
                }
            }
        } catch (_: Throwable) {}

        var romTotal = 256.0
        var romAvail = 128.0
        var romPct = 50
        try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val t = (stat.blockSizeLong * stat.blockCountLong).toDouble() / (1024.0 * 1024.0 * 1024.0)
            val a = (stat.blockSizeLong * stat.availableBlocksLong).toDouble() / (1024.0 * 1024.0 * 1024.0)
            if (t > 0) {
                romTotal = t
                romAvail = a
                val used = (t - a).coerceAtLeast(0.0)
                romPct = ((used / t) * 100.0).roundToInt().coerceIn(0, 100)
            }
        } catch (_: Throwable) {}

        val refreshRate = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                appCtx.display?.refreshRate?.roundToInt() ?: 120
            } else {
                @Suppress("DEPRECATION")
                (appCtx.getSystemService(Context.WINDOW_SERVICE) as? android.view.WindowManager)?.defaultDisplay?.refreshRate?.roundToInt() ?: 120
            }
        } catch (_: Throwable) { 120 }

        return DeviceRealtimeInfo(
            commercialName = commercialName,
            rawModel = rawModel,
            manufacturer = manufacturer,
            soc = soc,
            magicOsVersion = magicOs,
            androidVersion = androidVer,
            sdkInt = sdk,
            batteryPct = chargeData.batteryPct,
            isCharging = chargeData.isCharging,
            chargingWatt = chargeData.currentWatts,
            chargingTitle = chargeData.speedTitle,
            batteryTempC = tempC,
            batteryVoltageV = chargeData.voltageV,
            ramAvailGb = ramAvail,
            ramTotalGb = ramTotal,
            ramUsedPct = ramPct,
            romAvailGb = romAvail,
            romTotalGb = romTotal,
            romUsedPct = romPct,
            refreshRateHz = refreshRate
        )
    }

    fun buildDeviceContextForAi(context: Context): String {
        val d = getDeviceRealtimeInfo(context)
        val ramFreeStr = String.format(Locale.US, "%.1f", d.ramAvailGb)
        val ramTotalStr = String.format(Locale.US, "%.1f", d.ramTotalGb)
        val romFreeStr = String.format(Locale.US, "%.1f", d.romAvailGb)
        val romTotalStr = String.format(Locale.US, "%.0f", d.romTotalGb)
        val tempStr = String.format(Locale.US, "%.1f", d.batteryTempC)
        val chargeStatusStr = if (d.isCharging) {
            val wattStr = if (d.chargingWatt > 1.0) " (Công suất sạc thực tế: ~${d.chargingWatt.roundToInt()}W)" else ""
            "Đang sạc pin - ${d.chargingTitle}$wattStr"
        } else {
            "Đang dùng pin (không cắm sạc)"
        }

        return """
        [THÔNG TIN PHẦN CỨNG & HỆ THỐNG THỰC TẾ CHIẾC ĐIỆN THOẠI CỦA NGƯỜI DÙNG HIỆN TẠI]:
        - Tên dòng máy: ${d.commercialName} (Mã kỹ thuật: ${d.rawModel}, Hãng: ${d.manufacturer})
        - Vi xử lý (Chipset): ${d.soc}
        - Hệ điều hành & Giao diện: ${d.magicOsVersion} trên nền Android ${d.androidVersion} (API ${d.sdkInt})
        - Màn hình: Tần số quét thực tế ${d.refreshRateHz}Hz
        - Tình trạng Pin: ${d.batteryPct}% • $chargeStatusStr • Nhiệt độ pin: ${tempStr}°C (Điện áp: ${String.format(Locale.US, "%.2f", d.batteryVoltageV)}V)
        - Bộ nhớ RAM: Đang trống $ramFreeStr GB / Tổng $ramTotalStr GB (Đã dùng ${d.ramUsedPct}%)
        - Bộ nhớ lưu trữ máy (ROM): Còn trống $romFreeStr GB / Tổng $romTotalStr GB (Đã dùng ${d.romUsedPct}%)
        - Cẩm nang tính năng điện thoại: Thiết bị có thanh Sidebar vuốt giữ từ mép để mở ứng dụng dạng cửa sổ nổi Mini-Window, tính năng Magic Portal kéo thả, dịch cuộn Taobao/1688 xuyên thấu và Khoanh tròn tìm kiếm Circle to Search của MagicTune.
        """.trimIndent()
    }

    suspend fun optimizeDeviceMemory(context: Context) {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            if (am != null) {
                val runningApps = am.runningAppProcesses ?: emptyList()
                val myPkg = context.packageName
                val protectedPackages = setOf(
                    "com.zing.zalo", "com.facebook.orca", "com.facebook.katana",
                    "com.google.android.gm", "com.viber.voip", "org.telegram.messenger",
                    "com.whatsapp", "com.google.android.apps.messaging", "com.instagram.android",
                    "com.shopee.vn", "com.lazada.vn", "com.ss.android.ugc.aweme", "com.zhiliaoapp.musically",
                    myPkg
                )
                for (proc in runningApps) {
                    if (proc.pkgList != null) {
                        for (pkg in proc.pkgList) {
                            val isProtected = protectedPackages.contains(pkg) ||
                                pkg.contains("systemui") ||
                                pkg.contains("launcher") ||
                                pkg.contains("hihonor") ||
                                pkg.contains("huawei") ||
                                pkg.contains("android") ||
                                pkg.startsWith("com.google.android.gms")
                            if (!isProtected) {
                                try {
                                    am.killBackgroundProcesses(pkg)
                                } catch (_: Throwable) {}
                            }
                        }
                    }
                }
            }
            // Không gọi System.gc() cưỡng bức để tránh khựng khung hình (Stop-The-World)
            val shell = ShellEngine.getInstance(context)
            if (shell.state.value.isAdbReady) {
                shell.execute("sync; echo 3 > /proc/sys/vm/drop_caches 2>/dev/null; am trim-memory --all 2>/dev/null || true")
                shell.execute("cmd activity idle-maintenance")
            }
        } catch (_: Throwable) {}
    }

    suspend fun setBatterySaverMode(context: Context, enable: Boolean): Boolean {
        return try {
            val shell = ShellEngine.getInstance(context)
            val v = if (enable) "1" else "0"
            if (shell.state.value.isAdbReady) {
                shell.execute("settings put global low_power $v")
                true
            } else {
                val intent = Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
                launchIntentSafely(context, intent)
            }
        } catch (_: Throwable) {
            false
        }
    }

    data class MediaSearchIntent(
        val searchQuery: String,
        val spokenConfirmation: String,
        val autoPlay: Boolean = true
    )


    data class VoiceCommandResult(
        val handled: Boolean,
        val spokenConfirmation: String,
        val shouldDismissOverlay: Boolean = false,
        val shouldMinimizeOrPauseListening: Boolean = false,
        val screenContextForAi: String? = null
    )

    private val knownAppAliases: Map<String, List<String>> = mapOf(
        "zalo" to listOf("com.zing.zalo"),
        "facebook" to listOf("com.facebook.katana", "com.facebook.lite"),
        "fb" to listOf("com.facebook.katana", "com.facebook.lite"),
        "phay buc" to listOf("com.facebook.katana", "com.facebook.lite"),
        "messenger" to listOf("com.facebook.orca", "com.facebook.mlite"),
        "mess" to listOf("com.facebook.orca"),
        "met sen go" to listOf("com.facebook.orca"),
        "tiktok" to listOf("com.ss.android.ugc.trill", "com.zhiliaoapp.musically", "com.ss.android.ugc.aweme"),
        "tik tok" to listOf("com.ss.android.ugc.trill", "com.zhiliaoapp.musically", "com.ss.android.ugc.aweme"),
        "top top" to listOf("com.ss.android.ugc.trill", "com.zhiliaoapp.musically", "com.ss.android.ugc.aweme"),
        "douyin" to listOf("com.ss.android.ugc.aweme"),
        "pinedrama" to listOf("com.pinedrama.app", "com.pine.drama", "com.pinedrama"),
        "pine drama" to listOf("com.pinedrama.app", "com.pine.drama", "com.pinedrama"),
        "app pinedrama" to listOf("com.pinedrama.app", "com.pine.drama", "com.pinedrama"),
        "reels" to listOf("com.facebook.katana"),
        "fb reels" to listOf("com.facebook.katana"),
        "facebook reels" to listOf("com.facebook.katana"),
        "youtube" to listOf("com.google.android.youtube", "app.revanced.android.youtube", "app.rvx.android.youtube"),
        "ytb" to listOf("com.google.android.youtube", "app.revanced.android.youtube"),
        "diu tup" to listOf("com.google.android.youtube", "app.revanced.android.youtube"),
        "youtube music" to listOf("com.google.android.apps.youtube.music", "app.revanced.android.apps.youtube.music"),
        "shopee" to listOf("com.shopee.vn"),
        "shop pi" to listOf("com.shopee.vn"),
        "lazada" to listOf("com.lazada.android"),
        "tiki" to listOf("vn.tiki.app.tikiandroid"),
        "taobao" to listOf("com.taobao.taobao"),
        "tao bao" to listOf("com.taobao.taobao"),
        "1688" to listOf("com.alibaba.wireless"),
        "pinduoduo" to listOf("com.xunmeng.pinduoduo"),
        "wechat" to listOf("com.tencent.mm"),
        "alipay" to listOf("com.eg.android.AlipayGphone"),
        "xiaohongshu" to listOf("com.xingin.xhs"),
        "tieu hong thu" to listOf("com.xingin.xhs"),
        "bilibili" to listOf("tv.danmaku.bili", "com.bstar.intl"),
        "instagram" to listOf("com.instagram.android"),
        "ig" to listOf("com.instagram.android"),
        "ins" to listOf("com.instagram.android"),
        "threads" to listOf("com.instagram.barcelona"),
        "locket" to listOf("com.locket.Locket"),
        "telegram" to listOf("org.telegram.messenger", "org.telegram.messenger.web"),
        "tele" to listOf("org.telegram.messenger"),
        "whatsapp" to listOf("com.whatsapp"),
        "viber" to listOf("com.viber.voip"),
        "discord" to listOf("com.discord"),
        "capcut" to listOf("com.lemon.lvoverseas", "com.vega.lv"),
        "cap cut" to listOf("com.lemon.lvoverseas", "com.vega.lv"),
        "canva" to listOf("com.canva.editor"),
        "spotify" to listOf("com.spotify.music"),
        "zing mp3" to listOf("com.zing.mp3"),
        "zing" to listOf("com.zing.mp3"),
        "nhaccuatui" to listOf("ht.nct"),
        "soundcloud" to listOf("com.soundcloud.android"),
        "netflix" to listOf("com.netflix.mediaclient"),
        "vieon" to listOf("vieon.movies.tv.shows"),
        "fpt play" to listOf("com.fplay.activity"),
        "tv360" to listOf("com.viettel.tv360"),
        "grab" to listOf("com.grabtaxi.passenger"),
        "be" to listOf("xyz.be.customer"),
        "xanh sm" to listOf("com.gsm.customer"),
        "google dich" to listOf("com.google.android.apps.translate"),
        "dich" to listOf("com.google.android.apps.translate"),
        "google drive" to listOf("com.google.android.apps.docs"),
        "drive" to listOf("com.google.android.apps.docs"),
        "google meet" to listOf("com.google.android.apps.tachyon", "com.google.android.apps.meetings"),
        "zoom" to listOf("us.zoom.videomeetings"),
        "teams" to listOf("com.microsoft.teams"),
        "chatgpt" to listOf("com.openai.chatgpt"),
        "chat gpt" to listOf("com.openai.chatgpt"),
        "coc coc" to listOf("com.coccoc.trinhduyet", "com.coccoc.browser"),
        "coccoc" to listOf("com.coccoc.trinhduyet", "com.coccoc.browser"),
        "app coc coc" to listOf("com.coccoc.trinhduyet", "com.coccoc.browser"),
        "chrome" to listOf("com.android.chrome", "com.hihonor.baidu.browser", "com.huawei.browser"),
        "trinh duyet" to listOf("com.android.chrome", "com.hihonor.baidu.browser", "com.huawei.browser"),
        "google" to listOf("com.google.android.googlequicksearchbox"),
        "magic_live" to listOf("com.google.android.apps.bard"),
        "magic live" to listOf("com.google.android.apps.bard"),
        "ban do" to listOf("com.google.android.apps.maps"),
        "google maps" to listOf("com.google.android.apps.maps"),
        "maps" to listOf("com.google.android.apps.maps"),
        "gmail" to listOf("com.google.android.gm", "com.hihonor.email"),
        "email" to listOf("com.google.android.gm", "com.hihonor.email"),
        "ch play" to listOf("com.android.vending"),
        "play store" to listOf("com.android.vending"),
        "cua hang play" to listOf("com.android.vending"),
        "app market" to listOf("com.hihonor.appmarket", "com.huawei.appmarket"),
        "may anh" to listOf("com.hihonor.camera", "com.huawei.camera", "com.android.camera", "com.android.camera2"),
        "camera" to listOf("com.hihonor.camera", "com.huawei.camera", "com.android.camera", "com.android.camera2"),
        "thu vien" to listOf("com.hihonor.photos", "com.huawei.photos", "com.google.android.apps.photos", "com.android.gallery3d"),
        "bo suu tap" to listOf("com.hihonor.photos", "com.huawei.photos", "com.google.android.apps.photos", "com.android.gallery3d"),
        "anh" to listOf("com.hihonor.photos", "com.huawei.photos", "com.google.android.apps.photos"),
        "cai dat" to listOf("com.android.settings"),
        "settings" to listOf("com.android.settings"),
        "dien thoai" to listOf("com.hihonor.contacts", "com.android.dialer", "com.google.android.dialer", "com.android.contacts"),
        "cuoc goi" to listOf("com.hihonor.contacts", "com.android.dialer", "com.google.android.dialer"),
        "danh ba" to listOf("com.hihonor.contacts", "com.android.contacts", "com.google.android.contacts"),
        "tin nhan" to listOf("com.google.android.apps.messaging", "com.android.mms", "com.hihonor.mms"),
        "dong ho" to listOf("com.hihonor.deskclock", "com.android.deskclock", "com.google.android.deskclock"),
        "bao thuc" to listOf("com.hihonor.deskclock", "com.android.deskclock", "com.google.android.deskclock"),
        "may tinh" to listOf("com.hihonor.calculator", "com.android.calculator2", "com.google.android.calculator"),
        "ghi chu" to listOf("com.hihonor.notepad", "com.huawei.notepad", "com.google.android.keep"),
        "ghi am" to listOf("com.hihonor.soundrecorder", "com.huawei.soundrecorder", "com.android.soundrecorder"),
        "quan ly tep" to listOf("com.hihonor.filemanager", "com.huawei.hidisk", "com.google.android.apps.nbu.files"),
        "tep" to listOf("com.hihonor.filemanager", "com.huawei.hidisk", "com.google.android.apps.nbu.files"),
        "la ban" to listOf("com.hihonor.compass", "com.huawei.compass"),
        "suc khoe" to listOf("com.hihonor.health", "com.huawei.health"),
        "chu de" to listOf("com.hihonor.android.thememanager", "com.huawei.android.thememanager"),
        "lich" to listOf("com.hihonor.calendar", "com.android.calendar", "com.google.android.calendar"),
        "thoi tiet" to listOf("com.hihonor.android.totemweather", "com.huawei.android.totemweather", "com.google.android.apps.weather", "com.coloros.weather2"),
        "magictune" to listOf("com.magictune.tool", "com.example"),
        "magic tune" to listOf("com.magictune.tool", "com.example")
    )

    fun normalizeVi(text: String): String {
        val decomposed = Normalizer.normalize(text.lowercase(Locale.ROOT).trim(), Normalizer.Form.NFD)
        return decomposed
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace('đ', 'd')
            .replace(Regex("[^a-z0-9%\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    /**
     * Lọc bỏ các từ đệm / từ gọi trợ lý lịch sự tự nhiên trong Tiếng Việt (chuẩn Siri Tiếng Việt 2026)
     * như "Magic ơi", "Siri ơi", "Trợ lý ơi", "Làm ơn", "Giúp mình", "Cho mình", "Nhé", "Nha", "Ạ"...
     * để mọi câu lệnh tự nhiên đều khớp 100% với bộ thực thi tức thì.
     */
    fun stripPoliteVietnameseWrappers(normInput: String): String {
        var s = normInput.trim()
        val prefixes = listOf(
            "hey siri ", "hi siri ", "siri oi ", "siri ",
            "hey magic ", "hi magic ", "magic live oi ", "magic oi ", "magic ",
            "magic live oi ", "magic live ", "magic_live oi ", "magic_live ", "tro ly oi ", "tro ly magic oi ", "tro ly ",
            "em oi ", "ban oi ", "anh oi ", "chi oi ", "alo ", "nay ", "oi ",
            "lam on ", "vui long ", "xin vui long ", "hay ", "thu ",
            "giup toi ", "giup minh ", "giup anh ", "giup chi ", "giup em ", "ho toi ", "ho minh ",
            "cho toi ", "cho minh ", "cho anh ", "cho chi ", "cho em "
        )
        var changed = true
        while (changed) {
            changed = false
            for (p in prefixes) {
                if (s.startsWith(p) && s.length > p.length + 2) {
                    s = s.removePrefix(p).trim()
                    changed = true
                }
            }
        }
        val suffixes = listOf(
            " giup toi nhe", " giup minh nhe", " giup toi nha", " giup minh nha",
            " giup toi voi", " giup minh voi", " giup toi di", " giup minh di",
            " giup toi", " giup minh", " giup anh", " giup chi", " giup em",
            " cho toi nhe", " cho minh nhe", " cho toi nha", " cho minh nha",
            " cho toi voi", " cho minh voi", " cho toi", " cho minh", " ho toi", " ho minh",
            " dum minh", " dum toi", " gium minh", " gium toi",
            " len nhe", " len nha", " len di",
            " duoc khong", " nhe ban", " nha ban", " nhe em", " nha em",
            " nhe", " nha", " nhen", " nghen", " voi", " a"
        )
        changed = true
        while (changed) {
            changed = false
            for (suf in suffixes) {
                if (s.endsWith(suf) && s.length > suf.length + 2) {
                    s = s.removeSuffix(suf).trim()
                    changed = true
                }
            }
        }
        return s.trim()
    }

    /**
     * Phân tích và thực thi ngay câu lệnh điều khiển điện thoại của người dùng (nếu là câu lệnh thao tác).
     * Trả về `VoiceCommandResult(handled = false, ...)` nếu đây là câu hỏi trò chuyện thông thường.
     */
    suspend fun tryExecuteVoiceCommand(context: Context, rawSpokenText: String): VoiceCommandResult {
        val appCtx = context.applicationContext
        val cleanText = rawSpokenText.trim()
        val rawNorm = normalizeVi(cleanText)
        if (rawNorm.isEmpty()) return VoiceCommandResult(false, "")
        val norm = stripPoliteVietnameseWrappers(rawNorm).ifEmpty { rawNorm }

        // 0.001. Hỏi Giờ / Ngày / Thứ / Năm Hiện Tại (Chuẩn Siri Tiếng Việt 2026 — Phản hồi 0ms)
        if (norm in setOf(
                "may gio roi", "bay gio la may gio", "may gio", "xem gio", "gio hien tai",
                "hom nay la thu may", "hom nay thu may", "hom nay ngay may", "hom nay ngay bao nhieu",
                "hom nay la ngay bao nhieu", "hom nay la ngay may", "lich hom nay", "ngay hom nay",
                "ngay mai la thu may", "ngay mai ngay bao nhieu", "ngay mai la ngay may",
                "nam nay la nam bao nhieu", "nam nay nam may"
            ) || norm.startsWith("bay gio la may gio") || norm.startsWith("hom nay la thu may") ||
            norm.startsWith("hom nay la ngay bao nhieu") || norm.startsWith("hom nay ngay may")
        ) {
            val cal = java.util.Calendar.getInstance()
            if (norm.contains("ngay mai")) {
                cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
            }
            val hour = cal.get(java.util.Calendar.HOUR_OF_DAY)
            val minute = cal.get(java.util.Calendar.MINUTE)
            val dayOfWeek = when (cal.get(java.util.Calendar.DAY_OF_WEEK)) {
                java.util.Calendar.MONDAY -> "Thứ Hai"
                java.util.Calendar.TUESDAY -> "Thứ Ba"
                java.util.Calendar.WEDNESDAY -> "Thứ Tư"
                java.util.Calendar.THURSDAY -> "Thứ Năm"
                java.util.Calendar.FRIDAY -> "Thứ Sáu"
                java.util.Calendar.SATURDAY -> "Thứ Bảy"
                else -> "Chủ Nhật"
            }
            val day = cal.get(java.util.Calendar.DAY_OF_MONTH)
            val month = cal.get(java.util.Calendar.MONTH) + 1
            val year = cal.get(java.util.Calendar.YEAR)
            val reply = when {
                norm.contains("ngay mai") -> "Ngày mai là $dayOfWeek, ngày $day tháng $month năm $year."
                norm.contains("gio") -> "Bây giờ là $hour giờ ${String.format(Locale.US, "%02d", minute)} phút, $dayOfWeek ngày $day tháng $month năm $year."
                else -> "Hôm nay là $dayOfWeek, ngày $day tháng $month năm $year (hiện tại là $hour giờ ${String.format(Locale.US, "%02d", minute)} phút)."
            }
            return VoiceCommandResult(handled = true, spokenConfirmation = reply)
        }

        // 0.002. Tính Toán Nhanh & Đổi Ngoại Tệ Bằng Giọng Nói Tiếng Việt (Siri 2026 Instant Math & Currency)
        val currencyMatch = Regex("""^(?:doi\s+)?(\d+(?:[.,]\d+)?)\s*(te|nhan dan te|cny|ndt|do|do la|usd|yen|jpy|won|krw)\s*(?:sang|ra|bang bao nhieu|la bao nhieu)?\s*(?:tien viet|vnd|dong|viet nam dong)?$""").find(norm)
        if (currencyMatch != null) {
            val amount = currencyMatch.groupValues[1].replace(",", ".").toDoubleOrNull()
            val unit = currencyMatch.groupValues[2]
            if (amount != null && amount > 0) {
                val (rate, unitLabel) = when (unit) {
                    "te", "nhan dan te", "cny", "ndt" -> 3550.0 to "Nhân dân tệ"
                    "do", "do la", "usd" -> 25450.0 to "Đô la Mỹ (USD)"
                    "yen", "jpy" -> 170.0 to "Yên Nhật"
                    "won", "krw" -> 18.5 to "Won Hàn Quốc"
                    else -> 3550.0 to unit
                }
                val vnd = (amount * rate).toLong()
                val formattedVnd = java.text.NumberFormat.getNumberInstance(Locale("vi", "VN")).format(vnd)
                val formattedAmt = if (amount % 1.0 == 0.0) amount.toLong().toString() else amount.toString()
                return VoiceCommandResult(
                    handled = true,
                    spokenConfirmation = "$formattedAmt $unitLabel tương đương khoảng $formattedVnd đồng Việt Nam."
                )
            }
        }

        val mathMatch = Regex("""^(?:tinh\s+)?(\d+)\s*(cong|tru|nhan|chia|phan tram cua)\s*(\d+)(?:\s*bang bao nhieu|\s*la bao nhieu)?$""").find(norm)
        if (mathMatch != null) {
            val a = mathMatch.groupValues[1].toDoubleOrNull()
            val op = mathMatch.groupValues[2]
            val b = mathMatch.groupValues[3].toDoubleOrNull()
            if (a != null && b != null) {
                val resultStr = when (op) {
                    "cong" -> "${(a + b).toLong()}"
                    "tru" -> "${(a - b).toLong()}"
                    "nhan" -> java.text.NumberFormat.getNumberInstance(Locale("vi", "VN")).format((a * b).toLong())
                    "chia" -> if (b != 0.0) String.format(Locale.US, "%.2f", a / b).removeSuffix(".00") else "không thể chia cho 0"
                    "phan tram cua" -> String.format(Locale.US, "%.2f", (a * b) / 100.0).removeSuffix(".00")
                    else -> null
                }
                if (resultStr != null) {
                    val opVi = when (op) {
                        "cong" -> "cộng"
                        "tru" -> "trừ"
                        "nhan" -> "nhân"
                        "chia" -> "chia"
                        else -> "phần trăm của"
                    }
                    return VoiceCommandResult(
                        handled = true,
                        spokenConfirmation = "Kết quả của ${a.toLong()} $opVi ${b.toLong()} là $resultStr."
                    )
                }
            }
        }

        // 0. Lệnh Hỏi Tên / "Tôi là ai" / "Tên tôi là gì"
        if (norm == "toi la ai" || norm.contains("toi la ai") || norm.contains("ten toi la gi") ||
            norm.contains("ten cua toi la gi") || norm.contains("biet toi la ai khong") || norm.contains("ten nguoi dung")
        ) {
            val uName = getUserDisplayName(appCtx)
            val reply = if (uName.isNotBlank() && uName != "bạn") {
                "Bạn là $uName chứ ai nữa, người bạn thân thiết và cũng là chủ nhân chiếc điện thoại này mà, mình nhớ rõ lắm!"
            } else {
                "Bạn là người bạn đồng hành và là chủ nhân chiếc điện thoại này đó! Bạn có thể đặt tên trong phần Tài khoản MagicTune để mình gọi tên bạn thân mật hơn nha."
            }
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = reply
            )
        }

        // 0.01. Lệnh Hỏi Danh Tính / Giới thiệu / Mô hình AI ("Bạn là ai", "Tên bạn là gì", "Bạn là mô hình gì")
        val isIdentityOrModelQuery = norm == "ban la ai" || norm == "ten ban la gi" ||
            norm == "may la ai" || norm == "ten may la gi" || norm.contains("gioi thieu ban than") ||
            norm.contains("gioi thieu ve ban") || norm.contains("mo hinh gi") || norm.contains("model gi") ||
            norm.contains("chay model gi") || norm.contains("dung model gi") || norm.contains("ai tao ra ban") ||
            norm.contains("co phai llama") || norm.contains("co phai groq") || norm.contains("co phai chatgpt") ||
            norm.contains("co phai openai") || norm.contains("ban la ai day")

        if (isIdentityOrModelQuery) {
            val uName = getUserDisplayName(appCtx)
            val reply = if (uName.isNotBlank() && uName != "bạn") {
                "Mình là Gemini, trợ lý trí tuệ nhân tạo do Google phát triển, vừa hỗ trợ điều khiển thông minh, vừa là người bạn đồng hành luôn sẵn sàng trò chuyện cùng $uName mọi lúc!"
            } else {
                "Mình là Gemini, trợ lý trí tuệ nhân tạo do Google phát triển, luôn sẵn sàng hỗ trợ điều khiển thiết bị và trò chuyện thông minh cùng bạn bất cứ lúc nào!"
            }
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = reply
            )
        }

        // 0.05. AI ĐẶC TRỊ FIX THÔNG BÁO GMAIL, FACEBOOK, MESSENGER & ZALO CHO HONOR
        val isFixNotificationQuery = (
            (norm.contains("thong bao") || norm.contains("tit thong bao") || norm.contains("mat thong bao") || norm.contains("tre thong bao") || norm.contains("khong co chuong")) &&
            (norm.contains("gmail") || norm.contains("mail") || norm.contains("facebook") || norm.contains("fb") || norm.contains("honor") || norm.contains("zalo") || norm.contains("tat ca"))
        ) || norm.contains("fix thong bao") || norm.contains("sua thong bao") || norm.contains("bat thong bao gmail") || norm.contains("sua loi thong bao") || norm.contains("danh thuc thong bao")

        if (isFixNotificationQuery) {
            AutoWakeupPatrolManager.performHonorNotificationDeepFix(appCtx)
            val confirm = "AI đã kết hợp cơ chế tuần tra đánh thức phần cứng và vô hiệu hóa các trình dìm ngầm của Honor (PowerGenius, iAware). Đã kích hoạt toàn quyền chạy ngầm, Standby Bucket Active và đồng bộ hóa tức thì cho Gmail, Facebook, Messenger và Zalo!"
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = confirm
            )
        }

        // 0.06. HƯỚNG DẪN / TẮT CHẾ ĐỘ NHÀ PHÁT TRIỂN & GIẢI THÍCH LÝ DO KHÔNG VÀO ĐƯỢC APP NGÂN HÀNG, VNEID
        val isDevOptionsQuery = norm.contains("nha phat trien") || norm.contains("developer option") || norm.contains("go loi usb") || norm.contains("debugging")
        val isCannotOpenBankGovQuery = (norm.contains("khong vao duoc") || norm.contains("khong truy cap duoc") || norm.contains("bi chan") || norm.contains("bi vang") || norm.contains("khong mo duoc") || norm.contains("canh bao") || norm.contains("tai sao")) &&
            (norm.contains("ngan hang") || norm.contains("vneid") || norm.contains("vssid") || norm.contains("dich vu cong") || norm.contains("app do") || norm.contains("ung dung do"))

        if (isDevOptionsQuery || isCannotOpenBankGovQuery) {
            val devIntent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val openedDev = launchIntentSafely(appCtx, devIntent)

            val explanation = when {
                openedDev -> "Các ứng dụng tài chính và xác thực định danh thường chặn truy cập nếu Chế độ nhà phát triển đang bật để bảo mật tài khoản. Tôi đã mở trang Cài đặt Chế độ nhà phát triển cho bạn, bạn có thể kiểm tra hoặc tắt thủ công nếu cần nhé!"
                else -> "Các ứng dụng tài chính và xác thực định danh bảo mật từ chối mở khi điện thoại đang bật Chế độ nhà phát triển. Bạn có thể vào Cài đặt -> Tùy chọn nhà phát triển để quản lý thủ công nhé!"
            }
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = explanation
            )
        }

        // 0.1 Câu chào hỏi mở đầu ngắn: "Xin chào", "Chào bạn", "Hello", "Hi"
        if (norm in setOf(
                "xin chao", "chao", "chao ban", "chao magic live", "chao magic_live", "hello", "hi", "alo", "helo", "hello magic live", "hello magic_live", "hi magic live", "hi magic_live",
                "chao tro ly", "chao tro ly magic", "xin chao tro ly", "xin chao tro ly magic", "hey magic", "hi magic", "hello magic"
            )) {
            val uName = getUserDisplayName(appCtx)
            val greeting = if (uName.isNotBlank() && uName != "bạn") {
                "Chào $uName nha! Hôm nay của bạn thế nào rồi, có chuyện gì vui muốn kể hay cần mình giúp gì không?"
            } else {
                "Chào bạn nha! Hôm nay của bạn thế nào rồi, đang rảnh rỗi muốn tán gẫu hay cần mình làm gì trên máy cứ bảo mình nhé!"
            }
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = greeting
            )
        }

        // 1. Lệnh Đóng / Tạm biệt / Ngừng trò chuyện MAGIC LIVE
        if (norm in setOf(
                "tam biet", "dung lai", "tat magic live", "tat magic_live", "dong magic live", "dong magic_live", "thoat magic live", "thoat magic_live",
                "dung tro chuyen", "ket thuc tro chuyen", "nghi thoi", "tat di", "dong hop thoai"
            ) || norm.startsWith("tam biet magic live") || norm.startsWith("tam biet magic_live") || norm.startsWith("dong tro chuyen")
        ) {
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Tôi vẫn luôn ở đây sẵn sàng để giúp bạn bất kỳ lúc nào nhé!",
                shouldDismissOverlay = true
            )
        }

        // 1.1 Lệnh Hỏi Thông Tin Điện Thoại & Cấu Hình Máy (Device Info & Hardware Specs)
        if (norm in setOf("may toi la may gi", "dien thoai gi", "may nay la may gi", "may gi", "dien thoai cua toi", "ten dien thoai") ||
            norm.contains("may toi la may gi") || norm.contains("dien thoai cua toi la gi") ||
            norm.contains("thong tin may") || norm.contains("thong tin dien thoai") ||
            norm.contains("cau hinh may") || norm.contains("cau hinh dien thoai") ||
            norm.contains("chip gi") || norm.contains("vi xu ly gi") || norm.contains("chay chip gi") ||
            norm.contains("android may") || norm.contains("magicos may") || norm.contains("phien ban magicos")
        ) {
            val dev = getDeviceRealtimeInfo(appCtx)
            val reply = "Điện thoại của bạn là ${dev.commercialName}, chạy vi xử lý ${dev.soc}, giao diện ${dev.magicOsVersion} trên nền Android ${dev.androidVersion}, màn hình tần số quét ${dev.refreshRateHz}Hz."
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = reply
            )
        }

        // 1.2 Lệnh Hỏi Tình Trạng Pin, Công Suất Sạc & Nhiệt Độ (Battery & Charging & Temp)
        if (norm in setOf("pin con bao nhieu", "con bao nhieu pin", "pin the nao", "tinh trang pin") ||
            norm.contains("pin con bao nhieu") || norm.contains("may con may phan tram pin") ||
            norm.contains("con may phan tram pin") || norm.contains("con bao nhieu phan tram pin") ||
            norm.contains("tinh trang pin") || norm.contains("suc khoe pin") ||
            norm.contains("dang sac") || norm.contains("sac pin") || norm.contains("sac nhanh") ||
            norm.contains("sac bao nhieu oat") || norm.contains("sac bao nhieu watt") ||
            norm.contains("nhiet do pin") || norm.contains("pin co nong khong")
        ) {
            val dev = getDeviceRealtimeInfo(appCtx)
            val chargeDesc = if (dev.isCharging) {
                val wStr = if (dev.chargingWatt > 1.0) " với công suất khoảng ${dev.chargingWatt.roundToInt()}W" else ""
                ", máy đang cắm sạc (${dev.chargingTitle}$wStr)"
            } else {
                ", đang dùng pin"
            }
            val tempDesc = String.format(Locale.US, "%.1f", dev.batteryTempC)
            val reply = "Pin của bạn hiện còn ${dev.batteryPct}%$chargeDesc. Nhiệt độ pin mát mẻ ở mức $tempDesc độ C."
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = reply
            )
        }

        // 1.3 Lệnh Hỏi Bộ Nhớ RAM & Dung Lượng Lưu Trữ Máy (RAM & ROM Storage)
        if (norm.contains("ram con bao nhieu") || norm.contains("ram trong bao nhieu") ||
            norm.contains("ram dang dung bao nhieu") || norm.contains("dung luong ram") ||
            norm.contains("bo nho con trong bao nhieu") || norm.contains("bo nho con bao nhieu") ||
            norm.contains("dung luong con lai") || norm.contains("dung luong may") ||
            norm.contains("bo nho may") || norm.contains("bo nho trong")
        ) {
            val dev = getDeviceRealtimeInfo(appCtx)
            val ramFreeStr = String.format(Locale.US, "%.1f", dev.ramAvailGb)
            val ramTotalStr = String.format(Locale.US, "%.1f", dev.ramTotalGb)
            val romFreeStr = String.format(Locale.US, "%.1f", dev.romAvailGb)
            val romTotalStr = String.format(Locale.US, "%.0f", dev.romTotalGb)
            val reply = "Bộ nhớ RAM đang còn trống $ramFreeStr GB trên tổng $ramTotalStr GB. Dung lượng bộ nhớ trong máy còn trống $romFreeStr GB trên tổng $romTotalStr GB."
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = reply
            )
        }

        // 1.4 Lệnh Tối Ưu Tăng Tốc Máy & Dọn Dẹp RAM (RAM Boost & Cleanup)
        if (norm.contains("don dep ram") || norm.contains("giai phong ram") ||
            norm.contains("toi uu ram") || norm.contains("tang toc may") ||
            norm.contains("don rac") || norm.contains("giai phong bo nho") ||
            norm.contains("don bo nho") || norm.contains("tang toc dien thoai")
        ) {
            optimizeDeviceMemory(appCtx)
            val dev = getDeviceRealtimeInfo(appCtx)
            val ramFreeStr = String.format(Locale.US, "%.1f", dev.ramAvailGb)
            val reply = "Đã dọn dẹp RAM và giải phóng bộ nhớ ngầm cho bạn! Hiện máy còn trống $ramFreeStr GB RAM, hoạt động rất mượt mà."
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = reply
            )
        }

        // 1.5 Lệnh Làm Mát & Hạ Nhiệt Điện Thoại (Device Cool Down)
        if (norm.contains("ha nhiet may") || norm.contains("lam mat may") ||
            norm.contains("giam nhiet do") || norm.contains("ha nhiet dien thoai")
        ) {
            optimizeDeviceMemory(appCtx)
            val dev = getDeviceRealtimeInfo(appCtx)
            val tempDesc = String.format(Locale.US, "%.1f", dev.batteryTempC)
            val reply = "Nhiệt độ pin máy hiện tại là $tempDesc độ C. Tôi đã tắt các tiến trình ngầm tốn tài nguyên để giúp máy nhanh chóng hạ nhiệt mát mẻ hơn!"
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = reply
            )
        }

        // 1.6 Lệnh Bật / Tắt Tiết Kiệm Pin (Battery Saver Mode)
        if (norm.contains("bat tiet kiem pin") || norm.contains("mo tiet kiem pin") || norm.contains("bat che do tiet kiem pin")) {
            setBatterySaverMode(appCtx, true)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã bật chế độ tiết kiệm pin để tối ưu thời lượng sử dụng cho máy."
            )
        }
        if (norm.contains("tat tiet kiem pin") || norm.contains("tat che do tiet kiem pin")) {
            setBatterySaverMode(appCtx, false)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã tắt chế độ tiết kiệm pin, máy đã trở về hiệu năng đầy đủ."
            )
        }

        // 2. Lệnh Đọc / Tóm tắt nội dung đang hiển thị trên màn hình hiện tại
        if (norm.contains("doc man hinh") ||
            norm.contains("tom tat man hinh") ||
            norm.contains("tren man hinh co gi") ||
            norm.contains("man hinh dang hien gi") ||
            norm.contains("dich man hinh nay")
        ) {
            com.example.core.service.MagicTuneCtsAccessibilityService.beginTemporaryBurst(2500L)
            val nodes = try {
                NoAccessibilityScreenEngine.autoWakeAccessibilityIfNeeded(appCtx, 1300L)
                NoAccessibilityScreenEngine.extractVisibleScreenNodesNow(appCtx)
            } finally {
                com.example.core.service.MagicTuneCtsAccessibilityService.endTemporaryBurstAndIdle(appCtx, 150L)
            }
            if (nodes.isNotEmpty()) {
                val joined = nodes.take(35).joinToString(" | ") { it.text }
                return VoiceCommandResult(
                    handled = false,
                    spokenConfirmation = "",
                    screenContextForAi = joined
                )
            }
        }

        // 2.1. Lệnh Hỏi Thời Tiết Thông Minh (Mở Google tra cứu thời tiết chuẩn theo vị trí GPS/mạng của máy, rồi AI đọc ngay kết quả vị trí + độ C trên màn hình)
        if (norm.contains("thoi tiet") || norm.contains("du bao thoi tiet")) {
            val weatherQuery = if (cleanText.length >= 8) cleanText else "thời tiết hôm nay"
            launchGoogleWebSearch(appCtx, weatherQuery)
            // Nhường quyền cho Magic Live đọc trực tiếp thẻ kết quả vị trí & thời tiết thực tế đang hiện trên Google
            return VoiceCommandResult(
                handled = false,
                spokenConfirmation = "",
                screenContextForAi = null
            )
        }

        // 3. Lệnh Kích hoạt Khoanh tròn hỏi AI hoặc Dịch Cuộn Trực Tiếp của MagicTune
        if (norm.contains("khoanh tron tim kiem") || norm == "khoanh tron" || norm.contains("bat khoanh tron") ||
            norm.contains("google lens") || norm.contains("mo google lens") || norm.contains("mo lens") ||
            norm.contains("tim bang hinh anh") || norm.contains("tim kiem bang hinh anh") || norm.contains("tim hinh anh tren man hinh")
        ) {
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đang mở Google Khoanh tròn & Lens cho bạn.",
                shouldDismissOverlay = true
            ).also {
                CircleToSearchOverlayActivity.launch(appCtx)
            }
        }

        if (norm.contains("dich man hinh") || norm.contains("dich tin nhan") || norm.contains("dich doan chat") ||
            norm.contains("ho dang nhan gi") || norm.contains("ho vua nhan gi") ||
            norm.contains("ho nhan gi the") || norm.contains("dich tin moi nhat") ||
            norm.contains("dich chu tren man hinh") || norm.contains("doc tin nhan") ||
            norm.contains("doc doan chat") || norm.contains("doc man hinh") ||
            norm.contains("doc ho tin nhan") || norm.contains("doc giup tin nhan") || norm.contains("doc giup man hinh")
        ) {
            MagicLiveFloatingOverlay.translateCurrentScreenForeignText(appCtx)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "",
                shouldDismissOverlay = false
            )
        }

        if (norm.contains("hoi ve man hinh") || norm.contains("man hinh dang co gi") || norm.contains("tren man hinh co gi") ||
            norm.contains("xem man hinh nay") || norm.contains("xem man hinh hien gi") || norm.contains("man hinh hien gi") ||
            norm.contains("man hinh dang mo gi") || norm == "xem man hinh" || norm.contains("dang mo app gi") ||
            norm.contains("day la app gi") || norm.contains("co gi tren man hinh") ||
            norm.contains("xem giup man hinh") || norm.contains("xem ho man hinh") || norm.contains("man hinh co gi")
        ) {
            MagicLiveFloatingOverlay.askAboutCurrentScreen(appCtx)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "",
                shouldDismissOverlay = false
            )
        }

        if (norm.contains("bat dich cuon") || norm.contains("dich cuon truc tiep") || norm.contains("dich taobao")) {
            GoogleLiveTranslateOverlay.start(appCtx)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã bật chế độ dịch cuộn trực tiếp trên màn hình.",
                shouldDismissOverlay = true
            )
        }

        if (norm.contains("tat dich cuon") || norm.contains("dung dich cuon")) {
            GoogleLiveTranslateOverlay.stop(appCtx)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã tắt chế độ dịch cuộn trực tiếp."
            )
        }

        // 4. Lệnh Điều khiển Đèn Pin (Flashlight / Torch)
        if (norm.contains("bat den pin") || norm.contains("mo den pin") || norm.contains("bat den flash") || norm.contains("bat flash")) {
            val ok = setFlashlightState(appCtx, true)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = if (ok) "Đã bật đèn pin cho bạn." else "Không thể bật đèn pin trên thiết bị này."
            )
        }
        if (norm.contains("tat den pin") || norm.contains("tat den flash") || norm.contains("tat flash")) {
            val ok = setFlashlightState(appCtx, false)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = if (ok) "Đã tắt đèn pin." else "Không thể tắt đèn pin."
            )
        }

        // 5. Lệnh Điều khiển Âm lượng & Chế độ Chuông / Rung / Im lặng (Volume & Ringer Mode — Siri 2026)
        if (norm in setOf("bat che do rung", "che do rung", "chuyen sang rung", "bat rung", "de che do rung", "im lang rung")) {
            setRingerMode(appCtx, AudioManager.RINGER_MODE_VIBRATE)
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đã chuyển điện thoại sang chế độ rung.")
        }
        if (norm in setOf("bat chuong", "mo chuong", "bat am thanh", "che do chuong", "che do binh thuong", "mo tieng")) {
            setRingerMode(appCtx, AudioManager.RINGER_MODE_NORMAL)
            setMediaVolumePercent(appCtx, 70)
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đã bật lại chuông và âm thanh bình thường.")
        }
        val volumePercentMatch = Regex("""(?:am luong|muc am luong|dat am luong|chinh am luong|am thanh)\s*(?:muc\s*|len\s*|xuong\s*)?(\d{1,3})\s*(?:%|phan tram)?""").find(norm)
        if (volumePercentMatch != null) {
            val pct = volumePercentMatch.groupValues[1].toIntOrNull()?.coerceIn(0, 100) ?: 50
            setMediaVolumePercent(appCtx, pct)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã chỉnh âm lượng ở mức $pct phần trăm."
            )
        }
        if (norm.contains("tang am luong") || norm.contains("cho to tieng") || norm.contains("mo to len") || norm.contains("tang tieng") || norm.contains("to tieng len") || norm == "to len") {
            val newPct = adjustMediaVolumeByStep(appCtx, deltaPercent = +20)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã tăng âm lượng lên $newPct phần trăm."
            )
        }
        if (norm.contains("giam am luong") || norm.contains("cho nho tieng") || norm.contains("nho tieng xuong") || norm.contains("giam tieng") || norm.contains("van nho") || norm == "nho xuong") {
            val newPct = adjustMediaVolumeByStep(appCtx, deltaPercent = -20)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã giảm âm lượng xuống $newPct phần trăm."
            )
        }
        if (norm.contains("am luong toi da") || norm.contains("mo het co am luong") || norm.contains("max am luong") || norm.contains("am luong cao nhat")) {
            setMediaVolumePercent(appCtx, 100)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã bật âm lượng tối đa 100 phần trăm."
            )
        }
        if (norm == "tat tieng" || norm.contains("tat am thanh") || norm.contains("che do im lang") || norm.contains("tat chuong") || norm == "im lang") {
            setRingerMode(appCtx, AudioManager.RINGER_MODE_SILENT)
            setMediaVolumePercent(appCtx, 0)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã chuyển máy sang chế độ im lặng và tắt tiếng."
            )
        }

        // 6. Lệnh Điều khiển Độ sáng màn hình, Bảo vệ mắt & Màn hình 120Hz (Brightness & Display — Siri 2026)
        if (norm.contains("do sang toi da") || norm.contains("max do sang") || norm.contains("do sang cao nhat") || norm.contains("sang het co")) {
            setScreenBrightnessPercent(appCtx, 100)
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đã chỉnh độ sáng màn hình lên mức tối đa 100 phần trăm.")
        }
        if (norm.contains("do sang thap nhat") || norm.contains("do sang toi thieu") || norm.contains("toi nhat")) {
            setScreenBrightnessPercent(appCtx, 5)
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đã hạ độ sáng màn hình xuống mức thấp nhất.")
        }
        if (norm.contains("do sang tu dong") || norm.contains("bat do sang tu dong")) {
            try {
                if (Settings.System.canWrite(appCtx)) {
                    Settings.System.putInt(appCtx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC)
                } else {
                    val shell = ShellEngine.getInstance(appCtx)
                    if (shell.state.value.isAdbReady) shell.execute("settings put system screen_brightness_mode 1")
                }
            } catch (_: Throwable) {}
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đã bật chế độ độ sáng màn hình tự động.")
        }
        if (norm.contains("bao ve mat") || norm.contains("loc anh sang xanh") || norm.contains("che do doc sach") || norm.contains("diu mat")) {
            val enable = !norm.contains("tat ")
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) {
                val v = if (enable) "1" else "0"
                shell.execute("settings put secure night_display_activated $v; settings put system eyes_protection_mode $v")
            } else {
                launchIntentSafely(appCtx, Intent(Settings.ACTION_DISPLAY_SETTINGS))
            }
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = if (enable) "Đã bật chế độ Bảo vệ mắt giảm ánh sáng xanh." else "Đã tắt chế độ Bảo vệ mắt."
            )
        }
        if (norm.contains("120hz") || norm.contains("120 hz") || norm.contains("tan so quet cao") || norm.contains("man hinh muot")) {
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) {
                shell.execute("settings put system peak_refresh_rate 120.0; settings delete system min_refresh_rate; settings put system user_refresh_rate 0; cmd display set-match-content-frame-rate-pref 1 >/dev/null 2>&1 || true")
            } else {
                launchIntentSafely(appCtx, Intent(Settings.ACTION_DISPLAY_SETTINGS))
            }
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đã kích hoạt tần số quét 120Hz thích ứng LTPO mượt mà và tiết kiệm pin.")
        }
        val brightnessPercentMatch = Regex("""(?:do sang|muc do sang|chinh do sang)\s*(?:muc\s*|len\s*|xuong\s*)?(\d{1,3})\s*(?:%|phan tram)?""").find(norm)
        if (brightnessPercentMatch != null) {
            val pct = brightnessPercentMatch.groupValues[1].toIntOrNull()?.coerceIn(5, 100) ?: 70
            setScreenBrightnessPercent(appCtx, pct)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã chỉnh độ sáng màn hình ở mức $pct phần trăm."
            )
        }
        if (norm.contains("tang do sang") || norm.contains("man hinh sang len") || norm.contains("sang len")) {
            val pct = adjustScreenBrightnessByStep(appCtx, +25)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã tăng độ sáng màn hình lên $pct phần trăm."
            )
        }
        if (norm.contains("giam do sang") || norm.contains("ha do sang") || norm.contains("man hinh toi xuong") || norm.contains("toi xuong")) {
            val pct = adjustScreenBrightnessByStep(appCtx, -25)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã giảm độ sáng màn hình xuống $pct phần trăm."
            )
        }

        // 7. Lệnh Điều khiển Wi-Fi / Bluetooth / NFC / Cài đặt hệ thống
        if (norm.contains("bat nfc") || norm.contains("mo nfc") || norm.contains("tat nfc")) {
            val enable = !norm.contains("tat ")
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) {
                shell.execute(if (enable) "svc nfc enable" else "svc nfc disable")
            } else {
                launchIntentSafely(appCtx, Intent(Settings.ACTION_NFC_SETTINGS))
            }
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = if (enable) "Đang bật kết nối NFC cho bạn." else "Đang tắt kết nối NFC."
            )
        }
        if (norm.contains("cai dat sim") || norm.contains("quan ly sim") || norm.contains("mang di dong") || norm.contains("cai dat 4g") || norm.contains("cai dat 5g")) {
            if (!launchIntentSafely(appCtx, Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS))) {
                launchIntentSafely(appCtx, Intent(Settings.ACTION_WIRELESS_SETTINGS))
            }
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở cài đặt SIM và mạng di động cho bạn.")
        }
        if (norm.contains("cai dat dung luong") || norm.contains("cai dat bo nho") || norm.contains("kiem tra dung luong")) {
            launchIntentSafely(appCtx, Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở trang Quản lý dung lượng bộ nhớ.")
        }
        if (norm.contains("cai dat pin") || norm.contains("xem muc tieu thu pin")) {
            launchIntentSafely(appCtx, Intent(Intent.ACTION_POWER_USAGE_SUMMARY))
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở trang Cài đặt Pin.")
        }
        if (norm.contains("quan ly ung dung") || norm.contains("danh sach ung dung") || norm.contains("cai dat ung dung")) {
            launchIntentSafely(appCtx, Intent(Settings.ACTION_APPLICATION_SETTINGS))
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở trang Quản lý ứng dụng.")
        }
        if (norm.contains("cai dat van tay") || norm.contains("cai dat mat khau") || norm.contains("cai dat bao mat")) {
            launchIntentSafely(appCtx, Intent(Settings.ACTION_SECURITY_SETTINGS))
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở cài đặt Bảo mật và Sinh trắc học.")
        }

        if (norm.contains("bat wifi") || norm.contains("mo wifi") || norm.contains("bat mang wifi")) {
            toggleWifiOrOpenPanel(appCtx, enable = true)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đang bật kết nối Wi-Fi cho bạn."
            )
        }
        // Bảo vệ kết nối mạng & ứng dụng trợ lý: Không cho phép tắt Wi-Fi, Dữ liệu di động hay tắt MagicTune
        if (norm.contains("tat wifi") || norm.contains("ngat wifi") || norm.contains("tat mang") || norm.contains("tat du lieu di dong") || norm.contains("tat 4g") || norm.contains("tat 5g")) {
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Tôi không thể tắt mạng Wi-Fi hoặc dữ liệu di động vì cần kết nối mạng để trợ lý MAGIC LIVE hoạt động liên tục phục vụ bạn!"
            )
        }
        if (norm.contains("tat magictune") || norm.contains("tat ung dung nay") || norm.contains("xoa magictune") || norm.contains("go cai dat magictune")) {
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Tôi không thể tắt hoặc gỡ ứng dụng MagicTune vì đây là ứng dụng đang duy trì trợ lý cho bạn!"
            )
        }
        if (norm.contains("bat bluetooth") || norm.contains("mo bluetooth")) {
            toggleBluetoothDirectOrInSettings(appCtx, enable = true)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đang bật kết nối Bluetooth cho bạn."
            )
        }
        if (norm.contains("tat bluetooth") || norm.contains("ngat bluetooth") || norm.contains("dong bluetooth")) {
            toggleBluetoothDirectOrInSettings(appCtx, enable = false)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đang tắt kết nối Bluetooth."
            )
        }

        // 7.1. Lệnh Bật / Tắt Điểm phát sóng Wi-Fi (Hotspot)
        if (norm.contains("bat phat wifi") || norm.contains("mo phat wifi") || norm.contains("bat diem phat song") || norm.contains("chia se mang")) {
            val intent = Intent().apply {
                setClassName("com.android.settings", "com.android.settings.TetherSettings")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (!launchIntentSafely(appCtx, intent)) {
                launchIntentSafely(appCtx, Intent(Settings.ACTION_WIRELESS_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            }
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở cài đặt Điểm phát sóng Wi-Fi cho bạn.")
        }
        if (norm.contains("tat phat wifi") || norm.contains("tat diem phat song") || norm.contains("tat chia se mang")) {
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) {
                shell.execute("cmd connectivity tether stop")
            }
            launchIntentSafely(appCtx, Intent(Settings.ACTION_WIRELESS_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang tắt điểm phát sóng Wi-Fi.")
        }

        // 7.2. Lệnh Tự động xoay màn hình (Auto-rotate)
        if (norm.contains("bat tu dong xoay") || norm.contains("bat xoay man hinh") || norm.contains("mo tu xoay") || norm.contains("bat xoay")) {
            try {
                Settings.System.putInt(appCtx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1)
            } catch (_: Throwable) {
                val shell = ShellEngine.getInstance(appCtx)
                if (shell.state.value.isAdbReady) shell.execute("settings put system accelerometer_rotation 1")
            }
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đã bật tự động xoay màn hình.")
        }
        if (norm.contains("tat tu dong xoay") || norm.contains("tat xoay man hinh") || norm.contains("khoa xoay") || norm.contains("tat xoay")) {
            try {
                Settings.System.putInt(appCtx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
            } catch (_: Throwable) {
                val shell = ShellEngine.getInstance(appCtx)
                if (shell.state.value.isAdbReady) shell.execute("settings put system accelerometer_rotation 0")
            }
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đã khóa xoay màn hình.")
        }

        // 7.3. Lệnh Chế độ tối / Giao diện tối (Dark Mode)
        if (norm.contains("bat che do toi") || norm.contains("bat giao dien toi") || norm.contains("bat nen toi") || norm.contains("dark mode") || norm.contains("che do ban dem")) {
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) shell.execute("cmd uimode night yes")
            else launchIntentSafely(appCtx, Intent(Settings.ACTION_DISPLAY_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đã chuyển sang chế độ tối.")
        }
        if (norm.contains("tat che do toi") || norm.contains("bat che do sang") || norm.contains("giao dien sang") || norm.contains("che do sang") || norm.contains("light mode")) {
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) shell.execute("cmd uimode night no")
            else launchIntentSafely(appCtx, Intent(Settings.ACTION_DISPLAY_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đã chuyển sang chế độ sáng.")
        }

        // 7.4. Lệnh Chế độ máy bay (Airplane Mode)
        if (norm.contains("bat che do may bay") || norm.contains("mo che do may bay")) {
            launchIntentSafely(appCtx, Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở cài đặt Chế độ máy bay cho bạn.")
        }
        if (norm.contains("tat che do may bay") || norm.contains("dong che do may bay")) {
            launchIntentSafely(appCtx, Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở cài đặt để tắt Chế độ máy bay.")
        }

        // 7.5. Lệnh Không làm phiền (Do Not Disturb)
        if (norm.contains("bat khong lam phien") || norm.contains("che do khong lam phien") || norm.contains("bat dnd") || norm.contains("che do ngu")) {
            val nm = appCtx.getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager
            if (nm != null && nm.isNotificationPolicyAccessGranted) {
                nm.setInterruptionFilter(android.app.NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            } else {
                openDoNotDisturbSettings(appCtx)
            }
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đã bật chế độ Không làm phiền.")
        }
        if (norm.contains("tat khong lam phien") || norm.contains("tat dnd")) {
            val nm = appCtx.getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager
            if (nm != null && nm.isNotificationPolicyAccessGranted) {
                nm.setInterruptionFilter(android.app.NotificationManager.INTERRUPTION_FILTER_ALL)
            } else {
                openDoNotDisturbSettings(appCtx)
            }
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đã tắt chế độ Không làm phiền.")
        }

        // 7.6. Lệnh Vị trí / Định vị GPS
        if (norm.contains("bat vi tri") || norm.contains("bat dinh vi") || norm.contains("bat gps") || norm.contains("mo dinh vi")) {
            launchIntentSafely(appCtx, Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở cài đặt Định vị GPS cho bạn.")
        }
        if (norm.contains("tat vi tri") || norm.contains("tat dinh vi") || norm.contains("tat gps")) {
            launchIntentSafely(appCtx, Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở cài đặt để tắt Định vị GPS.")
        }

        // 7.65. Lệnh Chụp Ảnh Selfie / Camera Trước / Quay Video / Ghi Âm (Siri 2026 Camera & Recorder)
        if (norm in setOf("chup selfie", "chup anh selfie", "chup tu suong", "mo camera truoc", "bat camera truoc", "chup cam truoc")) {
            launchCameraMode(appCtx, selfie = true, video = false)
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở camera trước để bạn chụp selfie.", shouldDismissOverlay = true)
        }
        if (norm in setOf("quay video", "mo may quay", "bat quay phim", "quay phim", "quay clip")) {
            launchCameraMode(appCtx, selfie = false, video = true)
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở chế độ quay video cho bạn.", shouldDismissOverlay = true)
        }
        if (norm in setOf("chup anh", "chup hinh", "mo may anh", "bat may anh", "mo camera")) {
            launchCameraMode(appCtx, selfie = false, video = false)
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở máy ảnh cho bạn.", shouldDismissOverlay = true)
        }
        if (norm in setOf("ghi am", "bat ghi am", "mo may ghi am", "thu am")) {
            val launched = findAndLaunchAppByName(appCtx, "ghi am")
            if (launched == null) {
                launchIntentSafely(appCtx, Intent(android.provider.MediaStore.Audio.Media.RECORD_SOUND_ACTION))
            }
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở ứng dụng Ghi âm cho bạn.", shouldDismissOverlay = true)
        }

        // 7.7. Lệnh Gọi điện / Bấm số / Gọi khẩn cấp & Nhắn tin SMS (Siri 2026 Telephony & SMS)
        if (norm in setOf("goi cap cuu", "goi 115", "goi xe cap cuu")) {
            launchIntentSafely(appCtx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:115")))
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở bàn phím gọi cấp cứu y tế 115.", shouldDismissOverlay = true)
        }
        if (norm in setOf("goi cuu hoa", "goi 114", "bao chay")) {
            launchIntentSafely(appCtx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:114")))
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở bàn phím gọi cứu hỏa 114.", shouldDismissOverlay = true)
        }
        if (norm in setOf("goi cong an", "goi canh sat", "goi 113")) {
            launchIntentSafely(appCtx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:113")))
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở bàn phím gọi cảnh sát 113.", shouldDismissOverlay = true)
        }

        val smsMatch = Regex("""^(?:nhan tin sms|gui sms|soan tin nhan|nhan tin)\s+(?:cho\s+|den\s+|toi\s+)?([0-9+]{3,15})(?:\s+noi dung\s+|\s+la\s+|\s+)(.+)?$""").find(norm)
        if (smsMatch != null) {
            val phone = smsMatch.groupValues[1].trim()
            val body = smsMatch.groupValues.getOrNull(2)?.trim().orEmpty()
            launchSmsComposer(appCtx, phone, body)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = if (body.isNotEmpty()) "Đang mở trình nhắn tin gửi tới $phone với nội dung \"$body\"." else "Đang mở khung soạn tin nhắn tới số $phone.",
                shouldDismissOverlay = true
            )
        }

        val callMatch = Regex("""^(?:goi dien thoai cho|goi dien cho|goi cho|goi toi|goi den|goi so|quay so)\s+(.+)$""").find(norm)
        if (callMatch != null) {
            val target = callMatch.groupValues[1].trim()
            val phoneOnly = target.replace(Regex("[^0-9+*#]"), "")
            if (phoneOnly.length >= 3) {
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(phoneOnly)}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                launchIntentSafely(appCtx, intent)
                return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở bàn phím gọi số $phoneOnly cho bạn.", shouldDismissOverlay = true)
            } else {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("content://contacts/people")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                launchIntentSafely(appCtx, intent)
                return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở danh bạ để bạn gọi cho $target.", shouldDismissOverlay = true)
            }
        }

        // 7.8. Lệnh Đặt Báo Thức / Hẹn Giờ Đếm Ngược / Nhắc Nhở & Lịch Hẹn Tiếng Việt Tự Nhiên (Siri 2026)
        // Hỗ trợ cả "6 rưỡi sáng", "7 giờ kém 15", "8 giờ tối", "1 giờ chiều", "gọi tôi dậy lúc...", "đánh thức mình lúc...", "đếm ngược 30 giây / 10 phút / nửa tiếng / 1 tiếng rưỡi"
        val isTimerIntent = norm.startsWith("hen gio ") || norm.startsWith("dem nguoc ") || norm.startsWith("dat hen gio ") ||
            (norm.contains("sau ") && (norm.contains("phut") || norm.contains("giay") || norm.contains("tieng")) && (norm.contains("bao") || norm.contains("nhac") || norm.contains("hen")))
        val isAlarmIntent = norm.contains("bao thuc") || norm.startsWith("goi toi day") || norm.startsWith("goi minh day") ||
            norm.startsWith("danh thuc toi") || norm.startsWith("danh thuc minh") || norm.startsWith("hen bao thuc")

        if (isTimerIntent && !norm.contains("luc ")) {
            val parsedSec = parseVietnameseDurationSeconds(norm)
            if (parsedSec != null && parsedSec > 0) {
                val intent = Intent(android.provider.AlarmClock.ACTION_SET_TIMER).apply {
                    putExtra(android.provider.AlarmClock.EXTRA_LENGTH, parsedSec)
                    putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "Hẹn giờ bởi MAGIC LIVE")
                    putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, false)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                launchIntentSafely(appCtx, intent)
                val humanDur = if (parsedSec >= 60 && parsedSec % 60 == 0) "${parsedSec / 60} phút" else if (parsedSec > 60) "${parsedSec / 60} phút ${parsedSec % 60} giây" else "$parsedSec giây"
                return VoiceCommandResult(handled = true, spokenConfirmation = "Đã đặt bộ hẹn giờ đếm ngược $humanDur cho bạn.", shouldDismissOverlay = true)
            }
        }

        if (isAlarmIntent || (norm.startsWith("hen gio luc ") || norm.startsWith("dat gio luc "))) {
            val parsedTime = parseVietnameseTimeOfDay(norm)
            if (parsedTime != null) {
                val (h, m) = parsedTime
                val intent = Intent(android.provider.AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(android.provider.AlarmClock.EXTRA_HOUR, h)
                    putExtra(android.provider.AlarmClock.EXTRA_MINUTES, m)
                    putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "Báo thức bởi MAGIC LIVE")
                    putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, false)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                launchIntentSafely(appCtx, intent)
                val minText = if (m > 0) " $m phút" else " đúng"
                return VoiceCommandResult(handled = true, spokenConfirmation = "Đã đặt báo thức lúc $h giờ$minText cho bạn.", shouldDismissOverlay = true)
            } else {
                launchIntentSafely(appCtx, Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
                return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở đồng hồ báo thức cho bạn.", shouldDismissOverlay = true)
            }
        }

        // 7.8a. Lệnh Tạo Lời Nhắc / Sự Kiện Lịch / Ghi Chú Nhanh (Siri 2026 Reminders & Notes)
        val reminderMatch = Regex("""^(?:nhac toi|nhac minh|tao loi nhac|them lich hen|tao lich hen|dat lich)\s+(.+)$""").find(norm)
        if (reminderMatch != null) {
            val rawTask = cleanText.replace(Regex("""^(?:.*?(?:nhắc tôi|nhắc mình|tạo lời nhắc|thêm lịch hẹn|tạo lịch hẹn|đặt lịch))\s+""", RegexOption.IGNORE_CASE), "").trim()
            val parsedTime = parseVietnameseTimeOfDay(norm)
            if (parsedTime != null) {
                val (h, m) = parsedTime
                val intent = Intent(android.provider.AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(android.provider.AlarmClock.EXTRA_HOUR, h)
                    putExtra(android.provider.AlarmClock.EXTRA_MINUTES, m)
                    putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, rawTask.ifEmpty { "Lời nhắc MAGIC LIVE" })
                    putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, false)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                launchIntentSafely(appCtx, intent)
                return VoiceCommandResult(
                    handled = true,
                    spokenConfirmation = "Đã đặt lời nhắc \"$rawTask\" vào lúc $h giờ ${String.format(Locale.US, "%02d", m)} phút cho bạn.",
                    shouldDismissOverlay = true
                )
            } else {
                val calIntent = Intent(Intent.ACTION_INSERT).apply {
                    data = android.provider.CalendarContract.Events.CONTENT_URI
                    putExtra(android.provider.CalendarContract.Events.TITLE, rawTask.ifEmpty { "Sự kiện mới" })
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (!launchIntentSafely(appCtx, calIntent)) {
                    findAndLaunchAppByName(appCtx, "lich")
                }
                return VoiceCommandResult(
                    handled = true,
                    spokenConfirmation = "Đang mở Lịch để lưu lời nhắc \"$rawTask\" cho bạn.",
                    shouldDismissOverlay = true
                )
            }
        }

        // 7.8b. Lệnh Siri-style: Nhập chữ / Gõ văn bản / Trả lời tin nhắn trực tiếp vào ô nhập trên màn hình
        val typeAndSendMatch = Regex("""^(?:gui tin nhan|nhan tin la|tra loi la|nhan la|gui chu)\s+(.+)$""", RegexOption.IGNORE_CASE).find(cleanText.trim())
        val typeOnlyMatch = Regex("""^(?:nhap chu|go chu|dien chu|viet chu)\s+(.+)$""", RegexOption.IGNORE_CASE).find(cleanText.trim())
        if (typeAndSendMatch != null || typeOnlyMatch != null) {
            val contentToType = (typeAndSendMatch?.groupValues?.get(1) ?: typeOnlyMatch?.groupValues?.get(1)).orEmpty().trim()
            val shouldSend = typeAndSendMatch != null
            if (contentToType.isNotEmpty()) {
                val ok = NoAccessibilityScreenEngine.inputVoiceTextIntoScreenField(appCtx, contentToType, autoClickSend = shouldSend)
                val reply = if (ok) {
                    if (shouldSend) "Đã nhập và gửi tin nhắn: $contentToType." else "Đã nhập nội dung: $contentToType."
                } else {
                    "Không tìm thấy ô nhập văn bản nào trên màn hình hiện tại."
                }
                return VoiceCommandResult(handled = true, spokenConfirmation = reply)
            }
        }

        // 7.8c. Lệnh Siri-style: Điều khiển phát nhạc / Media (Tạm dừng, Phát tiếp, Qua bài)
        if (norm in setOf("tam dung nhac", "dung nhac", "tam dung video", "tam dung phat", "pause nhac", "tam dung", "dung phat")) {
            dispatchMediaKey(appCtx, android.view.KeyEvent.KEYCODE_MEDIA_PAUSE)
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đã tạm dừng phát.")
        }
        if (norm in setOf("phat tiep", "tiep tuc phat", "mo tiep nhac", "phat nhac tiep", "play nhac", "tiep tuc video")) {
            dispatchMediaKey(appCtx, android.view.KeyEvent.KEYCODE_MEDIA_PLAY)
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đã tiếp tục phát.")
        }
        if (norm in setOf("qua bai", "bai ke tiep", "chuyen bai tiep", "bai tiep", "next nhac")) {
            dispatchMediaKey(appCtx, android.view.KeyEvent.KEYCODE_MEDIA_NEXT)
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đã chuyển sang bài tiếp theo.")
        }
        if (norm in setOf("bai truoc", "quay lai bai truoc", "lui bai", "bai cu")) {
            dispatchMediaKey(appCtx, android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            return VoiceCommandResult(handled = true, spokenConfirmation = "Đã quay lại bài trước đó.")
        }

        // 7.9. Lệnh Bấm Chạm Trên Màn Hình Theo Chữ (Click node by text)
        val clickMatch = Regex("""(?:bam vao|cham vao|nhan vao|an vao|click vao|bam nut|nhan nut)\s*(.+)""").find(norm)
        if (clickMatch != null) {
            val targetText = clickMatch.groupValues[1].trim()
            if (targetText.isNotEmpty() && !targetText.startsWith("ung dung ") && !targetText.startsWith("app ")) {
                val clicked = NoAccessibilityScreenEngine.clickScreenElementByVoiceText(appCtx, targetText)
                val reply = if (clicked) "Đã bấm vào $targetText trên màn hình." else "Đang cố gắng tìm và bấm vào $targetText."
                return VoiceCommandResult(handled = true, spokenConfirmation = reply)
            }
        }

        // 8. Lệnh Điều hướng & Cử chỉ Màn hình (Back, Home, Recents, Notifications, Screenshot, Lock, Scroll/Swipe)
        if (norm in setOf("quay lai", "tro lai", "tro ve", "bam nut quay lai", "nhan quay lai", "lui lai")) {
            NoAccessibilityScreenEngine.performVoiceGlobalAction(appCtx, NoAccessibilityScreenEngine.GLOBAL_ACTION_BACK)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã quay lại trang trước."
            )
        }
        if (norm in setOf("ve man hinh chinh", "man hinh chinh", "ve trang chu", "trang chu", "ve home", "thoat ra man hinh chinh", "ra man hinh chinh")) {
            NoAccessibilityScreenEngine.performVoiceGlobalAction(appCtx, NoAccessibilityScreenEngine.GLOBAL_ACTION_HOME)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã về màn hình chính."
            )
        }
        if (norm.contains("mo da nhiem") || norm.contains("ung dung gan day") || norm.contains("xem da nhiem") || norm.contains("cua so da nhiem")) {
            NoAccessibilityScreenEngine.performVoiceGlobalAction(appCtx, NoAccessibilityScreenEngine.GLOBAL_ACTION_RECENTS)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã mở màn hình đa nhiệm."
            )
        }
        if (norm.contains("mo thanh thong bao") || norm.contains("keo thanh thong bao") || norm.contains("xem thong bao")) {
            NoAccessibilityScreenEngine.performVoiceGlobalAction(appCtx, NoAccessibilityScreenEngine.GLOBAL_ACTION_NOTIFICATIONS)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã mở thanh thông báo."
            )
        }
        if (norm.contains("mo cai dat nhanh") || norm.contains("keo cai dat nhanh") || norm.contains("trung tam dieu khien")) {
            NoAccessibilityScreenEngine.performVoiceGlobalAction(appCtx, NoAccessibilityScreenEngine.GLOBAL_ACTION_QUICK_SETTINGS)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã mở bảng cài đặt nhanh."
            )
        }
        if (norm.contains("chup man hinh") || norm.contains("chup anh man hinh") || norm == "screenshot") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                NoAccessibilityScreenEngine.performVoiceGlobalAction(appCtx, NoAccessibilityScreenEngine.GLOBAL_ACTION_TAKE_SCREENSHOT)
                return VoiceCommandResult(
                    handled = true,
                    spokenConfirmation = "Đã chụp ảnh màn hình."
                )
            }
        }
        if (norm.contains("khoa man hinh") || norm.contains("tat man hinh") || norm == "khoa may") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                NoAccessibilityScreenEngine.performVoiceGlobalAction(appCtx, NoAccessibilityScreenEngine.GLOBAL_ACTION_LOCK_SCREEN)
                return VoiceCommandResult(
                    handled = true,
                    spokenConfirmation = "Đang khóa màn hình.",
                    shouldDismissOverlay = true
                )
            }
        }

        // Cuộn lên / Cuộn xuống / Vuốt trái / Vuốt phải
        if (norm in setOf("cuon xuong", "luot xuong", "keo xuong", "vuot len", "xem tiep", "cuon tiep", "luot tiep", "keo tiep")) {
            NoAccessibilityScreenEngine.performVoiceScrollOrSwipe(appCtx, "DOWN")
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã cuộn xuống."
            )
        }
        if (norm in setOf("cuon len", "luot len", "keo len", "vuot xuong", "quay len dau", "len dau trang")) {
            NoAccessibilityScreenEngine.performVoiceScrollOrSwipe(appCtx, "UP")
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã cuộn lên."
            )
        }
        if (norm in setOf("vuot sang trai", "luot sang trai", "vuot trai", "trang tiep theo")) {
            NoAccessibilityScreenEngine.performVoiceScrollOrSwipe(appCtx, "LEFT")
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã vuốt sang trái."
            )
        }
        if (norm in setOf("vuot sang phai", "luot sang phai", "vuot phai")) {
            NoAccessibilityScreenEngine.performVoiceScrollOrSwipe(appCtx, "RIGHT")
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã vuốt sang phải."
            )
        }

        // 9. Lệnh Bấm / Nhấn / Chạm vào một nút hoặc dòng chữ trên màn hình hiện tại
        val clickTarget = extractClickTargetFromVoice(cleanText, norm)
        if (clickTarget != null && clickTarget.length >= 2) {
            val clicked = NoAccessibilityScreenEngine.clickScreenElementByVoiceText(appCtx, clickTarget)
            if (clicked) {
                return VoiceCommandResult(
                    handled = true,
                    spokenConfirmation = "Đã nhấn vào \"$clickTarget\" trên màn hình."
                )
            }
        }

        // 9.5. Tìm kiếm trực tiếp trên TikTok / Shopee / Lazada (Siri 2026 In-App Deep Search)
        val tiktokSearchMatch = Regex("""^(?:tim tren tiktok|tim tiktok|mo tiktok tim|vao tiktok tim|xem tiktok|luot tiktok xem)\s+(.+)$""").find(norm) ?:
            Regex("""^(?:tim|xem)\s+(.+?)\s+tren\s+(?:tiktok|tik tok|top top)$""").find(norm)
        if (tiktokSearchMatch != null) {
            val q = tiktokSearchMatch.groupValues[1].trim()
            if (q.isNotEmpty()) {
                launchTikTokSearch(appCtx, q)
                return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở TikTok và tìm kiếm \"$q\" cho bạn.", shouldDismissOverlay = true)
            }
        }

        val shopeeSearchMatch = Regex("""^(?:tim tren shopee|mua tren shopee|mo shopee tim|vao shopee tim|tim mua)\s+(.+)$""").find(norm) ?:
            Regex("""^(?:tim|mua|xem gia)\s+(.+?)\s+tren\s+shopee$""").find(norm)
        if (shopeeSearchMatch != null) {
            val q = shopeeSearchMatch.groupValues[1].trim()
            if (q.isNotEmpty()) {
                launchShopeeSearch(appCtx, q)
                return VoiceCommandResult(handled = true, spokenConfirmation = "Đang mở Shopee và tìm sản phẩm \"$q\" cho bạn.", shouldDismissOverlay = true)
            }
        }

        // 10. Lệnh YouTube Thông Minh (Quay về trang chủ, tự động phát video ngay, chuyển bài / đổi video khác siêu tốc)
        val fgPkg = NoAccessibilityScreenEngine.getActiveForegroundPackage().orEmpty()
        val isYoutubeForeground = fgPkg.contains("youtube")

        if (norm in setOf("ve trang chu youtube", "quay ve trang chu youtube", "trang chu youtube", "ve youtube", "quay ve youtube", "tro ve trang chu youtube") ||
            (isYoutubeForeground && norm in setOf("ve trang chu", "quay ve trang chu", "quay lai trang chu", "trang chu"))) {
            launchYoutubeHome(appCtx)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đang đưa bạn quay về trang chủ YouTube."
            )
        }

        // Đổi video khác / bài khác / video tiếp theo khi đang xem YouTube
        if (norm in setOf("video khac", "bai khac", "bai hat khac", "doi video", "doi bai", "bai tiep theo", "video tiep theo", "chuyen bai", "chuyen video", "next bai", "next video") ||
            (isYoutubeForeground && norm in setOf("khac", "doi bai khac", "video khac di", "bai khac di", "tiep theo"))) {
            executorScope.launch {
                NoAccessibilityScreenEngine.performVoiceGlobalAction(appCtx, NoAccessibilityScreenEngine.GLOBAL_ACTION_BACK)
                delay(400L)
                NoAccessibilityScreenEngine.clickFirstVideoOrContentCard(appCtx)
            }
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đang đổi sang video khác cho bạn."
            )
        }

        val mediaIntent = extractMediaSearchIntent(cleanText, norm)
        if (mediaIntent != null) {
            launchYoutubeSearch(appCtx, mediaIntent.searchQuery, autoPlay = mediaIntent.autoPlay)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = mediaIntent.spokenConfirmation
            )
        }

        val mapsQuery = extractMapsSearchQuery(cleanText, norm)
        if (mapsQuery != null) {
            launchGoogleMapsSearch(appCtx, mapsQuery)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đang mở Bản đồ tìm kiếm và chỉ đường tới \"$mapsQuery\"."
            )
        }

        val googleWebQuery = extractGoogleSearchQuery(cleanText, norm)
        if (googleWebQuery != null) {
            launchGoogleWebSearch(appCtx, googleWebQuery)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đang tìm kiếm \"$googleWebQuery\" trên Google cho bạn."
            )
        }

        // 10.5. Lệnh Sáng Tạo Hình Ảnh & Video với App Magic Live (Magic Live Creative Hand-off)
        val creativeIntent = extractMagicLiveCreativeIntent(cleanText, norm)
        if (creativeIntent != null) {
            launchMagicLiveCreativeHandOff(appCtx, creativeIntent.prompt, creativeIntent.isVideo)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = creativeIntent.spokenConfirmation,
                shouldDismissOverlay = true
            )
        }

        // 11. Lệnh Mở bất kỳ ứng dụng nào trên điện thoại (Open App by Voice)
        val requestedAppName = extractAppNameToOpen(cleanText, norm)
        if (requestedAppName != null) {
            val normApp = normalizeVi(requestedAppName)
            val explicitAppWord = norm.contains("ung dung ") || norm.contains("app ") || norm.contains("phan mem ")
            val sensitiveList = listOf(
                "vneid", "vssid", "dich vu cong", "cong dich vu cong", "etax", "thue dien tu",
                "ngan hang", "vietcombank", "techcombank", "mb bank", "mbbank", "bidv", "vietinbank",
                "agribank", "acb", "vpbank", "tpbank", "hdbank", "shb", "msb", "ocb", "sacombank",
                "viettel money", "momo", "zalopay", "vnpt pay", "vnpay", "shopeepay"
            )
            if (sensitiveList.any { normApp == it || normApp.contains(it) }) {
                val politeDecline = "Mình được thiết kế để bảo vệ an toàn cho bạn và không can thiệp vào các ứng dụng quan trọng của Chính phủ, Nhà Nước hay Ngân hàng. Bạn vui lòng mở trực tiếp ứng dụng này nhé!"
                return VoiceCommandResult(
                    handled = true,
                    spokenConfirmation = politeDecline
                )
            }

            val launchedLabel = findAndLaunchAppByName(appCtx, requestedAppName)
            if (launchedLabel != null) {
                return VoiceCommandResult(
                    handled = true,
                    spokenConfirmation = "Đang mở ứng dụng $launchedLabel cho bạn."
                )
            } else if (explicitAppWord) {
                return VoiceCommandResult(
                    handled = true,
                    spokenConfirmation = "Mình không tìm thấy ứng dụng \"$requestedAppName\" được cài trên máy của bạn."
                )
            }
        }

        return VoiceCommandResult(handled = false, spokenConfirmation = "")
    }

    /**
     * Thực thi thẻ lệnh `[ACTION:...]` do mô hình AI đính kèm trong phản hồi (khi người dùng nói câu tự nhiên phức tạp).
     * Trả về văn bản sạch (đã gỡ bỏ thẻ `[ACTION:...]`) để đọc thành tiếng.
     */
    suspend fun processAiActionTagsIfPresent(context: Context, aiRawReply: String): String {
        val appCtx = context.applicationContext
        val tagRegex = Regex("""\[([A-Z_]+):([^\]]*)\]""")
        val matches = tagRegex.findAll(aiRawReply).toList()
        if (matches.isEmpty()) return aiRawReply.trim()

        for (match in matches) {
            val actionType = match.groupValues[1].uppercase(Locale.ROOT).trim()
            val param = match.groupValues[2].trim()
            when (actionType) {
                "OPEN_APP" -> {
                    if (param.isNotEmpty()) {
                        findAndLaunchAppByName(appCtx, param)
                    }
                }
                "YOUTUBE_HOME" -> {
                    launchYoutubeHome(appCtx)
                }
                "YOUTUBE_SEARCH" -> {
                    if (param.isNotEmpty()) {
                        launchYoutubeSearch(appCtx, param)
                    }
                }
                "GOOGLE_SEARCH" -> {
                    if (param.isNotEmpty()) {
                        launchGoogleWebSearch(appCtx, param)
                    }
                }
                "MAPS_SEARCH" -> {
                    if (param.isNotEmpty()) {
                        launchGoogleMapsSearch(appCtx, param)
                    }
                }
                "TIKTOK_SEARCH" -> {
                    if (param.isNotEmpty()) {
                        launchTikTokSearch(appCtx, param)
                    }
                }
                "SHOPEE_SEARCH" -> {
                    if (param.isNotEmpty()) {
                        launchShopeeSearch(appCtx, param)
                    }
                }
                "SET_ALARM" -> {
                    val parts = param.split(":")
                    val h = parts.getOrNull(0)?.trim()?.toIntOrNull() ?: 7
                    val m = parts.getOrNull(1)?.trim()?.toIntOrNull() ?: 0
                    val intent = Intent(android.provider.AlarmClock.ACTION_SET_ALARM).apply {
                        putExtra(android.provider.AlarmClock.EXTRA_HOUR, h.coerceIn(0, 23))
                        putExtra(android.provider.AlarmClock.EXTRA_MINUTES, m.coerceIn(0, 59))
                        putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "Báo thức MAGIC LIVE")
                        putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, false)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    launchIntentSafely(appCtx, intent)
                }
                "SET_TIMER" -> {
                    val mins = param.toIntOrNull() ?: 5
                    val intent = Intent(android.provider.AlarmClock.ACTION_SET_TIMER).apply {
                        putExtra(android.provider.AlarmClock.EXTRA_LENGTH, (mins.coerceAtLeast(1)) * 60)
                        putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "Hẹn giờ MAGIC LIVE")
                        putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, false)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    launchIntentSafely(appCtx, intent)
                }
                "CALL_NUMBER" -> {
                    val phone = param.replace(Regex("[^0-9+*#]"), "")
                    if (phone.isNotEmpty()) {
                        launchIntentSafely(appCtx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
                    }
                }
                "SEND_SMS" -> {
                    val parts = param.split("|", limit = 2)
                    val phone = parts.getOrNull(0)?.trim().orEmpty()
                    val body = parts.getOrNull(1)?.trim().orEmpty()
                    if (phone.isNotEmpty()) {
                        launchSmsComposer(appCtx, phone, body)
                    }
                }
                "SELFIE_CAMERA" -> {
                    launchCameraMode(appCtx, selfie = true, video = false)
                }
                "VIDEO_CAMERA" -> {
                    launchCameraMode(appCtx, selfie = false, video = true)
                }
                "RINGER_MODE" -> {
                    when (param.uppercase(Locale.ROOT)) {
                        "VIBRATE" -> setRingerMode(appCtx, AudioManager.RINGER_MODE_VIBRATE)
                        "SILENT" -> setRingerMode(appCtx, AudioManager.RINGER_MODE_SILENT)
                        else -> setRingerMode(appCtx, AudioManager.RINGER_MODE_NORMAL)
                    }
                }
                "BRIGHTNESS" -> {
                    when (param.uppercase(Locale.ROOT)) {
                        "UP" -> adjustScreenBrightnessByStep(appCtx, +25)
                        "DOWN" -> adjustScreenBrightnessByStep(appCtx, -25)
                        "MAX" -> setScreenBrightnessPercent(appCtx, 100)
                        "MIN" -> setScreenBrightnessPercent(appCtx, 5)
                        else -> param.toIntOrNull()?.let { setScreenBrightnessPercent(appCtx, it) }
                    }
                }
                "DARK_MODE" -> {
                    val enable = param.equals("ON", ignoreCase = true)
                    val shell = ShellEngine.getInstance(appCtx)
                    if (shell.state.value.isAdbReady) shell.execute(if (enable) "cmd uimode night yes" else "cmd uimode night no")
                }
                "AUTO_ROTATE" -> {
                    val enable = param.equals("ON", ignoreCase = true)
                    try {
                        Settings.System.putInt(appCtx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (enable) 1 else 0)
                    } catch (_: Throwable) {}
                }
                "DND" -> {
                    val enable = param.equals("ON", ignoreCase = true)
                    val nm = appCtx.getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager
                    if (nm != null && nm.isNotificationPolicyAccessGranted) {
                        nm.setInterruptionFilter(if (enable) android.app.NotificationManager.INTERRUPTION_FILTER_PRIORITY else android.app.NotificationManager.INTERRUPTION_FILTER_ALL)
                    }
                }
                "TYPE_TEXT" -> {
                    if (param.isNotEmpty()) {
                        NoAccessibilityScreenEngine.inputVoiceTextIntoScreenField(appCtx, param, autoClickSend = false)
                    }
                }
                "SEND_TEXT" -> {
                    if (param.isNotEmpty()) {
                        NoAccessibilityScreenEngine.inputVoiceTextIntoScreenField(appCtx, param, autoClickSend = true)
                    }
                }
                "MEDIA" -> {
                    when (param.uppercase(Locale.ROOT)) {
                        "PAUSE", "STOP" -> dispatchMediaKey(appCtx, android.view.KeyEvent.KEYCODE_MEDIA_PAUSE)
                        "PLAY", "RESUME" -> dispatchMediaKey(appCtx, android.view.KeyEvent.KEYCODE_MEDIA_PLAY)
                        "NEXT" -> dispatchMediaKey(appCtx, android.view.KeyEvent.KEYCODE_MEDIA_NEXT)
                        "PREVIOUS", "PREV" -> dispatchMediaKey(appCtx, android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS)
                    }
                }
                "CLICK_TEXT" -> {
                    if (param.isNotEmpty()) {
                        NoAccessibilityScreenEngine.clickScreenElementByVoiceText(appCtx, param)
                    }
                }
                "SCROLL" -> {
                    NoAccessibilityScreenEngine.performVoiceScrollOrSwipe(appCtx, param.ifEmpty { "DOWN" })
                }
                "GLOBAL" -> {
                    when (param.uppercase(Locale.ROOT)) {
                        "BACK" -> NoAccessibilityScreenEngine.performVoiceGlobalAction(appCtx, NoAccessibilityScreenEngine.GLOBAL_ACTION_BACK)
                        "HOME" -> NoAccessibilityScreenEngine.performVoiceGlobalAction(appCtx, NoAccessibilityScreenEngine.GLOBAL_ACTION_HOME)
                        "RECENTS" -> NoAccessibilityScreenEngine.performVoiceGlobalAction(appCtx, NoAccessibilityScreenEngine.GLOBAL_ACTION_RECENTS)
                        "NOTIFICATIONS" -> NoAccessibilityScreenEngine.performVoiceGlobalAction(appCtx, NoAccessibilityScreenEngine.GLOBAL_ACTION_NOTIFICATIONS)
                        "QUICK_SETTINGS" -> NoAccessibilityScreenEngine.performVoiceGlobalAction(appCtx, NoAccessibilityScreenEngine.GLOBAL_ACTION_QUICK_SETTINGS)
                        "LOCK" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                            NoAccessibilityScreenEngine.performVoiceGlobalAction(appCtx, NoAccessibilityScreenEngine.GLOBAL_ACTION_LOCK_SCREEN)
                        }
                        "SCREENSHOT" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                            NoAccessibilityScreenEngine.performVoiceGlobalAction(appCtx, NoAccessibilityScreenEngine.GLOBAL_ACTION_TAKE_SCREENSHOT)
                        }
                    }
                }
                "TORCH" -> {
                    setFlashlightState(appCtx, param.equals("ON", ignoreCase = true))
                }
                "VOLUME" -> {
                    when (param.uppercase(Locale.ROOT)) {
                        "UP" -> adjustMediaVolumeByStep(appCtx, +20)
                        "DOWN" -> adjustMediaVolumeByStep(appCtx, -20)
                        "MUTE" -> setMediaVolumePercent(appCtx, 0)
                        "MAX" -> setMediaVolumePercent(appCtx, 100)
                        else -> param.toIntOrNull()?.let { setMediaVolumePercent(appCtx, it) }
                    }
                }
                "BLUETOOTH" -> {
                    toggleBluetoothDirectOrInSettings(appCtx, param.equals("ON", ignoreCase = true))
                }
                "WIFI" -> {
                    toggleWifiOrOpenPanel(appCtx, param.equals("ON", ignoreCase = true))
                }
                "OPTIMIZE_RAM" -> {
                    optimizeDeviceMemory(appCtx)
                }
                "POWER_SAVER" -> {
                    setBatterySaverMode(appCtx, param.equals("ON", ignoreCase = true))
                }
            }
        }

        return aiRawReply.replace(tagRegex, "").replace(Regex("\\s+"), " ").trim()
    }

    private fun extractClickTargetFromVoice(raw: String, norm: String): String? {
        val prefixes = listOf(
            "bam vao nut ", "nhan vao nut ", "cham vao nut ", "an vao nut ", "kich vao nut ",
            "bam vao muc ", "nhan vao muc ", "chon muc ", "an vao muc ",
            "bam vao chữ ", "nhan vao chu ", "bam vao ", "nhan vao ", "cham vao ", "an vao ",
            "bam ho toi ", "bam ho ", "nhan ho toi ", "nhan ho ", "cham ho ",
            "bam nut ", "nhan nut ", "cham nut ", "an nut ", "chon nut ",
            "bam cho nao ", "bam vao cho ", "nhan vao cho ", "cham vao cho ",
            "bam vao ", "nhan vao ", "chon "
        )
        for (prefix in prefixes) {
            if (norm.startsWith(prefix)) {
                val remainder = norm.removePrefix(prefix)
                    .removeSuffix(" tren man hinh")
                    .removeSuffix(" giup toi")
                    .removeSuffix(" đi")
                    .removeSuffix(" di")
                    .trim()
                if (remainder.isNotEmpty() && !remainder.startsWith("ung dung ") && !remainder.startsWith("app ")) {
                    return remainder
                }
            }
        }
        return null
    }

    fun extractMediaSearchIntent(raw: String, norm: String): MediaSearchIntent? {
        // 1. YouTube trực tiếp có từ khóa youtube
        val ytExplicit = Regex("""^(?:mo|vao|bat)\s+youtube\s+(?:tim kiem|tim|phat|nghe|xem|mo)\s+(.+)$""").find(norm)
        if (ytExplicit != null) {
            val q = ytExplicit.groupValues[1].removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            if (q.isNotEmpty()) return MediaSearchIntent(q, "Đang mở và phát \"$q\" trên YouTube cho bạn.", autoPlay = true)
        }

        val ytSuffix = Regex("""^(?:tim|tim kiem|phat|mo|nghe|xem)\s+(.+?)\s+tren\s+youtube$""").find(norm)
        if (ytSuffix != null) {
            val q = ytSuffix.groupValues[1].removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            if (q.isNotEmpty()) return MediaSearchIntent(q, "Đang mở và phát \"$q\" trên YouTube cho bạn.", autoPlay = true)
        }

        val ytPrefix = Regex("""^(?:xem tren youtube|tim tren youtube|nghe tren youtube|mo tren youtube)\s+(.+)$""").find(norm)
        if (ytPrefix != null) {
            val q = ytPrefix.groupValues[1].removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            if (q.isNotEmpty()) return MediaSearchIntent(q, "Đang mở và phát \"$q\" trên YouTube cho bạn.", autoPlay = true)
        }

        // 2. Phim / Phim bộ / Phim hoạt hình / Anime / Chiếu phim
        val movieMatch = Regex("""^(?:mo|xem|chieu|bat|tim|tim kiem)\s+(?:phim|bo phim|tap phim|hoat hinh|anime)\s+(.+)$""").find(norm)
        if (movieMatch != null) {
            val t = movieMatch.groupValues[1].removeSuffix(" tren youtube").removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            if (t.isNotEmpty()) {
                val searchQuery = if (t.startsWith("phim") || t.startsWith("hoat hinh")) t else "phim $t"
                return MediaSearchIntent(searchQuery, "Đang mở phim \"$t\" trên YouTube cho bạn.")
            }
        }
        if (norm.startsWith("phim ") || norm.startsWith("hoat hinh ")) {
            val t = norm.removeSuffix(" tren youtube").removeSuffix(" giup toi").trim()
            if (t.length > 5) return MediaSearchIntent(t, "Đang tìm phim \"$t\" trên YouTube cho bạn.")
        }

        // 3. Bài hát / Ca khúc / Album / Podcast
        val songMatch = Regex("""^(?:mo|nghe|phat|bat|tim|tim kiem)\s+(?:bai hat|ca khuc|bai ca|album|podcast)\s+(.+)$""").find(norm)
        if (songMatch != null) {
            val t = songMatch.groupValues[1].removeSuffix(" tren youtube").removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            if (t.isNotEmpty()) {
                val searchQuery = if (t.startsWith("bai hat") || t.startsWith("ca khuc")) t else "bài hát $t"
                return MediaSearchIntent(searchQuery, "Đang phát bài hát \"$t\" trên YouTube cho bạn.")
            }
        }
        val songShortMatch = Regex("""^(?:mo|nghe|phat|bat)\s+bai\s+(.+)$""").find(norm)
        if (songShortMatch != null) {
            val t = songShortMatch.groupValues[1].removeSuffix(" tren youtube").removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            if (t.isNotEmpty()) {
                return MediaSearchIntent("bài hát $t", "Đang phát bài \"$t\" trên YouTube cho bạn.")
            }
        }

        // 4. Nhạc (nhạc trẻ, remix, không lời, ballad...)
        val musicMatch = Regex("""^(?:bat nhac|mo nhac|nghe nhac|phat nhac|tim nhac)\s*(.*)$""").find(norm)
        if (musicMatch != null) {
            val t = musicMatch.groupValues[1].removeSuffix(" tren youtube").removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            val searchQuery = if (t.isNotEmpty()) (if (t.startsWith("nhac")) t else "nhạc $t") else "nhạc trẻ remix hot trend"
            val spoken = if (t.isNotEmpty()) "Đang phát nhạc \"$t\" trên YouTube cho bạn." else "Đang mở nhạc hay trên YouTube cho bạn."
            return MediaSearchIntent(searchQuery, spoken)
        }

        // 5. Video / Clip
        val videoMatch = Regex("""^(?:mo|xem|phat|bat|tim|tim kiem)\s+(?:video|clip|video clip)\s+(.+)$""").find(norm)
        if (videoMatch != null) {
            val t = videoMatch.groupValues[1].removeSuffix(" tren youtube").removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            if (t.isNotEmpty()) {
                val searchQuery = if (t.startsWith("video") || t.startsWith("clip")) t else "video $t"
                return MediaSearchIntent(searchQuery, "Đang mở video \"$t\" trên YouTube cho bạn.")
            }
        }

        // 6. Hài kịch / Tiểu phẩm
        val comedyMatch = Regex("""^(?:mo|xem|phat)\s+(?:hai|hai huoc|hai kich|kich)\s+(.+)$""").find(norm)
        if (comedyMatch != null) {
            val t = comedyMatch.groupValues[1].removeSuffix(" tren youtube").removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            if (t.isNotEmpty()) {
                return MediaSearchIntent("hài $t", "Đang mở hài \"$t\" trên YouTube cho bạn.")
            }
        }

        return null
    }

    private fun extractYoutubeSearchQuery(raw: String, norm: String): String? {
        return extractMediaSearchIntent(raw, norm)?.searchQuery
    }

    private fun extractMapsSearchQuery(raw: String, norm: String): String? {
        val patterns = listOf(
            Regex("""^(?:chi duong|dan duong|tim duong)\s+(?:den|toi|di|ra|ve)\s+(.+)$"""),
            Regex("""^(?:mo ban do|mo google maps|vao ban do)\s+(?:tim|den|toi|chi duong)\s+(.+)$"""),
            Regex("""^(?:tim)\s+(cay xang|tram xang|atm|ngan hang|benh vien|nha thuoc|hieu thuoc|quan an|nha hang|quan ca phe|cafe|sieu thi|cho|khach san|nha nghi|tram xe buyt|bai do xe)\s*(?:gan day|gan nhat|quanh day)?$"""),
            Regex("""^(.+?)\s+(?:gan day|gan nhat|o dau tren ban do)$""")
        )
        for (p in patterns) {
            val m = p.find(norm)
            if (m != null) {
                val q = m.groupValues[1].removeSuffix(" giup toi").removeSuffix(" cho minh").trim()
                if (q.isNotEmpty() && !q.startsWith("mo ") && !q.startsWith("bat ")) {
                    return if (norm.contains("gan day") || norm.contains("gan nhat")) "$q gần đây" else q
                }
            }
        }
        return null
    }

    private fun extractGoogleSearchQuery(raw: String, norm: String): String? {
        val patterns = listOf(
            Regex("""^(?:tim tren google|tra google|tim google|google tim|hoi google|search google)\s+(.+)$"""),
            Regex("""^(?:tim kiem tren google|tra cuu tren google|tra tren google|len google tim)\s+(.+)$""")
        )
        for (p in patterns) {
            val m = p.find(norm)
            if (m != null) {
                val q = if (m.groupValues.size > 1 && m.groupValues[1].isNotBlank()) {
                    m.groupValues[1].trim()
                } else {
                    norm
                }
                if (q.isNotEmpty()) return q
            }
        }
        return null
    }

    /**
     * Phân tích thời lượng đếm ngược Tiếng Việt tự nhiên (chuẩn Siri 2026):
     * Hỗ trợ "nửa tiếng" (1800s), "1 tiếng rưỡi" (5400s), "2 phút 30 giây", "45 giây", "15 phút"...
     */
    private fun parseVietnameseDurationSeconds(norm: String): Int? {
        if (norm.contains("nua tieng") || norm.contains("nua gio")) return 30 * 60
        val hourHalfMatch = Regex("""(\d+)\s*(?:tieng|gio)\s*ruoi""").find(norm)
        if (hourHalfMatch != null) {
            val h = hourHalfMatch.groupValues[1].toIntOrNull() ?: 1
            return h * 3600 + 1800
        }
        val minHalfMatch = Regex("""(\d+)\s*phut\s*ruoi""").find(norm)
        if (minHalfMatch != null) {
            val m = minHalfMatch.groupValues[1].toIntOrNull() ?: 1
            return m * 60 + 30
        }
        var totalSec = 0
        val hMatch = Regex("""(\d+)\s*(?:tieng|gio)""").find(norm)
        val mMatch = Regex("""(\d+)\s*(?:phut|p\b)""").find(norm)
        val sMatch = Regex("""(\d+)\s*(?:giay|s\b)""").find(norm)
        if (hMatch != null) totalSec += (hMatch.groupValues[1].toIntOrNull() ?: 0) * 3600
        if (mMatch != null) totalSec += (mMatch.groupValues[1].toIntOrNull() ?: 0) * 60
        if (sMatch != null) totalSec += (sMatch.groupValues[1].toIntOrNull() ?: 0)
        return if (totalSec > 0) totalSec else null
    }

    /**
     * Phân tích giờ giấc Tiếng Việt tự nhiên (chuẩn Siri 2026):
     * Hỗ trợ "6 rưỡi sáng" (06:30), "7 giờ kém 15" (06:45), "8 giờ tối" (20:00), "1 giờ chiều" (13:00), "12 giờ trưa" (12:00).
     */
    private fun parseVietnameseTimeOfDay(norm: String): Pair<Int, Int>? {
        val isPm = norm.contains("chieu") || norm.contains("toi") || norm.contains("dem")
        val isAm = norm.contains("sang") || norm.contains("khuya")

        // Trường hợp "X giờ kém Y": ví dụ "7 giờ kém 15" -> 6:45
        val kemMatch = Regex("""(\d{1,2})\s*(?:gio|h)\s*kem\s*(\d{1,2})""").find(norm)
        if (kemMatch != null) {
            var h = kemMatch.groupValues[1].toIntOrNull() ?: return null
            val minusMin = kemMatch.groupValues[2].toIntOrNull()?.coerceIn(1, 59) ?: 15
            if (isPm && h in 1..11) h += 12
            if (isAm && h == 12) h = 0
            h = (h - 1 + 24) % 24
            val m = (60 - minusMin).coerceIn(0, 59)
            return h to m
        }

        // Trường hợp "X rưỡi" hoặc "X giờ rưỡi": ví dụ "6 rưỡi sáng" -> 6:30
        val ruoiMatch = Regex("""(\d{1,2})\s*(?:gio\s*|h\s*)?ruoi""").find(norm)
        if (ruoiMatch != null) {
            var h = ruoiMatch.groupValues[1].toIntOrNull() ?: return null
            if (isPm && h in 1..11) h += 12
            if (isAm && h == 12) h = 0
            return h.coerceIn(0, 23) to 30
        }

        // Trường hợp chuẩn "X giờ Y phút" hoặc "X giờ"
        val stdMatch = Regex("""(\d{1,2})\s*(?:gio|h|:)\s*(\d{1,2})?""").find(norm)
        if (stdMatch != null) {
            var h = stdMatch.groupValues[1].toIntOrNull() ?: return null
            val m = stdMatch.groupValues.getOrNull(2)?.takeIf { it.isNotBlank() }?.toIntOrNull() ?: 0
            if (isPm && h in 1..11) h += 12
            if (isAm && h == 12) h = 0
            return h.coerceIn(0, 23) to m.coerceIn(0, 59)
        }

        return null
    }

    private fun launchCameraMode(context: Context, selfie: Boolean, video: Boolean) {
        val action = if (video) android.provider.MediaStore.INTENT_ACTION_VIDEO_CAMERA else android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA
        val intent = Intent(action).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (selfie) {
                putExtra("android.intent.extras.CAMERA_FACING", 1)
                putExtra("android.intent.extras.LENS_FACING_FRONT", 1)
                putExtra("android.intent.extra.USE_FRONT_CAMERA", true)
            }
        }
        if (!launchIntentSafely(context, intent)) {
            val fallback = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            launchIntentSafely(context, fallback)
        }
    }

    private fun launchSmsComposer(context: Context, phone: String, body: String) {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(phone)}")).apply {
            if (body.isNotEmpty()) {
                putExtra("sms_body", body)
            }
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        launchIntentSafely(context, intent)
    }

    private fun setRingerMode(context: Context, mode: Int) {
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            am.ringerMode = mode
        } catch (_: Throwable) {}
    }

    private fun launchTikTokSearch(context: Context, query: String) {
        val encoded = Uri.encode(query)
        val deepLinkIntent = Intent(Intent.ACTION_VIEW, Uri.parse("snssdk1180://search?keyword=$encoded")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (!launchIntentSafely(context, deepLinkIntent)) {
            val altIntent = Intent(Intent.ACTION_VIEW, Uri.parse("snssdk1233://search?keyword=$encoded")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (!launchIntentSafely(context, altIntent)) {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/search?q=$encoded")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                launchIntentSafely(context, webIntent)
            }
        }
    }

    private fun launchShopeeSearch(context: Context, query: String) {
        val encoded = Uri.encode(query)
        val deepLinkIntent = Intent(Intent.ACTION_VIEW, Uri.parse("shopeevn://reactPath?path=search&keyword=$encoded")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (!launchIntentSafely(context, deepLinkIntent)) {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://shopee.vn/search?keyword=$encoded")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            launchIntentSafely(context, webIntent)
        }
    }

    data class MagicLiveCreativeIntent(
        val prompt: String,
        val isVideo: Boolean,
        val spokenConfirmation: String
    )

    fun extractMagicLiveCreativeIntent(raw: String, norm: String): MagicLiveCreativeIntent? {
        val clean = raw.trim()
        val n = norm.trim()

        // 1. Nhận diện các mẫu lệnh Tạo Video
        val videoRegexes = listOf(
            Regex("""^(?:nho magic live|bao magic live|mo magic live|dung magic live|magic live|nho magic_live|bao magic_live|mo magic_live|dung magic_live|magic_live)\s+(?:tao|lam|quay|render)\s+(?:video|clip|phim)\s+(.+)$"""),
            Regex("""^(?:tao|lam|quay|render)\s+(?:giup toi|ho toi|cho toi)?\s*(?:video|clip|doan phim|phim ngan)\s+(.+)$"""),
            Regex("""^(?:tao video|lam video|quay video ai|tao clip ai|render video)\s+(.+)$"""),
            Regex("""^(?:tao video|lam video|quay video ai|tao clip ai)$""")
        )
        for (r in videoRegexes) {
            val m = r.find(n)
            if (m != null) {
                val groupVal = if (m.groupValues.size > 1) m.groupValues[1].trim() else ""
                val promptText = if (groupVal.isNotEmpty()) {
                    clean.removePrefix("Magic Live").removePrefix("magic live").removePrefix("magic_live").trim()
                } else "Tạo một đoạn video AI sáng tạo và ấn tượng"
                val spoken = "Đang mở ứng dụng Magic Live cho bạn. Tôi đã sao chép sẵn yêu cầu: \"$promptText\" vào bộ nhớ tạm. Bạn chỉ cần nhấn Dán và gửi nhé!"
                return MagicLiveCreativeIntent(promptText, isVideo = true, spokenConfirmation = spoken)
            }
        }

        // 2. Nhận diện các mẫu lệnh Tạo Ảnh / Vẽ Tranh
        val imageRegexes = listOf(
            Regex("""^(?:nho magic live|bao magic live|mo magic live|dung magic live|magic live|nho magic_live|bao magic_live|mo magic_live|dung magic_live|magic_live)\s+(?:tao|ve|lam)\s+(?:anh|hinh anh|buc anh|tranh|buc tranh|hinh)\s+(.+)$"""),
            Regex("""^(?:tao|ve|lam)\s+(?:giup toi|ho toi|cho toi)?\s*(?:buc anh|tam anh|hinh anh|anh|tranh|buc tranh)\s+(.+)$"""),
            Regex("""^(?:ve|draw)\s+(?:cho toi|giup toi)?\s*(?:hinh|anh|buc tranh)?\s*(.+)$"""),
            Regex("""^(?:tao anh|tao hinh anh|tao buc anh|ve anh|ve tranh|ve hinh|tao image)\s*(.*)$""")
        )
        for (r in imageRegexes) {
            val m = r.find(n)
            if (m != null) {
                val groupVal = if (m.groupValues.size > 1) m.groupValues[1].trim() else ""
                val promptText = if (groupVal.isNotEmpty()) {
                    clean.removePrefix("Magic Live").removePrefix("magic live").removePrefix("magic_live").trim()
                } else "Tạo một bức ảnh nghệ thuật tuyệt đẹp"
                val spoken = "Đang mở ứng dụng Magic Live cho bạn. Tôi đã sao chép sẵn yêu cầu tạo ảnh: \"$promptText\" vào bộ nhớ tạm. Bạn chỉ cần nhấn Dán và gửi nhé!"
                return MagicLiveCreativeIntent(promptText, isVideo = false, spokenConfirmation = spoken)
            }
        }

        return null
    }

    fun launchMagicLiveCreativeHandOff(context: Context, prompt: String, isVideo: Boolean) {
        val appCtx = context.applicationContext
        try {
            // 1. Lưu vào khay nhớ tạm (Clipboard)
            val clipboard = appCtx.getSystemService(Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
            if (clipboard != null) {
                val clip = android.content.ClipData.newPlainText("Magic Live Creative Prompt", prompt)
                clipboard.setPrimaryClip(clip)
            }

            // 2. Hiển thị Toast thông báo hướng dẫn
            val typeStr = if (isVideo) "video" else "ảnh"
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                Toast.makeText(
                    appCtx,
                    "🎨 Đã copy prompt tạo $typeStr!\nNhấn 'Dán' vào Magic Live và bấm Gửi để tạo ngay.",
                    Toast.LENGTH_LONG
                ).show()
            }

            // 3. Khởi chạy Google Magic Live App hoặc Fallback sang Trình duyệt Web
            val magic_livePackages = listOf(
                "com.google.android.apps.bard",
                "com.google.android.googlequicksearchbox"
            )
            var launched = false
            for (pkg in magic_livePackages) {
                val launchIntent = appCtx.packageManager.getLaunchIntentForPackage(pkg)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    appCtx.startActivity(launchIntent)
                    launched = true
                    break
                }
            }

            if (!launched) {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://gemini.google.com/app")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appCtx.startActivity(webIntent)
            }
        } catch (e: Throwable) {
            Log.e("Magic LiveAction", "Lỗi mở Magic Live Creative: ${e.message}", e)
        }
    }

    private fun extractAppNameToOpen(raw: String, norm: String): String? {
        val rawLower = raw.lowercase(Locale.ROOT).trim()
            .removePrefix("magic live ơi ")
            .removePrefix("magic live ")
            .removePrefix("magic_live ơi ")
            .removePrefix("magic_live ")
            .removePrefix("hãy ")
            .removePrefix("làm ơn ")
            .removePrefix("giúp tôi ")
            .removePrefix("giúp mình ")
            .trim()

        // Tránh nhận nhầm các từ có dấu khác hoàn toàn với "mở" / "bật" trong hội thoại tự nhiên (vd: "mơ thấy", "mờ mắt", "bắt đầu", "bất ngờ", "vào mùa", "chạy bộ")
        val nonCommandRawPrefixes = listOf(
            "mơ ", "mờ ", "mỡ ", "mợ ",
            "bắt ", "bất ", "bạt ", "bát ", "bận ", "bạn ",
            "vào mùa", "vào lúc", "vào năm", "vào ngày", "vào buổi", "vào việc", "vào đời",
            "chạy bộ", "chạy xe", "chạy đi", "chạy deadline", "chạy thử"
        )
        if (nonCommandRawPrefixes.any { rawLower.startsWith(it) }) {
            return null
        }

        val cleanNorm = norm
            .removePrefix("magic live oi ")
            .removePrefix("magic live ")
            .removePrefix("magic_live oi ")
            .removePrefix("magic_live ")
            .removePrefix("hay ")
            .removePrefix("lam on ")
            .removePrefix("giup toi ")
            .removePrefix("giup minh ")
            .trim()

        val openRegex = Regex("""^(?:mo|bat|vao|khoi dong|chay)\s+(?:ung dung\s+|app\s+|phan mem\s+)?(.+)$""")
        val m = openRegex.find(cleanNorm) ?: return null
        val target = m.groupValues[1]
            .removeSuffix(" len giup toi")
            .removeSuffix(" giup toi")
            .removeSuffix(" cho toi")
            .removeSuffix(" giup minh")
            .removeSuffix(" cho minh")
            .removeSuffix(" len nhe")
            .removeSuffix(" len di")
            .removeSuffix(" len")
            .removeSuffix(" nhe")
            .removeSuffix(" di")
            .trim()

        // 1. Tránh nhận nhầm các lệnh phần cứng / hệ thống đã xử lý ở trên hoặc câu hội thoại dài
        val ignoredTargets = setOf(
            "den pin", "den flash", "flash", "wifi", "bluetooth", "da nhiem",
            "thanh thong bao", "cai dat nhanh", "to len", "nho xuong",
            "dau", "chuyen", "long", "mat", "mi", "loi", "man"
        )
        if (target.isEmpty() || target in ignoredTargets || target.split(" ").size > 4) {
            return null
        }

        // 2. BỘ LỌC THÔNG MINH: Tuyệt đối không nhận nhầm phim, nhạc, bài hát, video, hoặc câu hỏi tìm kiếm thành mở ứng dụng!
        val nonAppIndicators = listOf(
            "phim", "bo phim", "tap phim", "hoat hinh", "anime", "cinema",
            "nhac", "bai hat", "ca khuc", "bai ca", "album", "podcast",
            "video", "clip", "mv",
            "cach ", "huong dan ", "lam the nao", "tai sao", "cong thuc",
            "gia vang", "gia xang", "thoi tiet", "tin tuc", "dia chi",
            "thong tin", "cau hinh", "pin con", "ram con", "bo nho", "tiet kiem pin"
        )
        for (indicator in nonAppIndicators) {
            if (target == indicator || target.startsWith("$indicator ") || target.contains(" $indicator ")) {
                return null
            }
        }

        return target
    }

    /**
     * Tìm và khởi chạy bất kỳ ứng dụng nào đã cài đặt trên máy theo tên Tiếng Việt / Tiếng Anh.
     */
    suspend fun findAndLaunchAppByName(context: Context, requestedName: String): String? {
        val appCtx = context.applicationContext
        val pm = appCtx.packageManager
        val normReq = normalizeVi(requestedName)
        if (normReq.isEmpty()) return null

        // AN TOÀN TUYỆT ĐỐI CHO NGƯỜI DÙNG:
        // Chặn thao tác tự động can thiệp vào các ứng dụng Ngân hàng, Ví điện tử hoặc Cổng Dịch vụ công/VNeID của Nhà Nước
        val sensitiveNames = listOf(
            "vneid", "vssid", "dich vu cong", "cong dich vu cong", "etax", "thue dien tu",
            "ngan hang", "vietcombank", "techcombank", "mb bank", "mbbank", "bidv", "vietinbank",
            "agribank", "acb", "vpbank", "tpbank", "hdbank", "shb", "msb", "ocb", "sacombank",
            "viettel money", "momo", "zalopay", "vnpt pay", "vnpay", "shopeepay"
        )
        if (sensitiveNames.any { normReq == it || normReq.contains(it) }) {
            val warnMsg = "Vì lý do bảo mật, AI không tự động thao tác trên ứng dụng Ngân hàng và Cổng dịch vụ công Nhà Nước."
            if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
                try { Toast.makeText(appCtx, warnMsg, Toast.LENGTH_LONG).show() } catch (_: Throwable) {}
            } else {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    try { Toast.makeText(appCtx, warnMsg, Toast.LENGTH_LONG).show() } catch (_: Throwable) {}
                }
            }
            // Vẫn cho phép mở app lên nếu người dùng yêu cầu mở, nhưng chỉ mở app thuần túy không tự thao tác
        }

        // 0. Nếu là cài đặt con đặc biệt (Cài đặt Wi-Fi, Cài đặt Bluetooth, Cài đặt Âm thanh, Cài đặt Hiển thị, Chế độ nhà phát triển)
        if (normReq.contains("nha phat trien") || normReq.contains("developer option")) {
            return if (launchIntentSafely(appCtx, Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))) "Chế độ nhà phát triển" else null
        }
        if (normReq.contains("cai dat wifi") || normReq == "wifi") {
            return if (launchIntentSafely(appCtx, Intent(Settings.ACTION_WIFI_SETTINGS))) "Cài đặt Wi-Fi" else null
        }
        if (normReq.contains("cai dat bluetooth")) {
            return if (launchIntentSafely(appCtx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))) "Cài đặt Bluetooth" else null
        }
        if (normReq.contains("cai dat am thanh")) {
            return if (launchIntentSafely(appCtx, Intent(Settings.ACTION_SOUND_SETTINGS))) "Cài đặt Âm thanh" else null
        }
        if (normReq.contains("cai dat hien thi") || normReq.contains("cai dat man hinh")) {
            return if (launchIntentSafely(appCtx, Intent(Settings.ACTION_DISPLAY_SETTINGS))) "Cài đặt Hiển thị" else null
        }

        // 0.5. Mở trực tiếp Facebook Reels nếu người dùng yêu cầu
        if (normReq in setOf("fb reels", "reels", "facebook reels", "mo fb reels", "mo reels", "mo facebook reels")) {
            try {
                val reelsIntent = Intent(Intent.ACTION_VIEW, Uri.parse("fb://reels")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (launchIntentSafely(appCtx, reelsIntent)) return "Facebook Reels"
            } catch (_: Throwable) {}
        }
        if (normReq.contains("pinedrama") || normReq.contains("pine drama")) {
            for (p in listOf("com.pinedrama.app", "com.pine.drama", "com.pinedrama")) {
                val lInt = pm.getLaunchIntentForPackage(p)
                if (lInt != null && launchIntentSafely(appCtx, lInt)) return "PineDrama"
            }
            try {
                val stInt = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=PineDrama")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (launchIntentSafely(appCtx, stInt)) return "PineDrama (Play Store)"
            } catch (_: Throwable) {}
        }

        // 1. Kiểm tra danh sách Alias phổ biến trước
        val aliasPackages = knownAppAliases[normReq] ?: knownAppAliases.entries.firstOrNull { (k, _) ->
            normReq == k || normReq.replace(" ", "") == k.replace(" ", "")
        }?.value

        if (!aliasPackages.isNullOrEmpty()) {
            for (pkg in aliasPackages) {
                if (pkg == appCtx.packageName || pkg == "com.magictune.tool" || pkg == "com.example") {
                    val selfIntent = Intent(appCtx, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
                    if (launchIntentSafely(appCtx, selfIntent)) return "MagicTune"
                }
                val launchIntent = pm.getLaunchIntentForPackage(pkg)
                if (launchIntent != null && launchIntentSafely(appCtx, launchIntent)) {
                    val label = try {
                        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                    } catch (_: Throwable) {
                        requestedName.replaceFirstChar { it.uppercase() }
                    }
                    return label
                }
            }
        }

        // 2. Quét toàn bộ danh sách ứng dụng có Launcher Icon trên thiết bị
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.queryIntentActivities(mainIntent, PackageManager.ResolveInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(mainIntent, 0)
            }
        } catch (_: Throwable) {
            emptyList()
        }

        var bestPkg: String? = null
        var bestLabel: String? = null
        var bestScore = 0
        val compactReq = normReq.replace(" ", "")

        for (ri in resolveInfos) {
            val pkg = ri.activityInfo?.packageName ?: continue
            val rawLabel = try {
                ri.loadLabel(pm).toString().trim()
            } catch (_: Throwable) {
                ""
            }
            if (rawLabel.isEmpty()) continue
            val normLabel = normalizeVi(rawLabel)
            val compactLabel = normLabel.replace(" ", "")
            val normPkg = pkg.lowercase(Locale.ROOT)

            // Tạo từ viết tắt của tên app (ví dụ: Liên Quân Mobile -> lqm, Bản Đồ -> bd)
            val acronym = normLabel.split(" ").filter { it.isNotEmpty() }.map { it.first() }.joinToString("")

            val score = when {
                normLabel == normReq || compactLabel == compactReq -> 100
                acronym.isNotEmpty() && (acronym == normReq || acronym == compactReq) -> 95
                normLabel.startsWith(normReq) || compactLabel.startsWith(compactReq) -> 88
                normReq.startsWith(normLabel) && normLabel.length >= 3 -> 85
                normLabel.contains(normReq) || compactLabel.contains(compactReq) -> 76
                normReq.contains(normLabel) && normLabel.length >= 3 -> 68
                normPkg.contains(compactReq) && compactReq.length >= 3 -> 60
                normReq.split(" ").any { part -> part.length >= 3 && normLabel.contains(part) } -> 55
                else -> 0
            }

            if (score > bestScore) {
                bestScore = score
                bestPkg = pkg
                bestLabel = rawLabel
            }
        }

        if (bestPkg != null && bestScore >= 50) {
            val launchIntent = pm.getLaunchIntentForPackage(bestPkg)
            if (launchIntent != null && launchIntentSafely(appCtx, launchIntent)) {
                return bestLabel ?: requestedName
            }
            // Dự phòng qua ShellEngine nếu bật ADB / Shizuku
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) {
                try {
                    shell.execute("monkey -p $bestPkg -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1")
                    return bestLabel ?: requestedName
                } catch (_: Throwable) {}
            }
        }

        return null
    }

    private fun launchYoutubeHome(context: Context) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            setPackage("com.google.android.youtube")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        if (!launchIntentSafely(context, intent)) {
            val webUri = Uri.parse("https://www.youtube.com")
            launchIntentSafely(context, Intent(Intent.ACTION_VIEW, webUri))
        }
    }

    fun launchYoutubeSearch(context: Context, query: String, autoPlay: Boolean = true) {
        val appCtx = context.applicationContext
        val intent = Intent(Intent.ACTION_SEARCH).apply {
            setPackage("com.google.android.youtube")
            putExtra("query", query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val launched = launchIntentSafely(appCtx, intent)
        if (!launched) {
            val webUri = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
            launchIntentSafely(appCtx, Intent(Intent.ACTION_VIEW, webUri))
        }

        // TỰ ĐỘNG PHÁT VIDEO NGAY LẬP TỨC:
        // Sau khi ứng dụng YouTube mở trang kết quả, tự động nhấp vào video đầu tiên phù hợp để phát ngay,
        // người dùng không cần chạm tay vào màn hình!
        if (autoPlay) {
            executorScope.launch {
                for (retry in 0..5) {
                    delay(650L)
                    val clicked = NoAccessibilityScreenEngine.clickFirstVideoOrContentCard(appCtx)
                    if (clicked) break
                }
            }
        }
    }

    private fun launchGoogleMapsSearch(context: Context, query: String) {
        val gmmIntentUri = Uri.parse("geo:0,0?q=${Uri.encode(query)}")
        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
            setPackage("com.google.android.apps.maps")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (!launchIntentSafely(context, mapIntent)) {
            val webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(query)}")
            launchIntentSafely(context, Intent(Intent.ACTION_VIEW, webUri))
        }
    }

    private fun launchGoogleWebSearch(context: Context, query: String) {
        val webUri = Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}&hl=vi")
        launchIntentSafely(context, Intent(Intent.ACTION_VIEW, webUri))
    }

    private fun openDoNotDisturbSettings(context: Context) {
        val action = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS
        } else {
            Settings.ACTION_SOUND_SETTINGS
        }
        launchIntentSafely(
            context,
            Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun launchIntentSafely(context: Context, intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val options = android.app.ActivityOptions.makeBasic().apply {
                    setPendingIntentBackgroundActivityStartMode(
                        @Suppress("DEPRECATION") android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                    )
                }
                context.startActivity(intent, options.toBundle())
            } else {
                context.startActivity(intent)
            }
            true
        } catch (_: Throwable) {
            try {
                context.startActivity(intent)
                true
            } catch (_: Throwable) {
                false
            }
        }
    }

    private fun setFlashlightState(context: Context, enabled: Boolean): Boolean {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager ?: return false
            for (id in cm.cameraIdList) {
                try {
                    cm.setTorchMode(id, enabled)
                    return true
                } catch (_: Throwable) {}
            }
            false
        } catch (_: Throwable) {
            false
        }
    }

    private fun setMediaVolumePercent(context: Context, percent: Int): Int {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return percent
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val targetVol = ((percent.coerceIn(0, 100) / 100f) * maxVol).roundToInt().coerceIn(0, maxVol)
        try {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, AudioManager.FLAG_SHOW_UI)
        } catch (_: Throwable) {}
        return ((targetVol.toFloat() / maxVol) * 100f).roundToInt()
    }

    private fun adjustMediaVolumeByStep(context: Context, deltaPercent: Int): Int {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return 50
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val curPct = ((curVol.toFloat() / maxVol) * 100f).roundToInt()
        val nextPct = (curPct + deltaPercent).coerceIn(0, 100)
        return setMediaVolumePercent(context, nextPct)
    }

    private suspend fun setScreenBrightnessPercent(context: Context, percent: Int): Int {
        val clamped = percent.coerceIn(5, 100)
        val brightnessVal = ((clamped / 100f) * 255f).roundToInt().coerceIn(10, 255)
        var success = false
        try {
            if (Settings.System.canWrite(context)) {
                Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, brightnessVal)
                success = true
            }
        } catch (_: Throwable) {}

        if (!success) {
            val shell = ShellEngine.getInstance(context.applicationContext)
            if (shell.state.value.isAdbReady) {
                try {
                    shell.execute("settings put system screen_brightness_mode 0; settings put system screen_brightness $brightnessVal")
                } catch (_: Throwable) {}
            }
        }
        return clamped
    }

    private suspend fun adjustScreenBrightnessByStep(context: Context, deltaPercent: Int): Int {
        val curVal = try {
            Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 140)
        } catch (_: Throwable) {
            140
        }
        val curPct = ((curVal / 255f) * 100f).roundToInt().coerceIn(5, 100)
        return setScreenBrightnessPercent(context, (curPct + deltaPercent).coerceIn(5, 100))
    }

    private suspend fun toggleWifiOrOpenPanel(context: Context, enable: Boolean) {
        val shell = ShellEngine.getInstance(context.applicationContext)
        if (shell.state.value.isAdbReady) {
            try {
                shell.execute(if (enable) "svc wifi enable" else "svc wifi disable")
                return
            } catch (_: Throwable) {}
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (!launchIntentSafely(context, Intent(Settings.Panel.ACTION_WIFI))) {
                launchIntentSafely(context, Intent(Settings.ACTION_WIFI_SETTINGS))
            }
        } else {
            launchIntentSafely(context, Intent(Settings.ACTION_WIFI_SETTINGS))
        }
    }

    private suspend fun toggleBluetoothDirectOrInSettings(context: Context, enable: Boolean) {
        val appCtx = context.applicationContext
        val shell = ShellEngine.getInstance(appCtx)
        if (shell.state.value.isAdbReady) {
            try {
                shell.execute(if (enable) "svc bluetooth enable" else "svc bluetooth disable")
                return
            } catch (_: Throwable) {}
        }
        launchIntentSafely(appCtx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        kotlinx.coroutines.delay(450L)
        NoAccessibilityScreenEngine.toggleSettingSwitchByTitle(appCtx, "Bluetooth", enable)
    }
    /**
     * Tra cứu nhanh thời tiết thực tế (nhiệt độ, cảm giác thực tế, tình trạng mưa/nắng) và dịch sang tiếng Việt tự nhiên
     * để AI đọc to thành tiếng ngay cho người dùng nghe rảnh tay 100%.
     */
    fun fetchInstantWeatherSummary(userQuery: String): String? {
        var conn: java.net.HttpURLConnection? = null
        return try {
            val queryLower = userQuery.lowercase(Locale.ROOT)
            val city = when {
                queryLower.contains("ha noi") || queryLower.contains("hà nội") -> "Hanoi"
                queryLower.contains("ho chi minh") || queryLower.contains("hồ chí minh") || queryLower.contains("sai gon") || queryLower.contains("sài gòn") -> "Ho_Chi_Minh_City"
                queryLower.contains("da nang") || queryLower.contains("đà nẵng") -> "Da_Nang"
                queryLower.contains("hai phong") || queryLower.contains("hải phòng") -> "Hai_Phong"
                queryLower.contains("can tho") || queryLower.contains("cần thơ") -> "Can_Tho"
                queryLower.contains("nha trang") -> "Nha_Trang"
                queryLower.contains("hue") || queryLower.contains("huế") -> "Hue"
                queryLower.contains("da lat") || queryLower.contains("đà lạt") -> "Da_Lat"
                queryLower.contains("vung tau") || queryLower.contains("vũng tàu") -> "Vung_Tau"
                queryLower.contains("quy nhon") || queryLower.contains("quy nhơn") -> "Quy_Nhon"
                else -> "Hanoi"
            }
            val url = java.net.URL("https://wttr.in/${java.net.URLEncoder.encode(city, "UTF-8")}?format=j1")
            conn = (url.openConnection() as java.net.HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 3200
                readTimeout = 4000
                setRequestProperty("User-Agent", "curl/7.68.0")
            }
            if (conn.responseCode in 200..299) {
                val jsonStr = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val root = org.json.JSONObject(jsonStr)
                val cur = root.optJSONArray("current_condition")?.optJSONObject(0) ?: return null
                val tempC = cur.optString("temp_C", "")
                val feelsLikeC = cur.optString("FeelsLikeC", "")
                val rawDesc = cur.optJSONArray("weatherDesc")?.optJSONObject(0)?.optString("value", "").orEmpty()
                val humidity = cur.optString("humidity", "")

                val viDesc = when {
                    rawDesc.contains("Sunny", ignoreCase = true) || rawDesc.contains("Clear", ignoreCase = true) -> "trời nắng ráo, quang đãng"
                    rawDesc.contains("Partly cloudy", ignoreCase = true) -> "trời có mây, nắng gián đoạn"
                    rawDesc.contains("Cloudy", ignoreCase = true) || rawDesc.contains("Overcast", ignoreCase = true) -> "trời nhiều mây, râm mát"
                    rawDesc.contains("Patchy rain", ignoreCase = true) || rawDesc.contains("Light rain", ignoreCase = true) -> "có mưa rào nhẹ rải rác"
                    rawDesc.contains("Heavy rain", ignoreCase = true) || rawDesc.contains("Moderate rain", ignoreCase = true) -> "có mưa to"
                    rawDesc.contains("Thunder", ignoreCase = true) -> "có dông và sấm sét"
                    rawDesc.contains("Fog", ignoreCase = true) || rawDesc.contains("Mist", ignoreCase = true) -> "có sương mù"
                    else -> rawDesc
                }

                val cityDisplay = when (city) {
                    "Hanoi" -> "Hà Nội"
                    "Ho_Chi_Minh_City" -> "Hồ Chí Minh"
                    "Da_Nang" -> "Đà Nẵng"
                    "Hai_Phong" -> "Hải Phòng"
                    "Can_Tho" -> "Cần Thơ"
                    "Nha_Trang" -> "Nha Trang"
                    "Hue" -> "Huế"
                    "Da_Lat" -> "Đà Lạt"
                    "Vung_Tau" -> "Vũng Tàu"
                    "Quy_Nhon" -> "Quy Nhơn"
                    else -> "khu vực của bạn"
                }

                if (tempC.isNotBlank()) {
                    val feelsText = if (feelsLikeC.isNotBlank() && feelsLikeC != tempC) ", cảm giác như ${feelsLikeC} độ" else ""
                    val humText = if (humidity.isNotBlank()) ", độ ẩm ${humidity}%" else ""
                    "Thời tiết tại $cityDisplay hiện tại là ${tempC} độ C$feelsText, $viDesc$humText."
                } else null
            } else null
        } catch (_: Throwable) {
            null
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    private fun dispatchMediaKey(context: Context, keyCode: Int) {
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            val downEvent = android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, keyCode)
            val upEvent = android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, keyCode)
            am.dispatchMediaKeyEvent(downEvent)
            am.dispatchMediaKeyEvent(upEvent)
        } catch (_: Throwable) {}
    }
}
