package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicPurple
import com.example.ui.theme.MagicPurpleLight
import com.example.ui.theme.MagicRoseLight
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

private data class FreeVsProBenefitRow(
    val featureTitle: String,
    val freeStatus: String,
    val proStatus: String,
    val freeIsLimited: Boolean = true
)

/**
 * Bảng so sánh đặc quyền Bản Miễn Phí (FREE) vs Bản PRO Vĩnh Viễn
 * giúp người dùng thấy rõ lợi ích vượt trội trước khi quét mã VietQR chuyển khoản nâng cấp.
 */
@Composable
fun ProBenefitsComparisonSection(
    proPrice: String,
    accountProPrice: String,
    totalTrialLimit: Int = 5,
    compact: Boolean = false,
    proOriginalPrice: String = "",
    accountProOriginalPrice: String = "",
    isProSaleActive: Boolean = false,
    modifier: Modifier = Modifier
) {
    val rows = remember(totalTrialLimit) {
        listOf(
            FreeVsProBenefitRow(
                featureTitle = "⚡ Lượt dùng 55+ công cụ hệ thống",
                freeStatus = "Giới hạn $totalTrialLimit lượt",
                proStatus = "Vĩnh viễn ∞",
                freeIsLimited = true
            ),
            FreeVsProBenefitRow(
                featureTitle = "✨ Khoanh tròn hỏi AI & Dịch Cuộn Live",
                freeStatus = "Dùng thử có hạn",
                proStatus = "Không giới hạn",
                freeIsLimited = true
            ),
            FreeVsProBenefitRow(
                featureTitle = "🔔 Fix thông báo 0s & Tối ưu 8-trong-1",
                freeStatus = "Bị khóa khi hết lượt",
                proStatus = "Chạy mọi lúc ∞",
                freeIsLimited = true
            ),
            FreeVsProBenefitRow(
                featureTitle = "🔋 Soi & triệt tiêu App xả pin 7 lớp ADB",
                freeStatus = "Bị giới hạn lượt",
                proStatus = "Mở khóa 100%",
                freeIsLimited = true
            ),
            FreeVsProBenefitRow(
                featureTitle = "🧹 Dọn app rác TQ, Sạc 97%/100%, 120Hz",
                freeStatus = "Bị giới hạn lượt",
                proStatus = "Toàn quyền VIP",
                freeIsLimited = true
            ),
            FreeVsProBenefitRow(
                featureTitle = "🖨️ In nhiệt K80/K57 & Vẽ chữ A–Z",
                freeStatus = "Giới hạn dùng thử",
                proStatus = "Không giới hạn",
                freeIsLimited = true
            ),
            FreeVsProBenefitRow(
                featureTitle = "☁️ Bảo lưu Cloud & Cập nhật bản mới",
                freeStatus = "Không bảo lưu VIP",
                proStatus = "Trọn đời + Hỗ trợ 1-1",
                freeIsLimited = true
            ),
            FreeVsProBenefitRow(
                featureTitle = "🎁 6 Widget Màn Hình Chính",
                freeStatus = "Free vĩnh viễn",
                proStatus = "Free vĩnh viễn",
                freeIsLimited = false
            )
        )
    }

    val borderBrush = remember {
        Brush.horizontalGradient(listOf(MagicAmber, MagicEmerald, MagicCyan))
    }
    val headerBgBrush = remember {
        Brush.horizontalGradient(
            listOf(
                MagicAmber.copy(alpha = 0.22f),
                MagicPurple.copy(alpha = 0.20f),
                MagicCyan.copy(alpha = 0.16f)
            )
        )
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF090F1D))
            .border(1.2.dp, borderBrush, RoundedCornerShape(14.dp))
            .testTag("pro_benefits_comparison_section"),
        verticalArrangement = Arrangement.spacedBy(0.dp)
    ) {
        // Header nổi bật
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(headerBgBrush)
                .padding(horizontal = 12.dp, vertical = if (compact) 9.dp else 11.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.WorkspacePremium,
                        contentDescription = null,
                        tint = MagicAmber,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "LÊN PRO CÓ LỢI GÌ HƠN FREE?",
                        color = MagicAmber,
                        fontSize = if (compact) 11.5.sp else 12.2.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MagicEmerald.copy(alpha = 0.22f),
                    border = BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.7f))
                ) {
                    Text(
                        text = "TRẢ 1 LẦN • TRỌN ĐỜI",
                        color = MagicEmeraldLight,
                        fontSize = 8.8.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            val saleNotice = if (isProSaleActive && proOriginalPrice.isNotBlank() && proOriginalPrice != proPrice) {
                "🔥 ĐANG GIẢM GIÁ: Chỉ từ $proPrice (Giá gốc $proOriginalPrice) — mở khóa 100% tính năng VIP, dịch màn hình AI, fix thông báo 0s & tối ưu máy vĩnh viễn!"
            } else {
                "☕ Chỉ từ $proPrice (không thu phí hàng tháng) — mở khóa 100% tính năng VIP, dịch màn hình AI, fix thông báo 0s & tối ưu máy không giới hạn vĩnh viễn!"
            }
            Text(
                text = saleNotice,
                color = if (isProSaleActive && proOriginalPrice.isNotBlank() && proOriginalPrice != proPrice) MagicRoseLight else Color(0xFFE2E8F0),
                fontSize = if (compact) 10.sp else 10.6.sp,
                lineHeight = if (compact) 14.sp else 15.sp,
                fontWeight = if (isProSaleActive) FontWeight.Bold else FontWeight.Medium
            )
        }

        // Tiêu đề cột bảng so sánh FREE vs PRO
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MagicSurfaceCard.copy(alpha = 0.85f))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Tính năng & Quyền lợi",
                color = TextSecondary,
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1.45f)
            )
            Text(
                text = "FREE",
                color = MagicRoseLight,
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(0.78f)
            )
            Text(
                text = "👑 PRO VIP",
                color = MagicEmeraldLight,
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(0.88f)
            )
        }

        // Các hàng so sánh chi tiết
        rows.forEachIndexed { index, item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (index % 2 == 0) Color.Transparent else Color.White.copy(alpha = 0.025f))
                    .padding(horizontal = 10.dp, vertical = if (compact) 5.5.dp else 6.5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.featureTitle,
                    color = Color.White,
                    fontSize = if (compact) 9.8.sp else 10.3.sp,
                    fontWeight = FontWeight.SemiBold,
                    lineHeight = 13.5.sp,
                    modifier = Modifier
                        .weight(1.45f)
                        .padding(end = 4.dp)
                )

                // Cột Free
                Row(
                    modifier = Modifier.weight(0.78f),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (item.freeIsLimited) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = null,
                            tint = MagicRoseLight.copy(alpha = 0.85f),
                            modifier = Modifier.size(11.dp)
                        )
                    }
                    Text(
                        text = item.freeStatus,
                        color = if (item.freeIsLimited) TextMuted else MagicCyanLight,
                        fontSize = 8.9.sp,
                        fontWeight = if (item.freeIsLimited) FontWeight.Medium else FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        lineHeight = 11.5.sp
                    )
                }

                // Cột Pro
                Row(
                    modifier = Modifier.weight(0.88f),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = MagicEmeraldLight,
                        modifier = Modifier.size(11.5.dp)
                    )
                    Text(
                        text = " ${item.proStatus}",
                        color = MagicEmeraldLight,
                        fontSize = 9.2.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center,
                        lineHeight = 12.sp
                    )
                }
            }
            if (index < rows.lastIndex) {
                HorizontalDivider(
                    thickness = 0.6.dp,
                    color = MagicBorder.copy(alpha = 0.4f)
                )
            }
        }

        // Dải cam kết bảo lưu & kích hoạt nhanh
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MagicEmerald.copy(alpha = 0.12f))
                .padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = MagicAmber,
                modifier = Modifier.size(15.dp)
            )
            Text(
                text = "Kích hoạt tự động ngay sau khi chuyển khoản • Gỡ app cài lại tự khôi phục 100% • Pro Tài Khoản ($accountProPrice) mang theo khi đổi máy mới!",
                color = MagicCyanLight,
                fontSize = 9.6.sp,
                lineHeight = 13.5.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
