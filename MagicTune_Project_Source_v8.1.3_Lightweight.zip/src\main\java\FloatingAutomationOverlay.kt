package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FloatingMiniWindowState
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.TextSecondary

@Composable
fun FloatingAutomationOverlay(
    state: FloatingMiniWindowState,
    onMinimizeToggle: (Boolean) -> Unit,
    onClose: () -> Unit,
    onStartLiveAutomation: () -> Unit,
    onEnterPipMultiWindow: () -> Unit,
    onOpenCurrentAppNotificationSettings: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (!state.isVisible) return
    val isFinished = state.totalSteps > 0 && state.currentStep >= state.totalSteps && !state.isRunningAutomation
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
        border = BorderStroke(1.5.dp, if (isFinished) MagicEmerald else MagicCyan)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isFinished) {
                        "✅ ĐÃ HOÀN TẤT (${state.totalSteps}/${state.totalSteps})"
                    } else {
                        "⚡ TỰ ĐỘNG GẠT CÔNG TẮC (${state.currentStep}/${state.totalSteps.coerceAtLeast(1)})"
                    },
                    color = if (isFinished) MagicEmerald else MagicCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.weight(1f)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = { onMinimizeToggle(!state.isMinimizedBubble) },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.heightIn(min = 28.dp),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, MagicBorder)
                    ) {
                        Text(if (state.isMinimizedBubble) "Mở rộng" else "Thu gọn", fontSize = 10.sp, color = Color.White)
                    }
                    Button(
                        onClick = onClose,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.heightIn(min = 28.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicRose, contentColor = Color.White)
                    ) {
                        Text("Đóng", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (!state.isMinimizedBubble) {
                if (state.totalSteps > 0) {
                    val progress = (state.currentStep.toFloat() / state.totalSteps.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(6.dp),
                        color = if (isFinished) MagicEmerald else MagicCyan,
                        trackColor = Color(0xFF1E293B)
                    )
                }

                if (state.currentAppName.isNotBlank()) {
                    Text(
                        text = "📱 ${state.currentAppName}" + if (state.currentPackageName.isNotBlank()) " (${state.currentPackageName})" else "",
                        color = Color.White,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (state.currentActionDetail.isNotBlank()) {
                    Text(
                        text = state.currentActionDetail,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!state.isRunningAutomation && !isFinished) {
                        Button(
                            onClick = onStartLiveAutomation,
                            modifier = Modifier.weight(1f).heightIn(min = 36.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617)),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("▶️ Chạy Tự Động", fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                        }
                    }
                    if (state.currentPackageName.isNotBlank()) {
                        OutlinedButton(
                            onClick = { onOpenCurrentAppNotificationSettings(state.currentPackageName) },
                            modifier = Modifier.weight(1f).heightIn(min = 36.dp),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, MagicAmber),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("⚙️ Mở Cài Đặt App", fontSize = 10.5.sp, color = MagicAmber, fontWeight = FontWeight.Bold)
                        }
                    }
                    OutlinedButton(
                        onClick = onEnterPipMultiWindow,
                        modifier = Modifier.heightIn(min = 36.dp),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, MagicBorder),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("🗗 Cửa sổ nổi", fontSize = 10.5.sp, color = Color.White)
                    }
                }
            }
        }
    }
}
