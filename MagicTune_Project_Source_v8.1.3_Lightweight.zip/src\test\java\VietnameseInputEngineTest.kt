package com.example.core.keyboard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VietnameseInputEngineTest {

    @Test
    fun applyTelex_basicVowelsAndConsonantD_transformsProperly() {
        assertEquals("đ", VietnameseInputEngine.applyTelex("d", "d"))
        assertEquals("Đ", VietnameseInputEngine.applyTelex("D", "d"))
        assertEquals("â", VietnameseInputEngine.applyTelex("a", "a"))
        assertEquals("ê", VietnameseInputEngine.applyTelex("e", "e"))
        assertEquals("ô", VietnameseInputEngine.applyTelex("o", "o"))
        assertEquals("ă", VietnameseInputEngine.applyTelex("a", "w"))
        assertEquals("ơ", VietnameseInputEngine.applyTelex("o", "w"))
        assertEquals("ư", VietnameseInputEngine.applyTelex("u", "w"))
    }

    @Test
    fun applyTelex_tonePlacementAndUoCluster_transformsProperly() {
        var word = ""
        for (ch in "dduowcj") {
            word = VietnameseInputEngine.applyTelex(word, ch.toString())
        }
        assertEquals("được", word)

        var delayedD = ""
        for (ch in "duowcjd") {
            delayedD = VietnameseInputEngine.applyTelex(delayedD, ch.toString())
        }
        assertEquals("được", delayedD)

        var person = ""
        for (ch in "nguowif") {
            person = VietnameseInputEngine.applyTelex(person, ch.toString())
        }
        assertEquals("người", person)

        var toi = ""
        for (ch in "towsi") {
            toi = VietnameseInputEngine.applyTelex(toi, ch.toString())
        }
        assertEquals("tới", toi)
        assertEquals("hoàn", VietnameseInputEngine.applyTelex("hòa", "n"))
    }

    @Test
    fun applyTelex_undoOnDoubleTapAndRemoveToneWithZ() {
        assertEquals("as", VietnameseInputEngine.applyTelex("á", "s"))
        assertEquals("a", VietnameseInputEngine.applyTelex("á", "z"))
    }

    @Test
    fun applyTelex_giAndQuOutOfOrderToneRepositioning_worksProperly() {
        fun typeAll(seq: String): String {
            var res = ""
            for (ch in seq) res = VietnameseInputEngine.applyTelex(res, ch.toString())
            return res
        }
        assertEquals("già", typeAll("gifa"))
        assertEquals("già", typeAll("giaf"))
        assertEquals("quá", typeAll("qusa"))
        assertEquals("quá", typeAll("quas"))
        assertEquals("giữa", typeAll("giuwax"))
        assertEquals("giữa", typeAll("giuaxw"))
        assertEquals("giường", typeAll("giuongwf"))
        assertEquals("quắc", typeAll("quacws"))
        assertEquals("quơ", typeAll("quow"))
        assertEquals("gửi", typeAll("guiwr"))
        assertEquals("rượu", typeAll("ruoujw"))
        assertEquals("tuyển", typeAll("tuyenre"))
        assertEquals("khuấy", typeAll("khuayas"))
    }

    @Test
    fun applyTelex_englishWordsAndDomains_notMangled() {
        fun typeAll(seq: String): String {
            var res = ""
            for (ch in seq) res = VietnameseInputEngine.applyTelex(res, ch.toString())
            return res
        }
        assertEquals("wifi", typeAll("wifi"))
        assertEquals("with", typeAll("with"))
        assertEquals("web", typeAll("web"))
        assertEquals("what", typeAll("what"))
        assertEquals("pas", typeAll("pass"))
        assertEquals("pass", typeAll("passs"))
        assertEquals("password", typeAll("password"))
        assertEquals("class", typeAll("class"))
        assertEquals("for", typeAll("for"))
        assertEquals("fix", typeAll("fix"))
        assertEquals("free", typeAll("free"))
        assertEquals("just", typeAll("just"))
        assertEquals("start", typeAll("start"))
        assertEquals("download", typeAll("download"))
        assertEquals("android", typeAll("android"))
        assertEquals("google", typeAll("google"))
        assertEquals("server", typeAll("server"))
        assertEquals("error", typeAll("error"))
        assertEquals("power", typeAll("power"))
        assertEquals("keyboard", typeAll("keyboard"))
        assertEquals("thanks", typeAll("thanks"))
        assertEquals("mobile", typeAll("mobile"))
        assertEquals("update", typeAll("update"))
        assertEquals("google.com", typeAll("google.com"))
        // Accidental period after Vietnamese accented word still lets user keep typing Vietnamese
        assertEquals("cải.thiện", typeAll("cair.thieenj"))
        assertEquals("cải.thiện", typeAll("cair.thienje"))
    }

    @Test
    fun isViVowel_identifiesVietnameseAndNonVietnameseChars() {
        assertTrue(VietnameseInputEngine.isViVowel('ệ'))
        assertTrue(VietnameseInputEngine.isViVowel('Ư'))
        assertFalse(VietnameseInputEngine.isViVowel('k'))
        assertFalse(VietnameseInputEngine.isViVowel('t'))
    }
}
