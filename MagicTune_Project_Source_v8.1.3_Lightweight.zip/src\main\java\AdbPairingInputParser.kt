package com.example.core.adb

/**
 * Bộ phân tích thông minh cho dữ liệu nhập ghép nối ADB Không Dây:
 * Hỗ trợ nhiều định dạng linh hoạt từ RemoteInput (Thanh thông báo) hoặc ô nhập liệu / Clipboard:
 * - "123456" -> pin = "123456", port = null
 * - "123 456" hoặc "123-456" -> pin = "123456", port = null
 * - "38475 123456" hoặc "38475:123456" -> port = 38475, pin = "123456"
 * - "192.168.1.5:38475 123456" -> host = "192.168.1.5", port = 38475, pin = "123456"
 * - "38475123456" (11 chữ số liền nhau: 5 số cổng + 6 số PIN) -> port = 38475, pin = "123456"
 */
data class ParsedPairingInput(
    val pin: String? = null,
    val port: Int? = null,
    val host: String? = null
)

object AdbPairingInputParser {

    private val hostPortRegex = Regex("""\b(\d{1,3}(?:\.\d{1,3}){3}):(\d{4,5})\b""")
    private val digitsGroupRegex = Regex("""\d+""")

    fun parse(rawInput: String): ParsedPairingInput {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return ParsedPairingInput()

        var extractedHost: String? = null
        var extractedPort: Int? = null
        var remaining = trimmed

        // 1. Kiểm tra mẫu IP:PORT (ví dụ 192.168.1.15:38475 123456)
        val hpMatch = hostPortRegex.find(trimmed)
        if (hpMatch != null) {
            val candidateHost = hpMatch.groupValues[1]
            val candidatePort = hpMatch.groupValues[2].toIntOrNull()
            if (isValidIpv4(candidateHost) && candidatePort != null && candidatePort in 1024..65535) {
                extractedHost = candidateHost
                extractedPort = candidatePort
                remaining = trimmed.removeRange(hpMatch.range)
            }
        }

        // 2. Gom các nhóm chữ số còn lại
        val groups = digitsGroupRegex.findAll(remaining).map { it.value }.toList()
        if (groups.isEmpty()) {
            return ParsedPairingInput(pin = null, port = extractedPort, host = extractedHost)
        }

        // Nếu đã có port từ IP:PORT, phần còn lại ghép lại lấy 6 số PIN
        if (extractedPort != null) {
            val digits = groups.joinToString("")
            val pin = if (digits.length >= 6) digits.take(6) else null
            return ParsedPairingInput(pin = pin, port = extractedPort, host = extractedHost)
        }

        // Trường hợp có >= 2 nhóm số, VD: ["38475", "123456"] hoặc ["123", "456"] hoặc ["38475", "123", "456"]
        if (groups.size >= 2) {
            val first = groups[0]
            val restDigits = groups.drop(1).joinToString("")
            val firstPort = first.toIntOrNull()
            if (first.length in 4..5 && firstPort != null && firstPort in 1024..65535 && restDigits.length == 6) {
                return ParsedPairingInput(pin = restDigits, port = firstPort, host = extractedHost)
            }
            // Kiểm tra trường hợp người dùng gõ PIN trước Port: "123456 38475"
            val last = groups.last()
            val headDigits = groups.dropLast(1).joinToString("")
            val lastPort = last.toIntOrNull()
            if (last.length in 4..5 && lastPort != null && lastPort in 1024..65535 && headDigits.length == 6) {
                return ParsedPairingInput(pin = headDigits, port = lastPort, host = extractedHost)
            }
        }

        val allDigits = groups.joinToString("")
        return when {
            allDigits.length == 6 -> ParsedPairingInput(pin = allDigits, port = null, host = extractedHost)
            allDigits.length == 11 -> {
                val p = allDigits.substring(0, 5).toIntOrNull()
                if (p != null && p in 1024..65535) {
                    ParsedPairingInput(pin = allDigits.substring(5, 11), port = p, host = extractedHost)
                } else {
                    ParsedPairingInput(pin = allDigits.take(6), port = null, host = extractedHost)
                }
            }
            allDigits.length == 10 -> {
                val p = allDigits.substring(0, 4).toIntOrNull()
                if (p != null && p in 1024..65535) {
                    ParsedPairingInput(pin = allDigits.substring(4, 10), port = p, host = extractedHost)
                } else {
                    ParsedPairingInput(pin = allDigits.take(6), port = null, host = extractedHost)
                }
            }
            allDigits.length > 6 -> ParsedPairingInput(pin = allDigits.take(6), port = null, host = extractedHost)
            else -> ParsedPairingInput(pin = null, port = null, host = extractedHost)
        }
    }

    private fun isValidIpv4(ip: String): Boolean {
        val parts = ip.split('.')
        if (parts.size != 4) return false
        return parts.all {
            val n = it.toIntOrNull() ?: return false
            n in 0..255
        }
    }
}
