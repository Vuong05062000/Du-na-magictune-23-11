package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.core.permission.AppSelfPermissionStatus
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicDarkBackground
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicRoseLight
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SelfPermissionModal(
    status: AppSelfPermissionStatus,
    isShizukuReady: Boolean,
    onGrantAllViaShizuku: () -> Unit,
    onRequestNotification: () -> Unit,
    onRequestOverlay: () -> Unit,
    onRequestUsageStats: () -> Unit,
    onRequestAccessibility: () -> Unit = {},
    onRequestAssistant: () -> Unit = {},
    onRequestWriteSecure: () -> Unit,
    onOpenAppSettings: () -> Unit,
    onOpenHonorAppLaunch: () -> Unit = {},
    onRepairHonor: () -> Unit = {},
    onOpenSpecialAccess: () -> Unit = {},
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false
        )
    ) {
        val context = androidx.compose.ui.platform.LocalContext.current
        val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current

        val scrollState = rememberScrollState()
        Card(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(vertical = 24.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScrollWithScrollbar(scrollState = scrollState, thumbColor = MagicCyan)
                    .padding(start = 20.dp, top = 20.dp, end = 24.dp, bottom = 20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f).padding(end = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MagicCyan.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = MagicCyanLight,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "KIỂM TRA QUYỀN HỆ THỐNG",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (status.isFullyGranted) "Ứng dụng đã có đầy đủ quyền cần thiết"
                                else "Còn thiếu ${status.missingCount} quyền quan trọng",
                                color = if (status.isFullyGranted) MagicEmerald else MagicAmber,
                                fontSize = 12.sp
                            )
                        }
                    }

                    // Nút Đóng (X) TO RÕ Ở GÓC TRÊN BÊN PHẢI (Không bao giờ bị bóp hẹp)
                    Box(
                        modifier = Modifier
                            .requiredSize(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                            .border(1.5.dp, Color.White.copy(alpha = 0.4f), CircleShape)
                            .clickable { onDismiss() }
                            .testTag("close_self_permission_dialog_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Đóng hộp thoại quyền",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Để MagicTune tối ưu hóa MagicOS mượt mà, ghim thanh tìm kiếm lên thanh thông báo, đọc ứng dụng gần đây và duy trì kết nối không bị hệ thống tắt ngầm, vui lòng cấp các quyền dưới đây:",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 18.sp,
                    softWrap = true
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Checklist - Now part of the main scrollable Column
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // 1. Quyền Thông Báo
                    PermissionItemRow(
                        title = "Quyền Thông Báo (POST_NOTIFICATIONS)",
                        description = "Ghim thanh tìm kiếm ứng dụng & giám sát sạc pin trên thanh điều hướng & màn hình khóa",
                        isGranted = status.hasNotificationPermission,
                        icon = Icons.Default.Notifications,
                        onGrant = onRequestNotification
                    )
                    

                    // 3. Hiển thị trên ứng dụng khác (Overlay)
                    PermissionItemRow(
                        title = "Hiển Thị Trên Ứng Dụng Khác (Overlay)",
                        description = "Cho phép hiển thị cửa sổ đa nhiệm PiP và các tiện ích nổi tức thì",
                        isGranted = status.hasOverlayPermission,
                        icon = Icons.Default.PlayArrow,
                        onGrant = onRequestOverlay
                    )

                    // 4. Lịch sử sử dụng app gần đây (Usage Stats)
                    PermissionItemRow(
                        title = "Truy Cập Dữ Liệu Sử Dụng (Recent Apps)",
                        description = "Hiển thị 5 ứng dụng mở gần đây trực tiếp trên thẻ tìm kiếm màn hình chính",
                        isGranted = status.hasUsageStatsPermission,
                        icon = Icons.Default.Star,
                        onGrant = onRequestUsageStats
                    )

                    // 5. Đọc Màn Hình & Trợ Năng An Toàn 100%
                    PermissionItemRow(
                        title = "Đọc Màn Hình & Trợ Năng An Toàn 100%",
                        description = "Tự động kích hoạt theo nhu cầu: Tuyệt đối không cần bật thủ công trong Cài đặt Honor. 100% ứng dụng tài chính và xác thực định danh hoạt động trơn tru vĩnh viễn không bao giờ bị báo lỗi.",
                        isGranted = status.hasMediaProjectionPermission,
                        icon = Icons.Default.Info,
                        warningText = if (!status.hasMediaProjectionPermission) {
                            "💡 LƯU Ý QUAN TRỌNG: Ứng dụng tự động quản lý Trợ Năng thông minh theo nhu cầu, KHÔNG BAO GIỜ cần bật trong Cài Đặt Trợ Năng của điện thoại Honor! " +
                                "Kết nối Gỡ lỗi WLAN (mã 6 số) sẽ tự động cấp quyền hệ thống, giúp bạn vừa dùng trọn vẹn mọi tính năng vừa mở ứng dụng tài chính & bảo mật mượt mà 24/7."
                        } else null,
                        actionLabel = if (status.hasMediaProjectionPermission) "ĐÃ CẤP" else "KẾT NỐI WLAN",
                        onGrant = onRequestAccessibility
                    )

                    // 6. Quyền Trợ Lý Kỹ Thuật Số (Digital Assistant - Thay thế hoàn toàn YOYO trên Honor MagicOS)
                    PermissionItemRow(
                        title = "Quyền Trợ Lý Kỹ Thuật Số (Digital Assistant)",
                        description = "Đặt Trợ lý Magic làm trợ lý mặc định để phân tích màn hình, dịch tin nhắn & cử chỉ nhanh",
                        isGranted = status.hasAssistantPermission,
                        icon = Icons.Default.PlayArrow,
                        onGrant = onRequestAssistant
                    )

                    // 7. Quyền Quản Trị Hệ Thống (WRITE_SECURE_SETTINGS)
                    PermissionItemRow(
                        title = "Điều Khiển Hệ Thống (WRITE_SECURE_SETTINGS)",
                        description = "Cấp trực tiếp qua Kết Nối Trực Tiếp WLAN ADB (Mã 6 số) để mở khóa 144Hz & tối ưu sâu",
                        isGranted = status.hasWriteSecureSettings,
                        icon = Icons.Default.Settings,
                        onGrant = onRequestWriteSecure
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Primary Quick Grant Action (Direct WLAN ADB 1-click)
                if (isShizukuReady) {
                    Button(
                        onClick = onGrantAllViaShizuku,
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 70.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "⚡ CẤP FULL QUYỀN TỰ ĐỘNG BẰNG 1 CHẠM",
                                color = Color(0xFF020617),
                                fontWeight = FontWeight.Black,
                                fontSize = 12.5.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Cấp toàn bộ 5 quyền quản trị qua Kết Nối Trực Tiếp WLAN ADB",
                                color = Color(0xFF020617).copy(alpha = 0.85f),
                                fontWeight = FontWeight.Medium,
                                fontSize = 10.5.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    // Honor specific repair button
                    Button(
                        onClick = { onRepairHonor() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 54.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicAmber.copy(alpha = 0.15f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicAmber.copy(alpha = 0.5f))
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = MagicAmber, modifier = Modifier.size(18.dp))
                            Text(
                                text = "SỬA LỖI QUYỀN HONOR / MAGICOS",
                                color = MagicAmber,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                } else if (!status.hasWriteSecureSettings) {
                    Button(
                        onClick = onRequestWriteSecure,
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 68.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "🔌 KẾT NỐI TRỰC TIẾP (MÃ 6 SỐ) ĐỂ CẤP QUYỀN",
                                color = Color(0xFF020617),
                                fontWeight = FontWeight.Black,
                                fontSize = 12.5.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Mở bảng ghép nối Gỡ lỗi Wi-Fi trực tiếp siêu nhanh",
                                color = Color(0xFF020617).copy(alpha = 0.85f),
                                fontWeight = FontWeight.Medium,
                                fontSize = 10.5.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Nút Sao Chép Lệnh ADB Khóa Quyền Vĩnh Viễn
                Button(
                    onClick = {
                        val pkg = context.packageName
                        val cmd = "adb shell \"pm grant $pkg android.permission.WRITE_SECURE_SETTINGS; pm grant $pkg android.permission.WRITE_SETTINGS; pm grant $pkg android.permission.DUMP; pm grant $pkg android.permission.READ_LOGS; pm grant $pkg android.permission.POST_NOTIFICATIONS; cmd appops set $pkg ACCESS_RESTRICTED_SETTINGS allow; cmd appops set $pkg SYSTEM_ALERT_WINDOW allow; cmd appops set $pkg PROJECT_MEDIA allow;  settings put secure magictune_wlan_activated_forever 1; settings put global magictune_wlan_activated_forever 1; settings put secure magictune_device_adb_permanently_unlocked 1; settings put global magictune_device_adb_permanently_unlocked 1\""
                        clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(cmd))
                        com.example.core.permission.AppPermissionChecker.markWlanActivated(context)
                        android.widget.Toast.makeText(context, "✅ Đã sao chép lệnh ADB khóa quyền vĩnh viễn vào bộ nhớ tạm!", android.widget.Toast.LENGTH_LONG).show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicAmber.copy(alpha = 0.15f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MagicAmber.copy(alpha = 0.6f))
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(imageVector = Icons.Default.Star, contentDescription = null, tint = MagicAmber, modifier = Modifier.size(16.dp))
                        Text(
                            text = "📋 SAO CHÉP LỆNH ADB KHÓA VĨNH VIỄN (CHO PC)",
                            color = MagicAmber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))

                // Special Access Button (Always visible as fallback)
                Button(
                    onClick = onOpenSpecialAccess,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.05f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.1f))
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                        Text(
                            text = "MỞ QUYỀN TRUY CẬP ĐẶC BIỆT (GỠ HẠN CHẾ)",
                            color = TextSecondary,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Mở cài đặt app
                    Button(
                        onClick = onOpenAppSettings,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .heightIn(min = 40.dp, max = 46.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.08f))
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "Cài Đặt App",
                                color = Color.White,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(1.dp))
                            Text(
                                text = "(Chi tiết ứng dụng)",
                                color = TextSecondary,
                                fontSize = 9.5.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    // Đóng / Đã hiểu
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .heightIn(min = 40.dp, max = 46.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (status.isFullyGranted) MagicEmerald else MagicCyan.copy(alpha = 0.2f))
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = if (status.isFullyGranted) "Hoàn Tất" else "Đóng",
                                color = if (status.isFullyGranted) Color.Black else MagicCyanLight,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(1.dp))
                            Text(
                                text = if (status.isFullyGranted) "(Đã đủ quyền)" else "(Để sau)",
                                color = if (status.isFullyGranted) Color.Black.copy(alpha = 0.75f) else TextSecondary,
                                fontSize = 9.5.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionItemRow(
    title: String,
    description: String,
    isGranted: Boolean,
    icon: ImageVector,
    onGrant: () -> Unit,
    warningText: String? = null,
    actionLabel: String = "CẤP"
) {
    val isWlanAction = actionLabel == "KẾT NỐI WLAN" || warningText != null
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            when {
                isGranted -> MagicEmerald.copy(alpha = 0.4f)
                warningText != null -> MagicAmber.copy(alpha = 0.65f)
                else -> MagicBorder
            }
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(if (isGranted) MagicEmerald.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.05f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isGranted) Icons.Default.CheckCircle else icon,
                            contentDescription = null,
                            tint = if (isGranted) MagicEmerald else Color.Gray,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = title,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = description,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }

                if (!isWlanAction) {
                    Spacer(modifier = Modifier.width(10.dp))
                    if (isGranted) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicEmerald.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "ĐÃ CẤP",
                                color = MagicEmerald,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Button(
                            onClick = onGrant,
                            modifier = Modifier.heightIn(min = 32.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                        ) {
                            Text(
                                text = actionLabel,
                                color = Color(0xFF020617),
                                fontSize = if (actionLabel.length > 4) 9.sp else 11.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            if (warningText != null && !isGranted) {
                Row(
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = MagicAmber,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = warningText,
                        color = MagicAmber,
                        fontSize = 10.5.sp,
                        lineHeight = 14.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (isWlanAction) {
                Spacer(modifier = Modifier.height(2.dp))
                if (isGranted) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicEmerald.copy(alpha = 0.15f))
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "✅ ĐÃ CẤP QUYỀN TRỢ NĂNG & KẾT NỐI WLAN",
                            color = MagicEmerald,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Button(
                        onClick = onGrant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 44.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = Color(0xFF020617),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "⚡ $actionLabel (KẾT NỐI WLAN ADB TRỰC TIẾP)",
                            color = Color(0xFF020617),
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}
