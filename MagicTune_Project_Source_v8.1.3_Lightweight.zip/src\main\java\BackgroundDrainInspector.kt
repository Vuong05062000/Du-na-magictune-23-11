package com.example.core.widget

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.TrafficStats
import android.os.Build
import android.os.Process
import androidx.compose.runtime.Immutable
import com.example.core.service.NoAccessibilityScreenEngine
import com.example.core.shell.ShellEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

@Immutable
data class BackgroundAppDrainEntry(
    val packageName: String,
    val appName: String,
    val isUserApp: Boolean,
    val isProtected: Boolean,
    val ramMb: Int,
    val cpuPercent: Float,
    val estimatedPowerMah: Double,
    val processCount: Int,
    val hasActiveService: Boolean,
    val standbyBucketLabel: String,
    val processStateLabel: String,
    val isHighDrain: Boolean,
    val drainScore: Double,
    // --- Telemetry 10x Nâng Cao ---
    val uid: Int = 0,
    val realtimeCpuPercent: Float = 0f,
    val wakeLockCount: Int = 0,
    val wakeLockSummary: String = "",
    val alarmWakeups: Int = 0,
    val activeServiceCount: Int = 0,
    val activeJobCount: Int = 0,
    val networkMb: Double = 0.0,
    val networkDeltaKbps: Double = 0.0,
    val isBackgroundRestricted: Boolean = false,
    val isUserWhitelisted: Boolean = false,
    val isSystemCommsProtected: Boolean = false,
    val oomImportanceLabel: String = "",
    val culpritReasons: List<String> = emptyList()
)

@Immutable
data class BackgroundDrainScanReport(
    val entries: List<BackgroundAppDrainEntry>,
    val totalCurrentDrainMa: Int,
    val totalCurrentDrainWatts: Double,
    val isCharging: Boolean,
    val batteryTempC: Double,
    val cpuTempC: Double,
    val availableRamMb: Int,
    val isDeepAdbScan: Boolean,
    val hasUsageStatsAccess: Boolean,
    val highDrainCount: Int,
    val scannedAtLabel: String,
    // --- Dashboard Telemetry 10x ---
    val totalRamMb: Int = 0,
    val usedRamMb: Int = 0,
    val batteryPct: Int = 0,
    val voltageV: Double = 4.0,
    val estimatedHoursLeft: Double = 0.0,
    val activeWakeLockAppsCount: Int = 0,
    val totalAlarmWakeups: Int = 0,
    val totalBgAppsRunning: Int = 0,
    val scanDurationMs: Long = 0L,
    val batteryTempAvailable: Boolean = false
)

object BackgroundDrainInspector {

    private const val PREF_DRAIN_INSPECTOR = "magictune_bg_drain_inspector_prefs"
    private const val KEY_USER_VIP_WHITELIST = "user_vip_whitelist_pkgs"

    // Lưu mốc TrafficStats lần quét trước để tính tốc độ truyền dữ liệu ngầm theo KB/s
    private val lastUidNetBytes = ConcurrentHashMap<Int, Long>()
    private val appLabelCache = ConcurrentHashMap<String, String>()
    private val cachedBucketByPkg = ConcurrentHashMap<String, String>()
    private val scanMutex = kotlinx.coroutines.sync.Mutex()
    @Volatile
    private var lastFullDumpsysMs: Long = 0L
    @Volatile
    private var lastNetSampleTimeMs: Long = 0L
    @Volatile
    private var cachedTotalRamMbValue: Int = 0
    @Volatile
    private var cachedLastReport: BackgroundDrainScanReport? = null
    @Volatile
    private var lastCompletedScanElapsedMs: Long = 0L
    @Volatile
    private var cachedInstalledApps: List<ApplicationInfo>? = null
    @Volatile
    private var cachedInstalledAppsElapsedMs: Long = 0L
    @Volatile
    private var cachedUsageStats: List<UsageStats>? = null
    @Volatile
    private var cachedUsageStatsElapsedMs: Long = 0L

    // Biên dịch sẵn Regex 1 lần duy nhất thay vì khởi tạo hàng nghìn lần trong vòng lặp quét dòng
    private val REGEX_WHITESPACE = Regex("\\s+")
    private val REGEX_UID_U0A = Regex("^u0_?a(\\d+)$", RegexOption.IGNORE_CASE)
    private val REGEX_DIGITS = Regex("(\\d+)")
    private val REGEX_CPUINFO_LINE = Regex("^([0-9]+(?:\\.[0-9]+)?)%\\s+\\d+/([^:\\s]+)")
    private val REGEX_WL_PKG = Regex("pkg=([a-zA-Z0-9_.]+)")
    private val REGEX_WL_UID = Regex("uid=(u0a\\d+|\\d+)")
    private val REGEX_WL_TAG = Regex("'([^']{2,36})'")
    private val REGEX_ALARM_FULL = Regex("(u0a\\d+|10\\d{3}):([a-zA-Z0-9_.]+).*?(\\d+)\\s+wakeups", RegexOption.IGNORE_CASE)
    private val REGEX_ALARM_UID = Regex("(u0a\\d+|10\\d{3})")
    private val REGEX_ALARM_WAKEUPS = Regex("(\\d+)\\s+wakeups", RegexOption.IGNORE_CASE)
    private val REGEX_SLASH_PKG = Regex("([a-zA-Z0-9_]+\\.[a-zA-Z0-9_.]+)/")
    private val REGEX_BATT_UID = Regex("Uid\\s+(u0a\\d+|10\\d{3}):\\s*([0-9]+(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE)
    private val REGEX_BUCKET_PKG = Regex("package=([^\\s]+)")
    private val REGEX_BUCKET_VAL = Regex("(?:standbyBucket|bucket)=([0-9A-Za-z_]+)")

    private const val ROM_DRAIN_SNAPSHOT_FILE = "bg_drain_report_v1.json"

    fun peekRamCachedReportOnly(): BackgroundDrainScanReport? = cachedLastReport

    fun invalidateScanAndAppsCache() {
        cachedInstalledApps = null
        cachedInstalledAppsElapsedMs = 0L
        cachedLastReport = null
        lastCompletedScanElapsedMs = 0L
        cachedUsageStats = null
        cachedUsageStatsElapsedMs = 0L
    }

    fun hasFreshRamReport(maxAgeMs: Long = 180_000L): Boolean {
        val last = lastCompletedScanElapsedMs
        return cachedLastReport != null &&
            last > 0L &&
            (android.os.SystemClock.elapsedRealtime() - last) < maxAgeMs
    }

    fun getCachedReportInstant(context: Context? = null): BackgroundDrainScanReport? {
        cachedLastReport?.let { return it }
        if (context != null) {
            hydrateCachedReport(context)
        }
        return cachedLastReport
    }

    fun hydrateCachedReport(context: Context): BackgroundDrainScanReport? {
        cachedLastReport?.let { return it }
        return try {
            val raw = com.example.core.perf.DeviceMemoryStorageOptimizer.readFastSnapshotJson(
                context,
                ROM_DRAIN_SNAPSHOT_FILE
            ) ?: return null
            val root = org.json.JSONObject(raw)
            val entriesArr = root.optJSONArray("entries") ?: org.json.JSONArray()
            val list = ArrayList<BackgroundAppDrainEntry>(entriesArr.length())
            for (i in 0 until entriesArr.length()) {
                val o = entriesArr.optJSONObject(i) ?: continue
                val reasonsArr = o.optJSONArray("reasons")
                val reasons = if (reasonsArr != null) {
                    List(reasonsArr.length()) { idx -> reasonsArr.optString(idx) }.filter { it.isNotBlank() }
                } else emptyList()
                list.add(
                    BackgroundAppDrainEntry(
                        packageName = o.optString("pkg"),
                        appName = o.optString("name"),
                        isUserApp = o.optBoolean("user"),
                        isProtected = o.optBoolean("prot"),
                        ramMb = o.optInt("ram"),
                        cpuPercent = o.optDouble("cpu").toFloat(),
                        estimatedPowerMah = o.optDouble("mah"),
                        processCount = o.optInt("procs"),
                        hasActiveService = o.optBoolean("svc"),
                        standbyBucketLabel = o.optString("bucket"),
                        processStateLabel = o.optString("state"),
                        isHighDrain = o.optBoolean("high"),
                        drainScore = o.optDouble("score"),
                        uid = o.optInt("uid"),
                        realtimeCpuPercent = o.optDouble("rtCpu").toFloat(),
                        wakeLockCount = o.optInt("wl"),
                        wakeLockSummary = o.optString("wlTag"),
                        alarmWakeups = o.optInt("alarm"),
                        activeServiceCount = o.optInt("svcCnt"),
                        activeJobCount = o.optInt("jobCnt"),
                        networkMb = o.optDouble("netMb"),
                        networkDeltaKbps = o.optDouble("netKbps"),
                        isBackgroundRestricted = o.optBoolean("rest"),
                        isUserWhitelisted = o.optBoolean("vip"),
                        isSystemCommsProtected = o.optBoolean("comms"),
                        oomImportanceLabel = o.optString("oom"),
                        culpritReasons = reasons
                    )
                )
            }
            val parsed = BackgroundDrainScanReport(
                entries = list,
                totalCurrentDrainMa = root.optInt("ma"),
                totalCurrentDrainWatts = root.optDouble("w"),
                isCharging = root.optBoolean("chg"),
                batteryTempC = root.optDouble("bTemp"),
                batteryTempAvailable = root.optBoolean("bTempValid", false),
                cpuTempC = root.optDouble("cTemp"),
                availableRamMb = root.optInt("availRam"),
                isDeepAdbScan = root.optBoolean("adb"),
                hasUsageStatsAccess = root.optBoolean("usage"),
                highDrainCount = root.optInt("highCnt"),
                scannedAtLabel = root.optString("at"),
                totalRamMb = root.optInt("totalRam"),
                usedRamMb = root.optInt("usedRam"),
                batteryPct = root.optInt("battPct"),
                voltageV = root.optDouble("volt", 4.0),
                estimatedHoursLeft = root.optDouble("hrsLeft"),
                activeWakeLockAppsCount = root.optInt("wlApps"),
                totalAlarmWakeups = root.optInt("alarms"),
                totalBgAppsRunning = root.optInt("bgCnt"),
                scanDurationMs = root.optLong("dur")
            )
            cachedLastReport = parsed
            parsed
        } catch (_: Throwable) {
            null
        }
    }

    private fun saveReportToRom(context: Context, report: BackgroundDrainScanReport) {
        try {
            val root = org.json.JSONObject().apply {
                put("ma", report.totalCurrentDrainMa)
                put("w", report.totalCurrentDrainWatts)
                put("chg", report.isCharging)
                put("bTemp", report.batteryTempC)
                put("bTempValid", report.batteryTempAvailable)
                put("cTemp", report.cpuTempC)
                put("availRam", report.availableRamMb)
                put("adb", report.isDeepAdbScan)
                put("usage", report.hasUsageStatsAccess)
                put("highCnt", report.highDrainCount)
                put("at", report.scannedAtLabel)
                put("totalRam", report.totalRamMb)
                put("usedRam", report.usedRamMb)
                put("battPct", report.batteryPct)
                put("volt", report.voltageV)
                put("hrsLeft", report.estimatedHoursLeft)
                put("wlApps", report.activeWakeLockAppsCount)
                put("alarms", report.totalAlarmWakeups)
                put("bgCnt", report.totalBgAppsRunning)
                put("dur", report.scanDurationMs)
                val arr = org.json.JSONArray()
                for (e in report.entries.take(80)) {
                    arr.put(
                        org.json.JSONObject().apply {
                            put("pkg", e.packageName)
                            put("name", e.appName)
                            put("user", e.isUserApp)
                            put("prot", e.isProtected)
                            put("ram", e.ramMb)
                            put("cpu", e.cpuPercent.toDouble())
                            put("mah", e.estimatedPowerMah)
                            put("procs", e.processCount)
                            put("svc", e.hasActiveService)
                            put("bucket", e.standbyBucketLabel)
                            put("state", e.processStateLabel)
                            put("high", e.isHighDrain)
                            put("score", e.drainScore)
                            put("uid", e.uid)
                            put("rtCpu", e.realtimeCpuPercent.toDouble())
                            put("wl", e.wakeLockCount)
                            put("wlTag", e.wakeLockSummary)
                            put("alarm", e.alarmWakeups)
                            put("svcCnt", e.activeServiceCount)
                            put("jobCnt", e.activeJobCount)
                            put("netMb", e.networkMb)
                            put("netKbps", e.networkDeltaKbps)
                            put("rest", e.isBackgroundRestricted)
                            put("vip", e.isUserWhitelisted)
                            put("comms", e.isSystemCommsProtected)
                            put("oom", e.oomImportanceLabel)
                            val rArr = org.json.JSONArray()
                            e.culpritReasons.forEach { rArr.put(it) }
                            put("reasons", rArr)
                        }
                    )
                }
                put("entries", arr)
            }
            com.example.core.perf.DeviceMemoryStorageOptimizer.writeFastSnapshotJson(
                context,
                ROM_DRAIN_SNAPSHOT_FILE,
                root.toString()
            )
        } catch (_: Throwable) {}
    }

    val protectedCommsPackages = setOf(
        "moe.shizuku.privileged.api",
        // Ứng dụng Gọi điện, Danh bạ, Tin nhắn SMS/MMS mặc định của mọi hãng
        "com.android.dialer",
        "com.google.android.dialer",
        "com.samsung.android.dialer",
        "com.android.incallui",
        "com.samsung.android.incallui",
        "com.android.server.telecom",
        "com.android.phone",
        "com.android.contacts",
        "com.google.android.contacts",
        "com.hihonor.contacts",
        "com.huawei.contacts",
        "com.android.mms",
        "com.google.android.apps.messaging",
        "com.samsung.android.messaging",
        "com.hihonor.mms",
        "com.huawei.message",
        // Ứng dụng Nhắn tin OTT & Gọi điện VoIP/Video Call phổ biến tại Việt Nam
        "com.zing.zalo",
        "com.facebook.orca",
        "com.facebook.mlite",
        "com.whatsapp",
        "com.whatsapp.w4b",
        "org.telegram.messenger",
        "org.telegram.plus",
        "org.thunderdog.challegram",
        "com.viber.voip",
        "org.thoughtcrime.securesms",
        "jp.naver.line.android",
        "com.tencent.mm",
        "com.skype.raider",
        "com.discord",
        "com.kakao.talk",
        "com.imo.android.imoim",
        "com.google.android.apps.tachyon",
        "com.google.android.apps.meetings",
        "us.zoom.videomeetings",
        "com.microsoft.teams",
        "com.instagram.android",
        "com.instagram.barcelona",
        "com.google.android.gm",
        "com.microsoft.office.outlook",
        // Bàn phím & Dịch vụ Push cốt lõi (FCM) để nhận thông báo thanh trạng thái & màn hình khóa
        "com.vng.inputmethod.labankey",
        "com.google.android.inputmethod.latin",
        "com.google.android.gms",
        "com.google.android.gsf",
        "com.android.vending"
    )

    private val dynamicCommsPkgCache = ConcurrentHashMap<String, Boolean>()

    fun getUserWhitelistedPackages(context: Context): Set<String> {
        return try {
            val prefs = context.applicationContext.getSharedPreferences(PREF_DRAIN_INSPECTOR, Context.MODE_PRIVATE)
            prefs.getStringSet(KEY_USER_VIP_WHITELIST, emptySet()).orEmpty().toSet()
        } catch (_: Throwable) {
            emptySet()
        }
    }

    fun isUserWhitelisted(context: Context, pkg: String): Boolean {
        return pkg in getUserWhitelistedPackages(context)
    }

    fun toggleUserWhitelistPackage(context: Context, pkg: String): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(PREF_DRAIN_INSPECTOR, Context.MODE_PRIVATE)
        val current = prefs.getStringSet(KEY_USER_VIP_WHITELIST, emptySet()).orEmpty().toMutableSet()
        val nowWhitelisted = if (current.contains(pkg)) {
            current.remove(pkg)
            false
        } else {
            current.add(pkg)
            true
        }
        prefs.edit().putStringSet(KEY_USER_VIP_WHITELIST, current).apply()
        return nowWhitelisted
    }

    fun isCallingOrMessagingApp(context: Context, pkg: String): Boolean {
        if (pkg.isBlank()) return false
        if (pkg in protectedCommsPackages) return true
        val lower = pkg.lowercase(Locale.US)
        return lower.contains(".dialer") ||
            lower.contains(".incallui") ||
            lower.contains(".telecom") ||
            lower.contains(".mms") ||
            lower.contains(".messaging") ||
            lower.contains(".voip") ||
            lower.contains("zalo") ||
            lower.contains("telegram") ||
            lower.contains("whatsapp") ||
            lower.contains("viber") ||
            lower.contains("wechat") ||
            lower.contains("messenger")
    }

    private val knownHeavyDrainerPackages = setOf(
        "com.ss.android.ugc.trill",
        "com.zhiliaoapp.musically",
        "com.ss.android.ugc.aweme",
        "com.facebook.katana",
        "com.shopee.vn",
        "com.lazada.android",
        "com.tiki.app.tikiandroid",
        "com.google.android.youtube",
        "com.hihonor.search",
        "com.hihonor.appmarket",
        "com.hihonor.hiboard",
        "com.huawei.appmarket"
    )

    fun hasUsageStatsPermission(context: Context): Boolean {
        return try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps?.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName
                )
            } else {
                @Suppress("DEPRECATION")
                appOps?.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName
                )
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Danh sách "Người Nhà Hệ Thống" (Quản lý hệ thống, Điều phối Pin/Nhiệt gốc, Cài đặt, Bảo mật, Launcher & Core Android):
     * Luôn cộng sinh hòa bình 100%, không bao giờ ép dừng (Force-Stop), không tước quyền AppOps hay đưa vào Standby Rare/Restricted
     * để hệ thống coi MagicTune là thành phần đồng minh thân thiện, không bao giờ xảy ra giằng co hay xung đột.
     */
    val trustedSystemFamilyPackages = setOf(
        "android",
        "com.android.systemui",
        "com.android.settings",
        "com.hihonor.settings",
        "com.huawei.settings",
        "com.hihonor.systemmanager",
        "com.huawei.systemmanager",
        "com.hihonor.powergenius",
        "com.huawei.powergenie",
        "com.hihonor.iaware",
        "com.huawei.iaware",
        "com.hihonor.android.launcher",
        "com.huawei.android.launcher",
        "com.hihonor.deskclock",
        "com.android.deskclock",
        "com.hihonor.calendar",
        "com.android.calendar",
        "com.hihonor.id",
        "com.huawei.hwid",
        "com.hihonor.detectrepair",
        "com.huawei.detectrepair",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.android.packageinstaller",
        "com.google.android.packageinstaller",
        "com.android.shell",
        "com.android.bluetooth",
        "com.android.nfc",
        "com.android.networkstack",
        "com.android.networkstack.tethering",
        "com.android.se",
        "com.android.keychain",
        "com.android.webview",
        "com.google.android.webview",
        // Quản lý hệ thống các hãng OEM khác (Xiaomi, OPPO/OnePlus/Realme, Vivo/iQOO, Samsung)
        "com.miui.securitycenter",
        "com.miui.powerkeeper",
        "com.miui.home",
        "com.coloros.safecenter",
        "com.oplus.safecenter",
        "com.oplus.battery",
        "com.coloros.oppoguardelf",
        "com.vivo.abe",
        "com.iqoo.secure",
        "com.vivo.permissionmanager",
        "com.samsung.android.lool",
        "com.sec.android.app.launcher"
    )

    fun isSystemFamilyOrManagerApp(pkg: String): Boolean {
        val clean = pkg.trim()
        if (clean.isEmpty()) return false
        if (clean in trustedSystemFamilyPackages) return true
        return clean.startsWith("com.android.systemui") ||
            clean.startsWith("com.hihonor.systemmanager") ||
            clean.startsWith("com.huawei.systemmanager") ||
            clean.startsWith("com.hihonor.android.launcher") ||
            clean.startsWith("com.huawei.android.launcher") ||
            clean.startsWith("com.android.phone") ||
            clean.startsWith("com.android.server.") ||
            clean.startsWith("com.android.internal.") ||
            clean.startsWith("com.android.providers.")
    }

    fun isProtectedApp(context: Context, pkg: String, myPkg: String, activeForegroundPkg: String): Boolean {
        if (pkg == myPkg || pkg.startsWith("$myPkg:") || pkg == activeForegroundPkg) return true
        if (isSystemFamilyOrManagerApp(pkg)) return true
        if (isCallingOrMessagingApp(context, pkg)) return true
        if (isUserWhitelisted(context, pkg)) return true
        return try {
            NoAccessibilityScreenEngine.isSensitiveBankingPackage(pkg)
        } catch (_: Throwable) {
            false
        }
    }

    private fun parseUidInt(rawUid: String): Int? {
        val clean = rawUid.trim()
        clean.toIntOrNull()?.let { return it }
        val u0aMatch = REGEX_UID_U0A.find(clean)
        if (u0aMatch != null) {
            val offset = u0aMatch.groupValues[1].toIntOrNull() ?: return null
            return 10000 + offset
        }
        return null
    }

    private fun formatStandbyBucket(rawBucket: String?, hasService: Boolean, isDeepAdbScan: Boolean): String {
        val clean = rawBucket?.trim()?.uppercase(Locale.US).orEmpty()
        return when (clean) {
            "5", "EXEMPTED" -> "Miễn trừ"
            "10", "ACTIVE" -> "Đang hoạt động"
            "20", "WORKING_SET" -> "Chạy thường xuyên"
            "30", "FREQUENT" -> "Hay mở"
            "40", "RARE" -> "Ngủ sâu"
            "45", "RESTRICTED" -> "Đã khóa ngầm"
            else -> when {
                hasService -> "Chạy dịch vụ"
                isDeepAdbScan -> "Bình thường"
                else -> "Cơ bản"
            }
        }
    }

    private fun readTotalRamMb(context: Context): Int {
        cachedTotalRamMbValue.takeIf { it > 0 }?.let { return it }
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am?.getMemoryInfo(mi)
            val resolved = if (mi.totalMem > 0L) (mi.totalMem / (1024L * 1024L)).toInt()
            else {
                val memLine = File("/proc/meminfo").bufferedReader().useLines { lines ->
                    lines.firstOrNull { it.startsWith("MemTotal:") }
                }.orEmpty()
                val kb = REGEX_DIGITS.find(memLine)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: 0L
                (kb / 1024L).toInt()
            }
            if (resolved > 0) cachedTotalRamMbValue = resolved
            resolved
        } catch (_: Throwable) {
            0
        }
    }

    suspend fun scanBackgroundApps(
        context: Context,
        lightweightLiveTick: Boolean = false
    ): BackgroundDrainScanReport = withContext(Dispatchers.IO) {
        val acquired = kotlinx.coroutines.withTimeoutOrNull(1_500L) {
            scanMutex.lock()
            true
        } ?: false
        if (!acquired) {
            cachedLastReport?.let { return@withContext it }
            return@withContext BackgroundDrainScanReport(
                entries = emptyList(),
                totalCurrentDrainMa = 0,
                totalCurrentDrainWatts = 0.0,
                isCharging = false,
                batteryTempC = 0.0,
                cpuTempC = 0.0,
                availableRamMb = 0,
                isDeepAdbScan = false,
                hasUsageStatsAccess = false,
                highDrainCount = 0,
                scannedAtLabel = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            )
        }
        try {
        val startedMs = System.currentTimeMillis()
        val appCtx = context.applicationContext ?: context
        val pm = appCtx.packageManager
        val am = appCtx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val usm = appCtx.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
        val myPkg = appCtx.packageName
        val hasUsage = hasUsageStatsPermission(appCtx)

        // Dùng chế độ siêu nhẹ (0 quét sysfs nhiệt CPU, 0 đọc chu kỳ sạc, 0 đọc dòng xả khi không sạc)
        val batteryData = BatteryInfoReader.read(appCtx, lightweight = true)
        val availableRamMb = BatteryInfoReader.readAvailableRamMb(appCtx)
        val totalRamMb = readTotalRamMb(appCtx)
        val usedRamMb = (totalRamMb - availableRamMb).coerceAtLeast(0)
        val activeForegroundPkg = try {
            NoAccessibilityScreenEngine.getActiveForegroundPackage(appCtx).orEmpty()
        } catch (_: Throwable) {
            ""
        }

        // Dùng flag = 0 + cache 5 phút để tránh bão Binder / lag khi chuyển Tab 7
        val nowElapsedForPm = android.os.SystemClock.elapsedRealtime()
        val pmCacheTtlMs = 300_000L
        val installedApps = cachedInstalledApps?.takeIf {
            it.isNotEmpty() && (nowElapsedForPm - cachedInstalledAppsElapsedMs) < pmCacheTtlMs
        } ?: try {
            pm.getInstalledApplications(0).also { fresh ->
                if (fresh.isNotEmpty()) {
                    cachedInstalledApps = fresh
                    cachedInstalledAppsElapsedMs = nowElapsedForPm
                }
            }
        } catch (_: Throwable) {
            cachedInstalledApps ?: emptyList()
        }
        val pkgToInfo = HashMap<String, ApplicationInfo>(installedApps.size)
        val uidToPkg = HashMap<Int, String>(installedApps.size)
        val uidToPkgs = HashMap<Int, MutableList<String>>(installedApps.size)
        for (info in installedApps) {
            if (!info.enabled) continue
            pkgToInfo[info.packageName] = info
            if (info.uid >= 10000) {
                uidToPkg.putIfAbsent(info.uid, info.packageName)
                uidToPkgs.getOrPut(info.uid) { mutableListOf() }.add(info.packageName)
            }
        }

        data class MutableStats(
            var uid: Int = 0,
            var ramKb: Long = 0L,
            var cpuPercent: Float = 0f,
            var realtimeCpuPercent: Float = 0f,
            var powerMah: Double = 0.0,
            var procCount: Int = 0,
            var activeServiceCount: Int = 0,
            var wakeLockCount: Int = 0,
            var wakeLockTag: String = "",
            var alarmWakeups: Int = 0,
            var activeJobCount: Int = 0,
            var networkBytes: Long = 0L,
            var networkDeltaKbps: Double = 0.0,
            var isForeground: Boolean = false,
            var oomImportanceLabel: String = "",
            var recentBgMinutesAgo: Long = -1L
        )

        val statsByPkg = HashMap<String, MutableStats>()
        fun getStats(pkg: String): MutableStats {
            return statsByPkg.getOrPut(pkg) {
                MutableStats(uid = pkgToInfo[pkg]?.uid ?: 0)
            }
        }

        val bucketByPkg = HashMap<String, String>(cachedBucketByPkg)
        val shell = ShellEngine.getInstance(appCtx)
        val isDeepAdbScan = shell.state.value.isAdbReady

        if (isDeepAdbScan) {
            // Quét Siêu Nhanh 1 Lệnh duy nhất (bỏ hoàn toàn dumpsys activity services khóa ActivityManagerService trên Honor MagicOS)
            val psCmd = "ps -A -o UID,PID,RSS,NAME 2>/dev/null || ps -A 2>/dev/null"
            val res = kotlinx.coroutines.withTimeoutOrNull(2_000L) {
                shell.execute(psCmd, isBackground = true)
            }
            val lines = res?.output?.lines().orEmpty()
            for (rawLine in lines) {
                val line = rawLine.trim()
                if (line.isBlank() || line.startsWith("UID") || line.startsWith("USER")) continue
                val cols = line.split(REGEX_WHITESPACE)
                if (cols.size >= 4) {
                    val nameToken = cols.last()
                    val basePkg = nameToken.substringBefore(':').trim()
                    if (!basePkg.contains('.') && !cols[0].startsWith("u0_a", ignoreCase = true) && !cols[0].startsWith("10")) {
                        continue
                    }
                    val uid = parseUidInt(cols[0])
                    val resolvedPkg = when {
                        basePkg in pkgToInfo -> basePkg
                        !basePkg.contains('.') && uid != null && uid >= 10000 && uidToPkgs[uid]?.size == 1 -> uidToPkg[uid]
                        else -> null
                    } ?: continue
                    if (resolvedPkg !in pkgToInfo) continue
                    val st = getStats(resolvedPkg)
                    val rssKb = cols.getOrNull(cols.size - 2)?.toLongOrNull() ?: 0L
                    st.ramKb += rssKb
                    st.procCount += 1
                    if (st.uid == 0 && uid != null) st.uid = uid
                }
            }
        }

        // Bổ sung siêu nhẹ từ ActivityManager.runningAppProcesses (KHÔNG gọi getProcessMemoryInfo gây kẹt smaps_rollup & KHÔNG gọi getRunningServices đã deprecated)
        try {
            val runningProcs = am?.runningAppProcesses.orEmpty()
            for (proc in runningProcs) {
                val pkgs = proc.pkgList ?: continue
                val importanceText = when (proc.importance) {
                    ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND -> "Tiền cảnh (Foreground)"
                    ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND_SERVICE -> "Dịch vụ nổi (FGS)"
                    ActivityManager.RunningAppProcessInfo.IMPORTANCE_TOP_SLEEPING -> "Ngủ màn hình khóa"
                    ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE -> "Đang hiển thị"
                    ActivityManager.RunningAppProcessInfo.IMPORTANCE_PERCEPTIBLE -> "Dễ nhận biết (Nhạc/Overlay)"
                    ActivityManager.RunningAppProcessInfo.IMPORTANCE_SERVICE -> "Dịch vụ nền"
                    ActivityManager.RunningAppProcessInfo.IMPORTANCE_CACHED -> "Đang cache RAM"
                    else -> "Nền"
                }
                for (pkg in pkgs) {
                    if (pkg !in pkgToInfo) continue
                    val st = getStats(pkg)
                    if (!isDeepAdbScan) {
                        st.procCount += 1
                    }
                    if (st.oomImportanceLabel.isBlank()) st.oomImportanceLabel = importanceText
                    if (proc.importance <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                        st.isForeground = true
                    } else if (proc.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND_SERVICE ||
                        proc.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_SERVICE
                    ) {
                        if (st.activeServiceCount == 0) st.activeServiceCount = 1
                    }
                }
            }
        } catch (_: Throwable) {}

        if (usm != null && hasUsage) {
            try {
                val now = System.currentTimeMillis()
                val nowElapsed = android.os.SystemClock.elapsedRealtime()
                val usageCacheTtlMs = 120_000L
                val usageList = cachedUsageStats?.takeIf {
                    it.isNotEmpty() && (nowElapsed - cachedUsageStatsElapsedMs) < usageCacheTtlMs
                } ?: run {
                    usm.queryUsageStats(UsageStatsManager.INTERVAL_BEST, now - 3 * 3600_000L, now)?.also { fresh ->
                        if (fresh.isNotEmpty()) {
                            cachedUsageStats = fresh
                            cachedUsageStatsElapsedMs = nowElapsed
                        }
                    }
                }
                for (u in usageList.orEmpty()) {
                    val pkg = u.packageName ?: continue
                    val info = pkgToInfo[pkg] ?: continue
                    val isUser = (info.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                        (info.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                    if (!isUser && pkg !in knownHeavyDrainerPackages) continue
                    val minsAgo = ((now - u.lastTimeUsed).coerceAtLeast(0L)) / 60_000L
                    if (u.lastTimeUsed > now - 120 * 60_000L) {
                        val st = getStats(pkg)
                        if (st.recentBgMinutesAgo < 0L || minsAgo < st.recentBgMinutesAgo) {
                            st.recentBgMinutesAgo = minsAgo
                        }
                    }
                }
            } catch (_: Throwable) {}
        }

        // Đọc danh sách VIP 1 lần duy nhất trước vòng lặp (triệt tiêu hàng trăm lần đọc SharedPreferences)
        val userWhitelistSet = getUserWhitelistedPackages(appCtx)
        val resultEntries = ArrayList<BackgroundAppDrainEntry>(statsByPkg.size)
        var wakeLockAppsCounter = 0
        var totalAlarmWakeupsCounter = 0

        for ((pkg, st) in statsByPkg) {
            if (pkg == myPkg) continue
            val info = pkgToInfo[pkg] ?: continue
            if (!info.enabled) continue
            val isUserApp = (info.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                (info.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0

            val ramMb = (st.ramKb / 1024L).toInt().coerceAtLeast(0)
            val isKnownBloat = pkg in knownHeavyDrainerPackages
            val hasService = st.activeServiceCount > 0
            val effectiveCpu = maxOf(st.cpuPercent, st.realtimeCpuPercent)

            if (!isUserApp &&
                !isKnownBloat &&
                effectiveCpu < 0.8f &&
                st.powerMah < 10.0 &&
                ramMb < 95 &&
                !hasService &&
                st.wakeLockCount == 0 &&
                st.alarmWakeups < 5
            ) {
                continue
            }
            if (st.procCount == 0 &&
                !hasService &&
                st.powerMah < 4.0 &&
                st.wakeLockCount == 0 &&
                st.alarmWakeups < 5 &&
                st.recentBgMinutesAgo !in 0L..90L
            ) {
                continue
            }

            // Chưa gọi pm.getApplicationLabel() ở đây để tránh bão Binder; chỉ đọc tên thật sau khi cắt top 45
            val cachedLabel = appLabelCache[pkg] ?: pkg

            val rawBucket = bucketByPkg[pkg]
            val isRestrictedBucket = rawBucket?.uppercase(Locale.US) in setOf("40", "45", "RARE", "RESTRICTED")
            val bucketLabel = formatStandbyBucket(rawBucket, hasService, isDeepAdbScan)
            val isCommsApp = isCallingOrMessagingApp(appCtx, pkg)
            val isUserVip = pkg in userWhitelistSet
            val isProtected = pkg == myPkg ||
                pkg.startsWith("$myPkg:") ||
                pkg == activeForegroundPkg ||
                isSystemFamilyOrManagerApp(pkg) ||
                isCommsApp ||
                isUserVip ||
                try { NoAccessibilityScreenEngine.isSensitiveBankingPackage(pkg) } catch (_: Throwable) { false }

            if (st.wakeLockCount > 0) wakeLockAppsCounter++
            totalAlarmWakeupsCounter += st.alarmWakeups

            // Lập danh sách nguyên nhân gây xả pin thực tế (Root-cause tags)
            val culpritList = ArrayList<String>(5)
            if (st.wakeLockCount > 0) {
                culpritList.add("🔴 Giữ WakeLock (${st.wakeLockCount})")
            }
            if (st.realtimeCpuPercent >= 2.0f) {
                culpritList.add(String.format(Locale.US, "🔥 Live CPU %.1f%%", st.realtimeCpuPercent))
            } else if (st.cpuPercent >= 2.0f) {
                culpritList.add(String.format(Locale.US, "⚡ CPU %.1f%%", st.cpuPercent))
            }
            if (st.alarmWakeups >= 6) {
                culpritList.add("⏰ ${st.alarmWakeups} lần đánh thức máy")
            }
            if (st.activeServiceCount >= 2) {
                culpritList.add("⚙️ ${st.activeServiceCount} dịch vụ nền")
            } else if (st.activeServiceCount == 1) {
                culpritList.add("⚙️ Chạy dịch vụ nền")
            }
            if (st.activeJobCount > 0) {
                culpritList.add("🧰 ${st.activeJobCount} Job chạy ngầm")
            }
            if (st.networkDeltaKbps >= 8.0) {
                culpritList.add(String.format(Locale.US, "📡 Đẩy mạng %.0f KB/s", st.networkDeltaKbps))
            }
            if (ramMb >= 220) {
                culpritList.add("🧠 Ngốn ${ramMb}MB RAM")
            }

            val stateLabel = when {
                pkg == activeForegroundPkg -> "📱 Đang mở trực tiếp trên màn hình"
                isCommsApp -> "🛡️ VIP Gọi Điện / Nhắn Tin (Bảo vệ cuộc gọi & thông báo tức thì)"
                isUserVip -> "🛡️ Danh sách VIP do bạn bảo vệ (Bỏ qua khi tối ưu hàng loạt)"
                st.wakeLockCount > 0 -> "🔴 Đang khóa CPU không cho máy ngủ (${st.wakeLockTag.ifBlank { "WakeLock" }})"
                st.realtimeCpuPercent >= 2.5f -> String.format(Locale.US, "🔥 Đang đốt CPU trực tiếp %.1f%%", st.realtimeCpuPercent)
                hasService && st.cpuPercent >= 1.5f -> "⚙️ Dịch vụ nền đang chạy CPU cao"
                hasService -> "⚙️ Đang chạy ${st.activeServiceCount.coerceAtLeast(1)} dịch vụ nền"
                st.alarmWakeups >= 10 -> "⏰ Đánh thức thiết bị liên tục (${st.alarmWakeups} lần)"
                st.procCount > 0 && st.cpuPercent >= 1.0f -> "⚡ Tiến trình ngầm đang hoạt động"
                st.procCount > 0 -> "🧠 Đang giữ ${st.procCount} tiến trình trong RAM"
                st.recentBgMinutesAgo in 0L..10L -> "🕒 Vừa chạy nền (${st.recentBgMinutesAgo}p trước)"
                st.recentBgMinutesAgo > 10L -> "🕒 Hoạt động gần đây (${st.recentBgMinutesAgo}p trước)"
                else -> "Đang tiêu thụ pin nền"
            }

            val isHighDrain = !isProtected && (
                (effectiveCpu >= 1.5f) ||
                    (st.wakeLockCount > 0) ||
                    (st.alarmWakeups >= 12) ||
                    (st.powerMah >= 20.0) ||
                    (ramMb >= 180 && st.procCount > 0) ||
                    (hasService && isKnownBloat) ||
                    (st.networkDeltaKbps >= 25.0)
                )

            val score = (st.realtimeCpuPercent * 24.0) +
                (st.cpuPercent * 14.0) +
                (st.wakeLockCount * 42.0) +
                (st.alarmWakeups * 1.4) +
                (st.powerMah * 0.9) +
                (ramMb * 0.22) +
                (st.activeServiceCount * 22.0) +
                (st.activeJobCount * 14.0) +
                (if (st.networkDeltaKbps >= 5.0) 20.0 else 0.0) +
                (if (isKnownBloat) 18.0 else 0.0) +
                (if (st.recentBgMinutesAgo in 0L..15L) 12.0 else 0.0)

            val netMb = st.networkBytes / (1024.0 * 1024.0)

            resultEntries.add(
                BackgroundAppDrainEntry(
                    packageName = pkg,
                    appName = cachedLabel,
                    isUserApp = isUserApp,
                    isProtected = isProtected,
                    ramMb = ramMb,
                    cpuPercent = effectiveCpu,
                    estimatedPowerMah = st.powerMah,
                    processCount = st.procCount,
                    hasActiveService = hasService,
                    standbyBucketLabel = bucketLabel,
                    processStateLabel = stateLabel,
                    isHighDrain = isHighDrain,
                    drainScore = score,
                    uid = st.uid,
                    realtimeCpuPercent = st.realtimeCpuPercent,
                    wakeLockCount = st.wakeLockCount,
                    wakeLockSummary = st.wakeLockTag,
                    alarmWakeups = st.alarmWakeups,
                    activeServiceCount = st.activeServiceCount,
                    activeJobCount = st.activeJobCount,
                    networkMb = netMb,
                    networkDeltaKbps = st.networkDeltaKbps,
                    isBackgroundRestricted = isRestrictedBucket,
                    isUserWhitelisted = isUserVip,
                    isSystemCommsProtected = isCommsApp,
                    oomImportanceLabel = st.oomImportanceLabel,
                    culpritReasons = culpritList
                )
            )
        }

        // Cắt top 45 trước rồi mới gọi pm.getApplicationLabel() cho những app chưa có trong RAM cache (giảm >80% Binder IPC)
        val sorted = resultEntries
            .sortedWith(compareByDescending<BackgroundAppDrainEntry> { it.isHighDrain }.thenByDescending { it.drainScore })
            .take(45)
            .map { entry ->
                val resolvedLabel = appLabelCache[entry.packageName] ?: run {
                    val info = pkgToInfo[entry.packageName]
                    if (info != null) {
                        try {
                            pm.getApplicationLabel(info).toString().trim().ifBlank { entry.packageName }.also {
                                appLabelCache[entry.packageName] = it
                            }
                        } catch (_: Throwable) {
                            entry.packageName
                        }
                    } else {
                        entry.packageName
                    }
                }
                if (resolvedLabel != entry.appName) entry.copy(appName = resolvedLabel) else entry
            }

        val drainAnalytics = try {
            com.example.core.ai.AiPowerAutopilotManager.getDrainRateAnalytics(
                context = appCtx,
                lightweightRead = true,
                preloadedBattery = batteryData
            )
        } catch (_: Throwable) {
            null
        }
        val estScreenOnMins = com.example.core.ai.AiPowerAutopilotManager.estimateScreenOnMinutes(
            batteryPct = batteryData.batteryPct,
            screenOnDrainPctPerHour = drainAnalytics?.screenOnDrainPctPerHour,
            designCapacityMah = batteryData.designCapacityMah
        )
        val estHoursLeft = estScreenOnMins / 60.0

        val elapsedScan = (System.currentTimeMillis() - startedMs).coerceAtLeast(1L)
        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val report = BackgroundDrainScanReport(
            entries = sorted,
            totalCurrentDrainMa = batteryData.currentMa,
            totalCurrentDrainWatts = if (batteryData.isCharging) batteryData.currentWatts else batteryData.dischargingWatts,
            isCharging = batteryData.isCharging,
            batteryTempC = batteryData.tempCelsius,
            batteryTempAvailable = batteryData.isBatteryTemperatureAvailable,
            cpuTempC = batteryData.cpuThermalCelsius,
            availableRamMb = availableRamMb,
            isDeepAdbScan = isDeepAdbScan,
            hasUsageStatsAccess = hasUsage || isDeepAdbScan,
            highDrainCount = sorted.count { it.isHighDrain },
            scannedAtLabel = timeStr,
            totalRamMb = totalRamMb,
            usedRamMb = usedRamMb,
            batteryPct = batteryData.batteryPct,
            voltageV = batteryData.voltageV,
            estimatedHoursLeft = estHoursLeft,
            activeWakeLockAppsCount = wakeLockAppsCounter,
            totalAlarmWakeups = totalAlarmWakeupsCounter,
            totalBgAppsRunning = sorted.size,
            scanDurationMs = elapsedScan
        )
        cachedLastReport = report
        lastCompletedScanElapsedMs = android.os.SystemClock.elapsedRealtime()
        if (!lightweightLiveTick) {
            saveReportToRom(appCtx, report)
        }
        report
        } finally {
            scanMutex.unlock()
        }
    }

    /**
     * Lệnh Bảo Vệ VIP cho các ứng dụng Gọi Điện & Nhắn Tin (Phone, SMS, Zalo, Messenger, Telegram, WhatsApp, Viber...):
     * Đảm bảo luôn nhận cuộc gọi đến (Full-Screen Call Intent) và tin nhắn tức thì trên màn hình khóa & thanh trạng thái.
     */
    fun buildCallAndMessageVipProtectionCommand(packageName: String): String {
        return buildString {
            append("dumpsys deviceidle whitelist +$packageName >/dev/null 2>&1 || true; ")
            append("am set-standby-bucket --user 0 $packageName active >/dev/null 2>&1 || am set-standby-bucket $packageName active >/dev/null 2>&1 || true; ")
            append("am set-inactive --user 0 $packageName false >/dev/null 2>&1 || true; ")
            append("cmd tare set-vip 0 $packageName true >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName RUN_IN_BACKGROUND allow >/dev/null 2>&1 || cmd appops set $packageName RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || cmd appops set $packageName RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName WAKE_LOCK allow >/dev/null 2>&1 || cmd appops set $packageName WAKE_LOCK allow >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName START_FOREGROUND allow >/dev/null 2>&1 || cmd appops set $packageName START_FOREGROUND allow >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName USE_FULL_SCREEN_INTENT allow >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName POST_NOTIFICATIONS allow >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1 || true; ")
            append("pm grant $packageName android.permission.POST_NOTIFICATIONS >/dev/null 2>&1 || true")
        }
    }

    /**
     * Lệnh Triệt Tiêu Triệt Để App Chạy Ngầm Xả Pin Nhưng Giữ Nguyên 100% Thông Báo Thanh Trạng Thái & Màn Hình Khóa.
     */
    fun buildThoroughDeepSleepPreservingNotificationsCommand(packageName: String): String {
        return buildString {
            append("cmd appops set --user 0 $packageName RUN_IN_BACKGROUND ignore >/dev/null 2>&1 || cmd appops set $packageName RUN_IN_BACKGROUND ignore >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName RUN_ANY_IN_BACKGROUND ignore >/dev/null 2>&1 || cmd appops set $packageName RUN_ANY_IN_BACKGROUND ignore >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName WAKE_LOCK ignore >/dev/null 2>&1 || cmd appops set $packageName WAKE_LOCK ignore >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName AUTO_START ignore >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName BOOT_COMPLETED ignore >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName START_FOREGROUND ignore >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName SCHEDULE_EXACT_ALARM ignore >/dev/null 2>&1 || true; ")
            append("cmd jobscheduler cancel $packageName >/dev/null 2>&1 || true; ")
            append("dumpsys deviceidle whitelist -$packageName >/dev/null 2>&1 || true; ")
            append("cmd tare set-vip 0 $packageName false >/dev/null 2>&1 || true; ")
            append("am set-standby-bucket --user 0 $packageName rare >/dev/null 2>&1 || am set-standby-bucket $packageName rare >/dev/null 2>&1 || true; ")
            append("am set-inactive --user 0 $packageName true >/dev/null 2>&1 || am set-inactive $packageName true >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName POST_NOTIFICATIONS allow >/dev/null 2>&1 || cmd appops set $packageName POST_NOTIFICATIONS allow >/dev/null 2>&1 || true; ")
            append("pm grant $packageName android.permission.POST_NOTIFICATIONS >/dev/null 2>&1 || true; ")
            append("am force-stop --user 0 $packageName >/dev/null 2>&1 || am force-stop $packageName >/dev/null 2>&1 || pkill -9 -f $packageName >/dev/null 2>&1 || am kill --user 0 $packageName >/dev/null 2>&1 || true")
        }
    }

    /**
     * Khôi phục app từ trạng thái ngủ sâu/hạn chế nền trở lại hoạt động bình thường.
     */
    fun buildRestoreNormalBackgroundCommand(packageName: String): String {
        return buildString {
            append("cmd appops set --user 0 $packageName RUN_IN_BACKGROUND allow >/dev/null 2>&1 || cmd appops set $packageName RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || cmd appops set $packageName RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName WAKE_LOCK allow >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName START_FOREGROUND allow >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName AUTO_START allow >/dev/null 2>&1 || true; ")
            append("cmd appops set --user 0 $packageName BOOT_COMPLETED allow >/dev/null 2>&1 || true; ")
            append("am set-standby-bucket --user 0 $packageName active >/dev/null 2>&1 || am set-standby-bucket $packageName active >/dev/null 2>&1 || true; ")
            append("am set-inactive --user 0 $packageName false >/dev/null 2>&1 || am set-inactive $packageName false >/dev/null 2>&1 || true")
        }
    }

    suspend fun restoreBackgroundNormal(
        context: Context,
        packageName: String
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        if (packageName.isBlank()) return@withContext false to "Gói không hợp lệ"
        val shell = ShellEngine.getInstance(appCtx)
        if (shell.state.value.isAdbReady) {
            val res = shell.execute(buildRestoreNormalBackgroundCommand(packageName), isBackground = false)
            invalidateScanAndAppsCache()
            return@withContext res.isSuccess to "🔓 Đã khôi phục chạy nền bình thường cho $packageName"
        }
        invalidateScanAndAppsCache()
        false to "Cần kết nối ADB / Shizuku để mở lại hạn chế appops hệ thống."
    }

    suspend fun forceStopApp(
        context: Context,
        packageName: String
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        if (packageName.isBlank() || packageName == appCtx.packageName) {
            return@withContext false to "Không thể ép dừng MagicTune."
        }
        if (isSystemFamilyOrManagerApp(packageName)) {
            return@withContext false to "🤝 Ứng dụng Quản lý & Lõi hệ thống ($packageName) được bảo vệ cộng sinh để tránh xung đột với máy!"
        }
        if (isCallingOrMessagingApp(appCtx, packageName)) {
            return@withContext false to "🛡️ App gọi điện/nhắn tin được bảo vệ khỏi Force-Stop để không lỡ cuộc gọi!"
        }
        val am = appCtx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        try { am?.killBackgroundProcesses(packageName) } catch (_: Throwable) {}

        val shell = ShellEngine.getInstance(appCtx)
        if (shell.state.value.isAdbReady) {
            val res = shell.execute(
                "am force-stop --user 0 $packageName >/dev/null 2>&1 || am force-stop $packageName >/dev/null 2>&1 ; cmd appops set --user 0 $packageName RUN_IN_BACKGROUND ignore >/dev/null 2>&1 || true ; pkill -9 -f $packageName >/dev/null 2>&1 || true",
                isBackground = false
            )
            invalidateScanAndAppsCache()
            return@withContext res.isSuccess to "🛑 Đã Ép Dừng (Force-Stop) hoàn toàn tiến trình của $packageName (0% CPU / 0MB RAM)"
        }
        invalidateScanAndAppsCache()
        true to "🧹 Đã dọn tiến trình nền cho $packageName (Kết nối Shizuku/ADB để ép dừng triệt để!)"
    }

    suspend fun trimSystemCachesAndReclaimRam(
        context: Context,
        entries: List<BackgroundAppDrainEntry>
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        val ramBefore = BatteryInfoReader.readAvailableRamMb(appCtx)
        val am = appCtx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val pm = appCtx.packageManager
        var killedCount = 0
        val candidates = entries.asSequence()
            .filter { it.isHighDrain && !it.isProtected && it.packageName != appCtx.packageName }
            .filterNot { isSystemFamilyOrManagerApp(it.packageName) }
            .filterNot { isCallingOrMessagingApp(appCtx, it.packageName) }
            .filterNot { isUserWhitelisted(appCtx, it.packageName) }
            .distinctBy { it.packageName }
            .toList()
        for (item in candidates) {
            try {
                if (pm.getApplicationInfo(item.packageName, 0).enabled) {
                    am?.killBackgroundProcesses(item.packageName)
                    killedCount++
                }
            } catch (_: Throwable) {}
        }
        val shell = ShellEngine.getInstance(appCtx)
        if (shell.state.value.isAdbReady && candidates.isNotEmpty()) {
            val pkillBatch = candidates.joinToString(" ; ") { "pkill -9 -f ${it.packageName} >/dev/null 2>&1 || true" }
            shell.execute(pkillBatch, isBackground = false)
        }
        val ramAfter = BatteryInfoReader.readAvailableRamMb(appCtx)
        val gained = (ramAfter - ramBefore).coerceAtLeast(0)
        val extra = if (gained > 0) " • Giải phóng +${gained}MB RAM!" else " • RAM trống hiện tại: ${ramAfter}MB"
        invalidateScanAndAppsCache()
        true to "🧹 Đã yêu cầu dừng $killedCount app xả cao; giữ app liên lạc và dịch vụ hệ thống$extra"
    }

    suspend fun stopBackgroundApp(
        context: Context,
        packageName: String,
        deepSleep: Boolean = true
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        if (packageName.isBlank() || packageName == appCtx.packageName) {
            return@withContext false to "Không thể đóng ứng dụng chính MagicTune."
        }
        if (isSystemFamilyOrManagerApp(packageName)) {
            return@withContext true to "🤝 Giữ nguyên hoạt động tự nhiên cho Quản lý hệ thống ($packageName) để máy vận hành ổn định, không xung đột!"
        }
        if (isCallingOrMessagingApp(appCtx, packageName)) {
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) {
                shell.execute(buildCallAndMessageVipProtectionCommand(packageName), isBackground = false)
            }
            return@withContext true to "🛡️ Đã bảo vệ & bật ưu tiên VIP nhận cuộc gọi/tin nhắn tức thì cho $packageName!"
        }
        val am = appCtx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        try {
            am?.killBackgroundProcesses(packageName)
        } catch (_: Throwable) {}

        val shell = ShellEngine.getInstance(appCtx)
        if (shell.state.value.isAdbReady) {
            val cmd = buildString {
                append(buildThoroughDeepSleepPreservingNotificationsCommand(packageName))
                append("; settings put secure lock_screen_show_notifications 1 >/dev/null 2>&1 || true")
                append("; settings put secure lock_screen_allow_private_notifications 1 >/dev/null 2>&1 || true")
                append("; settings put global heads_up_notifications_enabled 1 >/dev/null 2>&1 || true")
                append("; dumpsys deviceidle whitelist +com.google.android.gms >/dev/null 2>&1 || true")
            }
            val res = shell.execute(cmd, isBackground = false)
            invalidateScanAndAppsCache()
            return@withContext res.isSuccess to if (deepSleep) {
                "❄️ Đã triệt tiêu chạy ngầm vĩnh viễn $packageName (Giữ nguyên 100% thông báo thanh trạng thái & màn hình khóa)"
            } else {
                "🛑 Đã chặn chạy ngầm & giải phóng RAM cho $packageName (Giữ nguyên thông báo)"
            }
        }
        invalidateScanAndAppsCache()
        true to "🧹 Đã giải phóng tiến trình nền cho $packageName (Vẫn giữ nguyên 100% thông báo)"
    }

    suspend fun stopAllHighDrainApps(
        context: Context,
        entries: List<BackgroundAppDrainEntry>
    ): Pair<Int, String> = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        val targets = entries.filter {
            it.isHighDrain &&
                !it.isProtected &&
                it.packageName != appCtx.packageName &&
                !isSystemFamilyOrManagerApp(it.packageName) &&
                !isCallingOrMessagingApp(appCtx, it.packageName) &&
                !isUserWhitelisted(appCtx, it.packageName)
        }
        val commsEntries = entries.filter { isCallingOrMessagingApp(appCtx, it.packageName) || isUserWhitelisted(appCtx, it.packageName) }

        val am = appCtx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        for (item in targets) {
            try {
                am?.killBackgroundProcesses(item.packageName)
            } catch (_: Throwable) {}
        }

        val shell = ShellEngine.getInstance(appCtx)
        if (shell.state.value.isAdbReady) {
            val globalNotifGuardCmd = buildString {
                append("settings put secure lock_screen_show_notifications 1 >/dev/null 2>&1 || true; ")
                append("settings put secure lock_screen_allow_private_notifications 1 >/dev/null 2>&1 || true; ")
                append("settings put global heads_up_notifications_enabled 1 >/dev/null 2>&1 || true; ")
                append("dumpsys deviceidle whitelist +com.google.android.gms >/dev/null 2>&1 || true; ")
                append("am set-standby-bucket --user 0 com.google.android.gms active >/dev/null 2>&1 || true")
            }
            shell.execute(globalNotifGuardCmd, isBackground = false)

            val pm = appCtx.packageManager
            val installedComms = (commsEntries.map { it.packageName } + protectedCommsPackages + getUserWhitelistedPackages(appCtx))
                .distinct()
                .filter { pkg ->
                    pkg != "com.android.vending" && try {
                        pm.getPackageInfo(pkg, 0)
                        true
                    } catch (_: Throwable) {
                        false
                    }
                }
            installedComms.chunked(8).forEach { chunk ->
                val vipBatch = chunk.joinToString(" ; ") { pkg ->
                    buildCallAndMessageVipProtectionCommand(pkg)
                }
                shell.execute(vipBatch, isBackground = false)
            }

            if (targets.isEmpty()) {
                return@withContext 0 to "🛡️ Đã bảo vệ VIP ${installedComms.size} app Liên lạc & VIP! Không có app xả pin nào cần đóng."
            }

            targets.chunked(8).forEach { chunk ->
                val batch = chunk.joinToString(" ; ") { item ->
                    buildThoroughDeepSleepPreservingNotificationsCommand(item.packageName)
                }
                shell.execute(batch, isBackground = false)
            }
            invalidateScanAndAppsCache()
            return@withContext targets.size to "❄️ Đã triệt tiêu ${targets.size} app chạy ngầm xả pin • Giữ 100% thông báo & Bảo vệ VIP ${installedComms.size} app!"
        }
        if (targets.isEmpty()) {
            return@withContext 0 to "🛡️ Đã bảo vệ toàn bộ app Gọi điện, Nhắn tin & VIP, không có app ngầm xả pin!"
        }
        invalidateScanAndAppsCache()
        targets.size to "🧹 Đã dọn nền ${targets.size} app xả pin & bảo vệ app VIP (Kết nối ADB/Shizuku để khóa tự chạy ngầm vĩnh viễn!)"
    }
}
