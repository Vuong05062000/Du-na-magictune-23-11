package com.example.core.widget

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * BỘ NÃO TRÍ NHỚ DÀI HẠN & QUẢN LÝ PHIÊN TRÒ CHUYỆN CỦA MAGIC LIVE (MagicLiveBrainMemory):
 *
 * Giải quyết triệt để 2 yêu cầu cốt lõi:
 * 1. LƯU TRỮ BỀN VỮNG TRÊN MÁY (Persistent Brain Storage):
 *    - Toàn bộ lịch sử trò chuyện giữa chủ máy và MagicLive (bao gồm câu hỏi giọng nói, tin nhắn văn bản,
 *      nội dung vùng màn hình đã khoanh và câu trả lời hỗ trợ của MagicLive) đều được lưu trực tiếp vào bộ nhớ
 *      thiết bị (`filesDir/magic_live_brain_memory_v1.json`).
 *    - Kể cả khi đóng ứng dụng hay khởi động lại máy, MagicLive vẫn có trí nhớ dài hạn hiểu rõ mình đã từng
 *      hỗ trợ chủ máy những việc gì, giải thích hình ảnh/màn hình nào.
 *
 * 2. TÁCH BIỆT TUYỆT ĐỐI CUỘC TRÒ CHUYỆN MỚI & CUỘC TRÒ CHUYỆN CŨ (Strict Session Isolation):
 *    - `activeSessionMessages`: Chỉ chứa các lượt trao đổi của RIÊNG cuộc trò chuyện hiện tại (`currentSessionId`).
 *      Mỗi khi bắt đầu cuộc trò chuyện mới (mở lại MagicLive sau khi đóng, bấm "Phiên mới", hoặc khoanh vùng màn hình mới),
 *      `activeSessionMessages` được làm mới hoàn toàn -> Đảm bảo 100% MagicLive KHÔNG BAO GIỜ nhầm lẫn lệnh cũ
 *      hay chủ đề của cuộc trò chuyện cũ sang cuộc trò chuyện mới!
 *    - `archivedMemories`: Lưu trữ các cuộc trò chuyện cũ dưới dạng "Ký ức hỗ trợ trong Bộ Não" để MagicLive
 *      chỉ tham khảo khi chủ máy hỏi lại chuyện cũ hoặc cần hiểu bối cảnh đã từng hỗ trợ.
 */
object MagicLiveBrainMemory {

    private const val BRAIN_FILE_NAME = "magic_live_brain_memory_v1.json"
    private const val MAX_ARCHIVED_ENTRIES = 300
    private const val MAX_ACTIVE_SESSION_TURNS = 30

    data class MemoryTurnEntry(
        val sessionId: String,
        val timestampMs: Long,
        val userQuery: String,
        val assistantReply: String,
        val screenOrCircleContext: String = "",
        val appName: String = ""
    )

    private val lock = Any()
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    private var isLoadedFromDisk = false

    @Volatile
    private var currentSessionId: String = UUID.randomUUID().toString().take(8)

    @Volatile
    private var currentSessionStartMs: Long = System.currentTimeMillis()

    // Lịch sử tin nhắn CHỈ CỦA CUỘC TRÒ CHUYỆN HIỆN TẠI (Pair<"user"|"assistant", String>)
    private val activeSessionMessages = mutableListOf<Pair<String, String>>()

    // Ngữ cảnh vùng màn hình vừa khoanh trong phiên hiện tại (nếu có)
    @Volatile
    var activeCircledScreenContext: String = ""
        private set

    // Toàn bộ ký ức dài hạn đã lưu trên máy
    private val archivedMemories = mutableListOf<MemoryTurnEntry>()

    fun ensureLoaded(context: Context) {
        if (isLoadedFromDisk) return
        synchronized(lock) {
            if (isLoadedFromDisk) return
            try {
                val appCtx = context.applicationContext ?: context
                val file = File(appCtx.filesDir, BRAIN_FILE_NAME)
                if (file.exists() && file.length() > 2L) {
                    val raw = file.readText(Charsets.UTF_8)
                    val root = JSONObject(raw)
                    val arr = root.optJSONArray("memories") ?: JSONArray()
                    archivedMemories.clear()
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        val u = obj.optString("userQuery", "").trim()
                        val a = obj.optString("assistantReply", "").trim()
                        if (u.isNotEmpty() && a.isNotEmpty()) {
                            archivedMemories.add(
                                MemoryTurnEntry(
                                    sessionId = obj.optString("sessionId", "old"),
                                    timestampMs = obj.optLong("timestampMs", 0L),
                                    userQuery = u,
                                    assistantReply = a,
                                    screenOrCircleContext = obj.optString("screenOrCircleContext", ""),
                                    appName = obj.optString("appName", "")
                                )
                            )
                        }
                    }
                }
            } catch (_: Throwable) {
            } finally {
                isLoadedFromDisk = true
            }
        }
    }

    /**
     * Bắt đầu một cuộc trò chuyện mới hoàn toàn độc lập:
     * - Giữ nguyên toàn bộ ký ức cũ trong `archivedMemories` (đã lưu trên máy).
     * - Xóa sạch `activeSessionMessages` của phiên cũ để MagicLive KHÔNG BAO GIỜ nhầm lẫn
     *   lệnh cũ hoặc trả lời lạc sang chủ đề của cuộc trò chuyện trước!
     */
    fun startNewConversationSession(reason: String = "new_session", initialCircleContext: String = "") {
        synchronized(lock) {
            currentSessionId = UUID.randomUUID().toString().take(8)
            currentSessionStartMs = System.currentTimeMillis()
            activeSessionMessages.clear()
            activeCircledScreenContext = initialCircleContext.trim()
        }
    }

    fun updateActiveCircledScreenContext(contextSummary: String) {
        synchronized(lock) {
            activeCircledScreenContext = contextSummary.trim()
        }
    }

    fun getActiveSessionMessages(maxMessages: Int = 24): List<Pair<String, String>> {
        synchronized(lock) {
            return activeSessionMessages.takeLast(maxMessages).toList()
        }
    }

    fun isActiveSessionEmpty(): Boolean {
        synchronized(lock) {
            return activeSessionMessages.isEmpty()
        }
    }

    fun getTotalSavedMemoryCount(context: Context): Int {
        ensureLoaded(context)
        synchronized(lock) {
            return archivedMemories.size
        }
    }

    /**
     * Ghi nhận 1 lượt trao đổi vào cả Phiên Hiện Tại (`activeSessionMessages`)
     * VÀ lưu vĩnh viễn vào Bộ Não Thiết Bị (`archivedMemories` -> JSON trên đĩa).
     */
    fun recordConversationTurn(
        context: Context,
        userQuery: String,
        assistantReply: String,
        screenOrCircleContext: String = "",
        appName: String = ""
    ) {
        val cleanUser = userQuery.trim()
        val cleanReply = assistantReply.trim()
        if (cleanUser.isEmpty() || cleanReply.isEmpty()) return

        ensureLoaded(context)
        val appCtx = context.applicationContext ?: context

        synchronized(lock) {
            activeSessionMessages.add("user" to cleanUser)
            activeSessionMessages.add("assistant" to cleanReply)
            while (activeSessionMessages.size > MAX_ACTIVE_SESSION_TURNS * 2) {
                activeSessionMessages.removeAt(0)
            }

            val effectiveScreenCtx = screenOrCircleContext.ifBlank { activeCircledScreenContext }.take(500)
            val entry = MemoryTurnEntry(
                sessionId = currentSessionId,
                timestampMs = System.currentTimeMillis(),
                userQuery = cleanUser.take(400),
                assistantReply = cleanReply.take(700),
                screenOrCircleContext = effectiveScreenCtx,
                appName = appName.take(80)
            )
            archivedMemories.add(entry)
            while (archivedMemories.size > MAX_ARCHIVED_ENTRIES) {
                archivedMemories.removeAt(0)
            }
        }

        saveToDiskAsync(appCtx)
    }

    private fun saveToDiskAsync(appCtx: Context) {
        ioScope.launch {
            val snapshot = synchronized(lock) { archivedMemories.toList() }
            try {
                val arr = JSONArray()
                for (item in snapshot) {
                    arr.put(JSONObject().apply {
                        put("sessionId", item.sessionId)
                        put("timestampMs", item.timestampMs)
                        put("userQuery", item.userQuery)
                        put("assistantReply", item.assistantReply)
                        if (item.screenOrCircleContext.isNotBlank()) {
                            put("screenOrCircleContext", item.screenOrCircleContext)
                        }
                        if (item.appName.isNotBlank()) {
                            put("appName", item.appName)
                        }
                    })
                }
                val root = JSONObject().apply {
                    put("version", 1)
                    put("updatedAtMs", System.currentTimeMillis())
                    put("memories", arr)
                }
                val file = File(appCtx.filesDir, BRAIN_FILE_NAME)
                val tmpFile = File(appCtx.filesDir, "$BRAIN_FILE_NAME.tmp")
                tmpFile.writeText(root.toString(), Charsets.UTF_8)
                if (!tmpFile.renameTo(file)) {
                    file.writeText(root.toString(), Charsets.UTF_8)
                    tmpFile.delete()
                }
            } catch (_: Throwable) {}
        }
    }

    /**
     * Xây dựng khối kiến thức "Bộ Não Trí Nhớ Dài Hạn" để đưa vào System Prompt:
     * - Giúp MagicLive nhớ rõ trước đây đã từng hỗ trợ chủ máy những việc gì, đã giải thích hình ảnh/màn hình nào.
     * - Đồng thời đóng khung quy tắc NGHIÊM NGẶT để trong cuộc trò chuyện mới, MagicLive KHÔNG BAO GIỜ
     *   lấy lệnh cũ hoặc câu hỏi cũ ra trả lời nhầm cho câu hỏi mới!
     */
    fun buildLongTermBrainSystemInstruction(context: Context, currentUserQuery: String): String {
        ensureLoaded(context)
        val pastEntries: List<MemoryTurnEntry>
        val activeCircleCtx: String
        val activeTurnCount: Int
        synchronized(lock) {
            // Chỉ lấy các ký ức thuộc các phiên TRƯỚC ĐÂY (khác currentSessionId)
            pastEntries = archivedMemories.filter { it.sessionId != currentSessionId }
            activeCircleCtx = activeCircledScreenContext
            activeTurnCount = activeSessionMessages.size / 2
        }

        val sb = StringBuilder()
        sb.append("\n[QUY TẮC TÁCH BIỆT PHIÊN TRÒ CHUYỆN MỚI & BỘ NÃO TRÍ NHỚ MAGIC LIVE]:\n")
        sb.append("- Mã phiên trò chuyện hiện tại: #$currentSessionId (Số lượt đã trao đổi trong phiên này: $activeTurnCount).\n")
        sb.append("- NGUYÊN TẮC BẮT BUỘC 100%: Trong một cuộc trò chuyện mới, bạn CHỈ ĐƯỢC phép trả lời và thực thi lệnh dựa trên YÊU CẦU HIỆN TẠI của chủ máy trong phiên #$currentSessionId. TUYỆT ĐỐI KHÔNG lấy lệnh cũ, chủ đề cũ hay câu hỏi từ các cuộc trò chuyện trước đây để trả lời nhầm hoặc thực thi sai lệnh trên cuộc trò chuyện mới!\n")

        if (activeCircleCtx.isNotBlank()) {
            sb.append("- [DỮ LIỆU VÙNG MÀN HÌNH CHỦ MÁY VỪA KHOANH TRONG PHIÊN NÀY]:\n$activeCircleCtx\n")
            sb.append("  -> Khi chủ máy hỏi về hình ảnh/nội dung vừa khoanh ('cái này là gì', 'giải thích cho mình', 'giá bao nhiêu', 'dùng thế nào'...), hãy kết hợp chính xác hình ảnh đã khoanh và dữ liệu đọc màn hình ở trên để giải thích kiến thức chi tiết, chuẩn xác nhất.\n")
        }

        if (pastEntries.isNotEmpty()) {
            val df = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
            // Tìm các ký ức liên quan theo từ khóa nếu chủ máy hỏi lại chuyện cũ, cộng với 6 hỗ trợ gần nhất
            val queryWords = currentUserQuery.lowercase(Locale.getDefault())
                .split(Regex("\\s+"))
                .filter { it.length >= 3 }

            val relevantOld = if (queryWords.isNotEmpty()) {
                pastEntries.filter { entry ->
                    val hay = "${entry.userQuery} ${entry.assistantReply} ${entry.screenOrCircleContext}".lowercase(Locale.getDefault())
                    queryWords.count { hay.contains(it) } >= 2
                }.takeLast(4)
            } else emptyList()

            val recentOld = pastEntries.takeLast(6)
            val combinedOld = (relevantOld + recentOld).distinctBy { "${it.timestampMs}_${it.userQuery}" }.takeLast(8)

            sb.append("- [BỘ NÃO TRÍ NHỚ DÀI HẠN LƯU TRÊN MÁY (Tổng cộng ${pastEntries.size} lần đã hỗ trợ chủ máy trước đây - CHỈ THAM KHẢO KHI CHỦ MÁY HỎI LẠI CHUYỆN CŨ, TUYỆT ĐỐI KHÔNG NHẦM LẪN VÀO LỆNH MỚI)]:\n")
            for (item in combinedOld) {
                val timeStr = try { df.format(Date(item.timestampMs)) } catch (_: Throwable) { "" }
                val appTag = if (item.appName.isNotBlank()) " [${item.appName}]" else ""
                val circleTag = if (item.screenOrCircleContext.isNotBlank()) {
                    " (Khoanh màn hình: ${item.screenOrCircleContext.replace("\n", " ").take(90)})"
                } else ""
                sb.append("  • [$timeStr$appTag]$circleTag Chủ máy hỏi: \"${item.userQuery.take(100)}\" -> MagicLive đã hỗ trợ: \"${item.assistantReply.take(140)}\"\n")
            }
        }
        return sb.toString()
    }
}
