package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

@Composable
fun UpgradeProRequiredDialog(
    reason: String,
    deviceId: String,
    onDismiss: () -> Unit,
    onNavigateToAccount: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scrollState = rememberScrollState()
    androidx.compose.runtime.LaunchedEffect(Unit) {
        try {
            com.example.core.license.LicenseManager.logCustomerPaymentIntent(context, "OPENED_PRO_UPGRADE_DIALOG", reason)
        } catch (_: Exception) {}
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 640.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF0F172A))
                .border(
                    width = 2.dp,
                    brush = Brush.horizontalGradient(
                        listOf(Color(0xFFF59E0B), Color(0xFFEF4444), Color(0xFF8B5CF6))
                    ),
                    shape = RoundedCornerShape(24.dp)
                )
                .verticalScrollWithScrollbar(scrollState = scrollState, thumbColor = Color(0xFFF59E0B))
                .padding(start = 20.dp, top = 20.dp, end = 24.dp, bottom = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Row with Title & Close X Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFFF59E0B), Color(0xFFEF4444))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Text(
                        text = "👑 HẾT LƯỢT MIỄN PHÍ",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                // Close X Button
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1E293B))
                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                        .clickable { onDismiss() }
                        .testTag("close_upgrade_pro_dialog_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Đóng hộp thoại nâng cấp",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF1E293B))
                    .border(1.dp, Color(0xFFF59E0B).copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Text(
                    text = reason.ifBlank { "Bạn đã dùng hết lượt dùng thử miễn phí. Vui lòng nâng cấp bản PRO để tiếp tục sử dụng không giới hạn!" },
                    color = Color(0xFFE2E8F0),
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Medium,
                    lineHeight = 18.sp,
                    textAlign = TextAlign.Center
                )
            }

            val proPrice = com.example.core.license.LicenseManager.getProPrice(context)
            val proOriginalPrice = com.example.core.license.LicenseManager.getProOriginalPrice(context)
            val accountProPrice = com.example.core.license.LicenseManager.getAccountProPrice(context)
            val accountProOriginalPrice = com.example.core.license.LicenseManager.getAccountProOriginalPrice(context)
            val isProSaleActive = com.example.core.license.LicenseManager.isProSaleActive(context)
            val upgradePrice = com.example.core.license.LicenseManager.getUpgradeToAccountProPrice(context)
            val totalTrialLimit = com.example.core.license.LicenseManager.getFreeTrialLimit(context)
            val isUserLoggedIn = com.example.core.auth.FirebaseAuthManager.getCurrentUser() != null

            ProBenefitsComparisonSection(
                proPrice = proPrice,
                accountProPrice = accountProPrice,
                totalTrialLimit = totalTrialLimit,
                compact = true,
                proOriginalPrice = proOriginalPrice,
                accountProOriginalPrice = accountProOriginalPrice,
                isProSaleActive = isProSaleActive
            )

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = if (isProSaleActive) "🔥 CÁC GÓI ĐANG TRONG ĐỢT GIẢM GIÁ ĐẶC BIỆT:" else "📌 Các gói nâng cấp Bản PRO vĩnh viễn:",
                    color = if (isProSaleActive) Color(0xFFFB7185) else Color(0xFF38BDF8),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                val deviceProNotice = if (isProSaleActive && proOriginalPrice.isNotBlank() && proOriginalPrice != proPrice) {
                    "1. 📱 Pro Thiết Bị: $proPrice (🔥 Giá gốc $proOriginalPrice) - Gắn vĩnh viễn theo ID máy ($deviceId)."
                } else {
                    "1. 📱 Pro Thiết Bị ($proPrice): Gắn vĩnh viễn theo ID máy hiện tại ($deviceId). Gỡ app cài lại tự khôi phục."
                }
                Text(
                    text = deviceProNotice,
                    color = Color(0xFF94A3B8),
                    fontSize = 11.sp
                )
                if (isUserLoggedIn) {
                    val accountProNotice = if (isProSaleActive && accountProOriginalPrice.isNotBlank() && accountProOriginalPrice != accountProPrice) {
                        "2. 👑 Pro Tài Khoản: $accountProPrice (🔥 Giá gốc $accountProOriginalPrice) - Đăng nhập đổi máy tự do (1 máy hoạt động/lần)."
                    } else {
                        "2. 👑 Pro Tài Khoản ($accountProPrice): Đăng nhập đổi sang máy khác vẫn dùng được Pro (mỗi tài khoản đăng nhập 1 máy/lần; đăng nhập máy mới tự xuất máy cũ)."
                    }
                    Text(
                        text = accountProNotice,
                        color = Color(0xFFFBBF24),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "3. 🚀 Nâng cấp từ Pro Máy lên Pro Tài Khoản: Trả thêm chênh lệch (+$upgradePrice).",
                        color = Color(0xFF34D399),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF1E293B))
                    .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "🛡️ BẢO LƯU PRO 100%: Mỗi thiết bị được gắn cố định một Key duy nhất từ Admin/AI. Hãy lưu giữ Key hoặc đăng nhập tài khoản — về sau nếu lỡ lỗi không thấy Pro, chỉ cần đăng nhập là 100% tự động khôi phục!",
                    color = Color(0xFFE2E8F0),
                    fontSize = 10.5.sp,
                    lineHeight = 14.5.sp
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .heightIn(min = 40.dp, max = 44.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Để Sau", color = Color(0xFF94A3B8), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        onDismiss()
                        onNavigateToAccount()
                    },
                    modifier = Modifier
                        .weight(1.2f)
                        .fillMaxHeight()
                        .heightIn(min = 40.dp, max = 44.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("💳 Nâng Cấp Pro Ngay", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
