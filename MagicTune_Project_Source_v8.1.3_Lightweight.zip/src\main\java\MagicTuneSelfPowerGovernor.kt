package com.example.core.perf

import android.app.ActivityManager
import android.content.ComponentCallbacks2
import android.content.Context
import android.os.Debug
import android.os.Process
import com.example.core.service.AutoWakeupPatrolManager
import com.example.core.service.MagicTuneCtsAccessibilityService
import com.example.core.service.MagicTuneKeepAliveJobService
import com.example.core.service.MagicTuneKeepAliveService
import com.example.core.service.NoAccessibilityScreenEngine
import com.example.core.service.SystemFloatingHudOverlay
import com.example.core.shell.ShellEngine
import com.example.core.widget.CircleToSearchOverlayActivity
import com.example.core.widget.CircleToSearchWindowOverlay
import com.example.core.widget.GoogleLiveTranslateOverlay
import com.example.core.widget.MagicLiveFloatingOverlay

/**
 * Trung tâm Tự Kiểm Soát Điện Năng & Quản Lý Mô-đun Chạy Ngầm Nội Bộ của chính MagicTune.
 * Đảm bảo một ứng dụng đa tính năng như MagicTune không tự biến thành tác nhân gây hao pin hay chiếm RAM.
 */
object MagicTuneSelfPowerGovernor {

    private const val PREFS_NAME = "magictune_self_power_governor_prefs"
    private const val KEY_SELF_POWER_MODE = "self_power_mode"
    private const val KEY_STRICT_STOP_ON_EXIT = "strict_stop_service_when_idle"
    private const val KEY_ADAPTIVE_REFRESH_RESTORE_PENDING = "adaptive_refresh_restore_pending_v812"

    @Volatile
    private var activeTouchLeaseUntilElapsedMs: Long = 0L

    @Volatile
    private var isMainActivityInForeground: Boolean = false

    @Volatile
    private var lastTouchUpdateElapsedMs: Long = 0L

    /**
     * Đánh dấu trạng thái MainActivity đang hiển thị trên tiền cảnh.
     * Android 15/16/17 (ADPF) và Honor MagicOS 11 (iAware / top-app cgroup) tự động điều phối xung nhịp
     * luồng UI + RenderThread mượt mà nhất khi app KHÔNG tự ép Process.setThreadPriority thủ công.
     */
    fun setMainActivityForeground(inForeground: Boolean) {
        isMainActivityInForeground = inForeground
        if (inForeground) {
            val now = android.os.SystemClock.elapsedRealtime()
            lastTouchUpdateElapsedMs = now
            activeTouchLeaseUntilElapsedMs = now + 2_200L
        } else {
            activeTouchLeaseUntilElapsedMs = 0L
        }
    }

    /**
     * Ghi nhận người dùng đang chạm hoặc cuộn trang trong MainActivity (0 cấp phát bộ nhớ, 0 syscall).
     * Giãn nhịp ghi 600ms để không tốn chi phí ở tốc độ lấy mẫu cảm ứng 240Hz; trong thời gian cuộn
     * mọi tác vụ nền không thiết yếu sẽ tự nhường 100% CPU & Binder IPC cho luồng vẽ 120Hz/144Hz.
     */
    fun notifyUserTouchOrScrollInApp(leaseMs: Long = 2_400L, force: Boolean = false) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (!force && now - lastTouchUpdateElapsedMs < 600L) return
        lastTouchUpdateElapsedMs = now
        activeTouchLeaseUntilElapsedMs = now + leaseMs
    }

    fun isUserActivelyInteractingInApp(): Boolean {
        return isMainActivityInForeground &&
            android.os.SystemClock.elapsedRealtime() < activeTouchLeaseUntilElapsedMs
    }

    fun isMainActivityCurrentlyForeground(): Boolean = isMainActivityInForeground

    enum class SelfPowerMode(
        val id: String,
        val title: String,
        val badge: String,
        val description: String
    ) {
        ECO_ZERO_DRAIN(
            id = "ECO_ZERO_DRAIN",
            title = "🍃 Ngủ Sâu Khi Nhàn Rỗi",
            badge = "Tắt tác vụ nền không thiết yếu",
            description = "Tắt dịch vụ, thông báo ghim và tuần tra nền không cần thiết khi app nhàn rỗi. Overlay và tính năng đang dùng vẫn tiêu thụ pin; mức thực tế phụ thuộc thiết bị."
        ),
        SMART_BALANCED(
            id = "SMART_BALANCED",
            title = "⚖️ Cân Bằng Thông Minh",
            badge = "Giảm tác vụ nền",
            description = "Tắt tuần tra và làm mát nền tự động; KeepAlive chỉ chạy khi một tính năng được bật. Dòng xả thực tế không thể đo riêng cho app ở đây."
        ),
        MAX_24_7(
            id = "MAX_24_7",
            title = "🚀 Duy Trì 24/7 Tức Thì",
            badge = "Cho phép tác vụ nền đã chọn",
            description = "Giữ các thông báo/tính năng nền bạn bật; có thể tiêu thụ thêm pin. Không tự làm mát, tuần tra hay hồi sinh dịch vụ."
        );

        companion object {
            fun fromId(id: String?): SelfPowerMode {
                return entries.firstOrNull { it.id == id } ?: SMART_BALANCED
            }
        }
    }

    @androidx.compose.runtime.Immutable
    data class SelfModuleStatus(
        val id: String,
        val title: String,
        val subtitle: String,
        val isEnabled: Boolean,
        val estimatedMa: Double,
        val powerImpactLabel: String
    )

    @androidx.compose.runtime.Immutable
    data class SelfPowerSnapshot(
        val mode: SelfPowerMode,
        val strictStopWhenIdle: Boolean,
        val processPssMb: Int,
        val jvmHeapUsedMb: Int,
        val jvmHeapMaxMb: Int,
        val isKeepAliveServiceRunning: Boolean,
        val isAnyOverlayActive: Boolean,
        val isAccessibilityActiveInSettings: Boolean,
        val isWakeLockHeld: Boolean,
        val estimatedTotalMa: Double,
        val cpuCadenceLabel: String,
        val activeModuleCount: Int,
        val totalModuleCount: Int,
        val modules: List<SelfModuleStatus>
    )

    fun getSelfPowerMode(context: Context): SelfPowerMode {
        val appCtx = context.applicationContext ?: context
        val prefs = appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return SelfPowerMode.fromId(prefs.getString(KEY_SELF_POWER_MODE, SelfPowerMode.SMART_BALANCED.id))
    }

    fun isStrictStopWhenIdle(context: Context): Boolean {
        val appCtx = context.applicationContext ?: context
        val prefs = appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val mode = getSelfPowerMode(appCtx)
        return mode == SelfPowerMode.ECO_ZERO_DRAIN || prefs.getBoolean(KEY_STRICT_STOP_ON_EXIT, false)
    }

    /** One-time upgrade migration that removes legacy autonomous work and persistent high-refresh locks. */
    fun applyOnDemandThermalSafetyDefaults(context: Context) {
        val appCtx = context.applicationContext ?: context
        val prefs = appCtx.getSharedPreferences("magictune_thermal_safety", Context.MODE_PRIVATE)
        if (prefs.getBoolean("on_demand_thermal_defaults_v812", false)) return
        try { MagicTuneKeepAliveService.setAutoCoolingEnabled(appCtx, false) } catch (_: Throwable) {}
        try { AutoWakeupPatrolManager.setAutoWakeupEnabled(appCtx, false) } catch (_: Throwable) {}
        try { com.example.core.ai.AiPowerAutopilotManager.disableAllAutopilot(appCtx) } catch (_: Throwable) {}
        try { MagicTuneKeepAliveJobService.cancelAll(appCtx) } catch (_: Throwable) {}

        try {
            val kv = appCtx.getSharedPreferences("magictune_persisted_kv", Context.MODE_PRIVATE)
            if (kv.getBoolean("magictune_refresh_lock_active", false)) {
                kv.edit().putBoolean("magictune_refresh_lock_active", false).apply()
                prefs.edit().putBoolean(KEY_ADAPTIVE_REFRESH_RESTORE_PENDING, true).apply()
            }
        } catch (_: Throwable) {}
        prefs.edit().putBoolean("on_demand_thermal_defaults_v812", true).apply()
    }

    /** Restore OEM adaptive display refresh once after removing a legacy persistent lock. */
    suspend fun restoreAdaptiveRefreshSettingsIfPending(context: Context): Boolean {
        val appCtx = context.applicationContext ?: context
        val prefs = appCtx.getSharedPreferences("magictune_thermal_safety", Context.MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_ADAPTIVE_REFRESH_RESTORE_PENDING, false)) return true
        val shell = ShellEngine.getInstance(appCtx)
        if (!shell.state.value.isAdbReady) return false
        val result = try {
            shell.execute(
                "settings delete system peak_refresh_rate >/dev/null 2>&1 || true; " +
                    "settings delete system min_refresh_rate >/dev/null 2>&1 || true; " +
                    "settings put system user_refresh_rate 0 >/dev/null 2>&1 || true; " +
                    "cmd display set-match-content-frame-rate-pref 1 >/dev/null 2>&1 || true",
                isBackground = true
            )
        } catch (_: Throwable) { return false }
        if (!result.isSuccess) return false
        prefs.edit().putBoolean(KEY_ADAPTIVE_REFRESH_RESTORE_PENDING, false).apply()
        return true
    }

    fun getTickerCadenceMultiplier(context: Context): Float {
        return when (getSelfPowerMode(context)) {
            SelfPowerMode.ECO_ZERO_DRAIN -> 2.0f
            SelfPowerMode.SMART_BALANCED -> 1.35f
            SelfPowerMode.MAX_24_7 -> 1.0f
        }
    }

    fun applySelfPowerMode(context: Context, mode: SelfPowerMode): String {
        val appCtx = context.applicationContext ?: context
        appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_SELF_POWER_MODE, mode.id)
            .putBoolean(KEY_STRICT_STOP_ON_EXIT, mode == SelfPowerMode.ECO_ZERO_DRAIN)
            .apply()

        return when (mode) {
            SelfPowerMode.ECO_ZERO_DRAIN -> {
                // Tắt các tác vụ nền không thiết yếu của MagicTune khi người dùng chọn chế độ này.
                MagicTuneKeepAliveService.setSearchNotificationEnabled(appCtx, false)
                MagicTuneKeepAliveService.setChargingNotificationEnabled(appCtx, false)
                MagicTuneKeepAliveService.setAutoCoolingEnabled(appCtx, false)
                AutoWakeupPatrolManager.setAutoWakeupEnabled(appCtx, false)
                MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(appCtx)
                trimSelfMemoryNow()
                MagicTuneKeepAliveService.syncServiceNeed(appCtx, "Chế độ Siêu Tiết Kiệm 0% Xả Ngầm")
                "🍃 Đã bật Ngủ Sâu Khi Nhàn Rỗi: đã tắt thông báo và dịch vụ nền không thiết yếu của MagicTune."
            }
            SelfPowerMode.SMART_BALANCED -> {
                // No background thermal polling; use the manual ADB power-saving action when needed.
                MagicTuneKeepAliveService.setChargingNotificationEnabled(appCtx, false)
                MagicTuneKeepAliveService.setAutoCoolingEnabled(appCtx, false)
                AutoWakeupPatrolManager.setAutoWakeupEnabled(appCtx, false)
                MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(appCtx)
                trimSelfMemoryNow()
                MagicTuneKeepAliveService.syncServiceNeed(appCtx, "Chế độ Cân Bằng Thông Minh")
                "⚖️ Đã bật Cân Bằng Thông Minh: đã tắt tự làm mát/tuần tra nền; dùng ADB thủ công khi cần giảm tải."
            }
            SelfPowerMode.MAX_24_7 -> {
                MagicTuneKeepAliveService.setSearchNotificationEnabled(appCtx, true)
                MagicTuneKeepAliveService.setAutoCoolingEnabled(appCtx, false)
                AutoWakeupPatrolManager.setAutoWakeupEnabled(appCtx, false)
                MagicTuneKeepAliveService.syncServiceNeed(appCtx, "Chế độ Duy Trì 24/7 Sẵn Sàng")
                "🚀 Đã bật Duy Trì 24/7: chỉ giữ thanh tìm kiếm bạn chọn; không bật tự làm mát hay tuần tra nền."
            }
        }
    }

    private fun trimSelfMemoryNow() {
        try {
            com.example.core.widget.AppIconMemoryCache.trimMemory(ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW)
        } catch (_: Throwable) {}
    }

    /**
     * Thu gọn RAM & đưa toàn bộ mô-đun chạy ngầm của chính MagicTune về trạng thái ngủ sâu ngay lập tức.
     */
    fun hibernateSelfBackgroundNow(context: Context, closeFloatingOverlays: Boolean = false): String {
        val appCtx = context.applicationContext ?: context
        val beforePss = readOwnProcessPssMb(appCtx)

        if (closeFloatingOverlays) {
            try { MagicLiveFloatingOverlay.dismiss(appCtx) } catch (_: Throwable) {}
            try { GoogleLiveTranslateOverlay.stop(appCtx) } catch (_: Throwable) {}
            try { CircleToSearchWindowOverlay.dismiss(appCtx) } catch (_: Throwable) {}
        }

        // Tắt các mô-đun chạy nền thụ động của MagicTune để không ngốn pin
        MagicTuneKeepAliveService.setSearchNotificationEnabled(appCtx, false)
        MagicTuneKeepAliveService.setChargingNotificationEnabled(appCtx, false)
        MagicTuneKeepAliveService.setAutoCoolingEnabled(appCtx, false)
        AutoWakeupPatrolManager.setAutoWakeupEnabled(appCtx, false)
        MagicTuneCtsAccessibilityService.enterDeepSleepNow(appCtx, forceImmediate = true)

        // Nếu không còn overlay hay cầu nối nào cần giữ, dừng hẳn KeepAliveService & JobScheduler
        if (!MagicTuneKeepAliveService.needsToRun(appCtx)) {
            MagicTuneKeepAliveJobService.cancelAll(appCtx)
            MagicTuneKeepAliveService.stop(appCtx)
        } else {
            MagicTuneKeepAliveService.syncServiceNeed(appCtx)
        }

        trimSelfMemoryNow()
        val afterPss = readOwnProcessPssMb(appCtx)
        val freedMb = (beforePss - afterPss).coerceAtLeast(3)

        return "✅ Đã thu gọn ~${freedMb}MB RAM nội bộ & ngắt các dịch vụ chạy ngầm của MagicTune (RAM hiện tại: ${afterPss}MB)."
    }

    fun toggleSelfModule(context: Context, moduleId: String, enable: Boolean): String {
        val appCtx = context.applicationContext ?: context
        return when (moduleId) {
            "mod_search_notif" -> {
                MagicTuneKeepAliveService.setSearchNotificationEnabled(appCtx, enable)
                MagicTuneKeepAliveService.syncServiceNeed(appCtx)
                if (enable) "Đã bật Thanh Tìm Kiếm App Ghim Trên Thông Báo."
                else "Đã tắt Thanh Tìm Kiếm Thông Báo (Giảm giữ dịch vụ Foreground)."
            }
            "mod_auto_cooling" -> {
                MagicTuneKeepAliveService.setAutoCoolingEnabled(appCtx, false)
                MagicTuneKeepAliveService.syncServiceNeed(appCtx)
                "Tính năng làm mát tự động nền đã được gỡ để tránh tự phát sinh tải; dùng nút ADB thủ công khi cần."
            }
            "mod_charging_notif" -> {
                MagicTuneKeepAliveService.setChargingNotificationEnabled(appCtx, enable)
                MagicTuneKeepAliveService.syncServiceNeed(appCtx)
                if (enable) "Đã bật Theo Dõi Sạc & Báo Đầy Pin 100%."
                else "Đã tắt Theo Dõi Thông Báo Sạc Nền (Tiết kiệm điện)."
            }
            "mod_wakeup_patrol" -> {
                AutoWakeupPatrolManager.setAutoWakeupEnabled(appCtx, enable)
                MagicTuneKeepAliveService.syncServiceNeed(appCtx)
                "Tuần tra đánh thức nền đã bị tắt để tránh giữ CPU/modem hoạt động định kỳ."
            }
            "mod_nav_bridge" -> {
                if (enable) {
                    SystemFloatingHudOverlay.savePersistentNavModMode(appCtx, "CIRCLE_TO_SEARCH", explicitlyDisabled = false)
                    SystemFloatingHudOverlay.syncNavBarBridge(appCtx)
                    MagicTuneKeepAliveService.syncServiceNeed(appCtx)
                    "Đã bật Cầu Nối Thanh Điều Hướng (Khoanh tròn hỏi AI)."
                } else {
                    SystemFloatingHudOverlay.savePersistentNavModMode(appCtx, "DEFAULT", explicitlyDisabled = true)
                    SystemFloatingHudOverlay.syncNavBarBridge(appCtx)
                    MagicTuneKeepAliveService.syncServiceNeed(appCtx)
                    "Đã tắt Cầu Nối Thanh Điều Hướng (Ngắt hoàn toàn lắng nghe cử chỉ nền)."
                }
            }
            "mod_floating_overlays" -> {
                if (!enable) {
                    try { MagicLiveFloatingOverlay.dismiss(appCtx) } catch (_: Throwable) {}
                    try { GoogleLiveTranslateOverlay.stop(appCtx) } catch (_: Throwable) {}
                    try { CircleToSearchWindowOverlay.dismiss(appCtx) } catch (_: Throwable) {}
                    MagicTuneKeepAliveService.syncServiceNeed(appCtx)
                    "Đã đóng toàn bộ Bong Bóng Nổi (Magic Live / Dịch Màn Hình)."
                } else {
                    "Bạn có thể mở Bong Bóng Magic Live hoặc Dịch Màn Hình từ trang Công Cụ khi cần dùng."
                }
            }
            "mod_accessibility_ondemand" -> {
                MagicTuneCtsAccessibilityService.enterDeepSleepNow(appCtx, forceImmediate = true)
                "Đã đưa Trợ Năng vào ngủ sâu; không còn yêu cầu đọc màn hình nền."
            }
            "mod_keepalive_master" -> {
                if (!enable) {
                    MagicTuneKeepAliveService.setSearchNotificationEnabled(appCtx, false)
                    MagicTuneKeepAliveService.setChargingNotificationEnabled(appCtx, false)
                    MagicTuneKeepAliveService.setAutoCoolingEnabled(appCtx, false)
                    AutoWakeupPatrolManager.setAutoWakeupEnabled(appCtx, false)
                    MagicTuneKeepAliveJobService.cancelAll(appCtx)
                    MagicTuneKeepAliveService.stop(appCtx)
                    "Đã dừng dịch vụ KeepAlive của MagicTune khi không còn tác vụ cần nền."
                } else {
                    MagicTuneKeepAliveService.setAutoCoolingEnabled(appCtx, false)
                    AutoWakeupPatrolManager.setAutoWakeupEnabled(appCtx, false)
                    MagicTuneKeepAliveService.syncServiceNeed(appCtx)
                    "Đã khởi chạy lại dịch vụ theo yêu cầu; giám sát nhiệt nền vẫn tắt."
                }
            }
            else -> "Đã cập nhật trạng thái mô-đun."
        }
    }

    fun captureSnapshot(context: Context): SelfPowerSnapshot {
        val appCtx = context.applicationContext ?: context
        val mode = getSelfPowerMode(appCtx)
        val strictStop = isStrictStopWhenIdle(appCtx)
        val pssMb = readOwnProcessPssMb(appCtx)

        val rt = Runtime.getRuntime()
        val heapUsedMb = ((rt.totalMemory() - rt.freeMemory()) / (1024L * 1024L)).toInt().coerceAtLeast(1)
        val heapMaxMb = (rt.maxMemory() / (1024L * 1024L)).toInt().coerceAtLeast(64)

        val searchNotifOn = MagicTuneKeepAliveService.isSearchNotificationEnabled(appCtx)
        val chargingNotifOn = MagicTuneKeepAliveService.isChargingNotificationEnabled(appCtx)
        val patrolOn = AutoWakeupPatrolManager.isAutoWakeupEnabled(appCtx)
        val navBridgeOn = SystemFloatingHudOverlay.isNavBridgeConfiguredActive(appCtx)
        val navMicWakeOn = navBridgeOn && SystemFloatingHudOverlay.isMagicLiveMicWakeEnabled(appCtx)
        val anyOverlayOn = MagicLiveFloatingOverlay.isShowing ||
            GoogleLiveTranslateOverlay.isRunning ||
            CircleToSearchOverlayActivity.isOverlayActive ||
            CircleToSearchWindowOverlay.isShowing ||
            NoAccessibilityScreenEngine.isLiveScrollTranslateActive
        val voiceWakeLockHeld = MagicLiveFloatingOverlay.isVoiceOrSpeechActive()
        val a11yInSettings = MagicTuneCtsAccessibilityService.isServiceEnabledInSettings(appCtx)
        val serviceRunning = MagicTuneKeepAliveService.isServiceRunning

        val modules = listOf(
            SelfModuleStatus(
                id = "mod_keepalive_master",
                title = "Dịch vụ Duy trì Nền (KeepAlive Engine)",
                subtitle = if (serviceRunning) "Đang chạy; mức tiêu thụ thực tế cần đo trên thiết bị" else "KeepAlive đã dừng",
                isEnabled = serviceRunning,
                estimatedMa = if (serviceRunning) 0.45 else 0.0,
                powerImpactLabel = if (serviceRunning) "Đang chạy • mA chưa đo" else "Đã dừng"
            ),
            SelfModuleStatus(
                id = "mod_search_notif",
                title = "Thanh Tìm Kiếm App Ghim Trên Thông Báo",
                subtitle = if (searchNotifOn) "Đang ghim trên thanh trạng thái (Giữ Foreground Service)" else "Đã tắt (Cho phép dịch vụ nền tự nghỉ khi không dùng)",
                isEnabled = searchNotifOn,
                estimatedMa = if (searchNotifOn) 0.35 else 0.0,
                powerImpactLabel = if (searchNotifOn) "Đang bật • mA chưa đo" else "Đã tắt"
            ),
            SelfModuleStatus(
                id = "mod_nav_bridge",
                title = "Cầu Nối Thanh Điều Hướng & Khoanh Tròn AI",
                subtitle = when {
                    !navBridgeOn -> "Đã tắt (Không có lớp phủ điều hướng)"
                    navMicWakeOn -> "Magic Live nghe tối đa 6 giây sau mỗi lần mở khóa; tắt để giảm hao pin"
                    else -> "Hai nút tĩnh; lớp phủ được tháo khi tắt màn hình; không polling định kỳ"
                },
                isEnabled = navBridgeOn,
                estimatedMa = if (navBridgeOn) 0.50 else 0.0,
                powerImpactLabel = if (navBridgeOn) "Đang bật • mA chưa đo" else "Đã tắt"
            ),
            SelfModuleStatus(
                id = "mod_floating_overlays",
                title = "Bong Bóng Magic Live AI & Dịch Màn Hình",
                subtitle = if (anyOverlayOn) "Đang hiển thị cửa sổ nổi trên màn hình" else "Overlay đã đóng",
                isEnabled = anyOverlayOn,
                estimatedMa = if (anyOverlayOn) (if (voiceWakeLockHeld) 6.5 else 2.2) else 0.0,
                powerImpactLabel = if (anyOverlayOn) "Đang hoạt động • mA chưa đo" else "Đã đóng"
            ),
            SelfModuleStatus(
                id = "mod_auto_cooling",
                title = "Làm Mát Tự Động Nền",
                subtitle = "Đã gỡ bỏ vòng kiểm tra nhiệt nền; dùng ADB theo yêu cầu",
                isEnabled = false,
                estimatedMa = 0.0,
                powerImpactLabel = "Đã tắt"
            ),
            SelfModuleStatus(
                id = "mod_charging_notif",
                title = "Thông Báo Công Suất Sạc & Báo Đầy 100%",
                subtitle = if (chargingNotifOn) "Theo dõi dòng sạc khi cắm cáp" else "Đã tắt theo dõi thông báo sạc nền",
                isEnabled = chargingNotifOn,
                estimatedMa = if (chargingNotifOn) 0.25 else 0.0,
                powerImpactLabel = if (chargingNotifOn) "Đang bật • mA chưa đo" else "Đã tắt"
            ),
            SelfModuleStatus(
                id = "mod_wakeup_patrol",
                title = "Tuần Tra Cắt Đánh Thức Ngầm Định Kỳ",
                subtitle = if (patrolOn) "Tự động đóng băng app bên thứ 3 đánh thức CPU" else "Đã tắt tuần tra nền tự động",
                isEnabled = patrolOn,
                estimatedMa = if (patrolOn) 0.30 else 0.0,
                powerImpactLabel = if (patrolOn) "Đang bật • mA chưa đo" else "Đã tắt"
            ),
            SelfModuleStatus(
                id = "mod_accessibility_ondemand",
                title = "Trợ Năng Tức Thời (On-Demand 0% Idle)",
                subtitle = if (a11yInSettings) "Đang được bật tạm thời cho tính năng cần đọc màn hình" else "Đang tắt khi không có tính năng cần đọc màn hình",
                isEnabled = a11yInSettings,
                estimatedMa = if (a11yInSettings) 0.80 else 0.0,
                powerImpactLabel = if (a11yInSettings) "Đang bật • mA chưa đo" else "Đã tắt"
            )
        )

        val totalMa = modules.sumOf { it.estimatedMa }
        val activeCount = modules.count { it.isEnabled }
        val cadenceLabel = when {
            !serviceRunning && !anyOverlayOn -> "KeepAlive đã dừng; tiến trình app có thể vẫn được hệ thống giữ trong RAM"
            voiceWakeLockHeld -> "Đang xử lý giọng nói; KeepAlive kiểm tra thưa 8–10 giây"
            anyOverlayOn -> "Overlay đang mở; KeepAlive kiểm tra theo sự kiện/thưa"
            navMicWakeOn -> "Magic Live có thể nghe tối đa 6 giây sau mỗi lần mở khóa"
            navBridgeOn -> "Nút điều hướng là lớp phủ tĩnh; không chạy vòng polling khi nhàn rỗi"
            else -> "Không có vòng giám sát nền liên tục; không giữ WakeLock khi nhàn rỗi"
        }

        return SelfPowerSnapshot(
            mode = mode,
            strictStopWhenIdle = strictStop,
            processPssMb = pssMb,
            jvmHeapUsedMb = heapUsedMb,
            jvmHeapMaxMb = heapMaxMb,
            isKeepAliveServiceRunning = serviceRunning,
            isAnyOverlayActive = anyOverlayOn,
            isAccessibilityActiveInSettings = a11yInSettings,
            isWakeLockHeld = voiceWakeLockHeld,
            estimatedTotalMa = totalMa,
            cpuCadenceLabel = cadenceLabel,
            activeModuleCount = activeCount,
            totalModuleCount = modules.size,
            modules = modules
        )
    }

    private fun readOwnProcessPssMb(context: Context): Int {
        return try {
            val pssKb = Debug.getPss()
            if (pssKb > 0L) {
                (pssKb / 1024L).toInt().coerceAtLeast(12)
            } else {
                val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                val memInfos = am?.getProcessMemoryInfo(intArrayOf(Process.myPid()))
                val totalPssKb = memInfos?.firstOrNull()?.totalPss ?: 0
                if (totalPssKb > 0) (totalPssKb / 1024).coerceAtLeast(12) else 28
            }
        } catch (_: Throwable) {
            28
        }
    }
}
