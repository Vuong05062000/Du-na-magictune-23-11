package com.example.core.crash

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.Process
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * CrashBlackBox: "Hộp đen" ghi lại toàn bộ sự cố văng app (Crash), ANR và bị Android OS giết ngầm.
 * 
 * Chức năng:
 * 1. Bắt lỗi Crash Java/Kotlin qua UncaughtExceptionHandler và ghi stack trace đầy đủ xuống last_crash.txt.
 * 2. Bắt lỗi hệ thống giết ngầm qua ActivityManager.getHistoricalProcessExitReasons (Android 11+),
 *    nhận biết chính xác app chết do LMK (Low Memory Killer), ANR hay Native C/C++ crash.
 * 3. Hỗ trợ hiển thị hộp thoại xem nhanh, sao chép log và xóa sạch log sau khi xử lý.
 */
object CrashBlackBox {

    private const val TAG = "CrashBlackBox"
    const val CRASH_FILE_NAME = "last_crash.txt"
    const val PERFORMANCE_FILE_NAME = "performance_alert.txt"
    private const val PERFORMANCE_COOLDOWN_MS = 5 * 60 * 1000L
    private const val PERFORMANCE_POLL_MS = 180_000L
    private const val BATTERY_WARM_C = 40f
    private const val BATTERY_EARLY_WARNING_C = 38f
    private const val FAST_TEMP_RISE_C_PER_MIN = 3.0f
    private const val VERY_FAST_TEMP_RISE_C_PER_MIN = 6.0f
    private const val APP_CPU_HIGH_PERCENT = 80f
    private const val APP_CPU_WARMING_PERCENT = 40f
    private const val TEMP_RISE_WITH_CPU_C_PER_MIN = 1.6f
    private const val HEAP_GROWTH_ALERT_PERCENT_PER_MIN = 10f
    private const val HEAP_GROWTH_MIN_PERCENT = 60f
    private const val HEAP_SKIP_STACK_DUMP_PERCENT = 85f
    private const val PERFORMANCE_ENTRY_SEPARATOR = "\n\n========== PERFORMANCE ALERT ==========\n"
    private const val EXIT_INFO_SECTION = "\n\n---------------- XÁC THỰC TỪ HỆ ĐIỀU HÀNH ANDROID (EXIT INFO) ----------------\n"
    private const val PREFS_NAME = "magictune_crash_box"
    private const val KEY_LAST_EXIT_TIMESTAMP = "last_recorded_exit_timestamp"
    private const val KEY_HAS_UNREAD_CRASH = "has_unread_crash"
    private const val KEY_FIRESTORE_OOM_RECOVERY_REQUIRED = "firestore_oom_recovery_required"
    private const val KEY_FIRESTORE_OOM_OLD_LOG_ACKNOWLEDGED = "firestore_oom_old_log_acknowledged"

    @Volatile
    private var isInstalled = false
    private val monitorLock = Any()
    private var monitorScope: CoroutineScope? = null
    private var thermalListener: PowerManager.OnThermalStatusChangedListener? = null
    private var screenOffReceiver: BroadcastReceiver? = null
    private var lastPerformanceRecordMs = 0L
    private var lastTemperatureAlertBand = 0
    private data class PerformanceSample(
        val elapsedMs: Long,
        val temperatureC: Float,
        val cpuTimeMs: Long,
        val heapPercent: Float
    )
    private var lastPerformanceSample: PerformanceSample? = null
    @Volatile private var activeScreenName: String = "Không rõ"

    /**
     * Cài đặt UncaughtExceptionHandler toàn cục tại Application.onCreate().
     */
    fun install(context: Context) {
        if (isInstalled) return
        isInstalled = true

        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                if (throwable is OutOfMemoryError) {
                    Log.e(TAG, "[BlackBox] Bắt được OutOfMemoryError trên luồng [${thread.name}]: ${(throwable.message ?: "").take(240)}")
                } else {
                    Log.e(TAG, "🚨 [BlackBox] Bắt được Uncaught Exception trên luồng [${thread.name}]: ${throwable.message}", throwable)
                }
                recordJavaCrash(context, thread, throwable)
            } catch (e: Throwable) {
                Log.e(TAG, "Lỗi khi ghi hộp đen: ${e.message}", e)
            } finally {
                // Tiếp tục chuyển tiếp cho handler mặc định của hệ thống
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }
        Log.i(TAG, "🛡️ CrashBlackBox UncaughtExceptionHandler đã được kích hoạt thành công.")
    }

    /** Start only while the host activity is visible and the display is interactive. */
    fun startPerformanceMonitoring(context: Context) {
        synchronized(monitorLock) {
            if (monitorScope != null) return
            val appContext = context.applicationContext
            val powerManager = appContext.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return
            if (!powerManager.isInteractive) return
            val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
            monitorScope = scope
            monitorApplicationContext = appContext
            synchronized(monitorLock) { lastPerformanceSample = null }
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    if (intent?.action == Intent.ACTION_SCREEN_OFF) stopPerformanceMonitoring()
                }
            }
            try {
                val filter = IntentFilter(Intent.ACTION_SCREEN_OFF)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    appContext.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
                } else {
                    @Suppress("DEPRECATION")
                    appContext.registerReceiver(receiver, filter)
                }
                screenOffReceiver = receiver
            } catch (_: Throwable) {
                screenOffReceiver = null
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val listener = PowerManager.OnThermalStatusChangedListener { status ->
                    if (status >= PowerManager.THERMAL_STATUS_MODERATE && powerManager.isInteractive) {
                        scope.launch { recordPerformanceAlert(appContext, "Hệ thống báo thermal status ${thermalStatusName(status)}") }
                    }
                }
                thermalListener = listener
                try { powerManager.addThermalStatusListener(appContext.mainExecutor, listener) } catch (_: Throwable) { thermalListener = null }
                try {
                    val status = powerManager.currentThermalStatus
                    if (status >= PowerManager.THERMAL_STATUS_MODERATE) {
                        scope.launch { recordPerformanceAlert(appContext, "Thermal status hiện tại ${thermalStatusName(status)}") }
                    }
                } catch (_: Throwable) {}
            }
            scope.launch {
                // Prime a baseline immediately; subsequent regular samples remain at 30-second intervals.
                recordPerformanceAlert(appContext, null)
                while (isActive && powerManager.isInteractive) {
                    delay(PERFORMANCE_POLL_MS)
                    if (!isActive || !powerManager.isInteractive) break
                    recordPerformanceAlert(appContext, null)
                }
                stopPerformanceMonitoring()
            }
        }
    }

    fun stopPerformanceMonitoring() {
        val oldScope: CoroutineScope?
        val listener: PowerManager.OnThermalStatusChangedListener?
        val receiver: BroadcastReceiver?
        val context: Context?
        synchronized(monitorLock) {
            oldScope = monitorScope
            monitorScope = null
            listener = thermalListener
            thermalListener = null
            receiver = screenOffReceiver
            screenOffReceiver = null
            context = monitorApplicationContext
            monitorApplicationContext = null
        }
        oldScope?.cancel()
        try {
            if (listener != null && context != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                (context.getSystemService(Context.POWER_SERVICE) as? PowerManager)?.removeThermalStatusListener(listener)
            }
        } catch (_: Throwable) {}
        try { if (receiver != null && context != null) context.unregisterReceiver(receiver) } catch (_: Throwable) {}
    }

    @Volatile private var monitorApplicationContext: Context? = null

    fun updateActiveScreenName(name: String) { activeScreenName = name }

    fun isFirestoreOomRecoveryRequired(context: Context): Boolean {
        return try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            if (prefs.getBoolean(KEY_FIRESTORE_OOM_RECOVERY_REQUIRED, false)) return true
            if (prefs.getBoolean(KEY_FIRESTORE_OOM_OLD_LOG_ACKNOWLEDGED, false)) return false

            // Upgrade path: earlier CrashBlackBox versions did not save the recovery flag.
            // Scan a bounded prefix of the persisted crash report once, without loading it all into RAM.
            val file = File(context.filesDir, CRASH_FILE_NAME)
            if (!file.isFile || file.length() <= 0L) return false
            var foundOutOfMemory = false
            var foundFirestore = false
            var scannedBytes = 0
            var carry = ""
            val buffer = ByteArray(4096)
            file.inputStream().use { input ->
                while (scannedBytes < 512 * 1024) {
                    val read = input.read(buffer, 0, minOf(buffer.size, 512 * 1024 - scannedBytes))
                    if (read <= 0) break
                    scannedBytes += read
                    val chunk = (carry + String(buffer, 0, read, Charsets.UTF_8)).lowercase(Locale.ROOT)
                    if (chunk.contains("outofmemoryerror")) foundOutOfMemory = true
                    if (chunk.contains("firestore") || chunk.contains("com.google.firebase.firestore")) foundFirestore = true
                    carry = chunk.takeLast(64)
                    if (foundOutOfMemory && foundFirestore) break
                }
            }
            if (foundOutOfMemory && foundFirestore) {
                prefs.edit().putBoolean(KEY_FIRESTORE_OOM_RECOVERY_REQUIRED, true).apply()
                true
            } else false
        } catch (_: Throwable) { false }
    }

    fun clearFirestoreOomRecoveryRequired(context: Context) {
        try {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .remove(KEY_FIRESTORE_OOM_RECOVERY_REQUIRED)
                .putBoolean(KEY_FIRESTORE_OOM_OLD_LOG_ACKNOWLEDGED, true)
                .apply()
        } catch (_: Throwable) {}
    }

    private fun isFirestoreOutOfMemory(throwable: Throwable): Boolean {
        var current: Throwable? = throwable
        var causeDepth = 0
        while (current != null && causeDepth++ < 12) {
            if (current is OutOfMemoryError) {
                val message = current.message.orEmpty()
                if (message.contains("Firestore", ignoreCase = true)) return true
                var frameCount = 0
                for (frame in current.stackTrace) {
                    if (frame.className.startsWith("com.google.firebase.firestore.")) return true
                    if (++frameCount >= 120) break
                }
            }
            current = current.cause
        }
        return false
    }

    private fun compactStackTrace(throwable: Throwable): String {
        val out = StringBuilder(12 * 1024)
        var current: Throwable? = throwable
        var causeDepth = 0
        while (current != null && causeDepth++ < 8 && out.length < 48 * 1024) {
            if (causeDepth > 1) out.append("Caused by: ")
            out.append(current.javaClass.name).append(": ").append(current.message.orEmpty().take(400)).append('\n')
            var count = 0
            for (frame in current.stackTrace) {
                if (count++ >= 80 || out.length >= 48 * 1024) break
                out.append("\tat ").append(frame.toString()).append('\n')
            }
            current = current.cause
        }
        return out.toString()
    }

    private fun recordPerformanceAlert(context: Context, thermalReason: String?) {
        try {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            if (powerManager?.isInteractive == false) return
            val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val temperatureC = (batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1) / 10f
            val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
                ?: BatteryManager.BATTERY_STATUS_UNKNOWN
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            val currentMicroAmps = try { batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: Int.MIN_VALUE } catch (_: Throwable) { Int.MIN_VALUE }
            val currentMa = if (currentMicroAmps == Int.MIN_VALUE) null else kotlin.math.abs(currentMicroAmps) / 1000f
            val runtime = Runtime.getRuntime()
            val usedBytes = runtime.totalMemory() - runtime.freeMemory()
            val maxBytes = runtime.maxMemory().coerceAtLeast(1L)
            val heapPercent = usedBytes * 100f / maxBytes
            val nowElapsed = android.os.SystemClock.elapsedRealtime()
            val processCpuMs = try { Process.getElapsedCpuTime() } catch (_: Throwable) { -1L }
            val previousSample = synchronized(monitorLock) {
                val previous = lastPerformanceSample
                lastPerformanceSample = if (processCpuMs >= 0L) {
                    PerformanceSample(nowElapsed, temperatureC, processCpuMs, heapPercent)
                } else previous
                previous
            }
            val sampleElapsedMs = previousSample?.let { (nowElapsed - it.elapsedMs).coerceAtLeast(1L) }
            val temperatureRiseC = previousSample?.takeIf { temperatureC >= 0f && it.temperatureC >= 0f }?.let { temperatureC - it.temperatureC }
            val temperatureRisePerMinute = if (temperatureRiseC != null && sampleElapsedMs != null) {
                temperatureRiseC * 60_000f / sampleElapsedMs
            } else null
            val projectedTemperatureC = if (
                temperatureC in BATTERY_EARLY_WARNING_C..<BATTERY_WARM_C &&
                sampleElapsedMs != null && sampleElapsedMs >= 20_000L &&
                temperatureRisePerMinute != null && temperatureRisePerMinute >= 1f
            ) temperatureC + temperatureRisePerMinute / 2f else null
            val cpuPercent = if (previousSample != null && processCpuMs >= 0L && sampleElapsedMs != null && sampleElapsedMs >= 20_000L) {
                ((processCpuMs - previousSample.cpuTimeMs).coerceAtLeast(0L) * 100f / sampleElapsedMs)
            } else null
            val heapGrowthPerMinute = if (previousSample != null && sampleElapsedMs != null) {
                (heapPercent - previousSample.heapPercent) * 60_000f / sampleElapsedMs
            } else null
            // Bỏ qua cảnh báo ảo khi thiết bị đang ở trạng thái nghỉ hoàn toàn (dòng xả <= 50mA, không sạc, nhiệt không tăng)
            val isIdleBaseline = !charging && currentMa != null && currentMa <= 50f && (temperatureRisePerMinute == null || temperatureRisePerMinute <= 0.2f)
            if (isIdleBaseline && thermalReason == null && temperatureC < 42f) {
                return
            }
            val reasons = buildList {
                if (thermalReason != null) add(thermalReason)
                if (temperatureC >= 42f) add("Nhiệt độ pin >= 42°C")
                else if (temperatureC >= BATTERY_WARM_C && ((cpuPercent != null && cpuPercent >= APP_CPU_WARMING_PERCENT) || (temperatureRisePerMinute != null && temperatureRisePerMinute >= FAST_TEMP_RISE_C_PER_MIN))) {
                    add("Nhiệt độ pin >= 40°C cùng tải cao")
                }
                if (temperatureRisePerMinute != null && temperatureRisePerMinute >= VERY_FAST_TEMP_RISE_C_PER_MIN) {
                    add("Nhiệt pin tăng rất nhanh (+${"%.1f".format(Locale.US, temperatureRisePerMinute)}°C/phút)")
                } else if (temperatureRisePerMinute != null && cpuPercent != null &&
                    temperatureRisePerMinute >= TEMP_RISE_WITH_CPU_C_PER_MIN && cpuPercent >= APP_CPU_WARMING_PERCENT
                ) {
                    add("Nhiệt pin tăng nhanh cùng CPU app cao (+${"%.1f".format(Locale.US, temperatureRisePerMinute)}°C/phút)")
                } else if (temperatureRisePerMinute != null && temperatureRisePerMinute >= FAST_TEMP_RISE_C_PER_MIN && cpuPercent != null && cpuPercent >= 20f) {
                    add("Nhiệt pin tăng nhanh (+${"%.1f".format(Locale.US, temperatureRisePerMinute)}°C/phút)")
                }
                if (cpuPercent != null) {
                    val isRealSustainedSpike = cpuPercent >= 160f || (
                        cpuPercent >= APP_CPU_HIGH_PERCENT && (
                            (temperatureRisePerMinute != null && temperatureRisePerMinute > 0.5f) ||
                            (!charging && currentMa != null && currentMa > 500f) ||
                            (temperatureC >= BATTERY_WARM_C)
                        )
                    )
                    if (isRealSustainedSpike) {
                        add("CPU tiến trình app cao (%.1f%%) trong mẫu 30 giây".format(Locale.US, cpuPercent))
                    }
                }
                if (heapPercent >= HEAP_GROWTH_MIN_PERCENT && heapGrowthPerMinute != null &&
                    heapGrowthPerMinute >= HEAP_GROWTH_ALERT_PERCENT_PER_MIN
                ) {
                    add("Java Heap tăng nhanh (+${"%.1f".format(Locale.US, heapGrowthPerMinute)} điểm %/phút)")
                }
                if (!charging && currentMa != null && currentMa > 750f && (cpuPercent != null && cpuPercent >= 30f)) add("Dòng xả > 750 mA cùng CPU app")
                if (heapPercent > 80f) add("Java Heap > 80%")
            }
            if (reasons.isEmpty()) return
            val activeFeature = when {
                com.example.core.widget.GoogleLiveTranslateOverlay.isRunning -> "Dịch cuộn"
                com.example.core.widget.MagicLiveFloatingOverlay.isVoiceOrSpeechActive() -> "MagicLive đang nghe hoặc nói"
                com.example.core.widget.MagicLiveFloatingOverlay.isShowing -> "MagicLive đang mở"
                else -> "Không rõ"
            }
            val scrollProjectionActive = com.example.core.projection.MediaProjectionHolder.isContinuousScrollModeActive
            val scrollAccessibilityActive = com.example.core.service.NoAccessibilityScreenEngine.isLiveScrollTranslateActive
            val temperatureAlertBand = when {
                temperatureC >= 40f || thermalReason?.contains("SEVERE") == true ||
                    thermalReason?.contains("CRITICAL") == true || thermalReason?.contains("EMERGENCY") == true -> 3
                temperatureC >= BATTERY_WARM_C -> 2
                projectedTemperatureC != null && projectedTemperatureC >= BATTERY_WARM_C || thermalReason != null -> 1
                else -> 0
            }
            synchronized(monitorLock) {
                if (lastPerformanceRecordMs > 0L && nowElapsed - lastPerformanceRecordMs < PERFORMANCE_COOLDOWN_MS &&
                    temperatureAlertBand <= lastTemperatureAlertBand) return
                lastPerformanceRecordMs = nowElapsed
                lastTemperatureAlertBand = temperatureAlertBand
            }
            val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            // Only capture JVM thread stacks if there is an actual severe app CPU spike or critical heap pressure.
            // Avoid Thread.getAllStackTraces() for ambient heat or charging temperature.
            val shouldCaptureStack = (cpuPercent != null && cpuPercent >= APP_CPU_HIGH_PERCENT) || (heapPercent >= 80f && heapPercent < HEAP_SKIP_STACK_DUMP_PERCENT)
            val runnableStacks = if (!shouldCaptureStack) {
                emptyList()
            } else try {
                val stacks = ArrayList<String>(4)
                val fallbackStacks = ArrayList<String>(3)
                for ((thread, stack) in Thread.getAllStackTraces()) {
                    if (thread == Thread.currentThread()) continue
                    if (thread.state != Thread.State.RUNNABLE) continue
                    val appFrames = stack.asSequence().filter {
                        it.className.startsWith("com.example.") || it.className.startsWith(context.packageName + ".")
                    }.take(8).toList()
                    if (appFrames.isNotEmpty()) {
                        stacks.add("[${thread.name}]\n" + appFrames.joinToString("\n") { "    at $it" })
                        if (stacks.size >= 3) break
                    } else if (fallbackStacks.size < 3) {
                        val topFrames = stack.take(4).map { "    at $it" }
                        val frameContent = if (topFrames.isNotEmpty()) topFrames.joinToString("\n") else "    (Đang thực thi mã Native / Runtime GC)"
                        fallbackStacks.add("[${thread.name} (Luồng nền Runtime / Executor)]\n$frameContent")
                    }
                }
                if (stacks.isNotEmpty()) stacks else fallbackStacks
            } catch (_: Throwable) { emptyList() }
            val entry = buildString {
                append(PERFORMANCE_ENTRY_SEPARATOR)
                append("Thời gian: ").append(timestamp).append('\n')
                append("Bất thường: ").append(reasons.joinToString(", ")).append('\n')
                append("Nhiệt độ pin: ").append(if (temperatureC >= 0) "%.1f°C".format(Locale.US, temperatureC) else "không khả dụng").append('\n')
                append("Xu hướng nhiệt: ").append(
                    temperatureRisePerMinute?.let { "${if (it >= 0f) "+" else ""}${"%.1f".format(Locale.US, it)}°C/phút" } ?: "chưa đủ mẫu"
                ).append('\n')
                if (projectedTemperatureC != null) {
                    append("Ước lượng sau 30 giây nếu xu hướng giữ nguyên: ")
                        .append("%.1f°C".format(Locale.US, projectedTemperatureC)).append('\n')
                }
                append("Dòng pin: ").append(currentMa?.let { "%.0f mA".format(Locale.US, it) } ?: "không khả dụng")
                    .append(if (charging) " (đang sạc)" else " (không sạc)").append('\n')
                append("CPU tiến trình MagicTune: ").append(cpuPercent?.let { "%.1f%% trong mẫu ${sampleElapsedMs}ms".format(Locale.US, it) } ?: "chưa đủ mẫu").append('\n')
                append("Java Heap: ").append("%.1f%%".format(Locale.US, heapPercent)).append(" (")
                    .append(usedBytes / 1024 / 1024).append('/').append(maxBytes / 1024 / 1024).append(" MB)\n")
                append("Xu hướng Java Heap: ").append(
                    heapGrowthPerMinute?.let { "${if (it >= 0f) "+" else ""}${"%.1f".format(Locale.US, it)} điểm %/phút" } ?: "chưa đủ mẫu"
                ).append('\n')
                append("Màn hình/tab: ").append(activeScreenName).append('\n')
                append("Tính năng đang hoạt động: ").append(activeFeature).append('\n')
                append("Dịch cuộn / chụp liên tục / trợ năng dịch: ")
                    .append(com.example.core.widget.GoogleLiveTranslateOverlay.isRunning).append(" / ")
                    .append(scrollProjectionActive).append(" / ")
                    .append(scrollAccessibilityActive).append('\n')
                append("Stack RUNNABLE (Đang tiêu thụ CPU):\n")
                append(
                    when {
                        heapPercent >= HEAP_SKIP_STACK_DUMP_PERCENT -> "  Bỏ qua chụp stack để tránh tăng thêm tải khi heap đã >=85%.\n"
                        !shouldCaptureStack -> "  Không chụp stack vì CPU app và Heap ở ngưỡng an toàn.\n"
                        runnableStacks.isEmpty() -> "  Không tìm thấy thread RUNNABLE nào (CPU do tác vụ bên ngoài hoặc luồng gốc Kernel).\n"
                        else -> runnableStacks.joinToString("\n") + "\n"
                    }
                )
            }
            val file = File(context.filesDir, PERFORMANCE_FILE_NAME)
            synchronized(monitorLock) {
                val maxFileSize = 128 * 1024L
                if (file.exists() && file.length() > maxFileSize) {
                    try {
                        val text = file.readText(Charsets.UTF_8)
                        val entries = text.split(PERFORMANCE_ENTRY_SEPARATOR).filter { it.isNotBlank() }.takeLast(20)
                        file.writeText(entries.joinToString(PERFORMANCE_ENTRY_SEPARATOR, prefix = PERFORMANCE_ENTRY_SEPARATOR), Charsets.UTF_8)
                    } catch (_: Throwable) {}
                }
                try {
                    FileOutputStream(file, true).use { fos ->
                        fos.write(entry.toByteArray(Charsets.UTF_8))
                    }
                } catch (_: Throwable) {}
            }
        } catch (e: Throwable) { Log.w(TAG, "Không ghi được performance alert: ${e.message}") }
    }

    private fun thermalStatusName(status: Int) = when (status) {
        PowerManager.THERMAL_STATUS_MODERATE -> "MODERATE"
        PowerManager.THERMAL_STATUS_SEVERE -> "SEVERE"
        PowerManager.THERMAL_STATUS_CRITICAL -> "CRITICAL"
        PowerManager.THERMAL_STATUS_EMERGENCY -> "EMERGENCY"
        PowerManager.THERMAL_STATUS_SHUTDOWN -> "SHUTDOWN"
        else -> "status=$status"
    }

    private fun todayLocalDate(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun hasDateOnLine(report: String, label: String, date: String): Boolean =
        report.lineSequence().firstOrNull { it.startsWith(label) }?.startsWith("$label$date ") == true

    /** Chỉ đưa cảnh báo của ngày hiện tại lên giao diện; giữ nguyên file để tra cứu khi cần. */
    fun readPerformanceLog(context: Context): String? = try {
        val file = File(context.filesDir, PERFORMANCE_FILE_NAME)
        if (!file.isFile || file.length() == 0L) null else {
            val today = todayLocalDate()
            val text = if (file.length() > 256 * 1024L) {
                file.inputStream().use { input ->
                    input.skip(file.length() - 256 * 1024L)
                    input.bufferedReader(Charsets.UTF_8).readText()
                }
            } else {
                file.readText(Charsets.UTF_8)
            }
            text.split(PERFORMANCE_ENTRY_SEPARATOR)
                .filter { hasDateOnLine(it, "Thời gian: ", today) }
                .takeIf { it.isNotEmpty() }
                ?.joinToString(PERFORMANCE_ENTRY_SEPARATOR, prefix = PERFORMANCE_ENTRY_SEPARATOR)
        }
    } catch (_: Throwable) { null }

    fun clearPerformanceLog(context: Context): Boolean = try {
        val file = File(context.filesDir, PERFORMANCE_FILE_NAME)
        !file.exists() || file.delete()
    } catch (_: Throwable) { false }

    /**
     * Ghi chi tiết lỗi văng Java/Kotlin xuống đĩa flash ngay lập tức.
     */
    fun recordJavaCrash(context: Context, thread: Thread, throwable: Throwable) {
        try {
            val file = File(context.filesDir, CRASH_FILE_NAME)
            val nowStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault()).format(Date())

            val firestoreOom = isFirestoreOutOfMemory(throwable)
            if (firestoreOom) {
                try {
                    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                        .edit()
                        .putBoolean(KEY_FIRESTORE_OOM_RECOVERY_REQUIRED, true)
                        .apply()
                } catch (_: Throwable) {}
            }

            val stackTrace = if (throwable is OutOfMemoryError) {
                compactStackTrace(throwable)
            } else {
                val sw = StringWriter()
                val pw = PrintWriter(sw)
                throwable.printStackTrace(pw)
                sw.toString().take(256 * 1024)
            }

            val sb = StringBuilder()
            sb.append("================ HỘP ĐEN: BÁO CÁO VĂNG APP (JAVA/KOTLIN CRASH) ================\n")
            sb.append("Thời gian: ").append(nowStr).append("\n")
            sb.append("Loại sự cố: Uncaught Exception (Ngoại lệ chưa được bắt)\n")
            if (firestoreOom) {
                sb.append("Ghi chú khôi phục: Phát hiện Firestore OOM; lần mở tiếp theo sẽ yêu cầu chọn cách xử lý hàng đợi ngoại tuyến.\n")
            }
            sb.append("Luồng (Thread): [").append(thread.name).append("] (id: ").append(thread.id).append(", priority: ").append(thread.priority).append(")\n")
            sb.append("Ngoại lệ: ").append(throwable.javaClass.name).append(": ").append(throwable.message ?: "Không có thông báo").append("\n")
            sb.append("Thiết bị: ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL)
                .append(" (Android ").append(Build.VERSION.RELEASE).append(", API ").append(Build.VERSION.SDK_INT).append(")\n")
            sb.append("Bản dựng HĐH: ").append(Build.DISPLAY).append("\n")

            // Kiểm tra trạng thái bộ nhớ RAM tại thời điểm xảy ra sự cố
            try {
                val mi = ActivityManager.MemoryInfo()
                val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                am?.getMemoryInfo(mi)
                val availMb = mi.availMem / (1024 * 1024)
                val totalMb = mi.totalMem / (1024 * 1024)
                sb.append("Bộ nhớ RAM: Còn trống ").append(availMb).append(" MB / Tổng ").append(totalMb).append(" MB (lowMemory=").append(mi.lowMemory).append(")\n")
            } catch (_: Throwable) {}

            try {
                val runtime = Runtime.getRuntime()
                val usedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
                val maxMb = runtime.maxMemory().coerceAtLeast(1L) / (1024 * 1024)
                val heapPercent = (usedMb * 100L / maxMb.coerceAtLeast(1L)).coerceIn(0L, 100L)
                sb.append("Java Heap tại sự cố: ").append(usedMb).append("/").append(maxMb)
                    .append(" MB (").append(heapPercent).append("%)\n")
            } catch (_: Throwable) {}

            sb.append("\n---------------- STACK TRACE CHI TIẾT ----------------\n")
            sb.append(stackTrace.trim())
            sb.append("\n=================================================================================\n")

            // Ghi đồng bộ ngay lập tức và flush xuống flash storage
            FileOutputStream(file, false).use { fos ->
                val bytes = sb.toString().toByteArray(Charsets.UTF_8)
                fos.write(bytes)
                fos.flush()
                try {
                    fos.fd.sync()
                } catch (_: Throwable) {}
            }

            setUnreadStatus(context, true)
            Log.i(TAG, "💾 Đã lưu log văng app an toàn vào: ${file.absolutePath} (${file.length()} bytes)")
        } catch (e: Throwable) {
            Log.e(TAG, "Không thể ghi file last_crash.txt: ${e.message}", e)
        }
    }

    /**
     * Bắt lỗi hệ thống giết ngầm (ApplicationExitInfo - Android 11+ / API 30+).
     * Kiểm tra khi app mở lại để biết lần thoát trước app chết do code hay do Android tự giết.
     */
    fun checkAndRecordHistoricalExitReasons(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return

        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return
            val exitList = am.getHistoricalProcessExitReasons(context.packageName, 0, 5)
            if (exitList.isNullOrEmpty()) return

            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val lastRecordedTimestamp = prefs.getLong(KEY_LAST_EXIT_TIMESTAMP, 0L)

            val abnormalReasons = setOf(
                ApplicationExitInfo.REASON_CRASH,
                ApplicationExitInfo.REASON_CRASH_NATIVE,
                ApplicationExitInfo.REASON_LOW_MEMORY,
                ApplicationExitInfo.REASON_ANR,
                ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE
            )

            val latestExit = exitList.firstOrNull()
            if (latestExit != null && latestExit.timestamp > lastRecordedTimestamp) {
                if (latestExit.reason in abnormalReasons) {
                    val file = File(context.filesDir, CRASH_FILE_NAME)
                    val exitDateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(latestExit.timestamp))

                    val reasonText = when (latestExit.reason) {
                        ApplicationExitInfo.REASON_CRASH -> "REASON_CRASH (Ứng dụng bị văng do ngoại lệ mã nguồn Java/Kotlin)"
                        ApplicationExitInfo.REASON_CRASH_NATIVE -> "REASON_CRASH_NATIVE (Sập thư viện C/C++ Native - SIGSEGV/SIGABRT)"
                        ApplicationExitInfo.REASON_ANR -> "REASON_ANR (Ứng dụng không phản hồi / Treo Main Thread quá 5s)"
                        ApplicationExitInfo.REASON_LOW_MEMORY -> "REASON_LOW_MEMORY (Android LMK - Hệ điều hành thiếu RAM nên tự động buộc dừng app)"
                        ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "REASON_EXCESSIVE_RESOURCE_USAGE (Android ngắt do chiếm CPU/WakeLock/Mạng quá mức)"
                        else -> "REASON_ABNORMAL (${latestExit.reason})"
                    }

                    val importanceText = when (latestExit.importance) {
                        ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND -> "FOREGROUND (Đang mở tương tác trên màn hình)"
                        ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND_SERVICE -> "FOREGROUND_SERVICE (Đang chạy dịch vụ ngầm có thông báo)"
                        ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE -> "VISIBLE (Nhìn thấy một phần)"
                        ActivityManager.RunningAppProcessInfo.IMPORTANCE_TOP_SLEEPING -> "TOP_SLEEPING (Màn hình đang tắt)"
                        ActivityManager.RunningAppProcessInfo.IMPORTANCE_SERVICE -> "SERVICE (Dịch vụ ngầm không thông báo)"
                        ActivityManager.RunningAppProcessInfo.IMPORTANCE_CACHED -> "CACHED (Tiến trình đệm dưới nền)"
                        else -> "IMPORTANCE_${latestExit.importance}"
                    }

                    var traceSnippet: String? = null
                    try {
                        latestExit.traceInputStream?.use { stream ->
                            val reader = stream.bufferedReader(Charsets.UTF_8)
                            val buffer = CharArray(3072)
                            val read = reader.read(buffer, 0, 3072)
                            if (read > 0) {
                                traceSnippet = String(buffer, 0, read)
                            }
                        }
                    } catch (_: Throwable) {}

                    val existingContent = if (file.exists()) {
                        try { file.readText() } catch (_: Throwable) { "" }
                    } else ""

                    val sb = StringBuilder()
                    if (existingContent.isNotBlank()) {
                        sb.append(existingContent)
                        sb.append(EXIT_INFO_SECTION)
                    } else {
                        sb.append("================ HỘP ĐEN: BÁO CÁO HỆ THỐNG GIẾT APP (EXIT INFO) ================\n")
                    }

                    sb.append("Thời gian hệ thống ghi nhận: ").append(exitDateStr).append("\n")
                    sb.append("Nguyên nhân dừng: ").append(reasonText).append("\n")
                    sb.append("Mô tả hệ thống (Description): ").append(latestExit.description ?: "Không có mô tả chi tiết").append("\n")
                    sb.append("Trạng thái tiến trình lúc chết: ").append(importanceText).append("\n")
                    sb.append("Mức RAM tiêu thụ: PSS ").append(latestExit.pss / 1024).append(" MB | RSS ").append(latestExit.rss / 1024).append(" MB\n")
                    sb.append("Mã trạng thái / Tín hiệu: ").append(latestExit.status).append("\n")
                    if (!traceSnippet.isNullOrBlank()) {
                        sb.append("\n---------------- DẤU VẾT HỆ THỐNG (TRACE / TOMBSTONE) ----------------\n")
                        sb.append(traceSnippet.trim())
                        sb.append("\n")
                    }
                    sb.append("=================================================================================\n")

                    FileOutputStream(file, false).use { fos ->
                        fos.write(sb.toString().toByteArray(Charsets.UTF_8))
                        fos.flush()
                        try {
                            fos.fd.sync()
                        } catch (_: Throwable) {}
                    }

                    setUnreadStatus(context, true)
                    Log.w(TAG, "🚨 Phát hiện lần dừng bất thường trước: $reasonText")
                }

                // Cập nhật mốc thời gian đã xử lý
                prefs.edit().putLong(KEY_LAST_EXIT_TIMESTAMP, latestExit.timestamp).apply()
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Không thể kiểm tra historical exit reasons: ${e.message}", e)
        }
    }

    /** Chỉ đưa sự cố của ngày hiện tại lên giao diện; giữ nguyên file gốc. */
    fun readCrashLog(context: Context): String? {
        return try {
            val file = File(context.filesDir, CRASH_FILE_NAME)
            if (!file.isFile || file.length() == 0L) return null
            val content = file.readText(Charsets.UTF_8)
            val today = todayLocalDate()
            val parts = content.split(EXIT_INFO_SECTION)
            val crashPart = parts.first()
            val crashToday = hasDateOnLine(crashPart, "Thời gian: ", today)
            val standaloneExitToday = parts.size == 1 &&
                hasDateOnLine(crashPart, "Thời gian hệ thống ghi nhận: ", today)
            val todaysExitParts = parts.drop(1).filter {
                hasDateOnLine(it, "Thời gian hệ thống ghi nhận: ", today)
            }
            if (!crashToday && !standaloneExitToday && todaysExitParts.isEmpty()) null else buildString {
                if (crashToday || standaloneExitToday) append(crashPart)
                todaysExitParts.forEach { exitPart ->
                    if (isEmpty()) {
                        append("================ HỘP ĐEN: BÁO CÁO HỆ THỐNG GIẾT APP (EXIT INFO) ================\n")
                        append(exitPart.trimStart())
                    } else {
                        append(EXIT_INFO_SECTION).append(exitPart)
                    }
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Lỗi đọc file last_crash.txt: ${e.message}", e)
            null
        }
    }

    /**
     * Kiểm tra có file log sự cố chưa đọc hay không.
     */
    fun hasUnreadCrash(context: Context): Boolean {
        val file = File(context.filesDir, CRASH_FILE_NAME)
        if (!file.exists() || file.length() == 0L) return false
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_HAS_UNREAD_CRASH, true)
    }

    /**
     * Đánh dấu trạng thái đã đọc/chưa đọc.
     */
    fun setUnreadStatus(context: Context, isUnread: Boolean) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().putBoolean(KEY_HAS_UNREAD_CRASH, isUnread).apply()
        } catch (_: Throwable) {}
    }

    /**
     * Xóa sạch file last_crash.txt và cập nhật trạng thái.
     */
    fun clearCrashLog(context: Context): Boolean {
        return try {
            val file = File(context.filesDir, CRASH_FILE_NAME)
            val deleted = if (file.exists()) file.delete() else true
            setUnreadStatus(context, false)
            Log.i(TAG, "🗑️ Đã xóa sạch file last_crash.txt")
            deleted
        } catch (e: Throwable) {
            Log.e(TAG, "Không thể xóa file last_crash.txt: ${e.message}", e)
            false
        }
    }
}
