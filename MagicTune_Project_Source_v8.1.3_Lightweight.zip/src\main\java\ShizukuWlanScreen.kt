package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.adb.AdbDiagnosticReport
import com.example.core.adb.AdbTelemetrySnapshot
import com.example.core.shell.ShellEngineState
import com.example.data.ShizukuInfo
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

@Composable
fun ShizukuWlanScreen(
    isActive: Boolean = true,
    shizukuInfo: ShizukuInfo,
    shellState: ShellEngineState,
    isBusy: Boolean,
    onRequestShizukuPermission: () -> Unit,
    onOpenShizukuApp: () -> Unit,
    onOpenDeveloperSettings: () -> Unit,
    onOpenWlanDialog: () -> Unit,
    onProtectShizuku: () -> Unit,
    onAuthorizeCompanions: () -> Unit,
    onTestShizukuDiagnostic: () -> Unit = {},
    onStartNotificationPairing: () -> Unit = {},
    onStartShizukuDirectly: () -> Unit = {},
    onUnlockRestrictedSettings: () -> Unit = {},
    onConnectWlanPort: (Int) -> Unit = {},
    onRunShellCommand: (String) -> Unit = {},
    onForceResetShizuku: () -> Unit = {},
    adbTelemetry: AdbTelemetrySnapshot = AdbTelemetrySnapshot(),
    adbDiagnosticReport: AdbDiagnosticReport? = null,
    isRunningAdbDiagnostics: Boolean = false,
    onAutoConnectWlan: () -> Unit = {},
    onPingWlan: () -> Unit = {},
    onRunAdbDiagnostics: () -> Unit = {},
    onResetRsaKeys: () -> Unit = {},
    onNavigateToUniversalFix: () -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
    val nsdScanner = remember { com.example.core.adb.AdbNsdScanner.getInstance(context) }

    val isShizukuLive = shizukuInfo.isRunning && shizukuInfo.isPermissionGranted
    val isDirectWlanLive = shellState.isWirelessAdbConnected
    val isLiveReady = isShizukuLive || isDirectWlanLive
    var showShizukuMethod by remember { mutableStateOf(false) }

    val liveBorderBrush = remember { Brush.linearGradient(listOf(MagicEmerald, MagicCyan)) }
    val idleBorderBrush = remember { Brush.linearGradient(listOf(MagicAmber, MagicCyan)) }

    // Chỉ recompose khi cổng connectPort thực sự thay đổi (tránh giật lag do statusText spam mDNS)
    val detectedConnectPort by remember(nsdScanner) {
        nsdScanner.state.map { it.connectPort }.distinctUntilChanged()
    }.collectAsState(initial = nsdScanner.state.value.connectPort)

    // Khởi động discovery trên luồng nền sau khi chuyển tab hoàn tất 350ms (đạt chuẩn 120fps không đơ khung hình)
    // Tự động giải phóng 100% tài nguyên mạng và MulticastLock khi rời tab
    LaunchedEffect(isActive, isDirectWlanLive) {
        if (isActive && !isDirectWlanLive) {
            kotlinx.coroutines.delay(350L)
            if (isActive && !shellState.isWirelessAdbConnected) {
                val existingPort = nsdScanner.getBestConnectPort()
                if (existingPort == null) {
                    nsdScanner.startConnectDiscoveryOnly()
                }
            }
        } else {
            if (!com.example.core.adb.AdbPairingNotificationManager.isNotificationPairingActive) {
                nsdScanner.releaseMulticastLock()
                nsdScanner.stopDiscovery(updateStatusText = false)
            }
        }
    }

    DisposableEffect(isActive) {
        onDispose {
            if (!com.example.core.adb.AdbPairingNotificationManager.isNotificationPairingActive) {
                nsdScanner.releaseMulticastLock()
                nsdScanner.stopDiscovery(updateStatusText = false)
            }
        }
    }

    val isShizukuDisabled by remember(context) {
        mutableStateOf(com.example.core.license.LicenseManager.isShizukuConnectionDisabled(context))
    }

    val fullAdbCommand = remember(context.packageName) {
        val pkg = context.packageName
        "adb shell \"pm grant $pkg android.permission.WRITE_SECURE_SETTINGS; pm grant $pkg android.permission.WRITE_SETTINGS; pm grant $pkg android.permission.DUMP; pm grant $pkg android.permission.READ_LOGS; pm grant $pkg android.permission.POST_NOTIFICATIONS; cmd appops set $pkg ACCESS_RESTRICTED_SETTINGS allow; cmd appops set $pkg SYSTEM_ALERT_WINDOW allow; cmd appops set $pkg PROJECT_MEDIA allow;  settings put secure magictune_wlan_activated_forever 1; settings put global magictune_wlan_activated_forever 1; settings put secure magictune_device_adb_permanently_unlocked 1; settings put global magictune_device_adb_permanently_unlocked 1\""
    }

    val lazyListState = rememberLazyListState()

    LazyColumn(
        state = lazyListState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // 1. Thẻ Trạng Thái Dual-Engine Tóm Tắt (Gọn gàng, vẽ trong 0.2ms)
        item(key = "tab5_header_status", contentType = "header_status") {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    if (isDirectWlanLive) liveBorderBrush else idleBorderBrush
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val pillBg = if (isDirectWlanLive) MagicEmerald.copy(alpha = 0.2f) else MagicRose.copy(alpha = 0.2f)
                    val pillColor = if (isDirectWlanLive) MagicEmerald else Color(0xFFFF6B6B)
                    val pillText = if (isDirectWlanLive) {
                        "🟢 ĐÃ KẾT NỐI DIRECT WLAN ADB THÀNH CÔNG • SẴN SÀNG"
                    } else {
                        "🔴 CHƯA KẾT NỐI • KẾT NỐI BẰNG MÃ 6 SỐ HOẶC NỐI NHANH"
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(pillBg)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = pillText,
                            color = pillColor,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicCyan.copy(alpha = 0.22f))
                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Ô #36",
                                color = MagicCyanLight,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                    Text(
                        text = "🔌 Trung Tâm Kết Nối Trực Tiếp (WLAN ADB Mã 6 Số)",
                        color = Color.White,
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "Hệ thống chuẩn hóa 100% sử dụng Kết nối trực tiếp WLAN ADB Mã 6 Số để đảm bảo độ mượt 120 FPS và ổn định tuyệt đối trên MagicOS 10 / 11 & Android 13–17.",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )

                    // Trạng thái trực tiếp của Engine WLAN ADB
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isDirectWlanLive) MagicEmerald.copy(alpha = 0.15f)
                                else Color(0xFF0F172A)
                            )
                            .border(
                                1.dp,
                                if (isDirectWlanLive) MagicEmerald else MagicCyan.copy(alpha = 0.4f),
                                RoundedCornerShape(10.dp)
                            )
                            .clickable { onOpenWlanDialog() }
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "⚡ Trạng Thái: Direct WLAN ADB (Tiêu Chuẩn)",
                                color = if (isDirectWlanLive) MagicEmeraldLight else MagicCyanLight,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = if (isDirectWlanLive) "🟢 Đang kết nối ổn định (Cổng ${shellState.wirelessAdbPort}) • Sẵn sàng chạy lệnh"
                                else if (detectedConnectPort != null) "🟡 Sẵn cổng $detectedConnectPort (Chạm vào đây để kết nối)"
                                else "⚪ Chưa kết nối (Chạm vào đây để ghép nối mã 6 số)",
                                color = if (isDirectWlanLive) MagicEmerald else TextSecondary,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 2. Live Telemetry HUD (Phân tách riêng, độc lập composition)
        if (isDirectWlanLive || detectedConnectPort != null || adbTelemetry.lanIp != null) {
            item(key = "tab5_telemetry_hud", contentType = "telemetry_hud") {
                AdbTelemetryHudCard(
                    telemetry = adbTelemetry,
                    isWirelessConnected = isDirectWlanLive,
                    connectedPort = shellState.wirelessAdbPort,
                    detectedConnectPort = detectedConnectPort,
                    onPing = onPingWlan
                )
            }
        }



        // 4. CÁCH 1: KẾT NỐI TRỰC TIẾP BẰNG MÃ 6 SỐ (Card riêng biệt, 120fps)
        item(key = "tab5_method_1_wlan", contentType = "method_1_wlan") {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (shellState.isWirelessAdbConnected) MagicEmerald.copy(alpha = 0.7f) else MagicCyan.copy(alpha = 0.5f)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicCyan.copy(alpha = 0.22f))
                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Ô #37",
                                color = MagicCyanLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicEmerald.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "SIÊU NHANH • KHUYÊN DÙNG",
                                color = MagicEmeraldLight,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                    Text(
                        text = "⚡ KẾT NỐI TRỰC TIẾP QUA MÃ 6 SỐ",
                        color = MagicCyanLight,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "Kết nối trực tiếp qua Gỡ lỗi Wi-Fi bằng Mã ghép đôi 6 số (nhập nhanh trên thanh Thông báo không cần thoát Cài đặt).",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    if (!shellState.isWirelessAdbConnected) {
                        Button(
                            onClick = {
                                val targetPort = detectedConnectPort
                                if (targetPort != null) onConnectWlanPort(targetPort)
                                else onAutoConnectWlan()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 36.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MagicEmerald,
                                contentColor = Color(0xFF020617)
                            )
                        ) {
                            Text(
                                text = if (detectedConnectPort != null) {
                                    "⚡ BẤM KẾT NỐI NGAY (ĐÃ TỰ TÌM THẤY CỔNG $detectedConnectPort)"
                                } else {
                                    "⚡ TỰ DÒ ĐA TẦNG & KẾT NỐI NGAY (1-CHẠM)"
                                },
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Button(
                        onClick = onOpenWlanDialog,
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (shellState.isWirelessAdbConnected) MagicEmerald else MagicCyan,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(imageVector = Icons.Default.Wifi, contentDescription = null, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = if (shellState.isWirelessAdbConnected) {
                                        "✓ ĐÃ KẾT NỐI TRỰC TIẾP THÀNH CÔNG (CỔNG ${shellState.wirelessAdbPort})"
                                    } else {
                                        "🔑 MỞ BẢNG NHẬP MÃ 6 SỐ ĐỂ KẾT NỐI"
                                    },
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = "Tự động tìm cổng • Nhập PIN trên thanh Thông Báo • Kết nối tức thì",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF020617).copy(alpha = 0.85f),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. LỆNH ADB KHÓA QUYỀN VĨNH VIỄN CHO MÁY TÍNH / LADB (Tách riêng)
        item(key = "tab5_adb_pc_command", contentType = "adb_command") {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, MagicAmber.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "📋 TÙY CHỌN THÊM: DÙNG MÁY TÍNH / LADB (KHÓA VĨNH VIỄN)",
                        color = MagicAmber,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Nếu bạn muốn chạy từ Máy tính qua cáp USB hoặc app LADB/Termux: Bấm nút dưới để sao chép lệnh 1 dòng duy nhất khóa quyền Trợ Năng & Chạy Ngầm vĩnh viễn.",
                        color = TextSecondary,
                        fontSize = 11.5.sp,
                        lineHeight = 16.sp
                    )

                    Button(
                        onClick = {
                            clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(fullAdbCommand))
                            com.example.core.permission.AppPermissionChecker.markWlanActivated(context)
                            android.widget.Toast.makeText(
                                context,
                                "✅ Đã sao chép toàn bộ lệnh ADB khóa quyền vĩnh viễn vào bộ nhớ tạm!",
                                android.widget.Toast.LENGTH_LONG
                            ).show()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 34.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicAmber,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Build,
                                contentDescription = null,
                                tint = Color(0xFF020617),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "📋 SAO CHÉP LỆNH ADB KHÓA VĨNH VIỄN (1 CHẠM)",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
        }



        // Ô #39: Công cụ bảo vệ & chẩn đoán kết nối nâng cao (Tách nhỏ từng item cho LazyColumn - đạt 120fps mượt mà)
        item(key = "tab5_tools_header", contentType = "tools_header") {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(MagicCyan.copy(alpha = 0.22f))
                        .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 7.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "Ô #39",
                        color = MagicCyanLight,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Text(
                    text = "🛡️ Công Cụ Bảo Vệ & Sửa Lỗi Kết Nối Nâng Cao",
                    color = MagicCyanLight,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        item(key = "tab5_tools_diag_row", contentType = "tools_row") {
            Row(
                modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onTestShizukuDiagnostic,
                    modifier = Modifier
                        .fillMaxHeight().weight(1f)
                        .defaultMinSize(minHeight = 36.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MagicSurfaceCard,
                        contentColor = MagicCyan
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Kiểm Tra Kết Nối", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onResetRsaKeys,
                    modifier = Modifier
                        .fillMaxHeight().weight(1f)
                        .defaultMinSize(minHeight = 36.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF450a0a),
                        contentColor = MagicRose
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MagicRose.copy(alpha = 0.5f))
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Làm Mới Khóa RSA", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        item(key = "tab5_tools_protect_row", contentType = "tools_row") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight().weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MagicSurfaceDark)
                        .border(1.dp, MagicBorder, RoundedCornerShape(12.dp))
                        .clickable { onProtectShizuku() }
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "🛡️ Giữ Sống Kết Nối 24/7",
                            color = MagicCyan,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Chống MagicOS tự ngắt Gỡ lỗi Wi-Fi khi tắt màn hình.",
                            color = TextMuted,
                            fontSize = 11.5.sp,
                            lineHeight = 16.sp
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxHeight().weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MagicSurfaceDark)
                        .border(1.dp, MagicEmerald.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .clickable { onUnlockRestrictedSettings() }
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "🔓 Mở Khóa Cài Đặt Bị Mờ",
                            color = MagicEmerald,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Cho phép bật Trợ năng & Thông báo trên Android 13–17.",
                            color = TextMuted,
                            fontSize = 11.5.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }

        item(key = "tab5_tools_diagnostic_card", contentType = "tools_card") {
            AdbDiagnosticReportCard(
                report = adbDiagnosticReport,
                isRunning = isRunningAdbDiagnostics,
                onRunDiagnostics = onRunAdbDiagnostics,
                onResetRsaKeys = onResetRsaKeys
            )
        }

        item(key = "tab5_footer", contentType = "footer") {
            Column(modifier = Modifier.fillMaxWidth()) {
                HonorOptimizationDisclaimerFooter(onNavigateToUniversalFix = onNavigateToUniversalFix)
                Spacer(modifier = Modifier.height(28.dp))
            }
        }
    }
}
