package com.example.core.projection

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.nio.ByteBuffer

/**
 * Kiến Trúc Chiếu / Chụp Màn Hình Công Khai Hợp Lệ KHÔNG DÙNG TRỢ NĂNG (MediaProjection Engine).
 *
 * TỐI ƯU PIN & NHIỆT ĐỘ v5.7:
 * - VirtualDisplay luôn ở trạng thái NGỦ (surface = null, 0 FPS, 0% GPU/SurfaceFlinger) khi không chụp/dịch.
 * - Chỉ gắn surface trong tích tắc khi chụp đơn (captureCurrentScreen) hoặc khi Dịch Cuộn đang bật,
 *   rồi lập tức tách surface (setSurface(null)) ngay sau khi lấy được khung hình.
 * - Toàn bộ callback ImageReader chạy trên HandlerThread nền riêng biệt, không chạm Main Thread.
 */
object MediaProjectionHolder {
    private const val TAG = "MediaProjectionHolder"

    @Volatile
    var mediaProjection: MediaProjection? = null
        private set

    @Volatile
    var isProjectionActive: Boolean = false
        private set

    @Volatile
    var lastCapturedBitmap: Bitmap? = null
        private set

    @Volatile
    var lastCaptureTimeMs: Long = 0L
        private set

    private val stateLock = Any()

    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var screenWidth: Int = 1080
    private var screenHeight: Int = 2400
    private var screenDensity: Int = 440

    private val mainHandler = Handler(Looper.getMainLooper())
    private var projectionThread: HandlerThread? = null
    private var projectionHandler: Handler? = null

    @Volatile
    private var isSurfaceAttached: Boolean = false

    @Volatile
    private var activeOneShotRequests: Int = 0

    @Volatile
    private var pendingCaptureDeferred: CompletableDeferred<Bitmap?>? = null

    // Callback xử lý màn hình liên tục khi người dùng cuộn
    @Volatile
    var onLiveScrollFrameListener: ((Bitmap) -> Unit)? = null

    @Volatile
    var isContinuousScrollModeActive: Boolean = false

    @Volatile
    var hasEverGrantedThisSession: Boolean = false

    private var lastContinuousFrameTimeMs: Long = 0L
    @Volatile
    private var continuousFrameIntervalMs: Long = 480L

    fun hasProjectionPermission(): Boolean = (mediaProjection != null && isProjectionActive) || hasEverGrantedThisSession

    private fun getOrCreateProjectionHandlerLocked(): Handler {
        val existingThread = projectionThread
        val existingHandler = projectionHandler
        if (existingThread != null && existingThread.isAlive && existingHandler != null) {
            return existingHandler
        }
        val newThread = HandlerThread("MagicTuneProjectionDrain").apply { start() }
        val newHandler = Handler(newThread.looper)
        projectionThread = newThread
        projectionHandler = newHandler
        return newHandler
    }

    /**
     * Đồng bộ trạng thái gắn/tách Surface của VirtualDisplay:
     * - Khi cần chụp đơn hoặc đang Dịch Cuộn -> gắn ImageReader.surface để nhận khung hình.
     * - Khi ở trạng thái nghỉ -> setSurface(null) để dừng hoàn toàn luồng phản chiếu GPU/SurfaceFlinger (0 FPS).
     */
    private fun syncVirtualDisplaySurfaceLocked() {
        val vd = virtualDisplay ?: return
        val reader = imageReader
        val shouldAttach = isProjectionActive &&
            reader != null &&
            (isContinuousScrollModeActive || activeOneShotRequests > 0)

        if (shouldAttach && !isSurfaceAttached) {
            val r = reader ?: return
            try {
                drainPendingImagesQuietly(r)
                vd.setSurface(r.surface)
                isSurfaceAttached = true
            } catch (e: Throwable) {
                Log.w(TAG, "Failed to attach VirtualDisplay surface: ${e.message}")
            }
        } else if (!shouldAttach && isSurfaceAttached) {
            try {
                vd.setSurface(null)
            } catch (_: Throwable) {}
            isSurfaceAttached = false
            reader?.let { drainPendingImagesQuietly(it) }
        }
    }

    private fun drainPendingImagesQuietly(reader: ImageReader?) {
        if (reader == null) return
        try {
            while (true) {
                val img = reader.acquireNextImage() ?: break
                try {
                    img.close()
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    /**
     * Khởi tạo MediaProjection sau khi người dùng cấp quyền qua hộp thoại hệ thống.
     * Mặc định VirtualDisplay bắt đầu với surface = null (chế độ tiết kiệm pin 0 FPS).
     */
    fun initProjection(projection: MediaProjection, context: Context) {
        synchronized(stateLock) {
            try {
                cleanupInternal()
                mediaProjection = projection
                isProjectionActive = true
                hasEverGrantedThisSession = true

                val bgHandler = getOrCreateProjectionHandlerLocked()

                // BẮT BUỘC TRÊN ANDROID 14+ (API 34+): Phải đăng ký callback TRƯỚC KHI tạo VirtualDisplay!
                projection.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() {
                        super.onStop()
                        Log.d(TAG, "MediaProjection stopped by system")
                        cleanup()
                    }
                }, mainHandler)

                updateScreenDimensions(context)
                setupVirtualDisplayAndImageReaderLocked(bgHandler)

                Log.d(TAG, "MediaProjection initialized in zero-drain standby (${screenWidth}x$screenHeight, dpi=$screenDensity)")
            } catch (e: Throwable) {
                Log.e(TAG, "Failed to init MediaProjection: ${e.message}", e)
                cleanupInternal()
            }
        }
    }

    private fun updateScreenDimensions(context: Context) {
        var rawW = 1080
        var rawH = 2400
        var rawDpi = 440
        try {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            if (wm != null) {
                val dm = DisplayMetrics()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val metrics = wm.currentWindowMetrics
                    val bounds = metrics.bounds
                    rawW = bounds.width().coerceAtLeast(480)
                    rawH = bounds.height().coerceAtLeast(800)
                    rawDpi = context.resources.configuration.densityDpi
                } else {
                    @Suppress("DEPRECATION")
                    wm.defaultDisplay.getRealMetrics(dm)
                    rawW = dm.widthPixels.coerceAtLeast(480)
                    rawH = dm.heightPixels.coerceAtLeast(800)
                    rawDpi = dm.densityDpi
                }
            }
        } catch (_: Throwable) {
            val dm = context.resources.displayMetrics
            rawW = dm.widthPixels.coerceAtLeast(480)
            rawH = dm.heightPixels.coerceAtLeast(800)
            rawDpi = dm.densityDpi
        }
        val scale = if (rawW >= 900) com.example.core.compat.DeviceCompatProfile.recommendedProjectionScale(context) else 1.0f
        screenWidth = (rawW * scale).toInt().coerceAtLeast(480)
        screenHeight = (rawH * scale).toInt().coerceAtLeast(800)
        screenDensity = (rawDpi * scale).toInt().coerceAtLeast(160)
    }

    private fun setupVirtualDisplayAndImageReaderLocked(bgHandler: Handler) {
        val proj = mediaProjection ?: return

        val reader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        imageReader = reader

        reader.setOnImageAvailableListener({ ir ->
            try {
                val image = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val now = System.currentTimeMillis()

                    // 1. Phục vụ yêu cầu chụp đơn (One-Shot Capture) cho Khoanh tròn hỏi AI / Dịch tĩnh
                    val deferred = pendingCaptureDeferred
                    if (deferred != null && !deferred.isCompleted) {
                        val bmp = imageToBitmap(image)
                        if (bmp != null) {
                            val old = lastCapturedBitmap
                            lastCapturedBitmap = bmp
                            lastCaptureTimeMs = now
                            if (old != null && old !== bmp && !old.isRecycled &&
                                !com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive
                            ) {
                                try { old.recycle() } catch (_: Throwable) {}
                            }
                            deferred.complete(bmp)
                            return@setOnImageAvailableListener
                        }
                    }

                    // 2. Phục vụ chế độ Cuộn Đến Đâu Dịch Đến Đó (Continuous Scroll Mode)
                    if (isContinuousScrollModeActive) {
                        if (now - lastContinuousFrameTimeMs >= continuousFrameIntervalMs) {
                            lastContinuousFrameTimeMs = now
                            val bmp = imageToBitmap(image)
                            if (bmp != null) {
                                val listener = onLiveScrollFrameListener
                                if (listener != null) {
                                    listener.invoke(bmp)
                                } else if (!bmp.isRecycled) {
                                    try { bmp.recycle() } catch (_: Throwable) {}
                                }
                            }
                        }
                    }
                } finally {
                    image.close()
                }
            } catch (_: Throwable) {}
        }, bgHandler)

        // Tạo VirtualDisplay với surface = null để SurfaceFlinger KHÔNG dựng hình 60-120 FPS khi app đang nghỉ!
        virtualDisplay = proj.createVirtualDisplay(
            "MagicTuneScreenCapture",
            screenWidth,
            screenHeight,
            screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            null,
            null,
            bgHandler
        )
        isSurfaceAttached = false
        syncVirtualDisplaySurfaceLocked()
    }

    /**
     * Chụp nhanh khung hình hiện tại từ MediaProjection theo cơ chế On-Demand (~15-35ms).
     * Tự động gắn Surface lúc chụp và lập tức tách Surface (0 FPS) ngay khi hoàn tất.
     */
    suspend fun captureCurrentScreen(context: Context, timeoutMs: Long = 650L): Bitmap? = withContext(Dispatchers.IO) {
        if (mediaProjection == null || !isProjectionActive || imageReader == null) {
            return@withContext null
        }

        // 1. Nếu vừa chụp cách đây dưới 220ms và cache còn hợp lệ, trả về ngay (0ms)
        val now = System.currentTimeMillis()
        val cached = lastCapturedBitmap
        if (cached != null && !cached.isRecycled && (now - lastCaptureTimeMs < 220L)) {
            return@withContext cached
        }

        val deferred = CompletableDeferred<Bitmap?>()
        synchronized(stateLock) {
            if (mediaProjection == null || !isProjectionActive || imageReader == null) {
                return@withContext null
            }
            activeOneShotRequests++
            pendingCaptureDeferred = deferred
            syncVirtualDisplaySurfaceLocked()
        }

        return@withContext try {
            // Đợi khung hình tươi từ SurfaceFlinger sau khi gắn surface
            val result = withTimeoutOrNull(timeoutMs) {
                deferred.await()
            }
            if (result != null) {
                result
            } else {
                // Dự phòng đọc ngay khung hình cuối cùng nếu listener vừa nhận kịp sát timeout
                val reader = synchronized(stateLock) { imageReader }
                val immediateImage = try { reader?.acquireLatestImage() } catch (_: Throwable) { null }
                if (immediateImage != null) {
                    try {
                        imageToBitmap(immediateImage)?.also { bmp ->
                            val old = lastCapturedBitmap
                            lastCapturedBitmap = bmp
                            lastCaptureTimeMs = System.currentTimeMillis()
                            if (old != null && old !== bmp && !old.isRecycled &&
                                !com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive
                            ) {
                                try { old.recycle() } catch (_: Throwable) {}
                            }
                        }
                    } finally {
                        immediateImage.close()
                    }
                } else {
                    val freshCache = lastCapturedBitmap
                    if (freshCache != null && !freshCache.isRecycled && (System.currentTimeMillis() - lastCaptureTimeMs < 1500L)) {
                        freshCache
                    } else null
                }
            }
        } finally {
            synchronized(stateLock) {
                if (pendingCaptureDeferred === deferred) {
                    pendingCaptureDeferred = null
                }
                activeOneShotRequests = (activeOneShotRequests - 1).coerceAtLeast(0)
                syncVirtualDisplaySurfaceLocked()
            }
        }
    }

    /**
     * Bật chế độ lắng nghe khung hình liên tục khi người dùng cuộn (gắn Surface khi đang dịch cuộn).
     */
    fun startContinuousScrollMode(context: Context, onFrame: (Bitmap) -> Unit) {
        synchronized(stateLock) {
            continuousFrameIntervalMs = com.example.core.compat.DeviceCompatProfile.recommendedContinuousProjectionIntervalMs(context)
            onLiveScrollFrameListener = onFrame
            isContinuousScrollModeActive = true
            lastContinuousFrameTimeMs = 0L
            syncVirtualDisplaySurfaceLocked()
        }
    }

    /**
     * Tắt chế độ lắng nghe khung hình liên tục (tách Surface ngay lập tức -> 0 FPS).
     */
    fun stopContinuousScrollMode() {
        synchronized(stateLock) {
            isContinuousScrollModeActive = false
            onLiveScrollFrameListener = null
            syncVirtualDisplaySurfaceLocked()
        }
    }

    /**
     * Đảm bảo tách Surface ngay lập tức khi tắt màn hình hoặc chuyển sang trạng thái nghỉ.
     */
    fun pauseSurfaceIfIdle() {
        synchronized(stateLock) {
            if (!isContinuousScrollModeActive && activeOneShotRequests <= 0) {
                syncVirtualDisplaySurfaceLocked()
                val stale = lastCapturedBitmap
                lastCapturedBitmap = null
                lastCaptureTimeMs = 0L
                if (stale != null && !stale.isRecycled &&
                    !com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive
                ) {
                    try { stale.recycle() } catch (_: Throwable) {}
                }
            }
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        return try {
            val planes = image.planes
            val buffer: ByteBuffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * image.width

            val bitmap = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)

            if (rowPadding == 0) {
                bitmap
            } else {
                val cropped = Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
                if (cropped !== bitmap) {
                    bitmap.recycle()
                }
                cropped
            }
        } catch (e: Throwable) {
            Log.e(TAG, "imageToBitmap conversion failed: ${e.message}")
            null
        }
    }

    fun cleanup() {
        synchronized(stateLock) {
            cleanupInternal()
        }
    }

    /**
     * Release the projection session after the last screen-reading UI has gone away.
     * A projection may be left initialized after an on-demand screenshot even though
     * its surface is detached; stopping it here also prevents stale service/session
     * state from surviving a dismissed feature.
     */
    fun releaseIfNoActiveConsumer(context: Context) {
        if (com.example.core.widget.GoogleLiveTranslateOverlay.isRunning ||
            com.example.core.widget.CircleToSearchWindowOverlay.isShowing ||
            com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive ||
            com.example.core.widget.MagicLiveFloatingOverlay.isShowing
        ) return

        stopContinuousScrollMode()
        cleanup()
        com.example.core.service.MagicTuneMediaProjectionService.stop(context.applicationContext ?: context)
    }

    private fun cleanupInternal() {
        isProjectionActive = false
        hasEverGrantedThisSession = false
        isContinuousScrollModeActive = false
        activeOneShotRequests = 0
        isSurfaceAttached = false
        onLiveScrollFrameListener = null
        pendingCaptureDeferred?.complete(null)
        pendingCaptureDeferred = null
        val oldBmp = lastCapturedBitmap
        lastCapturedBitmap = null
        lastCaptureTimeMs = 0L
        if (oldBmp != null && !oldBmp.isRecycled &&
            !com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive
        ) {
            try { oldBmp.recycle() } catch (_: Throwable) {}
        }
        try { virtualDisplay?.setSurface(null) } catch (_: Throwable) {}
        try { virtualDisplay?.release() } catch (_: Throwable) {}
        virtualDisplay = null
        try { imageReader?.setOnImageAvailableListener(null, null) } catch (_: Throwable) {}
        try { imageReader?.close() } catch (_: Throwable) {}
        imageReader = null
        try { mediaProjection?.stop() } catch (_: Throwable) {}
        mediaProjection = null
        try { projectionThread?.quitSafely() } catch (_: Throwable) {}
        projectionThread = null
        projectionHandler = null
    }
}
