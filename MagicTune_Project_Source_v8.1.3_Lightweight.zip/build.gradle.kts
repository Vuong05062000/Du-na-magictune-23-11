import java.io.File
import java.util.Properties
import java.util.UUID
import java.util.zip.ZipFile

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.google.devtools.ksp)
    alias(libs.plugins.secrets)
    alias(libs.plugins.google.services)
}

val releaseSigningPropertiesPath = System.getenv("MAGICTUNE_SIGNING_PROPERTIES")
val releaseSigningPropertiesFile = releaseSigningPropertiesPath?.let(::File)?.takeIf { it.isFile }
    ?: rootProject.file("keystore.properties").takeIf { it.isFile }
val releaseSigningProperties = Properties().apply {
    releaseSigningPropertiesFile?.inputStream()?.use(::load)
}
val configuredReleaseKeyStore = releaseSigningPropertiesFile?.let { propertiesFile ->
    val keyStorePath = releaseSigningProperties.getProperty("storeFile")
    keyStorePath?.let { File(propertiesFile.parentFile, it) }
}
if (configuredReleaseKeyStore == null) {
    println("WARNING: No keystore.properties found — the release build will be signed with debug.keystore (NOT a production certificate).")
    println("         Create keystore.properties + a real keystore for a full-certificate release APK.")
}

android {
    namespace = "com.example"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.magictune.tool"
        minSdk = 24
        targetSdk = 36
        versionCode = 142
        versionName = "8.1.3"

        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86_64")
        }

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        buildConfigField("String", "ADMIN_EMAIL", "\"vuongdhkmhn@gmail.com\"")
        buildConfigField("String", "ADMIN_PHONE", "\"0393368007\"")
        buildConfigField("String", "PRO_SECRET_SALT", "\"MagicTunePro_SecretSalt_2026_VVuong_0393368007\"")
        buildConfigField("String", "PRO_ACCOUNT_SALT", "\"MagicTuneAccountPro_Salt_2026_VVuong_0393368007\"")
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }

    signingConfigs {
        create("release") {
            storeFile = configuredReleaseKeyStore ?: file("${rootDir}/debug.keystore")
            storePassword = releaseSigningProperties.getProperty("storePassword", "android")
            keyAlias = releaseSigningProperties.getProperty("keyAlias", "androiddebugkey")
            keyPassword = releaseSigningProperties.getProperty("keyPassword", "android")
            enableV1Signing = true
            enableV2Signing = true
            enableV3Signing = true
            enableV4Signing = false
        }
        create("debugConfig") {
            storeFile = file("${rootDir}/debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
            enableV1Signing = true
            enableV2Signing = true
            enableV3Signing = true
            enableV4Signing = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            signingConfig = signingConfigs.getByName("debugConfig")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    sourceSets {
        getByName("main") {
            manifest.srcFile("AndroidManifest.xml")
            java.srcDirs("src/main/java")
            res.srcDirs("res")
        }
        getByName("test") {
            java.srcDirs("src/test/java")
        }
    }
}

secrets {
    propertiesFileName = ".env"
    defaultPropertiesFileName = ".env.example"
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.profileinstaller)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.activity.compose)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.core)
    implementation(files("libs/material-icons-subset.jar"))
    implementation(libs.androidx.navigation.compose)

    implementation(libs.shizuku.api)
    implementation(libs.shizuku.provider)

    implementation(libs.coil.compose)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.play.services.location)

    // Firebase
    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.ai)
    implementation(libs.firebase.appcheck.recaptcha)
    implementation(libs.firebase.appcheck.debug)
    implementation(libs.firebase.firestore)
    implementation(libs.firebase.auth)
    implementation(libs.androidx.credentials)
    implementation(libs.androidx.credentials.play.services)
    implementation(libs.googleid)

    // ADB Direct WLAN & TLS
    implementation(libs.libadb.android)
    // implementation(libs.sun.security.android) // Đã thay bằng chuẩn ASN.1 DER X.509v3 thuần túy để tránh lỗi X500Name trên ART
    implementation(libs.conscrypt.android)

    // ML Kit
    implementation(libs.mlkit.text.recognition)
    implementation(libs.mlkit.text.recognition.chinese)

    // Tests
    testImplementation(libs.junit)
    testImplementation(libs.robolectric)
    testImplementation(libs.androidx.junit)
    testImplementation(libs.androidx.core)
    testImplementation(libs.kotlinx.coroutines.test)
}

configurations.matching { it.name.contains("UnitTest") }.configureEach {
    exclude(group = "org.conscrypt", module = "conscrypt-android")
}

fun findApksignerBinary(sdkDir: File): File? {
    val buildToolsDir = File(sdkDir, "build-tools")
    val dirs = buildToolsDir.listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.name } ?: return null
    val isWindows = System.getProperty("os.name").contains("Windows", ignoreCase = true)
    for (dir in dirs) {
        val candidate = File(dir, if (isWindows) "apksigner.bat" else "apksigner")
        if (candidate.isFile && (isWindows || candidate.canExecute())) return candidate
    }
    return null
}

fun ensureV1V2V3Signed(
    apkFile: File,
    keystoreFile: File,
    keyAlias: String,
    storePassword: String,
    keyPassword: String,
    apksigner: File?
) {
    if (!apkFile.exists()) return
    if (!keystoreFile.isFile) throw GradleException("Signing keystore not found: ${keystoreFile.absolutePath}")
    if (apksigner == null) throw GradleException("Android SDK apksigner was not found")
    // cmd/Java on Windows can lose Unicode characters in the original keystore path.
    // Sign from an ASCII-only temporary copy and remove it as soon as signing finishes.
    val temporaryKeystore = File(
        System.getProperty("java.io.tmpdir"),
        "magictune-signing-${UUID.randomUUID()}.jks"
    )
    keystoreFile.copyTo(temporaryKeystore, overwrite = true)
    val command = mutableListOf<String>()
    if (System.getProperty("os.name").contains("Windows", ignoreCase = true)) {
        command.add(File(System.getProperty("java.home"), "bin/java.exe").absolutePath)
        command.add("-jar")
        command.add(File(apksigner.parentFile, "lib/apksigner.jar").absolutePath)
    } else {
        command.add(File(System.getProperty("java.home"), "bin/java").absolutePath)
        command.add("-jar")
        command.add(File(apksigner.parentFile, "lib/apksigner.jar").absolutePath)
    }
    command.addAll(listOf(
        "sign",
        "--ks", temporaryKeystore.absolutePath,
        "--ks-key-alias", keyAlias,
        "--ks-pass", "pass:$storePassword",
        "--key-pass", "pass:$keyPassword",
        "--min-sdk-version", "24",
        "--v1-signing-enabled", "true",
        "--v2-signing-enabled", "true",
        "--v3-signing-enabled", "true",
        "--v4-signing-enabled", "false",
        apkFile.absolutePath
    ))
    try {
        val proc = ProcessBuilder(command).redirectErrorStream(true).start()
        val output = proc.inputStream.bufferedReader().readText()
        val exit = proc.waitFor()
        if (exit != 0) {
            throw GradleException("apksigner v1/v2/v3 failed (exit=$exit): $output")
        }
    } finally {
        temporaryKeystore.delete()
    }
}

fun hasV1Signature(apkFile: File): Boolean = try {
    ZipFile(apkFile).use { zip ->
        zip.entries().asSequence().any { entry ->
            val name = entry.name.uppercase()
            name.startsWith("META-INF/") && (name.endsWith(".RSA") || name.endsWith(".DSA") || name.endsWith(".EC"))
        }
    }
} catch (_: Exception) { false }

tasks.matching {
    it.name == "packageDebug" || it.name == "assembleDebug" ||
        it.name == "packageRelease" || it.name == "assembleRelease"
}.configureEach {
    val taskName = name
    val sdkRoot = System.getenv("ANDROID_SDK_ROOT")?.let { file(it) }
        ?: System.getenv("ANDROID_HOME")?.let { file(it) }
        ?: file("/opt/android/sdk")
    val keystoreFile = file("${rootDir}/debug.keystore")
    val releaseKeystoreFile = configuredReleaseKeyStore ?: keystoreFile
    val releaseStorePassword = releaseSigningProperties.getProperty("storePassword", "android")
    val releaseKeyAlias = releaseSigningProperties.getProperty("keyAlias", "androiddebugkey")
    val releaseKeyPassword = releaseSigningProperties.getProperty("keyPassword", "android")
    val rootProjectDir = rootDir

    doLast {
        val apksigner = findApksignerBinary(sdkRoot)
        if (taskName == "packageDebug" || taskName == "assembleDebug") {
            val debugDir = layout.buildDirectory.file("outputs/apk/debug").get().asFile
            val debugApk = debugDir.listFiles()?.firstOrNull { it.extension == "apk" && !it.name.contains("unaligned") }
                ?: File(debugDir, "app-debug.apk")
            if (debugApk.exists()) {
                ensureV1V2V3Signed(debugApk, keystoreFile, "androiddebugkey", "android", "android", apksigner)

                val apkFileName = "MagicTune_Tool_v8.1.0_CapNhatTrongApp.apk"
                debugApk.copyTo(File(rootProjectDir, apkFileName), overwrite = true)

                val exportsDir = File(rootProjectDir, "public/exports")
                if (exportsDir.exists() || exportsDir.mkdirs()) {
                    debugApk.copyTo(File(exportsDir, apkFileName), overwrite = true)
                }
            }
        }
    }
}

tasks.register("signReleaseV1V2V3") {
    doLast {
        val sdkRoot = System.getenv("ANDROID_SDK_ROOT")?.let { file(it) }
            ?: System.getenv("ANDROID_HOME")?.let { file(it) }
            ?: file("/opt/android/sdk")
        val apksigner = findApksignerBinary(sdkRoot)
        val releaseDir = layout.buildDirectory.file("outputs/apk/release").get().asFile
        val releaseApk = releaseDir.listFiles()?.firstOrNull { it.extension == "apk" && !it.name.contains("unaligned") }
            ?: File(releaseDir, "app-release.apk")
        ensureV1V2V3Signed(
            releaseApk,
            configuredReleaseKeyStore ?: file("${rootDir}/debug.keystore"),
            releaseSigningProperties.getProperty("keyAlias", "androiddebugkey"),
            releaseSigningProperties.getProperty("storePassword", "android"),
            releaseSigningProperties.getProperty("keyPassword", "android"),
            apksigner
        )
        val javaBinary = if (System.getProperty("os.name").contains("Windows", ignoreCase = true)) "java.exe" else "java"
        val verifierCommand = listOf(
            File(System.getProperty("java.home"), "bin/$javaBinary").absolutePath,
            "-jar",
            File(apksigner!!.parentFile, "lib/apksigner.jar").absolutePath,
            "verify",
            "--verbose",
            "--min-sdk-version",
            "23",
            releaseApk.absolutePath
        )
        val verifier = ProcessBuilder(verifierCommand).redirectErrorStream(true).start()
        val verificationOutput = verifier.inputStream.bufferedReader().readText()
        val verificationExit = verifier.waitFor()
        val requiredSchemeReports = listOf(
            "Verified using v1 scheme (JAR signing): true",
            "Verified using v2 scheme (APK Signature Scheme v2): true",
            "Verified using v3 scheme (APK Signature Scheme v3): true"
        )
        if (verificationExit != 0 || requiredSchemeReports.any { !verificationOutput.contains(it) }) {
            throw GradleException("Release APK failed v1/v2/v3 signature verification: $verificationOutput")
        }
        releaseApk.copyTo(File(rootDir, "MagicTune_Tool_v8.1.0_CapNhatTrongApp.apk"), overwrite = true)
        releaseApk.copyTo(File(rootDir, "MagicTune_Tool_v8.1.0.apk"), overwrite = true)
        releaseApk.copyTo(File(rootDir, "MagicTune_Tool_v8.0.28_CapNhatTrongApp.apk"), overwrite = true)
        releaseApk.copyTo(File(rootDir, "MagicTune_Tool_v8.0.28.apk"), overwrite = true)
    }
}

tasks.matching { it.name == "assembleRelease" }.configureEach {
    finalizedBy("signReleaseV1V2V3")
}

tasks.withType<JavaCompile>().configureEach {
    enabled = false
}


