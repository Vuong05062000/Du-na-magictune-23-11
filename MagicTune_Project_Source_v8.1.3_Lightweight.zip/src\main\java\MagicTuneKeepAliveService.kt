package com.example.core.service

import android.app.Notification
import android.app.AlarmManager
import android.app.PendingIntent
import android.os.SystemClock
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.BatteryManager
import android.os.PowerManager
import android.provider.Settings
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.core.widget.AppSearchActivity
import com.example.core.widget.BatteryInfoReader
import com.example.core.widget.BatteryChargeData
import com.example.core.widget.MagicTuneBatteryWidgetProvider
import com.example.core.widget.MagicTuneMemoryWidgetProvider
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import java.util.Locale

class MagicTuneKeepAliveService : Service() {

    private var liveBatteryReceiver: BroadcastReceiver? = null
    private var screenStateReceiver: BroadcastReceiver? = null
    private var wasFullyChargedNotified = false

    private var overlayKeepAliveWakeLock: PowerManager.WakeLock? = null

    @Volatile
    private var isCurrentlyInBanking: Boolean = false

    // Scope nền chuyên biệt để đọc sysfs pin, cập nhật Widget và UsageStats mà không bao giờ gây khựng Main Thread (120Hz/144Hz)
    private val serviceScope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.SupervisorJob() +
            kotlinx.coroutines.Dispatchers.IO +
            com.example.MagicTuneApplication.globalCoroutineExceptionHandler
    )

    // Event watcher only while a screen overlay or an active accessibility feature is in use.
    private val loopHandler = Handler(Looper.getMainLooper())

@Volatile
    private var lastObservedFgPkgForTicker: String? = null

    @Volatile
    private var cachedHasHomeWidgets: Boolean = false

    // Cache UsageStats results: poll getActiveForegroundPackage() tối đa 1 lần / 30s.
    // Mỗi cycle ticker khác không poll lại nếu cache còn mới — giảm 80-90% wakelock từ UsageStats API.
    @Volatile
    private var cachedForegroundPackage: String? = null
    private var lastUsageStatsPollMs: Long = 0L
    private val usageStatsCacheMs: Long = 30_000L // 30s cache TTL

    @Volatile
    private var lastHomeWidgetLookupMs: Long = 0L

    private fun hasAnyHomeWidgets(context: Context): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (now - lastHomeWidgetLookupMs < 60_000L && lastHomeWidgetLookupMs > 0L) {
            return cachedHasHomeWidgets
        }
        return try {
            val mgr = AppWidgetManager.getInstance(context)
            val hasAny = mgr.getAppWidgetIds(ComponentName(context, MagicTuneBatteryWidgetProvider::class.java)).isNotEmpty() ||
                mgr.getAppWidgetIds(ComponentName(context, com.example.core.widget.MagicTuneSimpleBatteryWidgetProvider::class.java)).isNotEmpty() ||
                mgr.getAppWidgetIds(ComponentName(context, MagicTuneMemoryWidgetProvider::class.java)).isNotEmpty() ||
                mgr.getAppWidgetIds(ComponentName(context, com.example.core.widget.MagicTuneAppSearchWidgetProvider::class.java)).isNotEmpty() ||
                mgr.getAppWidgetIds(ComponentName(context, com.example.core.widget.MagicTunePerpetualCalendarWidgetProvider::class.java)).isNotEmpty()
            cachedHasHomeWidgets = hasAny
            lastHomeWidgetLookupMs = now
            hasAny
        } catch (_: Throwable) {
            false
        }
    }

    private val realtimeTickerRunnable = object : Runnable {
        override fun run() {
            val self = this
            val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
            val isScreenInteractive = pm?.isInteractive ?: true
            val isVoiceOrSpeechActive = com.example.core.widget.MagicLiveFloatingOverlay.isVoiceOrSpeechActive()
            val isLiveScrollActive = com.example.core.service.NoAccessibilityScreenEngine.isLiveScrollTranslateActive &&
                com.example.core.widget.GoogleLiveTranslateOverlay.isRunning
            val isHeavyStreamingOverlay = isVoiceOrSpeechActive || isLiveScrollActive
            val isAnyOverlayRunning = isHeavyStreamingOverlay ||
                com.example.core.widget.GoogleLiveTranslateOverlay.isRunning ||
                com.example.core.widget.MagicLiveFloatingOverlay.isShowing ||
                com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive ||
                com.example.core.widget.CircleToSearchWindowOverlay.isShowing

            if (!isScreenInteractive) {
                try { com.example.core.widget.GoogleLiveTranslateOverlay.stop(applicationContext) } catch (_: Throwable) {}
                try { com.example.core.widget.CircleToSearchWindowOverlay.dismiss(applicationContext) } catch (_: Throwable) {}
                try { com.example.core.widget.MagicLiveFloatingOverlay.onDeviceScreenOff(applicationContext) } catch (_: Throwable) {}
                syncOverlayKeepAliveWakeLock(false)
                loopHandler.removeCallbacks(self)
                return
            }

            // Giữ CPU WakeLock nhẹ CHỈ khi màn hình sáng VÀ đang thu âm / đọc giọng nói AI Live (tối đa 60s)
            syncOverlayKeepAliveWakeLock(isScreenInteractive && isVoiceOrSpeechActive)
            // Tự động gỡ thông báo nền ngay khi phiên giọng nói kết thúc và người dùng không bật thanh tìm kiếm / sạc pin
            if (isForegroundActive &&
                !isVoiceOrSpeechActive &&
                !isSearchNotificationEnabled(applicationContext) &&
                !isChargingNotificationEnabled(applicationContext)
            ) {
                demoteForegroundAndHideNotification()
            }

            if (isScreenInteractive || isVoiceOrSpeechActive) {
                // Nếu người dùng đang trực tiếp chạm/cuộn trang bên trong MainActivity của MagicTune,
                // tạm hoãn công việc nền để ưu tiên thao tác giao diện.
                if (!isHeavyStreamingOverlay &&
                    com.example.core.perf.MagicTuneSelfPowerGovernor.isUserActivelyInteractingInApp()
                ) {
                    loopHandler.removeCallbacks(self)
                    loopHandler.postDelayed(self, 3_500L)
                    return
                }

                val navBridgeActive = SystemFloatingHudOverlay.isNavBridgeConfiguredActive(applicationContext)
                val a11yFeatureActive = MagicTuneCtsAccessibilityService.isServiceConnected() &&
                    MagicTuneCtsAccessibilityService.isAnyFeatureActive()
                // During live scroll the active accessibility service already receives window-state
                // events and identifies banking apps immediately. Avoid a second UsageStats query
                // every ticker cycle while that event stream is available.
                val liveScrollEventsAvailable = isLiveScrollActive && MagicTuneCtsAccessibilityService.isServiceConnected()
                val shouldPollForeground = (isAnyOverlayRunning || a11yFeatureActive) && !liveScrollEventsAvailable

                serviceScope.launch {
                    try {
if (shouldPollForeground) {
                            // Cache UsageStats: chỉ poll thực tế mỗi 30s; các cycle khác dùng cache
                            val nowMs = SystemClock.elapsedRealtime()
                            if (cachedForegroundPackage == null || nowMs - lastUsageStatsPollMs > usageStatsCacheMs) {
                                cachedForegroundPackage = NoAccessibilityScreenEngine.getActiveForegroundPackage(applicationContext)
                                lastUsageStatsPollMs = nowMs
                            }
                            val currentPkg = cachedForegroundPackage
                            val isBanking = currentPkg != null && NoAccessibilityScreenEngine.isSensitiveBankingPackage(currentPkg)
                            val isInSettings = currentPkg != null && MagicTuneCtsAccessibilityService.isSystemSettingsPackage(currentPkg)
                            val wasInBanking = isCurrentlyInBanking
                            isCurrentlyInBanking = isBanking

                            if (isBanking && !wasInBanking) {
                                MagicTuneCtsAccessibilityService.forceDisableServiceNow(applicationContext)
                                NoAccessibilityScreenEngine.notifyBankingTransition(applicationContext, enteredBanking = true)
                                SystemFloatingHudOverlay.showSecurityPill(applicationContext, currentPkg ?: "")
                            } else if (isInSettings) {
                                MagicTuneCtsAccessibilityService.disableServiceViaSecureSettings(
                                    applicationContext,
                                    forceRemoveFromSettings = true,
                                    isBankingBlock = false
                                )
                            } else if (!isBanking && wasInBanking) {
                                MagicTuneCtsAccessibilityService.resetAutoHiddenFlagIfSafe(applicationContext)
                                SystemFloatingHudOverlay.hideSecurityPill(applicationContext)
                                NoAccessibilityScreenEngine.notifyBankingTransition(applicationContext, enteredBanking = false)
                            }

                            val fgChanged = currentPkg != lastObservedFgPkgForTicker
                            if (fgChanged) {
                                lastObservedFgPkgForTicker = currentPkg
                            }
                            if (fgChanged || isVoiceOrSpeechActive) {
                                SystemFloatingHudOverlay.interceptYoyoIfForeground(applicationContext, currentPkg)
                                if (fgChanged) {
                                    SystemFloatingHudOverlay.checkAndUpdateNavBarVisibility(applicationContext, currentPkg)
                                }
                            }
                        } else {
                            isCurrentlyInBanking = false
                            lastObservedFgPkgForTicker = null
                        }

                        val observedPkg = lastObservedFgPkgForTicker
                        // Dọn Secure Settings & khóa Component DISABLED khi nhàn rỗi hoặc khi đang mở Cài đặt / Ngân hàng
                        if (shouldPollForeground && (!MagicTuneCtsAccessibilityService.isAnyFeatureActive() ||
                            isCurrentlyInBanking ||
                            (observedPkg != null && MagicTuneCtsAccessibilityService.isSystemSettingsPackage(observedPkg))
                        )) {
                            MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(applicationContext)
                        }
                    } finally {
                        val currentPm = getSystemService(Context.POWER_SERVICE) as? PowerManager
                        val stillInteractive = currentPm?.isInteractive ?: true
                        val voiceActiveNow = com.example.core.widget.MagicLiveFloatingOverlay.isVoiceOrSpeechActive()
                        val liveScrollActiveNow = com.example.core.service.NoAccessibilityScreenEngine.isLiveScrollTranslateActive &&
                            com.example.core.widget.GoogleLiveTranslateOverlay.isRunning
                        val passiveOverlayActiveNow = com.example.core.widget.GoogleLiveTranslateOverlay.isRunning ||
                            com.example.core.widget.MagicLiveFloatingOverlay.isShowing ||
                            com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive ||
                            com.example.core.widget.CircleToSearchWindowOverlay.isShowing
                        loopHandler.removeCallbacks(self)
                        if (!needsToRun(applicationContext)) {
                            stopSelf()
                            return@launch
                        }
                        if (!stillInteractive) {
                            try { com.example.core.widget.GoogleLiveTranslateOverlay.stop(applicationContext) } catch (_: Throwable) {}
                            try { com.example.core.widget.CircleToSearchWindowOverlay.dismiss(applicationContext) } catch (_: Throwable) {}
                            try { com.example.core.widget.MagicLiveFloatingOverlay.onDeviceScreenOff(applicationContext) } catch (_: Throwable) {}
                            syncOverlayKeepAliveWakeLock(false)
                            loopHandler.removeCallbacks(self)
                            return@launch
                        }
if (stillInteractive && needsRealtimeTicker()) {
                            val navActiveNow = SystemFloatingHudOverlay.isNavBridgeConfiguredActive(applicationContext)
                            val isLowEndDevice = com.example.core.compat.DeviceCompatProfile.isLowEndOrLegacyDevice(applicationContext)
                            val a11yActiveNow = MagicTuneCtsAccessibilityService.isServiceConnected() ||
                                MagicTuneCtsAccessibilityService.isServiceEnabledInSettings(applicationContext)
                            val baseDelay = when {
                                voiceActiveNow -> if (isLowEndDevice) 10_000L else 8_000L
                                liveScrollActiveNow -> if (isLowEndDevice) 18_000L else 14_000L
                                passiveOverlayActiveNow -> if (isLowEndDevice) 30_000L else 20_000L
                                isCurrentlyInBanking -> if (isLowEndDevice) 12_000L else 8_000L
                                a11yActiveNow -> if (isLowEndDevice) 30_000L else 20_000L
                                navActiveNow -> if (isLowEndDevice) 300_000L else 240_000L // Giãn nhịp ngủ sâu 4-5 phút siêu mát
                                else -> if (isLowEndDevice) 900_000L else 1_200_000L // Nhàn rỗi: Ngủ sâu 15-20 phút (0% nhiệt CPU)
                            }
                            val powerMultiplier = com.example.core.perf.MagicTuneSelfPowerGovernor.getTickerCadenceMultiplier(applicationContext)
                            val minimumDelay = when {
                                voiceActiveNow -> 8_000L
                                liveScrollActiveNow -> 12_000L
                                else -> 2_500L
                            }
                            val nextDelay = (baseDelay * powerMultiplier).toLong().coerceAtLeast(minimumDelay)
                            // Khi ở trạng thái nhàn rỗi tuyệt đối (không overlay, không voice, không a11y, không nav):
                            // DỪNG ticker hoàn toàn thay vì postDelayed. Sẽ chỉ restart khi có sự kiện (screen on, notification, overlay start).
                            val isIdle = !voiceActiveNow && !liveScrollActiveNow && !passiveOverlayActiveNow &&
                                !isCurrentlyInBanking && !a11yActiveNow && !navActiveNow
                            if (isIdle) {
                                loopHandler.removeCallbacks(self)
                                // KHÔNG repost: chờ sự kiện để restart (tiết kiệm pin tối đa)
                            } else {
                                loopHandler.postDelayed(self, nextDelay)
                            }
                        }
                    }
                }
            } else {
                // Khi màn hình TẮT và không mở overlay: Dọn dẹp Trợ năng 1 lần và NGỪNG hẳn bộ đếm để máy ngủ sâu 100%
                isCurrentlyInBanking = false
                lastObservedFgPkgForTicker = null
                MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(applicationContext)
                loopHandler.removeCallbacks(this)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        if (com.example.core.crash.CrashBlackBox.isFirestoreOomRecoveryRequired(applicationContext)) {
            isServiceRunning = false
            stopSelf()
            return
        }
        isServiceRunning = true
        instanceRef = java.lang.ref.WeakReference(this)
        createNotificationChannels()
        // Chỉ giữ đăng ký listener nhẹ trên Main Thread để tuyệt đối không gây ANR khi đồng khởi động cùng MainActivity
        registerLiveBatteryListener()
        registerScreenStateListener()
        startRealtimeWidgetTicker()

        serviceScope.launch {
            try { BatteryInfoReader.restorePersistedState(applicationContext) } catch (_: Throwable) {}
            try { MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(applicationContext) } catch (_: Throwable) {}
        }
    }

    private fun syncOverlayKeepAliveWakeLock(shouldHold: Boolean) {
        try {
            if (shouldHold) {
                val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return
                val wl = overlayKeepAliveWakeLock ?: pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "MagicTune:OverlayKeepAliveLock"
                ).apply {
                    setReferenceCounted(false)
                    overlayKeepAliveWakeLock = this
                }
                if (!wl.isHeld) {
                    wl.acquire(60_000L) // Tối đa 60s cho phiên thu âm trực tiếp, tự nhả khi tắt màn hình
                }
            } else {
                overlayKeepAliveWakeLock?.let { wl ->
                    if (wl.isHeld) {
                        wl.release()
                    }
                }
            }
        } catch (_: Throwable) {}
    }

    private fun needsRealtimeTicker(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
        if (pm?.isInteractive == false) return false
        return com.example.core.widget.MagicLiveFloatingOverlay.isShowing ||
            com.example.core.widget.MagicLiveFloatingOverlay.isVoiceOrSpeechActive() ||
            com.example.core.widget.GoogleLiveTranslateOverlay.isRunning ||
            com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive ||
            com.example.core.widget.CircleToSearchWindowOverlay.isShowing ||
            com.example.core.service.NoAccessibilityScreenEngine.isLiveScrollTranslateActive ||
            (MagicTuneCtsAccessibilityService.isServiceConnected() && MagicTuneCtsAccessibilityService.isAnyFeatureActive())
    }

    private fun startRealtimeWidgetTicker() {
        loopHandler.removeCallbacks(realtimeTickerRunnable)
        if (needsRealtimeTicker()) loopHandler.postDelayed(realtimeTickerRunnable, 1_200L)
    }

    private fun registerScreenStateListener() {
        if (screenStateReceiver == null) {
            screenStateReceiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    when (intent?.action) {
                        Intent.ACTION_SCREEN_ON -> {
                            com.example.core.shell.ShellEngine.getInstanceIfCreated()?.onScreenStateChanged(true)
                            com.example.core.ai.AiPowerAutopilotManager.onScreenOn(applicationContext)
                            startRealtimeWidgetTicker()
                            com.example.core.widget.MagicTuneAppSearchWidgetProvider.refreshAllWidgets(applicationContext)
                            if (MagicTuneCtsAccessibilityService.isServiceEnabledInSettings(applicationContext)) {
                                serviceScope.launch {
                                    MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(applicationContext)
                                }
                            }
                        }
                        Intent.ACTION_USER_PRESENT -> {
                            com.example.core.widget.MagicTuneAppSearchWidgetProvider.refreshAllWidgets(applicationContext)
                            if (SystemFloatingHudOverlay.isNavBridgeConfiguredActive(applicationContext)) {
                                SystemFloatingHudOverlay.syncNavBarBridge(applicationContext)
                                SystemFloatingHudOverlay.onDeviceUnlockedByUser(applicationContext)
                            }
                            if (MagicTuneCtsAccessibilityService.isServiceEnabledInSettings(applicationContext)) {
                                serviceScope.launch {
                                    MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(applicationContext)
                                }
                            }
                        }
                        Intent.ACTION_SCREEN_OFF -> {
                            lastObservedFgPkgForTicker = null
                            isCurrentlyInBanking = false
                            // Screen-reading and voice features must release animated surfaces,
                            // capture sessions, microphone access, and speech work on lock.
                            try { com.example.core.widget.GoogleLiveTranslateOverlay.stop(applicationContext) } catch (_: Throwable) {}
                            try { com.example.core.widget.CircleToSearchWindowOverlay.dismiss(applicationContext) } catch (_: Throwable) {}
                            try { com.example.core.widget.MagicLiveFloatingOverlay.onDeviceScreenOff(applicationContext) } catch (_: Throwable) {}
                            com.example.core.shell.ShellEngine.getInstanceIfCreated()?.onScreenStateChanged(false)
                            com.example.core.projection.MediaProjectionHolder.pauseSurfaceIfIdle()
                            if (MagicTuneCtsAccessibilityService.isServiceEnabledInSettings(applicationContext)) {
                                serviceScope.launch {
                                    MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(applicationContext)
                                }
                            }
                            SystemFloatingHudOverlay.stopUnlockVoiceWakeListener()
                            syncOverlayKeepAliveWakeLock(false)
                            loopHandler.removeCallbacks(realtimeTickerRunnable)
                            // AI Autopilot 10x: chỉ chạy khi người dùng bật, 0% vòng lặp, tự hủy ngay nếu mở sáng màn hình lại
                            com.example.core.ai.AiPowerAutopilotManager.onScreenOff(applicationContext)
                            if (!needsToRun(applicationContext)) {
                                isExplicitStopRequested = true
                                MagicTuneKeepAliveJobService.cancelAll(applicationContext)
                                stopSelf()
                                return
                            }
                        }
                    }
                }
            }
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            try {
                androidx.core.content.ContextCompat.registerReceiver(
                    this,
                    screenStateReceiver,
                    filter,
                    androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
                )
            } catch (_: Throwable) {
                try {
                    registerReceiver(screenStateReceiver, filter)
                } catch (_: Throwable) {}
            }
        }
    }

    private fun updateAllHomeWidgetsRealtime(forceHeavyWidgets: Boolean = false) {
        try {
            val appWidgetManager = AppWidgetManager.getInstance(this)

            val batComp = ComponentName(this, MagicTuneBatteryWidgetProvider::class.java)
            val batIds = appWidgetManager.getAppWidgetIds(batComp)
            for (id in batIds) {
                MagicTuneBatteryWidgetProvider.updateWidget(this, appWidgetManager, id)
            }
            com.example.core.widget.MagicTuneSimpleBatteryWidgetProvider.notifyAllWidgets(this)

            // Chỉ cập nhật Widget RAM tối đa 5 phút/lần khi sáng màn (tránh spam IPC launcher mỗi phút)
            val nowElapsed = SystemClock.elapsedRealtime()
            if (forceHeavyWidgets || (nowElapsed - lastMemoryWidgetPushMs) >= 300_000L) {
                lastMemoryWidgetPushMs = nowElapsed
                val memComp = ComponentName(this, MagicTuneMemoryWidgetProvider::class.java)
                val memIds = appWidgetManager.getAppWidgetIds(memComp)
                for (id in memIds) {
                    MagicTuneMemoryWidgetProvider.updateWidget(this, appWidgetManager, id)
                }
            }

            // KHÔNG đẩy lại 10 icon Bitmap của Widget Tìm kiếm App theo nhịp pin (Widget Tìm kiếm tự cập nhật khi mở app / cài đặt)!

            // Chỉ cập nhật widget Lịch Vạn Niên khi sang ngày dương mới để tiết kiệm pin tối đa
            val todayKey = java.util.Calendar.getInstance().let {
                (it.get(java.util.Calendar.YEAR) * 1000) + it.get(java.util.Calendar.DAY_OF_YEAR)
            }
            if (todayKey != lastPerpetualCalendarDayKey) {
                lastPerpetualCalendarDayKey = todayKey
                val pcComp = ComponentName(this, com.example.core.widget.MagicTunePerpetualCalendarWidgetProvider::class.java)
                val pcIds = appWidgetManager.getAppWidgetIds(pcComp)
                for (id in pcIds) {
                    com.example.core.widget.MagicTunePerpetualCalendarWidgetProvider.updateWidget(this, appWidgetManager, id)
                }
            }
        } catch (_: Exception) {}
    }

    @Volatile
    private var lastPerpetualCalendarDayKey = -1

    @Volatile
    private var lastMemoryWidgetPushMs = 0L

    @Volatile
    private var lastWidgetPushBatteryPct = -1

    @Volatile
    private var lastWidgetPushTempTenths = -1

    @Volatile
    private var lastWidgetPushCharging: Boolean? = null

    @Volatile
    private var lastWidgetPushElapsedMs = 0L

    @Volatile
    private var lastBatteryBroadcastProcessMs = 0L

    @Volatile
    private var lastObservedBatteryPct = -1

    @Volatile
    private var lastObservedPowerConnected: Boolean? = null

    @Volatile
    private var lastForegroundNotifSignature: String = ""

    private fun registerLiveBatteryListener() {
        if (liveBatteryReceiver == null) {
            liveBatteryReceiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    val action = intent?.action.orEmpty()
                    if (action == android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED ||
                        action == android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED ||
                        action == com.example.core.widget.MagicTuneSimpleBatteryWidgetProvider.ACTION_BT_BATTERY_LEVEL_CHANGED
                    ) {
                        com.example.core.widget.MagicTuneSimpleBatteryWidgetProvider.recordBluetoothBroadcast(applicationContext, intent)
                        val pmBt = getSystemService(Context.POWER_SERVICE) as? PowerManager
                        if (pmBt?.isInteractive != false) {
                            serviceScope.launch {
                                com.example.core.widget.MagicTuneSimpleBatteryWidgetProvider.notifyAllWidgets(applicationContext)
                            }
                        }
                        return
                    }
                    val now = SystemClock.elapsedRealtime()
                    val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                    val isPowerEvent = action == Intent.ACTION_POWER_CONNECTED || action == Intent.ACTION_POWER_DISCONNECTED
                    val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
                    val tempC = if (tempTenths > 0) tempTenths / 10.0f else 0f
                    val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
                    val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
                    val isChargingNow = plugged > 0 ||
                        status == BatteryManager.BATTERY_STATUS_CHARGING ||
                        status == BatteryManager.BATTERY_STATUS_FULL
                    val chargingNotifEnabled = isChargingNotificationEnabled(this@MagicTuneKeepAliveService)

                    val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
                    val isScreenOn = pm?.isInteractive ?: true
                    val isLowOrSaveBroadcast = action == Intent.ACTION_BATTERY_LOW ||
                        action == PowerManager.ACTION_POWER_SAVE_MODE_CHANGED
                    // A charger-notification toggle waits for cable events, but unplugged battery
                    // broadcasts while the screen is off do not need to wake the service work.
                    if (!isScreenOn && !isPowerEvent && !isLowOrSaveBroadcast &&
                        !(chargingNotifEnabled && isChargingNow)
                    ) {
                        return
                    }

                    // Nếu người dùng đang trực tiếp cuộn trang trong MainActivity, bỏ qua đợt broadcast định kỳ để không chiếm Binder/CPU
                    if (!isPowerEvent && !isLowOrSaveBroadcast &&
                        com.example.core.perf.MagicTuneSelfPowerGovernor.isUserActivelyInteractingInApp()
                    ) {
                        return
                    }

                    // Chống spam broadcast & đọc sysfs liên tục: tối thiểu 15s khi đang sạc, 60s khi không sạc (trừ lúc vừa cắm/rút sạc hoặc pin yếu)
                    val minBroadcastThrottleMs = if (isChargingNow) 15_000L else 60_000L
                    if (!isPowerEvent && !isLowOrSaveBroadcast && (now - lastBatteryBroadcastProcessMs < minBroadcastThrottleMs)) {
                        return
                    }
                    lastBatteryBroadcastProcessMs = now
                    val wasAbove20 = lastObservedBatteryPct > 20 || lastObservedBatteryPct == -1
                    if (level >= 0) {
                        lastObservedBatteryPct = level
                    }

                    val isLowBatteryOrPowerSave = isLowOrSaveBroadcast ||
                        (level in 0..20 && wasAbove20)
                    if (isLowBatteryOrPowerSave && !com.example.core.widget.MagicTuneBatteryWidgetProvider.isMagicLiveOrScrollTranslateRunning()) {
                        serviceScope.launch {
                            com.example.core.service.MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(applicationContext)
                        }
                    }

                    // Ghi nhận mẫu tụt pin thực tế & chạy lá chắn AI Autopilot (Pin <=20% / Nóng >38.5°C, đã throttle 60s)
                    if (level >= 0 &&
                        com.example.core.ai.AiPowerAutopilotManager.getConfig(applicationContext).lowBatterySurvivalEnabled
                    ) {
                        com.example.core.ai.AiPowerAutopilotManager.onBatteryStateSampled(
                            context = applicationContext,
                            batteryPct = level,
                            isCharging = isChargingNow,
                            tempC = tempC.toDouble(),
                            isScreenOn = isScreenOn
                        )
                    }

                    // Do not redraw every 15-second charging broadcast when the displayed data is unchanged.
                    // Charging watts still refresh at most once per minute; unplugged widgets use a 5-minute heartbeat.
                    val widgetHeartbeatMs = if (isChargingNow) 60_000L else 300_000L
                    val batteryChangedVisibly = isPowerEvent ||
                        lastWidgetPushCharging != isChargingNow ||
                        (level >= 0 && level != lastWidgetPushBatteryPct) ||
                        (tempTenths > 0 && kotlin.math.abs(tempTenths - lastWidgetPushTempTenths) >= 5) ||
                        (now - lastWidgetPushElapsedMs >= widgetHeartbeatMs)

                    val shouldUpdateWidgets = isScreenOn && batteryChangedVisibly && hasAnyHomeWidgets(this@MagicTuneKeepAliveService)
                    val shouldUpdateCharging = isPowerEvent || (chargingNotifEnabled && isChargingNow)
                    if (shouldUpdateWidgets || shouldUpdateCharging) {
                        if (shouldUpdateWidgets) {
                            lastWidgetPushBatteryPct = level
                            lastWidgetPushTempTenths = tempTenths
                            lastWidgetPushCharging = isChargingNow
                            lastWidgetPushElapsedMs = now
                        }
                        serviceScope.launch {
                            if (shouldUpdateWidgets) updateAllHomeWidgetsRealtime()
                            if (shouldUpdateCharging) checkChargingNotification()
                        }
                    }

                }
            }
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_BATTERY_CHANGED)
                addAction(Intent.ACTION_POWER_CONNECTED)
                addAction(Intent.ACTION_POWER_DISCONNECTED)
                addAction(Intent.ACTION_BATTERY_LOW)
                addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
                addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED)
                addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED)
                addAction(com.example.core.widget.MagicTuneSimpleBatteryWidgetProvider.ACTION_BT_BATTERY_LEVEL_CHANGED)
            }
            try {
                androidx.core.content.ContextCompat.registerReceiver(
                    this,
                    liveBatteryReceiver,
                    filter,
                    androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
                )
            } catch (_: Throwable) {
                try {
                    registerReceiver(liveBatteryReceiver, filter)
                } catch (_: Throwable) {}
            }
        }
    }

    private fun checkChargingNotification() {
        try {
            val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val data = BatteryInfoReader.read(this, batteryIntent)
            val manager = getSystemService(NotificationManager::class.java) ?: return

            val isChargingNotifEnabled = isChargingNotificationEnabled(this)
            val isSearchNotifEnabled = isSearchNotificationEnabled(this)

            if (data.isCharging) {
                if (data.batteryPct >= 100) {
                    if (data.isFullySaturated) {
                        // ĐÃ SẠC NGÂM BÃO HÒA ĐỦ 15 PHÚT: Pin đã thực sự no 100% hóa học!
                        if (!wasFullyChargedNotified) {
                            wasFullyChargedNotified = true
                            val fullNotif = buildFullyChargedNotification(data.phoneDisplayName)
                            manager.notify(NOTIF_ID_CHARGED_ALERT, fullNotif)
                        }
                    } else {
                        // ĐANG TRONG 15 PHÚT SẠC NGÂM BÙ ION: Tuyệt đối chưa ngắt sạc và chưa giục rút sạc
                        wasFullyChargedNotified = false
                    }
                } else {
                    wasFullyChargedNotified = false
                }
            } else {
                wasFullyChargedNotified = false
                if (lastObservedPowerConnected == true) {
                    manager.cancel(NOTIF_ID_CHARGED_ALERT)
                    restoreNormalChargingSettings(applicationContext)
                }
            }
            lastObservedPowerConnected = data.isCharging

            val isMicActiveNow = com.example.core.widget.MagicLiveFloatingOverlay.isVoiceOrSpeechActive()
            val notifSignature = when {
                isSearchNotifEnabled -> "SEARCH_PINNED"
                isChargingNotifEnabled && data.isCharging -> "CHARGING_${data.batteryPct}_${data.currentWatts.toInt()}_sat_${data.isFullySaturated}"
                isMicActiveNow -> "MIC_ACTIVE"
                else -> "HIDDEN"
            }

            // Chỉ cập nhật khi trạng thái thông báo thực sự thay đổi để tránh spam IPC lên Main Thread!
            if (notifSignature == lastForegroundNotifSignature) {
                return
            }
            lastForegroundNotifSignature = notifSignature

            if (notifSignature == "HIDDEN") {
                loopHandler.post {
                    demoteForegroundAndHideNotification()
                }
                return
            }

            val activeNotif = when {
                isSearchNotifEnabled -> buildPinnedSearchNotification()
                isChargingNotifEnabled && data.isCharging -> {
                    val contentText = when {
                        data.batteryPct >= 100 && !data.isFullySaturated -> {
                            if (data.saturationRemainingMinutes > 0) {
                                String.format(
                                    Locale.US,
                                    "⚡ Pin 100%% • Đang nạp bù ion (~còn %dp • %.1fW) • Chờ dòng về ≤ 1W",
                                    data.saturationRemainingMinutes,
                                    data.currentWatts
                                )
                            } else {
                                String.format(
                                    Locale.US,
                                    "⚡ Pin 100%% • Dòng vào còn %.1fW • Tiếp tục sạc cho đầy thực sự (sẽ ngắt khi về ≤ 1W)",
                                    data.currentWatts
                                )
                            }
                        }
                        data.batteryPct >= 100 && data.isFullySaturated -> {
                            String.format(
                                Locale.US,
                                "✅ Đã sạc đầy 100%% thực tế (Dòng sạc đã về ≤ 1W • %.1fW) • Đã ngắt dòng an toàn",
                                data.currentWatts
                            )
                        }
                        else -> {
                            String.format(
                                Locale.US,
                                "%s • Pin %d%% • Dự kiến đầy sau: ~%dp (%.1fW)",
                                data.speedTitle,
                                data.batteryPct,
                                data.minutesToFull,
                                data.currentWatts
                            )
                        }
                    }
                    buildChargingLockscreenNotification(contentText)
                }
                else -> buildSilentNotification()
            }
            loopHandler.post {
                if (startForegroundSafely(activeNotif, requestMicType = isMicActiveNow)) {
                    isForegroundActive = true
                }
            }
        } catch (_: Throwable) {}
    }

    private fun isDeviceChargingQuick(): Boolean {
        return try {
            val battIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val status = battIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        } catch (_: Throwable) {
            false
        }
    }

    @Suppress("DEPRECATION")
    private fun demoteForegroundAndHideNotification() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                stopForeground(true)
            }
        } catch (_: Throwable) {}
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm?.cancel(NOTIFICATION_ID)
        } catch (_: Throwable) {}
        isForegroundActive = false
        lastForegroundNotifSignature = "HIDDEN"
    }

    private fun startForegroundSafely(notif: Notification, requestMicType: Boolean = false): Boolean {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val hasMicPerm = androidx.core.content.ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.RECORD_AUDIO
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                val serviceType = if (requestMicType && hasMicPerm) {
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                } else {
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                }
                return try {
                    startForeground(NOTIFICATION_ID, notif, serviceType)
                    true
                } catch (_: Throwable) {
                    try {
                        startForeground(
                            NOTIFICATION_ID,
                            notif,
                            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                        )
                        true
                    } catch (_: Throwable) {
                        false
                    }
                }
            } else {
                startForeground(NOTIFICATION_ID, notif)
                return true
            }
        } catch (_: Throwable) {
            return try {
                startForeground(NOTIFICATION_ID, notif)
                true
            } catch (_: Throwable) {
                false
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (com.example.core.crash.CrashBlackBox.isFirestoreOomRecoveryRequired(applicationContext)) {
            isServiceRunning = false
            stopSelf(startId)
            return START_NOT_STICKY
        }
        isServiceRunning = true
        val statusText = intent?.getStringExtra(EXTRA_STATUS_TEXT).orEmpty()
        val startedAsForeground = intent?.getBooleanExtra(EXTRA_STARTED_AS_FOREGROUND, false) == true
        val wantMic = statusText.contains("Magic Live", ignoreCase = true) ||
            statusText.contains("Magic Active", ignoreCase = true) ||
            statusText.contains("Microphone", ignoreCase = true) ||
            com.example.core.widget.MagicLiveFloatingOverlay.isVoiceOrSpeechActive()
        val wantSearchNotif = isSearchNotificationEnabled(this)
        val wantChargingNotif = isChargingNotificationEnabled(this) && isDeviceChargingQuick()
        val needsVisibleForeground = wantMic || wantSearchNotif || wantChargingNotif

        if (needsVisibleForeground) {
            val activeNotif = try {
                when {
                    wantSearchNotif -> buildPinnedSearchNotification()
                    wantChargingNotif -> {
                        val batt = BatteryInfoReader.read(this)
                        buildChargingLockscreenNotification(
                            String.format(Locale.US, "%s • Pin %d%% (%.1fW)", batt.speedTitle, batt.batteryPct, batt.currentWatts)
                        )
                    }
                    else -> buildSilentNotification()
                }
            } catch (_: Throwable) {
                buildSilentNotification()
            }
            val started = startForegroundSafely(activeNotif, requestMicType = wantMic)
            if (started) {
                isForegroundActive = true
                lastForegroundNotifSignature = when {
                    wantSearchNotif -> "SEARCH_PINNED"
                    wantChargingNotif -> "CHARGING_INIT"
                    else -> "MIC_ACTIVE"
                }
            } else if (startedAsForeground && !isForegroundActive) {
                isServiceRunning = false
                try { stopSelf() } catch (_: Throwable) {}
                return START_NOT_STICKY
            }
        } else if (startedAsForeground) {
            // Hệ điều hành ép khởi chạy qua startForegroundService từ nền: đáp ứng hợp đồng 5s rồi lập tức gỡ thông báo để không làm phiền người dùng
            val started = startForegroundSafely(buildSilentNotification(), requestMicType = false)
            if (started) {
                isForegroundActive = true
                loopHandler.postDelayed({
                    if (!isSearchNotificationEnabled(applicationContext) &&
                        !(isChargingNotificationEnabled(applicationContext) && isDeviceChargingQuick()) &&
                        !com.example.core.widget.MagicLiveFloatingOverlay.isVoiceOrSpeechActive()
                    ) {
                        demoteForegroundAndHideNotification()
                    }
                }, 150L)
            } else {
                isServiceRunning = false
                try { stopSelf() } catch (_: Throwable) {}
                return START_NOT_STICKY
            }
        } else {
            // Chạy nền âm thầm hoàn toàn — KHÔNG hiển thị bất kỳ thông báo "app đang chạy ngầm" nào
            if (isForegroundActive) {
                demoteForegroundAndHideNotification()
            }
        }
        syncOverlayKeepAliveWakeLock(
            com.example.core.widget.MagicLiveFloatingOverlay.isVoiceOrSpeechActive()
        )
        // Do not let Android silently resurrect a background polling service after process death.
        return START_NOT_STICKY
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
    }

    override fun onLowMemory() {
        super.onLowMemory()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            // Xóa kênh cũ vốn hiển thị công khai trên màn hình khóa & thanh trạng thái
            try {
                manager?.deleteNotificationChannel(LEGACY_CHANNEL_ID)
            } catch (_: Throwable) {}

            // Kênh ẩn hoàn toàn (IMPORTANCE_MIN + VISIBILITY_SECRET: không hiện icon thanh trạng thái, không hiện màn hình khóa, không âm thanh/rung)
            val silentChannel = NotificationChannel(
                CHANNEL_ID,
                "MagicTune Hệ Thống Tĩnh",
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = "Kênh dự phòng ẩn hoàn toàn cho phiên giọng nói ngắn"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
                enableVibration(false)
                enableLights(false)
                setSound(null, null)
            }
            manager?.createNotificationChannel(silentChannel)

            // Channel Ghim Tìm Kiếm Trên Cùng & Màn Hình Khóa (IMPORTANCE_HIGH, Ongoing, Silent)
            val searchChannel = NotificationChannel(
                CHANNEL_SEARCH_ID,
                "MagicTune Thanh Tìm Kiếm Cố Định",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Ghim thanh tìm kiếm ứng dụng lên đầu thanh điều hướng và màn hình khóa"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                enableVibration(false)
                enableLights(false)
                setSound(null, null)
            }
            manager?.createNotificationChannel(searchChannel)

            // Channel cảnh báo khi đầy pin (Âm thanh + Rung + Nổi màn hình khóa nếu người dùng cần)
            val fullAlertChannel = NotificationChannel(
                CHANNEL_ALERT_ID,
                "MagicTune Cảnh Báo Pin Đầy",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Báo chuông và rung thông báo khi điện thoại sạc đạt 100%"
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                enableVibration(true)
            }
            manager?.createNotificationChannel(fullAlertChannel)
        }
    }

    /**
     * Thanh tìm kiếm ứng dụng & Gọi Trợ lý Magic ghim cố định ở vị trí trên cùng của Thanh thông báo & Màn hình khóa
     */
    private fun buildPinnedSearchNotification(): Notification {
        val searchIntent = Intent(this, AppSearchActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val searchPendingIntent = PendingIntent.getActivity(
            this,
            5001,
            searchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val manageAppsIntent = Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val appsPendingIntent = PendingIntent.getActivity(
            this,
            5002,
            manageAppsIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val magic_liveLockscreenIntent = Intent(this, com.example.core.widget.MagicLiveLockscreenActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val magic_livePendingIntent = PendingIntent.getActivity(
            this,
            5003,
            magic_liveLockscreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val customViews = try {
            RemoteViews(packageName, R.layout.notification_app_search).apply {
                setOnClickPendingIntent(R.id.notif_search_bar, searchPendingIntent)
                setOnClickPendingIntent(R.id.notif_search_root, searchPendingIntent)
                setOnClickPendingIntent(R.id.notif_btn_magic_live, magic_livePendingIntent)
                setOnClickPendingIntent(R.id.notif_btn_apps, appsPendingIntent)
            }
        } catch (_: Throwable) { null }

        val publicNotif = NotificationCompat.Builder(this, CHANNEL_SEARCH_ID)
            .setSmallIcon(R.drawable.ic_stat_magictune)
            .setContentTitle("🔍 Tìm Kiếm Nhanh & 🎙️ Magic Live AI")
            .setContentText("Chạm để mở tìm kiếm ứng dụng hoặc gọi Trợ lý Magic Live")
            .setContentIntent(searchPendingIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()

        val builder = NotificationCompat.Builder(this, CHANNEL_SEARCH_ID)
            .setSmallIcon(R.drawable.ic_stat_magictune)
            .setContentTitle("🔍 Tìm kiếm App & 🎙️ Gọi MAGIC LIVE")
            .setContentText("Chạm 🎙️ Magic Live trên màn hình khóa để mở khóa khuôn mặt & trò chuyện AI...")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MAX) // Ưu tiên cao nhất để ghim trên cùng
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC) // Hiển thị đầy đủ trên màn hình khóa
            .setPublicVersion(publicNotif)
            .setOnlyAlertOnce(true)
            .setSilent(true) // Hoàn toàn không phát âm thanh làm phiền
            .setContentIntent(searchPendingIntent)

        if (customViews != null) {
            builder.setCustomContentView(customViews)
            builder.setCustomBigContentView(customViews)
            builder.setStyle(NotificationCompat.DecoratedCustomViewStyle())
        } else {
            builder.addAction(
                android.R.drawable.ic_btn_speak_now,
                "🎙️ Gọi MAGIC LIVE",
                magic_livePendingIntent
            )
        }

        return builder.build()
    }

    /**
     * Thông báo dự phòng tối giản mức MIN + SECRET (chỉ dùng trong vài trăm ms nếu Android bắt buộc FGS hoặc khi thu âm AI Live),
     * tuyệt đối không hiện trên màn hình khóa, không hiện icon thanh trạng thái và không báo "app đang chạy ngầm".
     */
    private fun buildSilentNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("MagicTune")
            .setContentText("")
            .setSmallIcon(R.drawable.ic_stat_magictune)
            .setOngoing(false)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_DEFERRED)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setShowWhen(false)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun buildChargingLockscreenNotification(contentText: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val publicNotif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("⚡ Giám Sát Sạc Pin Thời Gian Thực")
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_stat_magictune)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(pendingIntent)
            .build()

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("⚡ Giám Sát Sạc Pin Thời Gian Thực")
            .setContentText(contentText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(contentText))
            .setSmallIcon(R.drawable.ic_stat_magictune)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPublicVersion(publicNotif)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun restoreNormalChargingSettings(context: Context) {
        serviceScope.launch(Dispatchers.IO) {
            try {
                com.example.data.MagicTuneRepository.restoreNormalChargingAfterCutOff(context)
            } catch (_: Throwable) {}
        }
    }

    private fun buildFullyChargedNotification(phoneName: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            1,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ALERT_ID)
            .setContentTitle("🔋 $phoneName Đã Sạc Đầy 100%!")
            .setContentText("Android báo pin đã sạc đầy. MagicTune không tự ngắt mạch sạc; hãy rút sạc khi thuận tiện.")
            .setSmallIcon(R.drawable.ic_stat_magictune)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        try {
            // A pinned notification is an explicit user choice; all other in-session overlays
            // are closed when the app task is dismissed so they cannot become orphaned surfaces.
            val hasExplicitBackgroundNotification = isSearchNotificationEnabled(applicationContext) ||
                (isChargingNotificationEnabled(applicationContext) && isDeviceChargingQuick())
            if (hasExplicitBackgroundNotification) return
            try { com.example.core.widget.GoogleLiveTranslateOverlay.stop(applicationContext) } catch (_: Throwable) {}
            try { com.example.core.widget.CircleToSearchWindowOverlay.dismiss(applicationContext) } catch (_: Throwable) {}
            try { com.example.core.widget.MagicLiveFloatingOverlay.onDeviceScreenOff(applicationContext) } catch (_: Throwable) {}
            isExplicitStopRequested = true
            MagicTuneKeepAliveJobService.cancelAll(applicationContext)
            stopSelf()
        } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        isServiceRunning = false
        instanceRef = null
        isForegroundActive = false
        loopHandler.removeCallbacks(realtimeTickerRunnable)
        syncOverlayKeepAliveWakeLock(false)
        try {
            serviceScope.coroutineContext[kotlinx.coroutines.Job]?.cancel()
        } catch (_: Exception) {}
        try {
            screenStateReceiver?.let { unregisterReceiver(it) }
            screenStateReceiver = null
        } catch (_: Exception) {}
        try {
            liveBatteryReceiver?.let { unregisterReceiver(it) }
            liveBatteryReceiver = null
        } catch (_: Exception) {}

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        @Volatile
        var instanceRef: java.lang.ref.WeakReference<MagicTuneKeepAliveService>? = null

        private const val LEGACY_CHANNEL_ID = "magictune_keepalive_channel_silent"
        private const val CHANNEL_ID = "magictune_keepalive_stealth_min_v3"
        private const val CHANNEL_SEARCH_ID = "magictune_pinned_search_channel"
        private const val CHANNEL_ALERT_ID = "magictune_battery_alert_channel"
        private const val NOTIFICATION_ID = 20001
        private const val NOTIF_ID_CHARGED_ALERT = 20002
        private const val PREFS_NAME = "magictune_charging_prefs"
        private const val KEY_CHARGING_NOTIF_ENABLED = "charging_notification_enabled"
        private const val KEY_SEARCH_NOTIF_ENABLED = "search_notification_pinned_enabled"
        private const val KEY_AUTO_COOLING_ENABLED = "auto_cooling_enabled_v37"
        private const val NOTIF_ID_COOLING_ALERT = 20003
        private const val EXTRA_STARTED_AS_FOREGROUND = "extra_started_as_foreground"
        const val ACTION_REVIVE_KEEPALIVE = "com.example.core.service.ACTION_REVIVE_KEEPALIVE"

        @Volatile
        private var isExplicitStopRequested = false

        @Volatile
        var isServiceRunning = false
            private set

        @Volatile
        private var isForegroundActive = false

        fun isAutoCoolingEnabled(context: Context): Boolean {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            return prefs.getBoolean(KEY_AUTO_COOLING_ENABLED, false)
        }

        fun setAutoCoolingEnabled(context: Context, enabled: Boolean) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_AUTO_COOLING_ENABLED, enabled)
                .apply()
        }
        const val EXTRA_STATUS_TEXT = "extra_status_text"

        fun isChargingNotificationEnabled(context: Context): Boolean {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            return prefs.getBoolean(KEY_CHARGING_NOTIF_ENABLED, false)
        }

        fun setChargingNotificationEnabled(context: Context, enabled: Boolean) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_CHARGING_NOTIF_ENABLED, enabled)
                .apply()
        }

        fun isSearchNotificationEnabled(context: Context): Boolean {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            return prefs.getBoolean(KEY_SEARCH_NOTIF_ENABLED, false) // Mặc định TẮT để không gửi thông báo chạy ngầm làm phiền người dùng
        }

        fun setSearchNotificationEnabled(context: Context, enabled: Boolean) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_SEARCH_NOTIF_ENABLED, enabled)
                .apply()
        }

        private fun isAppInForeground(): Boolean {
            return try {
                val info = android.app.ActivityManager.RunningAppProcessInfo()
                android.app.ActivityManager.getMyMemoryState(info)
                info.importance <= android.app.ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE
            } catch (_: Throwable) {
                false
            }
        }

        fun scheduleAutoReviveAlarm(context: Context) {
            // Đã tắt Alarm đánh thức CPU sau 1.5 giây để tránh tụt pin chờ & ngăn vòng lặp hồi sinh cưỡng bức
        }

        /**
         * Bật Ticker chỉ trong phiên Overlay/đọc màn hình do người dùng mở.
         */
        fun wakeTickerImmediately(context: Context) {
            try {
                val appCtx = context.applicationContext ?: context
                val svc = instanceRef?.get()
                if (svc != null) {
                    svc.startRealtimeWidgetTicker()
                } else if (needsToRun(appCtx)) {
                    startOrUpdate(appCtx, forceFromBootOrOverlay = true)
                }
            } catch (_: Throwable) {}
        }

        fun isDeviceChargingQuick(context: Context): Boolean {
            return try {
                val appCtx = context.applicationContext ?: context
                val battIntent = appCtx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val plugged = battIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
                val status = battIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
                plugged > 0 || status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            } catch (_: Throwable) {
                false
            }
        }

        fun needsToRun(context: Context): Boolean {
            val appCtx = context.applicationContext ?: context
            return isSearchNotificationEnabled(appCtx) ||
                (isChargingNotificationEnabled(appCtx) && isDeviceChargingQuick(appCtx)) ||
                com.example.core.ai.AiPowerAutopilotManager.isAnyAutopilotEnabled(appCtx) ||
                com.example.core.widget.MagicLiveFloatingOverlay.isShowing ||
                com.example.core.widget.GoogleLiveTranslateOverlay.isRunning ||
                com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive ||
                com.example.core.widget.CircleToSearchWindowOverlay.isShowing ||
                com.example.core.service.NoAccessibilityScreenEngine.isLiveScrollTranslateActive
        }

        fun syncServiceNeed(
            context: Context,
            statusText: String = "Đang duy trì tiện ích MagicTune"
        ) {
            val appCtx = context.applicationContext ?: context
            if (needsToRun(appCtx)) {
                MagicTuneKeepAliveJobService.ensureScheduled(appCtx)
                startOrUpdate(appCtx, statusText, forceFromBootOrOverlay = true)
            } else {
                MagicTuneKeepAliveJobService.cancelAll(appCtx)
                stop(appCtx)
            }
        }

        fun startOrUpdate(
            context: Context,
            statusText: String = "Đang duy trì Khoanh tròn hỏi AI & Bảng Vẽ Mở App 24/7",
            forceFromBootOrOverlay: Boolean = false
        ) {
            try {
                isExplicitStopRequested = false
                val appCtx = context.applicationContext ?: context
                val inForeground = isAppInForeground()
                val hasOverlayExemption = try { Settings.canDrawOverlays(appCtx) } catch (_: Throwable) { false }
                if (!forceFromBootOrOverlay && !inForeground && !hasOverlayExemption) return

                if (!needsToRun(appCtx)) {
                    stop(appCtx)
                    return
                }

                val wantMic = statusText.contains("Magic Live", true) ||
                    statusText.contains("Magic Active", true) ||
                    statusText.contains("Microphone", true) ||
                    com.example.core.widget.MagicLiveFloatingOverlay.isVoiceOrSpeechActive()
                val needsVisibleForeground = wantMic ||
                    isSearchNotificationEnabled(appCtx) ||
                    isChargingNotificationEnabled(appCtx)
                val isNotifToggleSync = statusText.contains("Notif", true) ||
                    statusText.contains("Search", true) ||
                    statusText.contains("Chế độ", true)

                // Nếu dịch vụ đã đang chạy đúng trạng thái (ẩn hoặc hiện) và không có lệnh đổi trạng thái thông báo/Mic thì không spam startService
                if (isServiceRunning && (isForegroundActive == needsVisibleForeground) && !wantMic && !isNotifToggleSync) {
                    instanceRef?.get()?.startRealtimeWidgetTicker()
                    return
                }

                val intent = Intent(appCtx, MagicTuneKeepAliveService::class.java).apply {
                    putExtra(EXTRA_STATUS_TEXT, statusText)
                    putExtra(EXTRA_STARTED_AS_FOREGROUND, false)
                }
                val canStartFg = inForeground || forceFromBootOrOverlay || hasOverlayExemption
                if (!needsVisibleForeground) {
                    // Ưu tiên khởi chạy nền ẩn hoàn toàn (ZERO notification). Chỉ fallback FGS nếu hệ điều hành chặn khởi động từ nền, rồi tự gỡ thông báo sau 150ms.
                    try {
                        appCtx.startService(intent)
                    } catch (_: Throwable) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && canStartFg) {
                            try {
                                intent.putExtra(EXTRA_STARTED_AS_FOREGROUND, true)
                                androidx.core.content.ContextCompat.startForegroundService(appCtx, intent)
                            } catch (_: Throwable) {}
                        }
                    }
                } else {
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && canStartFg) {
                            intent.putExtra(EXTRA_STARTED_AS_FOREGROUND, true)
                            androidx.core.content.ContextCompat.startForegroundService(appCtx, intent)
                        } else {
                            appCtx.startService(intent)
                        }
                    } catch (_: Throwable) {
                        try {
                            intent.putExtra(EXTRA_STARTED_AS_FOREGROUND, false)
                            appCtx.startService(intent)
                        } catch (_: Throwable) {}
                    }
                }
            } catch (_: Throwable) {}
        }

        fun ensureMicrophoneForeground(context: Context) {
            try {
                isExplicitStopRequested = false
                val appCtx = context.applicationContext ?: context
                val inForeground = isAppInForeground()
                val intent = Intent(appCtx, MagicTuneKeepAliveService::class.java).apply {
                    putExtra(EXTRA_STATUS_TEXT, "Microphone Assistant Active")
                    putExtra(EXTRA_STARTED_AS_FOREGROUND, false)
                }
                try {
                    appCtx.startService(intent)
                } catch (_: Throwable) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && inForeground) {
                        try {
                            intent.putExtra(EXTRA_STARTED_AS_FOREGROUND, true)
                            androidx.core.content.ContextCompat.startForegroundService(appCtx, intent)
                        } catch (_: Throwable) {}
                    }
                }
            } catch (_: Throwable) {}
        }

        fun stop(context: Context) {
            try {
                isExplicitStopRequested = true
                isServiceRunning = false
                isForegroundActive = false
                context.stopService(Intent(context, MagicTuneKeepAliveService::class.java))
            } catch (_: Throwable) {}
        }
    }
}
