package com.example.core.assistant

import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import com.example.core.service.SystemFloatingHudOverlay
import com.example.core.widget.MagicLiveFloatingOverlay
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Dịch vụ Trợ Lý Giọng Nói Hệ Thống (VoiceInteractionService) chuẩn Android.
 * Biến MagicTune thành ỨNG DỤNG TRỢ LÝ ẢO MẶC ĐỊNH (Default Assistant App) cho điện thoại Honor MagicOS:
 * 1. Xuất hiện chính thức trong Cài đặt Honor -> Ứng dụng mặc định -> Ứng dụng hỗ trợ & đầu vào giọng nói.
 * 2. Đón nhận toàn bộ cử chỉ hệ thống: Nhấn giữ nút nguồn, vuốt từ góc dưới màn hình, nhấn giữ phím Home.
 * 3. Hỗ trợ chụp ảnh màn hình ngầm (`onHandleScreenshot`) và đọc cấu trúc giao diện (`AssistStructure`)
 *    mà KHÔNG CẦN QUYỀN TRỢ NĂNG (Accessibility), đảm bảo tương thích 100% với MB Bank, VNeID và mọi ứng dụng Ngân hàng!
 */
class MagicTuneVoiceInteractionService : VoiceInteractionService() {

    override fun onReady() {
        super.onReady()
        instance = this
        // Trợ lý ảo hệ thống hoạt động on-demand theo sự kiện bấm giữ nguồn/Home của Android.
        // Tuyệt đối không tự động kích hoạt Service chạy ngầm liên tục khi nhàn rỗi để bảo đảm tiêu thụ 0%.
        SystemFloatingHudOverlay.syncNavBarBridge(applicationContext)
    }

    override fun onShutdown() {
        if (instance === this) {
            instance = null
        }
        super.onShutdown()
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_SILENT_CAPTURE = "magictune_extra_silent_capture"

        @Volatile
        var isSilentCaptureInProgress: Boolean = false

        @Volatile
        var instance: MagicTuneVoiceInteractionService? = null
            private set

        @Volatile
        var pendingScreenshotDeferred: CompletableDeferred<Bitmap?>? = null

        @Volatile
        var pendingStructureDeferred: CompletableDeferred<Boolean>? = null

        @Volatile
        var lastCapturedAssistBitmap: Bitmap? = null
        @Volatile
        var lastCapturedAssistTimeMs: Long = 0L

        fun releaseCapturedAssistBitmap() {
            val bmp = lastCapturedAssistBitmap
            lastCapturedAssistBitmap = null
            lastCapturedAssistTimeMs = 0L
            if (bmp != null && !bmp.isRecycled) {
                try { bmp.recycle() } catch (_: Throwable) {}
            }
        }

        fun isDefaultAssistant(context: Context): Boolean {
            return instance != null && com.example.core.permission.AppPermissionChecker.isAssistantPermissionGranted(context)
        }

        /**
         * Yêu cầu phiên Trợ lý Kỹ thuật số chụp màn hình & trích xuất cấu trúc giao diện (`AssistStructure`)
         * ngầm trong ~50ms mà KHÔNG mở hộp thoại Voice, thay thế hoàn toàn AccessibilityService!
         * Khi người dùng CHƯA cấp quyền Trợ lý Kỹ thuật số (instance == null), hàm thoát ngay trong 0ms
         * mà không gọi startService hay chờ đợi gây giật lag điện thoại.
         */
        suspend fun requestSilentCaptureViaAssist(
            context: Context,
            needScreenshot: Boolean = true,
            timeoutMs: Long = 900L
        ): Bitmap? {
            val svc = instance ?: return null
            if (!com.example.core.permission.AppPermissionChecker.isAssistantPermissionGranted(context)) {
                return null
            }

            com.example.core.service.MagicTuneCtsAccessibilityService.ensureAssistSettingsEnabledIfNeeded(context)

            val shotDef = CompletableDeferred<Bitmap?>()
            val structDef = CompletableDeferred<Boolean>()
            pendingScreenshotDeferred = shotDef
            pendingStructureDeferred = structDef
            isSilentCaptureInProgress = true

            return try {
                val args = Bundle().apply {
                    putBoolean(EXTRA_SILENT_CAPTURE, true)
                }
                val flags = if (needScreenshot) {
                    VoiceInteractionSession.SHOW_WITH_ASSIST or VoiceInteractionSession.SHOW_WITH_SCREENSHOT
                } else {
                    VoiceInteractionSession.SHOW_WITH_ASSIST
                }
                svc.showSession(args, flags)

                if (needScreenshot) {
                    withTimeoutOrNull(timeoutMs) {
                        shotDef.await()
                    }
                } else {
                    withTimeoutOrNull(timeoutMs) {
                        structDef.await()
                    }
                    null
                }
            } catch (_: Throwable) {
                null
            } finally {
                isSilentCaptureInProgress = false
                if (pendingScreenshotDeferred === shotDef) pendingScreenshotDeferred = null
                if (pendingStructureDeferred === structDef) pendingStructureDeferred = null
            }
        }
    }
}
